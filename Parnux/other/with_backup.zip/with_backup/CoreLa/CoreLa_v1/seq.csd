

<CsoundSynthesizer>
<CsOptions>
-m128 	;-dm0 -n -+rtmidi=null -M0
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

massign	0,0


giRythArr  []   fillarray .5,.5,2,1,.5,1,2,1,.5
giRythArrP []   fillarray .5,.5,2,1,.5,1,2,1,.5
giRythArrB []   fillarray .5,.5,2,1,.5,1,2,1,.5
giPlusArr  []   fillarray -1.5,-1,-0.5, 0.5, 1, 1.5
giSumArr        sumarray giRythArr

giNoteArr  []   init 7 ;fillarray 75, 80, 68, 70
giAccArr   []   fillarray 2, 0, 1, 1, 0, 0, 1, 0
giNoteArrP []   init 7	
giLength        init lenarray:i(giNoteArr)
giEmptyArr []   init giLength	

	
giTalaCount  init 0
giPlusCount  init 0
giChngIndx   init 0
giElement    init 0

giActive     init 0
giCountMIDI  init 0



;;indian
opcode ArrTala, i[], i[]
 iInArr[] xin
 giTalaCount = (giTalaCount+1)% lenarray(iInArr)
 iRead = 0
 iWrite = giTalaCount
 while iRead <lenarray(iInArr) do
 	giRythArrP [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% lenarray(iInArr)
 od
 printarray giRythArrP,"%.2f", "ArrTala ="
 xout giRythArrP
endop
opcode ArrRep, i[], i[]
 iInArr[] xin
 giRythArrP[] = iInArr
 giRythArrP[giTalaCount+1] = iInArr[giTalaCount]
 giTalaCount = (giTalaCount+1)% (lenarray(iInArr)-1)
 xout giRythArrP
endop
opcode ArrPlus, i[],i[]
 iInArr[] xin
  giPlusCount = (giPlusCount+1)% lenarray(giPlusArr)
 if giPlusCount == 0  then
    giTalaCount = (giTalaCount+1)% (lenarray(iInArr))
 endif
 giRythArrP[] = iInArr
  giRythArrP[giTalaCount] = iInArr[giTalaCount] + giPlusArr[giPlusCount]
  giRythArrP[giTalaCount] = ( giRythArrP[giTalaCount] < 0.5 ) ?
  giRythArr[giTalaCount] :  giRythArrP[giTalaCount]
  printarray giRythArrP,"%.02f", "ArrPlus ="
 xout giRythArrP
endop
opcode ArrPlusR, i[], i[]
 iInArr[] xin
 if giTalaCount == giChngIndx then
  iElm random 0, lenarray(iInArr)
  iAdd random -2,2 
  iAdd = (iAdd == 0) ? 1 : iAdd
  giRythArrP[iElm] =  iInArr[iElm]+iAdd
  giRythArrP[iElm] = ( giRythArrP[iElm] < 1 ) ?
    giRythArr[iElm] :  giRythArrP[iElm]
  giChngIndx = (giChngIndx+1)% 3
  printarray giRythArrP,"%.02f", "ArrPlusR ="   
  giTalaCount = 0
 endif
 giTalaCount = (giTalaCount+1)% lenarray(iInArr)
 xout giRythArrP
endop
opcode ArrPlusJ, i[], i[]
 iInArr[] xin
 if giTalaCount == giChngIndx then
  giRythArrP[giElement] =  iInArr[giElement]+ giPlusArr[giPlusCount]
  giRythArrP[giElement] = ( giRythArrP[giElement] < 1 ) ?
    giRythArr[giElement] :  giRythArrP[giElement]
  giChngIndx = (giChngIndx+1)% 3
  giChngIndx = (giChngIndx=0) ? 1: giChngIndx 
  giTalaCount = 0
  giElement = (giElement+1)%lenarray(iInArr)
  giPlusCount =(giPlusCount+1) % lenarray(giPlusArr)
  printarray giRythArrP,"%.02f", "ArrPlusJ =" 
 endif
 giTalaCount = (giTalaCount+1)% lenarray(iInArr)
 xout giRythArrP
endop



instr widgets
;;tempo
 kBPM chnget "BPM"
 kdvn chnget "DV" 
 
  gkTempoChnge  ctrl7    5,30,0,1
 if gkTempoChnge == 1 && changed(gkTempoChnge) == 1 then
 chnset "colour(50, 200, 253)", "tmpchID"
  ktmpchng random 3,5
 elseif  gkTempoChnge == 0 then
 chnset "colour(100, 100, 110)", "tmpchID"
   ktmpchng = 1
 endif
  gkTempo = (kBPM/60)*kdvn*ktmpchng


 
 
 ;;sequencer
 kSq chnget "sq1"
 if kSq == 1 && changed(kSq) == 1 then
  schedulek "TIAB_seq", 0, 999
 elseif kSq == 0 && changed(kSq) == 1 then
  turnoff2 "TIAB_seq1", 0, 0
 endif 
 
 ;;rythm
 gkTala chnget "tala"


	
;;out widgets
 kSqCC    ctrl7    5,20,0,1
 kHoldCC    ctrl7    5,21,0,1
 if changed(kSqCC) == 1 then
 chnset kSqCC,    "sq"
 endif
 if changed(kHoldCC) == 1 then
 chnset kHoldCC,    "hold"
 endif
 
 
endin

instr MIDI_Play
 kHold = 1
 kstatus, kchan, kNote, kVel  midiin
 ktrig changed kchan, kNote, kVel
 kCount init 0
 if ktrig == 1 && kVel != 0 then
 kCount = ((kCount+1) > giLength) ? giLength : kCount+1
 elseif ktrig == 1 && kVel == 0 then
  kCount = (kCount-1 < 0) ? 0 : kCount-1
 endif
 
 if kVel != 0 && ktrig == 1 && kCount == 1 then
  schedulek "NoteRmv",  0, 0, kNote
 endif
 
 	if     kVel != 0 && ktrig == 1 && kchan == 1 && kCount != 1 then	;channel 1 to sequence 1
  	 schedulek "NoteOn_sq1",  0, 0, kNote
 	elseif kVel == 0 && ktrig == 1 && kchan == 1 && kHold == 0 then
  	 schedulek "NoteOff_sq1", 0, 0, kNote
 	elseif kVel != 0 && ktrig == 1 && kchan == 2 && kCount != 1 then ;channel 2 to sequence 2
  	 schedulek "NoteOn_sq2",  0, 0, kNote
 	elseif kVel == 0 && ktrig == 1 && kchan == 2 && kHold == 0 then
  	 schedulek "NoteOff_sq2", 0, 0, kNote
 	endif
endin

instr NoteOn_sq1
 giCountMIDI = (giCountMIDI+1 >= giLength) ? giLength : giCountMIDI+1
 iNote = p4
 iRead = giCountMIDI 
 if giCountMIDI == 0 then
  giNoteArr [] = giEmptyArr
 endif
 while iRead < giLength do
  giNoteArr [iRead] = giEmptyArr[iRead]
  iRead += 1
 od	
 giNoteArr [giCountMIDI-1] = iNote	
 printarray giNoteArr, "%.0f", "Notes On ="
endin
instr NoteOff_sq1
 giCountMIDI = (giCountMIDI-1 < 0) ? 0 : giCountMIDI-1
 iRead  = 0
 iWrite = 0
 iNote  = p4
 while iRead < giLength do
   if giNoteArr[iRead] != iNote then		
     giNoteArr [iWrite] = giNoteArr [iRead]						
     iWrite += 1											
   endif		
 iRead +=1
 od
 iRead2 = giCountMIDI
  while iRead2 < giLength do
  giNoteArr [iRead2] = giEmptyArr[iRead2]
  iRead2 += 1
 od	
 printarray giNoteArr, "%.0f", "Notes Off ="
endin




instr NoteOn_sq2
 giCountMIDI = (giCountMIDI+1 >= giLength) ? giLength : giCountMIDI+1
 iNote = p4
 iRead = 0 
 iWrite = 0
 giNoteIndx = 0
 while iWrite < giCountMIDI do								
	if giNoteArr[iWrite] == 0 then
		giNoteArr[giNoteIndx] = iNote
	else
		giNoteIndx +=1
	endif
 iWrite += 1
 od	
 printarray giNoteArr, "%.0f", "Notes On ="
endin
instr NoteOff_sq2
 giCountMIDI = (giCountMIDI-1 < 0) ? 0 : giCountMIDI-1
 iRead = 0
 iNote = p4
 while iRead < giLength do
	if giNoteArr[iRead] = iNote then	
	 giNoteArr [iRead] = 0				
	endif
 iRead +=1
 od
  	if giNoteIndx == giLength then
		giNoteArr[giLength-1] = iNote
	endif	
 printarray giNoteArr, "%.0f", "Notes Off ="
endin
instr NoteRmv
giCountMIDI = 1
giNoteArr [] = giEmptyArr
giNoteArr [giCountMIDI-1] = p4
printarray giNoteArr, "%.0f", "Notes On ="
endin



;;short sequencer 1
instr TIAB_seq1 
;to infinity and beyond
kTala = gkTala
kRythArrIndx init 0
kNoteArrIndx init 0
kAccArrIndx  init 0
kTime init 0

if metro:k(kTime) == 1 then
kTime = 1/(giRythArrP[kRythArrIndx])*gkTempo
  if giNoteArrP[kNoteArrIndx] != 0 then
   ;schedulek "ShortTrigger",0,0,kdb+(giAccArr[kAccArrIndx]),
  endif
kRythArrIndx = (kRythArrIndx+1) % lenarray(giRythArrP)
kNoteArrIndx = (kNoteArrIndx+1) % (giCountMIDI)
kAccArrIndx  = (kAccArrIndx+1)  % lenarray(giAccArr)
	if kRythArrIndx == 0 then
	schedulek "TalaTrig",0,0,kTala
	endif
	
			schedulek "Seq1On",0,0
			schedulek "Seq1Off",0.1,0
			
 
endif

  if changed(gkTempoChnge) == 1 then
  endif

endin

;;triger instrument
instr TalaTrig
iTala = p4
if iTala == 1 then
giRythArrP [] = giRythArr
elseif iTala == 2 then
giRythArrP [] ArrTala giRythArr
elseif iTala == 3 then
giRythArrP [] ArrRep giRythArr
elseif iTala == 4 then
giRythArrP [] ArrPlus giRythArr
elseif iTala == 5 then
giRythArrP [] ArrPlusR giRythArr
elseif iTala == 6 then
giRythArrP [] ArrPlusJ giRythArr
endif
;printarray giRythArr,"%.02f", "org ="
;printarray giRythArrP,"%.02f", "note ="
endin




instr SeqOn
chnset "colour(208, 200, 253)", "SeqLID"
endin
instr SeqOff
chnset "colour(100, 100, 110)", "SeqLID"
endin
instr MIDIOn
chnset "colour(208, 200, 253)", "MIDILID"
endin
instr MIDIOff
chnset "colour(100, 100, 110)", "MIDILID"
endin

</CsInstruments>
<CsScore>
i "MIDI_Play" 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>604</x>
 <y>683</y>
 <width>400</width>
 <height>300</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
