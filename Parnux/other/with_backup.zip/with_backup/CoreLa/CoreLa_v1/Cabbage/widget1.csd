<Cabbage>
form caption("CoreLa") size(600, 300), pluginId("crla") guiMode("queue"), style("legacy")  colour:0(20, 30, 82, 255)

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>
ksmps = 32
nchnls = 2
0dbfs = 1


instr WidtArrW
    iRyArr [] fillarray 1, .5,.5, 1, 2, 1, 2,2, .5,.5, 1, 2, 1, 3
    iAcArr [] fillarray 1,0,1,0,0,0,1,1,0,0,1,1,1,0
    iBsArr [] fillarray 1,1,0,0,0,1,1,0,0,1,1,0,1,0
    iWidget = 0
    
    while iWidget < 14 do
        ; create bank of nslider using cabbageCreate opcode 
        SRyArr sprintf "nslider bounds(%d, %d, 40, 28), channel(\"ryarr%d\"), velocity(50), range(0.5, 4, %d, 1, 0.01) colour(10, 10, 10, 200) fontColour(200, 200, 250, 250)", iWidget%14*40+25, 30, iWidget+1, iRyArr[iWidget]
        cabbageCreate SRyArr
        SsqArr sprintf "checkbox bounds(%d, %d, 10, 10), channel(\"sqarr%d\"), range(0, 1, %d, 1, 0.01) colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", iWidget%14*40+40, 60, iWidget+1,0
        cabbageCreate SsqArr
        SAccArr sprintf "checkbox bounds(%d, %d, 10, 10), channel(\"acarr%d\"), range(0, 1, %d, 1, 0.01) colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", iWidget%14*40+40, 80, iWidget+1, iAcArr[iWidget]
        cabbageCreate SAccArr
        SBsArr sprintf "checkbox bounds(%d, %d, 10, 10), channel(\"bsarr%d\"), range(0, 1, %d, 1, 0.01) colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", iWidget%14*40+40, 100, iWidget+1, iBsArr[iWidget]
        cabbageCreate SBsArr
        iWidget += 1
    od

endin

instr WidtArrR

 S1 sprintfk "sqarr%d",2
 chnset 1, S1
 
 
    iRead = 0
    iSteps[] init 14
    
    while iRead < 14 do 
       iSteps[iRead] cabbageGetValue sprintfk("ryarr%d", iRead+1)
       iRead += 1
    od
    printarray iSteps,"%.1f", "Steps ="
endin







instr h
 iWidget = 0
 while iWidget < 14 do
   S1 sprintfk "pos(%d, %d)", iWidget%14*40+25, 90
   S2 sprintfk "check_ident%d", iWidget+1
   S3 sprintfk "pos(%d, %d)", iWidget%14*40+40, 125
   S4 sprintfk "sq_ident%d", iWidget+1
   S5 sprintfk "pos(%d, %d)", iWidget%14*40+40, 145
   S6 sprintfk "ac_ident%d", iWidget+1
   chnset S1, S2
   chnset S3, S4
   chnset S5, S6
   iWidget += 1
 od

 iRyArr [] fillarray 1, .5,.5, 1, 2, 1, 2,2, .5,.5, 1, 2, 1, 3
 iAcArr [] fillarray 1,0,1,0,0,0,1,1,0,0,1,1,1,0
 iWrite = 0
 while iWrite < 14 do
   S2 sprintfk "check%d", iWrite+1
   chnset iRyArr[iWrite], S2
   S6 sprintfk "ac%d", iWrite+1
   chnset iAcArr[iWrite], S6
   iWrite += 1
 od 

endin

instr hh
ktrigarr chnget "check%d"
 iRead = 0
 iSteps[] init 14
 iAcArr[] init 14
 while iRead < 14 do 
   iSteps[iRead] chnget sprintfk("check%d", iRead+1)
   iAcArr[iRead] chnget sprintfk("ac%d", iRead+1)
   iRead += 1
 od
 printarray iSteps,"%.1f", "Steps ="
    giRythArr [] = iSteps
	giRythArrP [] = iSteps	
	giAccArr [] = iAcArr
endin

</CsInstruments>
<CsScore>
i "WidtArrW"  0 z
i "WidtArrR"  0 z
</CsScore>
</CsoundSynthesizer>

