<Cabbage>
form size(300, 290), caption("1"), pluginid("WdAr")
;checkbox bounds(-100, -100, 25, 25), text("Push"), widgetarray("check", 20), value(0)

nslider bounds(-100, -100, 35, 25) velocity(50) range(0, 4, 0, 1, 0.5) colour(75, 51, 51, 255)fontcolour(195, 18, 18, 255) widgetarray("check", 7) channel("check7") ;identchannel("check_ident7")


</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-n -d -+rtmidi=NULL -M0 -m0d --midi-key=4
</CsOptions>
<CsInstruments>
;sr is set by the host
ksmps = 32
nchnls = 2
0dbfs=1
  
  
  seed 0
instr 1
 iWidget = 0
 while iWidget < 7 do
   S1 sprintfk "pos(%d, %d)", iWidget%10*40+10, 130
   S2 sprintfk "check_ident%d", iWidget+1
   chnset S1, S2
   iWidget += 1
 od

 iRyArr [] fillarray 1, .5,.5, 1, 2, 1, 2
 iWrite = 0
 while iWrite < 7 do
   S2 sprintfk "check%d", iWrite+1
   chnset iRyArr[iWrite], S2
   iWrite += 1
 od 

 iRead = 0
 iSteps[] init 7
 while iRead < 7 do 
   iSteps[iRead] chnget sprintfk("check%d", iRead+1)
   iRead += 1
 od
 printarray iSteps,"%.1f", "Steps ="
		
endin



</CsInstruments>  
<CsScore> 
i1 0 z

</CsScore>
</CsoundSynthesizer> 