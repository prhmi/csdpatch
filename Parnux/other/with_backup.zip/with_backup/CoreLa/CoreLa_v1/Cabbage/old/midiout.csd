<Cabbage>
form size(300, 290), caption("1"), pluginid("WdAr")

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-n -d -+rtmidi=NULL -M0 -m0d --midi-key=4
</CsOptions>
<CsInstruments>
;sr is set by the host
ksmps = 32
nchnls = 2
0dbfs=1
  
massign	0,0

instr 1
kstatus, kchan, kNote, kVel midiin
kTrig changed kchan, kNote, kVel
if kTrig == 1 then
schedulek 2, 0, 1, kNote, kVel
endif
endin


instr 2
inum = p4
ivel = p5
midion 1, inum, ivel
endin

</CsInstruments>  
<CsScore> 
i1 0 z
</CsScore>
</CsoundSynthesizer> 
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>100</x>
 <y>100</y>
 <width>320</width>
 <height>240</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
