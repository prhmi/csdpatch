<Cabbage>
form caption("CoreLa") size(600, 300), pluginId("crla") guiMode("queue"), style("legacy")  colour:0(20, 30, 82, 255)

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>
ksmps = 32
nchnls = 2
0dbfs = 1


instr WidtArrW
    iRyArr [] fillarray 1, .5,.5, 1, 2, 1, 2,2, .5,.5, 1, 2, 1, 3
    iAcArr [] fillarray 1,0,1,0,0,0,1,1,0,0,1,1,1,0
    iBsArr [] fillarray 1,1,0,0,0,1,1,0,0,1,1,0,1,0
    iWidget = 0
    
    while iWidget < 14 do
        ; create bank of nslider using cabbageCreate opcode 
        SRyArr sprintf "nslider bounds(%d, %d, 40, 28), channel(\"ryarr%d\"), velocity(50), range(0.5, 4, %d, 1, 0.01) colour(10, 10, 10, 200) fontColour(200, 200, 250, 250)", iWidget%14*40+25, 30, iWidget+1, iRyArr[iWidget]
        cabbageCreate SRyArr
        SsqArr sprintf "checkbox bounds(%d, %d, 10, 10), channel(\"sqarr%d\"), range(0, 1, %d, 1, 0.01) colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", iWidget%14*40+40, 60, iWidget+1,0
        cabbageCreate SsqArr
        SAccArr sprintf "checkbox bounds(%d, %d, 10, 10), channel(\"acarr%d\"), range(0, 1, %d, 1, 0.01) colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", iWidget%14*40+40, 80, iWidget+1, iAcArr[iWidget]
        cabbageCreate SAccArr
        SBsArr sprintf "checkbox bounds(%d, %d, 10, 10), channel(\"bsarr%d\"), range(0, 1, %d, 1, 0.01) colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", iWidget%14*40+40, 100, iWidget+1, iBsArr[iWidget]
        cabbageCreate SBsArr
        iWidget += 1
    od

endin

instr WidtArrR

 S1 sprintfk "sqarr%d",2
 chnset 1, S1
 
 
    iRead = 0
    iRy [] init 14
    iAc [] init 14
    iB  [] init 14
    
    while iRead < 14 do 
       iRy[iRead] cabbageGetValue sprintfk("ryarr%d", iRead+1)
       iRead += 1
    od
    printarray iRy,"%.1f", "Steps ="
endin




</CsInstruments>
<CsScore>
i "WidtArrW"  0 z
i "WidtArrR"  0 z
</CsScore>
</CsoundSynthesizer>

