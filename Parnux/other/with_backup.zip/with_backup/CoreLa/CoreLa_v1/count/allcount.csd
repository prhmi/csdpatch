<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0 

instr 1
kCount = 7
kndx init 0
kndx3 init 0
kmod = 3


if metro(2) == 1 then
 kndx = (kndx+1) % (kCount)
 kndx2 = (kndx*-1)+(kCount-1)
  if kndx3 == 0 then
   kupdn = 1
  elseif kndx3 == kCount-1 then
   kupdn = -1
  endif 
 kndx3 = kndx3 + kupdn
 kndx4 = int(random:k( 0, kCount))
endif
if kmod == 1 then ;count up
 kndxout = kndx
elseif kmod == 2 then ;count down
 kndxout = kndx2
elseif kmod == 3 then ;count up and down
 kndxout = kndx3
elseif kmod == 4 then
 kndxout = kndx4
endif
printk2 kndxout
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
