
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 48000
ksmps = 32
nchnls = 2
0dbfs = 1

seed 0
massign	0,0

giRythArr [] fillarray 1,1,.5,2
giNoteArr  []   init 7 ;fillarray 75, 80, 68, 70
giLength        init lenarray:i(giNoteArr)
giEmptyArr []   init giLength	


giActive     init 0
giCountMIDI  init 0

 gkCount init 0


instr midi
 kstatus, kchn, kNote, kVel  midiin
 ktrig changed kchn, kNote, kVel

 if ktrig == 1 && kVel != 0 then
 gkCount = ((gkCount+1) > giLength) ? giLength : gkCount+1
 elseif ktrig == 1 && kVel == 0 then
  gkCount = (gkCount-1 < 0) ? 0 : gkCount-1
 endif
gktrig changed kNote

 ;kchan chnget "sqmod"
 kHold  = 0 ;chnget "hold"

 if kVel != 0 && ktrig == 1 && gkCount == 1 then
 schedulek "NoteRmv",  0, 0, kNote
 endif
 if kHold == 0 && changed(kHold) == 1 then
schedulek "NoteRmv",  0, 0, 0
 endif
 
 	if     kVel != 0 && ktrig == 1 && gkCount != 1 then
  	 schedulek "NoteOn_sq1",  0, 0, kNote
 	elseif kVel == 0 && ktrig == 1 && kHold == 0 then
  	 schedulek "NoteOff_sq1", 0, 0, kNote
 	endif

endin



instr NoteOn_sq1
 giCountMIDI = (giCountMIDI+1 >= giLength) ? giLength : giCountMIDI+1
 iNote = p4
 iRead = giCountMIDI 
 if giCountMIDI == 0 then
  giNoteArr [] = giEmptyArr
 endif
 while iRead < giLength do
  giNoteArr [iRead] = giEmptyArr[iRead]
  iRead += 1
 od	
 giNoteArr [giCountMIDI-1] = iNote	
 ;printarray giNoteArr, "%.0f", "Notes On ="
endin
instr NoteOff_sq1
 giCountMIDI = (giCountMIDI-1 < 0) ? 0 : giCountMIDI-1
 iRead  = 0
 iWrite = 0
 iNote  = p4
 while iRead < giLength do
   if giNoteArr[iRead] != iNote then		
     giNoteArr [iWrite] = giNoteArr [iRead]						
     iWrite += 1											
   endif		
 iRead +=1
 od
 iRead2 = giCountMIDI
  while iRead2 < giLength do
  giNoteArr [iRead2] = giEmptyArr[iRead2]
  iRead2 += 1
 od	
 ;printarray giNoteArr, "%.0f", "Notes Off ="
endin




instr NoteRmv
giCountMIDI = 1
giNoteArr [] = giEmptyArr
giNoteArr [giCountMIDI-1] = p4
;printarray giNoteArr, "%.0f", "Notes On ="
endin



;;short sequencer 1
instr TIAB
;to infinity and beyond

kRythArrIndx init 0
kNoteArrIndx init 0
kAccArrIndx  init 0
kTime init 0
kDur = 1

if gktrig == 1 then
kNoteArrIndx = gkCount-1
endif
if metro:k(1) == 1 then
kTime = 1/(giRythArr[kRythArrIndx])*4
  if giNoteArr[kNoteArrIndx] != 0 then
   schedulek "Ding",0,kDur,giNoteArr[kNoteArrIndx]
  endif
printk2 kNoteArrIndx
kRythArrIndx = (kRythArrIndx+1) % lenarray(giRythArr)
kNoteArrIndx = (kNoteArrIndx+1) % (giCountMIDI)

			
endif

endin



instr Ding
 iFreq    = p4
 iAmp     = 0.3
iAtt= 0.01
iRel = 1
 aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -4, 0
 aSine poscil aEnv, mtof(iFreq)
out aSine,aSine
endin




</CsInstruments>
<CsScore>
i "midi" 0 999
i "TIAB" 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
