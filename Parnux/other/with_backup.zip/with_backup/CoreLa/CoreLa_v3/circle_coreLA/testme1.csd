<Cabbage>
form caption("CircleCoreLa") size(1280, 720), colour(34, 34, 34), guiMode("queue"), pluginId("ccrl")

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

ksmps = 32
nchnls = 2
0dbfs = 1

opcode circle, ii,iiiii
    iX, iY, iRadius, iBeat, iPoints xin
    iSlice = ($M_PI*2)/(iPoints)
    iAngle = iSlice*iBeat
    iXPoint = iX + iRadius * cos(iAngle)
    iYPoint = iY + iRadius * sin(iAngle)
    xout iXPoint, iYPoint
endop

instr 1
iCircleX = 200
iCircleY = 200
iCircleWide = 120
iVoice = 1
iPoints init 15
iCnt init 0
  while iCnt < 16 do
        iXPoint, iYPoint circle iCircleX, iCircleY, iCircleWide, iCnt, iPoints
        SChannel sprintf "voice%dCircle%d", iVoice, iCnt
        SCircleString = sprintf("bounds(%d, %d, 20, 21), shape(\"circle\"), channel(\"%s\")", iXPoint, iYPoint, SChannel)
        cabbageCreate "image", SCircleString
        iCnt += 1
    od
endin

</CsInstruments>
<CsScore>
i1 0 1
</CsScore>
</CsoundSynthesizer>
