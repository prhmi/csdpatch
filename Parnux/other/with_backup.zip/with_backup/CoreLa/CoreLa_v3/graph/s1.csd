<Cabbage>
form caption("Quads") size(800, 500), colour(0, 0, 0),  guiMode("queue") pluginId("def1")
;image bounds(50, 50, 15, 15), shape("square")
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-n -d -+rtmidi=NULL -M0 -m0d 
</CsOptions>
<CsInstruments>
; Initialize the global variables. 
ksmps = 32
nchnls = 2
0dbfs = 1

instr 1
iCrt init 0
iPosX init 100
iRote init 0
  while iCrt < 23 do
        Sshape  sprintf "bounds(%d, 250, 200, 5),  shape(\"square\"),\
         corners(10),channel(\"shapes%d\"),rotate(%d,%d,0)",iPosX, iCrt ,iRote,0
        cabbageCreate "image", Sshape
        iCrt += 1
        iPosX += 20
        iRote += 2
    od
;Smessage sprintfk "rotate(%f,%d,%d)",
endin

</CsInstruments>
<CsScore>
i1 0 1
</CsScore>
</CsoundSynthesizer>
