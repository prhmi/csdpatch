<Cabbage>
form caption("Quads") size(800, 500), colour(0, 0, 0),  guiMode("queue") pluginId("def1")
;image bounds(50, 50, 15, 15), shape("square")
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-n -d -+rtmidi=NULL -M0 -m0d 
</CsOptions>
<CsInstruments>
; Initialize the global variables. 
ksmps = 32
nchnls = 2
0dbfs = 1

opcode circle, kk,iikii
    iX, iY, kRadius, iBeat, iPoints xin
    iSlice = ($M_PI*2)/(iPoints)
    iAngle = iSlice*iBeat
    kXPoint = iX + kRadius * cos(iAngle)
    kYPoint = iY + kRadius * sin(iAngle)
    xout kXPoint, kYPoint
endop


instr Create
iCrt init 0
  while iCrt < 23 do
        Sshape  sprintf "bounds(10, 10, 5, 5),  shape(\"square\"),channel(\"shapes%d\"),visible(0)", iCrt
        cabbageCreate "image", Sshape
        iCrt += 1
    od
endin
schedule "Create",0, 0


instr Metro
if metro(1) == 1 then
    kindx = 0
    while kindx < 23 do
    schedulek "Graph", 0, 0.2,kindx
    schedulek "Fade", 0.1, 0.4,kindx
    kindx += 1
    od
endif
endin
schedule "Metro",0, 999

instr Graph
indx = p4
kCircleWide linseg 0, p3, 80
iSizeX random 10, 50
iPoints = 23
iCircleY = 200
iCircleX = 200
iRndRot random 1, 5
iG random 20, 80
iR random 20, 200
iB random 50, 250
iRotate = indx*iRndRot
kPosX, kPosY circle iCircleX, iCircleY, kCircleWide, indx, iPoints
Schnl sprintf "shapes%d", indx
Schng sprintfk "bounds(%d, %d, %d, 5), corners(10),visible(1),rotate(%d,0,0),alpha(1)\
colour(%d,%d,%d)",kPosX,kPosY,iSizeX,iRotate,iG,iR,iB
cabbageSet metro(50),Schnl, Schng
endin

instr Fade
indx = p4
kFade linseg 1, p3,-0.9
Schnl sprintf "shapes%d", indx
cabbageSet metro(50),Schnl, "alpha", kFade
endin
</CsInstruments>
<CsScore>
</CsScore>
</CsoundSynthesizer>
