<Cabbage>
form caption("CircleCoreLa") size(700, 400), colour(34, 34, 34), guiMode("queue"), pluginId("ccrl")
;image channel("image")
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

ksmps = 64
nchnls = 2
0dbfs = 1

instr 1


   
        
        ;SCircleString = sprintf("bounds(,100,50,51), shape(\"circle\"), channel(\"image\")",100)
        cabbageCreate "image", "bounds(100,100,50,51), shape(\"2\"), channel(\"image\")"
        
    kPointY = poscil:k(20, 17) + 150

               Sbounds sprintfk "bounds(100, %d, 50, 51)",kPointY
         cabbageSet metro(50),"image", Sbounds  
endin

</CsInstruments>
<CsScore>
i1 0 9999
</CsScore>
</CsoundSynthesizer>
