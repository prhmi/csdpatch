
<Cabbage>
form caption("CoreLa") size(800, 300)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")
;image bounds(0, 0, 250, 300) channel("img") file("CoreLa.jpg")
;;Sequencer

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

giArrStartX[] init 5

instr Create
iCrt init 0
iPosX init 50
iG init 50
    while iCrt < 5 do
      SSteps  sprintf "bounds(%d, 100, 30, 30), shape(\"sharp\"), channel(\"steps%d\"), visible(1),\
      colour(100,%d,200)",iPosX,iCrt,iG
      cabbageCreate "image", SSteps
      giArrStartX[iCrt] = iPosX
    iCrt += 1
    iPosX += 40
    iG += 50
    od
endin
schedule "Create",0,0





instr Metro
if metro(1) == 1 then
schedulek "MotionTrg", 0, 0.2
endif
endin

schedule "Metro",0,9999


instr MotionTrg
indx = 0
while indx < 5 do
schedule "Motion",0,1,indx
indx += 1
od
endin

instr Motion
indx = p4
if indx == 0 then
iStart = giArrStartX[indx]
kFade linseg 1, p3,-0.9
Schnl sprintf "steps%d", indx
cabbageSet metro(50),Schnl, "alpha", kFade
endif

if indx != 0 then
iStart = giArrStartX[indx]
iEnd = giArrStartX[indx]-50
kPointX linseg iStart, p3, iEnd
Schnl sprintf "steps%d", indx
SSteps  sprintfk "bounds(%d, 100, 30, 30), shape(\"sharp\"),visible(1)" ,kPointX
      cabbageSet metro(50),Schnl, SSteps
   giArrStartX[indx] = iEnd
endif

endin
</CsInstruments>
<CsScore>

</CsScore>
</CsoundSynthesizer>

