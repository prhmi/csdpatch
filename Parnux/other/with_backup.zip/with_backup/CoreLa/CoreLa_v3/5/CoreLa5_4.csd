
<Cabbage>
form caption("CoreLa") size(800, 300)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")
;image bounds(0, 0, 250, 300) channel("img") file("CoreLa.jpg")
;;Sequencer

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 ;	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1


opcode ArrTala, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr [] init iLen
 iRead = 0
 iWrite = iTalaCount
 while iRead < iLen do
 	iOutArr [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% (iLen)
 od
 xout iOutArr
endop


giArrStartX[] init 5
giArrSeqIn[]  fillarray 1,1,2,1,4
giArrSeq[]    fillarray 1,1,2,1,4

instr Create
iCrt init 0
    while iCrt < 5 do
      SSteps  sprintf "bounds(10, 10, 30, 30), shape(\"sharp\"), channel(\"steps%d\"),alpha(1), visible(%d)",iCrt,0
      cabbageCreate "image", SSteps
    iCrt += 1
    od
endin
schedule "Create",0,0

instr StepsChng
iCrt init 0
iPosX init 50
    while iCrt < 5 do
      iG = giArrSeq[iCrt]*50
      iSizeX = giArrSeq[iCrt]*30
      Schnl   sprintf "steps%d", iCrt
      SSteps  sprintf "bounds(%d, 100, %d, 30), shape(\"sharp\"), channel(\"steps%d\"),alpha(1), visible(1),\
      colour(120,%d,250)",iPosX,iSizeX,iCrt,iG
      cabbageSet Schnl, SSteps
      ;giArrStartX[iCrt] = iPosX
    iCrt += 1
    iPosX += 10+iSizeX
    od
endin
schedule "StepsChng",0,0


instr Tala
iTala = p4
giArrSeq[] ArrTala giArrSeqIn, iTala
schedule "StepsChngTala",0,0
;printarray giArrSeq, "%d"
endin

instr StepsChngTala
iCrt init 0
iPosX init 50
    while iCrt < 5 do
      iG = giArrSeq[iCrt]*50
      iSizeX = giArrSeq[iCrt]*30
      giArrStartX[iCrt] = iPosX
    iCrt += 1
    iPosX += 10+iSizeX
    od
endin
schedule "StepsChngTala",0,0



instr Metro
kTalaCount init 1
kTime init 0
kSeqIndx init 0
iBPM = 90/60
if metro(1/kTime) == 1 then
kTime = (giArrSeq[kSeqIndx]*iBPM)/7
if kSeqIndx != 4 then
schedulek "SeqMotion", 0, kTime/2, kSeqIndx
endif
;schedulek "Sound", 0, 0.3, 500
    if kSeqIndx == 4 && changed(kSeqIndx) == 1 then
    schedulek "SeqMotion", 0, kTime/2, kSeqIndx,2
schedulek "MotionTrg", 0, 0.2
schedulek "StepsChng",kTime,0
schedulek "Tala",0.1,0.1,kTalaCount
    kTalaCount = (kTalaCount+1) % (lenarray(giArrSeq))
    endif
    if kSeqIndx == 0 && changed(kSeqIndx) == 1 then
    ;schedulek "StepsChng",0.3,0
    ;
    endif
    ;
kSeqIndx = (kSeqIndx+1) % (lenarray(giArrSeq))
endif
endin

schedule "Metro",0,9999





instr MotionTrg
indx = 0
while indx < 5 do
schedule "StepMotion",0,0.2,indx
indx += 1
od
endin

instr StepMotion
kFade linseg 1, p3,-0.9
cabbageSet metro(50),"steps0", "alpha", kFade

indx = p4
if indx != 0 then
iStart = giArrStartX[indx]
iEnd = (giArrStartX[indx]-((giArrSeq[0]*30)+10))
kPointX linseg iStart, p3, iEnd-0.1

iSizeX = giArrSeq[indx]*30
Schnl   sprintf "steps%d", indx
SSteps  sprintfk "bounds(%d, 100, %d, 30), shape(\"sharp\"),visible(1)" ,kPointX,iSizeX
      cabbageSet metro(80),Schnl, SSteps
endif
endin

instr SeqMotion
iStepNumber = p4
iSizeX = giArrSeq[iStepNumber]*30
kSizeX linseg iSizeX-15, p3, iSizeX
iEndX = giArrStartX[iStepNumber]
kPointX linseg iEndX+5,p3,iEndX
Schnl   sprintf "steps%d", iStepNumber
SSteps  sprintfk "bounds(%d, 100, %d, 30), shape(\"sharp\"),visible(1)" ,kPointX,kSizeX
      cabbageSet metro(80),Schnl, SSteps
endin

instr Sound
aEnv linseg 0,0.01, 0.5, p3-0.01, 0
a1 poscil aEnv, p4
outs a1,a1
endin
</CsInstruments>
<CsScore>

</CsScore>
</CsoundSynthesizer>

