
<Cabbage>
form caption("CoreLa") size(500, 300)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")
;image bounds(0, 0, 250, 300) channel("img") file("CoreLa.jpg")
;;Sequencer

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1


opcode ArrTala, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr [] init iLen
 iRead = 0
 iWrite = iTalaCount
 while iRead < iLen do
 	iOutArr [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% (iLen)
 od
 xout iOutArr
endop


giArrStartX[] init 5
giArrSeqIn[]  fillarray 1,2,3,4,5
giArrSeq[] fillarray 1,2,3,4,5

instr Create
iCrt init 0
    while iCrt < 5 do
      SSteps  sprintf "bounds(10, 10, 30, 30), shape(\"sharp\"), channel(\"steps%d\"),alpha(1), visible(%d)",iCrt,0
      cabbageCreate "image", SSteps
    iCrt += 1
    od
endin
schedule "Create",0,0

instr StepsChng
iCrt init 0
iPosX init 50
    while iCrt < 5 do
      iG = giArrSeq[iCrt]*50
      Schnl   sprintf "steps%d", iCrt
      SSteps  sprintf "bounds(%d, 100, 30, 30), shape(\"sharp\"), channel(\"steps%d\"),alpha(1), visible(1),\
      colour(120,%d,250)",iPosX,iCrt,iG
      cabbageSet Schnl, SSteps
      giArrStartX[iCrt] = iPosX
    iCrt += 1
    iPosX += 40
    od
endin

schedule "StepsChng",0,0


instr Metro
kTalaCount init 0
if metro(1) == 1 then
schedulek "MotionTrg", 0, 0.2
schedulek "Tala",0.1,0.1,kTalaCount
kTalaCount = (kTalaCount+1) % lenarray(giArrSeq)
schedulek "StepsChng",0.4,0.3
endif
endin

schedule "Metro",0,9999


instr Tala
iTala = p4
giArrSeq[] ArrTala giArrSeqIn, iTala
;printarray giArrSeq, "%d"
endin


instr MotionTrg
indx = 0
while indx < 5 do
schedule "Motion",0,0.3,indx
indx += 1
od
endin

instr Motion
indx = p4
if indx == 0 then
iStart = giArrStartX[indx]
kFade linseg 1, p3,-0.9
Schnl sprintf "steps%d", indx
cabbageSet metro(50),Schnl, "alpha", kFade
endif

if indx != 0 then
iStart = giArrStartX[indx]
iEnd = giArrStartX[indx]-40
kPointX linseg iStart, p3, iEnd
Schnl sprintf "steps%d", indx
SSteps  sprintfk "bounds(%d, 100, 30, 30), shape(\"sharp\"),visible(1)" ,kPointX
      cabbageSet metro(50),Schnl, SSteps
   giArrStartX[indx] = iEnd
endif

endin
</CsInstruments>
<CsScore>

</CsScore>
</CsoundSynthesizer>

