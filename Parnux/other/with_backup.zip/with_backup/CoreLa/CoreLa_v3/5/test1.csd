
<Cabbage>
form caption("CoreLa") size(500, 300)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")
;image bounds(0, 0, 250, 300) channel("img") file("CoreLa.jpg")
;;Sequencer

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1


instr Create
      SSteps  sprintf "bounds(50, 100, 30, 30), shape(\"sharp\"), channel(\"steps\"), visible(%d)",1
      cabbageCreate "image", SSteps
endin
schedule "Create",0,0


giArrPosX[] fillarray 50,80
giPosXindx init 0



instr Metro
if metro(1) == 1 then
schedulek "Motion", 0, 0.2
endif
endin

schedule "Metro",0,9999

instr Motion
iStart = giArrPosX[0]
iEnd = giArrPosX[1]
kPointX linseg iStart, p3, iEnd
SSteps  sprintfk "bounds(%d, 120, 30, 30), shape(\"sharp\"),visible(1)" ,kPointX
      cabbageSet metro(50),"steps", SSteps
       giPosXindx = (giPosXindx+1) %2
       giArrPosX[0] = iStart+30
       giArrPosX[1] = iEnd+30
       
endin
</CsInstruments>
<CsScore>

</CsScore>
</CsoundSynthesizer>

