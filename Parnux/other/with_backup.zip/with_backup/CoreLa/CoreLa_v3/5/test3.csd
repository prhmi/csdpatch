
<Cabbage>
form caption("CoreLa") size(500, 300)  guiMode("queue")  colour(0,0,0)  pluginId("crla")

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1


instr 1
a1 poscil 0.3, 800
outs a1,a1    
endin
</CsInstruments>
<CsScore>
i1 0 3
</CsScore>
</CsoundSynthesizer>

