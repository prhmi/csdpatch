
<Cabbage>
form caption("CoreLa") size(800, 500)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")
;image bounds(0, 0, 250, 300) channel("img") file("CoreLa.jpg")
;;Sequencer

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 ;	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

opcode circle, kk,iikii
    iX, iY, kRadius, iBeat, iPoints xin
    iSlice = ($M_PI*2)/(iPoints)
    iAngle = iSlice*iBeat
    kXPoint = iX + kRadius * cos(iAngle)
    kYPoint = iY + kRadius * sin(iAngle)
    xout kXPoint, kYPoint
endop

opcode ArrTala, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr [] init iLen
 iRead = 0
 iWrite = iTalaCount
 while iRead < iLen do
 	iOutArr [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% (iLen)
 od
 xout iOutArr
endop

opcode RGB, iii,i
iNumber xin
      if iNumber == 1 then
      iRed = 120
      iGrn = 120
      iBlu = 250
      elseif iNumber == 2 then
      iRed = 100
      iGrn = 200
      iBlu = 100
      elseif iNumber == 3 then
      iRed = 100
      iGrn = 100
      iBlu = 200
      elseif iNumber == 4 then
      iRed = 200
      iGrn = 120
      iBlu = 250
      elseif iNumber == 5 then
      iRed = 100
      iGrn = 150
      iBlu = 150
      endif
xout iRed,iGrn,iBlu
endop

giArrSeqIn[]  fillarray 1,1,2,2,1,2,1,3,4
giArrSeq[]    fillarray 1,1,2,2,1,2,1,3,4
giLenSeq lenarray giArrSeq
giArrStartX[] init giLenSeq

giRepArr[] fillarray 1,4,6,8
giLenRep lenarray giRepArr

giBassArr[] fillarray 3,5,7
giLenBass lenarray giBassArr

giNoteArr[] fillarray 58, 78, 65, 60, 63, 64, 72

instr Create
iCrtStep init 0
    while iCrtStep < giLenSeq do
      SSteps  sprintf "bounds(10, 10, 30, 30), shape(\"sharp\"), channel(\"steps%d\"),alpha(1), visible(%d)",iCrtStep,0
      cabbageCreate "image", SSteps
    iCrtStep += 1
    od
iCrtRep init 0
    while iCrtRep < 4 do
      SRep  sprintf "bounds(10, 10, 20, 21), shape(\"circle\"), channel(\"Reps%d\"), visible(0)", iCrtRep
      cabbageCreate "image", SRep
      SRepG  sprintf "bounds(10, 10, 20, 21),corners(5), shape(\"square\"), channel(\"RepsG%d\"), visible(0)", iCrtRep
      cabbageCreate "image", SRepG
    iCrtRep += 1
    od
      SBassShape  sprintf "bounds(100,100, 20, 21), shape(\"circle\"), channel(\"BassShape\"), visible(%d)", 0
      cabbageCreate "image", SBassShape
iCrtGraph init 0
  while iCrtGraph < 23 do
        Sgraph  sprintf "bounds(10, 10, 5, 5),  shape(\"circle\"),channel(\"shapes%d\"),visible(0)", iCrtGraph
        cabbageCreate "image", Sgraph
        iCrtGraph += 1
    od
    
endin
schedule "Create",0,0

instr StepsChng
iCrt init 0
iPosX init 50
    while iCrt < giLenSeq do
    iStepValue = giArrSeq[iCrt]
    iRed,iGrn,iBlu RGB iStepValue
      iG = giArrSeq[iCrt]*50
      iSizeX = giArrSeq[iCrt]*30
      Schnl   sprintf "steps%d", iCrt
      SSteps  sprintf "bounds(%d, 100, %d, 30), shape(\"sharp\"), channel(\"steps%d\"),alpha(1), visible(1),\
      colour(%d,%d,%d)",iPosX,iSizeX,iCrt,iRed,iGrn,iBlu
      cabbageSet Schnl, SSteps
      ;giArrStartX[iCrt] = iPosX
    iCrt += 1
    iPosX += 10+iSizeX
    od
endin
schedule "StepsChng",0,0


instr Tala
iTala = p4
giArrSeq[] ArrTala giArrSeqIn, iTala
schedule "StepsChngTala",0,0
;printarray giArrSeq, "%d"
endin

instr StepsChngTala
iCrt init 0
iPosX init 50
    while iCrt < giLenSeq do
      iG = giArrSeq[iCrt]*50
      iSizeX = giArrSeq[iCrt]*30
      giArrStartX[iCrt] = iPosX
    iCrt += 1
    iPosX += 10+iSizeX
    od
endin
schedule "StepsChngTala",0,0



instr Metro
kTalaCount init 1
kTime init 0
kSeqIndx init 0
kNoteIndx init 0
iBPM = 90/60
if metro(1/kTime) == 1 then
kTime = (giArrSeq[kSeqIndx]*iBPM)/7
kNote = giNoteArr[kNoteIndx]
kStepsValue = giArrSeq[kSeqIndx]
if kSeqIndx != (giLenSeq-1) then
schedulek "SeqMotion", 0, kTime/2, kSeqIndx,1
endif
if kTalaCount == 0 && changed(kTalaCount) == 1 then
schedulek "ColorOff", 0, 0.1
endif
schedulek "Sound", 0, 0.3, kNote
schedulek "GraphTrig", 0, kTime,kNote,kTalaCount
    if kSeqIndx == (giLenSeq-1) && changed(kSeqIndx) == 1 then
    schedulek "SeqMotion", 0, kTime/2, kSeqIndx,2
    schedulek "MotionTrg", 0, kTime/2
    schedulek "Tala",0.1,0,kTalaCount
    kTalaCount = (kTalaCount+1) % (lenarray(giArrSeq))
    endif
    if kSeqIndx == 0 && changed(kSeqIndx) == 1 then
    schedulek "StepsChng",0,0.1
    endif
    ;;rep
    kRepIndx = 0
    while kRepIndx < giLenRep do
        if kSeqIndx+1 == giRepArr[kRepIndx] then
            if giArrSeq[kSeqIndx] == 1 then
            kRepT = 1*kStepsValue
            elseif giArrSeq[kSeqIndx] == 2 then
            kRepT = random:k(0,100) > 50 ? kStepsValue:kStepsValue*2
            elseif giArrSeq[kSeqIndx] > 2 then
            kRepT = int(random:k(2,5))
            endif
                kNoteRep = kNote
			    until kNoteRep > 80 do
  				kNoteRep = kNoteRep+12
  			    enduntil
        kRep = 0
        kDelay = kTime/kRepT
        kTrig = kDelay
            while kRep < kRepT do
            schedulek "RepShape1", kTrig,0.1,kRep,giRepArr[kRepIndx],giArrSeq[kSeqIndx]
            schedulek "Sound", kTrig, 0.1, kNoteRep
            schedulek "GraphRep", kTrig, 0.1,kRep, kNoteRep
            schedulek "RepShape0", kTrig+(kTime/kRepT),0.1,kRep,giRepArr[kRepIndx]
            kRep += 1
            kTrig += kTime/kRepT
            od
        endif
     kRepIndx += 1
     od
    ;;Bass
    kBassIndx = 0
    while kBassIndx < giLenBass do
        if kSeqIndx+1 == giBassArr[kBassIndx] then
            if kStepsValue == 1 then
            kRndBass = 0
            elseif kStepsValue == 2 then
            kRndBass = 2
            endif
                kNoteBass = kNote
			    until kNoteBass < 50 do
  			    kNoteBass = kNoteBass-12
  				enduntil
        schedulek "Sound", (kTime/4)*kRndBass, 0.1, kNoteBass
        schedulek "BassShape1", kTime/2,0.1,giBassArr[kBassIndx],giArrSeq[kSeqIndx]
        schedulek "BassShape0", kTime  ,0.1,giBassArr[kBassIndx]
        endif
    kBassIndx += 1
    od
kSeqIndx = (kSeqIndx+1) % (lenarray(giArrSeq))
kNoteIndx = (kNoteIndx+1) % (lenarray(giNoteArr))
endif
endin

schedule "Metro",0,9999





instr MotionTrg
indx = 0
while indx < giLenSeq do
schedule "StepMotion",0,p3,indx
indx += 1
od
endin

instr StepMotion
kFade linseg 1, p3,-0.9
cabbageSet metro(50),"steps0", "alpha", kFade

indx = p4
if indx != 0 then
iStart = giArrStartX[indx]
iEnd = (giArrStartX[indx]-((giArrSeq[0]*30)+10))
kPointX linseg iStart, p3, iEnd-0.1

iSizeX = giArrSeq[indx]*30
Schnl   sprintf "steps%d", indx
SSteps  sprintfk "bounds(%d, 100, %d, 30), shape(\"sharp\"),visible(1)" ,kPointX,iSizeX
      cabbageSet metro(80),Schnl, SSteps
endif
endin

instr SeqMotion
iStepNumber = p4

iSizeX = giArrSeq[iStepNumber]*30
iSizeY = 30
iPosY = 100
if p5 = 1 then
iStart = giArrStartX[iStepNumber]+5
iEndX = giArrStartX[iStepNumber]
elseif p5 = 2 then
kSizeX linseg iSizeX-20, p3, iSizeX
iStart = giArrStartX[iStepNumber]+5
iEndX = (giArrStartX[iStepNumber]-((giArrSeq[0]*30)+10))
endif
kSizeX linseg iSizeX-15, p3, iSizeX
kSizeY linseg iSizeY+10,p3,iSizeY
kPosX linseg iStart,p3,iEndX
kPosY linseg iPosY-5,p3, iPosY
Schnl   sprintf "steps%d", iStepNumber
SSteps  sprintfk "bounds(%d, %d, %d, %d), shape(\"sharp\"),visible(1)" ,kPosX,kPosY,kSizeX,kSizeY
      cabbageSet metro(80),Schnl, SSteps

endin


instr RepShape1
iRepNumber = p4
iRepIndx = p5-1
iPointX = (iRepNumber*10)+giArrStartX[iRepIndx]
iPointY = 70
iStepValue = p6
  iRed,iGrn,iBlu RGB iStepValue   
SChannel sprintf "Reps%d", iRepNumber
      SRep  sprintf "bounds(%d, %d, 17, 18), channel(\"Reps%d\"),visible(1),\
      colour(%d,%d,%d)", iPointX,iPointY, iRepNumber,iRed,iGrn,iBlu
      cabbageSet SChannel, SRep
endin
instr RepShape0
iRepNumber = p4
iPointX = (p5*70)
iPointY = (iRepNumber*(-20))+150
SChannel sprintf "Reps%d", iRepNumber
      SRep  sprintf "bounds(%d, %d, 20, 21), channel(\"Reps%d\"),visible(%d),colour(250,120,250)", iPointX,iPointY, iRepNumber,0
      cabbageSet SChannel, SRep
endin

instr BassShape1
iBassIndx = p4-1
iStepValue = p5
  iRed,iGrn,iBlu RGB iStepValue  
iPointX = giArrStartX[iBassIndx]+10
      SBassShape  sprintf "bounds(%d, 140, 20, 21), channel(\"BassShape\"),visible(1),colour(%d,%d,%d)", iPointX,iRed,iGrn,iBlu
      cabbageSet "BassShape", SBassShape
endin
instr BassShape0
iPointX = (p4*70)+30
      SBassShape  sprintf "bounds(%d, 250, 20, 21), channel(\"BassShape\"),visible(%d),colour(120,150,250)", iPointX,0
      cabbageSet "BassShape", SBassShape
endin



instr GraphTrig
    iGraph = 0
    while iGraph < giLenSeq do
    schedule "Graph", 0, p3/2,iGraph,p4
    schedule "Fade", p3/3, p3,iGraph
    iGraph += 1
    od
    schedule "ColorOn", 0, 0.1,p5
endin


instr Graph
indx = p4
iTala = p6
kCircleWide linseg 30, p3, 100
iSizeX = 30
iSizeY = 31
iPoints = giLenSeq
iCircleX = 200
iCircleY = 300
iRotate = 0
kPosX, kPosY circle iCircleX, iCircleY, kCircleWide, indx, iPoints
Schnl sprintf "shapes%d", indx
Schng sprintfk "bounds(%d, %d, %d, %d), corners(10),visible(1),rotate(%d,0,0),alpha(1)\
",kPosX,kPosY,iSizeX,iSizeY,iRotate
cabbageSet metro(50),Schnl, Schng
endin

instr Fade
indx = p4
kFade linseg 2, p3,-0.9
Schnl sprintf "shapes%d", indx
cabbageSet metro(50),Schnl, "alpha", kFade
endin


instr ColorOn
indx = p4
iG = 150
iR = 80
iB = 100
Schnl sprintf "shapes%d", indx
Schng sprintf "colour(%d,%d,%d)",iG,iR,iB
cabbageSet Schnl, Schng
endin


instr ColorOff
indx = 0
while indx < giLenSeq do
Schnl sprintf "shapes%d", indx
Schng sprintf "colour(100,100,%d)",100
cabbageSet Schnl, Schng
indx += 1
od
endin
schedule "ColorOff", 0, 0

instr GraphRep
indx = p4
iG = p5*10
iR = (p5*20)+100
iB = (p5*10)+200
iPosX = 200
iPosY = 300
iSizeX random 30, 80
iSizeY = 10
iRotate random 0, 100
Schnl sprintf "RepsG%d", indx
;puts Schnl,1
Schng sprintf "bounds(%d, %d, %d, %d),visible(1),rotate(%d,10,10),alpha(1)\
colour(%d,%d,%d)",iPosX,iPosY,iSizeX,iSizeY,iRotate,iG,iR,iB
cabbageSet Schnl, Schng
endin

instr Sound
iFrq mtof p4
aEnv linseg 0,0.01, 0.2, p3-0.01, 0
a1 poscil aEnv, iFrq
outs a1,a1
endin
</CsInstruments>
<CsScore>

</CsScore>
</CsoundSynthesizer>

