
<Cabbage>
form caption("CoreLa") size(1200, 700)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")
;image bounds(0, 0, 250, 300) channel("img") file("CoreLa.jpg")
;;Sequencer

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1



opcode RGB, iii,i
iNumber xin
      if iNumber == 1 then
      iRed = 150
      iGrn = 200
      iBlu = 250
      elseif iNumber == 2 then
      iRed = 100
      iGrn = 200
      iBlu = 100
      elseif iNumber == 3 then
      iRed = 100
      iGrn = 100
      iBlu = 200
      elseif iNumber == 4 then
      iRed = 200
      iGrn = 120
      iBlu = 250
      elseif iNumber == 5 then
      iRed = 100
      iGrn = 150
      iBlu = 150
      endif
xout iRed,iGrn,iBlu
endop

opcode ArrTala, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr [] init iLen
 iRead = 0
 iWrite = iTalaCount+1
 while iRead < iLen do
 	iOutArr [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% iLen
 od
 xout iOutArr
endop

giSeqArrIn[] fillarray 1,1,2,3,4,5,1,2
giSeqArr[]   fillarray 1,1,2,3,4,5,1,2

instr Widget

endin

instr Create
iCrtShape init 0
iCrtRep init 0
iCrtBass init 0
    while iCrtShape < 8 do
      SSteps  sprintf "bounds(10, 10, 30, 30), shape(\"sharp\"), channel(\"steps%d\"), visible(0)",iCrtShape
      cabbageCreate "image", SSteps
    iCrtShape += 1
    od
    while iCrtRep < 4 do
      SRep  sprintf "bounds(60, 10, 20, 21), shape(\"circle\"), channel(\"Reps%d\"), visible(0)", iCrtRep
      cabbageCreate "image", SRep
    iCrtRep += 1
    od
    while iCrtBass < 2 do
      SBassShape  sprintf "bounds(100,100, 20, 21), shape(\"circle\"), channel(\"Bass%d\"), visible(0)",iCrtBass
      cabbageCreate "image", SBassShape
    iCrtBass += 1
    od
endin

schedule "Create",0,0

instr StepsChange
iLen lenarray giSeqArr
giPointXArr[] init iLen
giStepSizeXArr[] init iLen
  iCrt init 0
  iPointX init 50
    while iCrt < 8 do
      giPointXArr[iCrt] = iPointX
      iSeqValue = giSeqArr[iCrt]
      iRed,iGrn,iBlu RGB iSeqValue
      iStepSizeX = giSeqArr[iCrt]*30
      giStepSizeXArr[iCrt] = iStepSizeX
      SStepsChnl sprintf  "steps%d",iCrt
      SSteps  sprintf "bounds(%d, 120, %d, 30), shape(\"sharp\"),visible(1),colour:1(%d, %d, %d)", iPointX, iStepSizeX,iRed,iGrn,iBlu
      cabbageSet SStepsChnl, SSteps
      iPointX += iStepSizeX+10
    iCrt += 1
    od
endin
schedule "StepsChange",0,0


instr Metro
kTime init 0
kSeqIndx init 0
kTalaCount init 0
iBPM = 90/60
kRepArr[] fillarray 4, 5
iLenRep lenarray kRepArr
kBassArr[] fillarray 3, 6
iLenBass lenarray kBassArr

  if metro(1/kTime) == 1 then
  kStepsValue = giSeqArr[kSeqIndx]
  kTime = (kStepsValue*iBPM)/10
  schedulek "StepsMotion", 0, 0.2, kSeqIndx,kStepsValue
    ;;rep
    kRepIndx = 0
    while kRepIndx < iLenRep do
        if kSeqIndx+1 == kRepArr[kRepIndx] then
            if giSeqArr[kSeqIndx] == 1 then
            kRepT = 1*kStepsValue
            elseif giSeqArr[kSeqIndx] == 2 then
            kRepT = random:k(0,100) > 50 ? kStepsValue:kStepsValue*2
            elseif giSeqArr[kSeqIndx] > 2 then
            kRepT = int(random:k(2,5))*kStepsValue
            endif
        kRep = 0
        kDelay = kTime/kRepT
        kTrig = kDelay
            while kRep < kRepT do
            ;schedulek "RepShape1", kTrig,0.1,kRep,kRepArr[kRepIndx]
            ;schedulek "RepShape0", kTrig+(kTime/kRepT),0.1,kRep,kRepArr[kRepIndx]
            kRep += 1
            kTrig += kTime/kRepT
            od
        endif
    kRepIndx += 1
    od
    ;;Bass
    kBassIndx = 0
    while kBassIndx < iLenBass do
        if kSeqIndx+1 == kBassArr[kBassIndx] then
        ;schedulek "BassShape1", kTime/2,0.1,kBassArr[kBassIndx]
        ;schedulek "BassShape0", kTime  ,0.1,kBassArr[kBassIndx]
        endif
    kBassIndx += 1
    od
              
  kSeqIndx = (kSeqIndx+1)%lenarray(giSeqArr)
            if kSeqIndx == 0 && changed(kSeqIndx) == 1 then
            schedulek "tala",0,0.1,kTalaCount
            schedulek "StepsChange", 0, 1
            kTalaCount = (kTalaCount+1) % lenarray(giSeqArrIn)
          endif
  endif
endin

schedule "Metro", 0, 9999

instr tala
iTala = p4
giSeqArr[] ArrTala giSeqArrIn, iTala
endin

instr StepsMotion

endin


instr RepShape1
iRepNumber = p4
iRepIndx = p5-1
iPointX = (iRepNumber*10)+giPointXArr[iRepIndx]
iPointY = 90
      iRed,iGrn,iBlu RGB iRepIndx
      
SChannel sprintf "Reps%d", iRepNumber
      SRep  sprintf "bounds(%d, %d, 17, 18), channel(\"Reps%d\"),visible(%d),colour(%d,%d,%d)", iPointX,iPointY, iRepNumber,1,iRed,iGrn,iBlu
      cabbageSet SChannel, SRep
endin
instr RepShape0
iRepNumber = p4
iPointX = (p5*70)
iPointY = (iRepNumber*(-20))+150
SChannel sprintf "Reps%d", iRepNumber
      SRep  sprintf "bounds(%d, %d, 20, 21), channel(\"Reps%d\"),visible(%d),colour(250,120,250)", iPointX,iPointY, iRepNumber,0
      cabbageSet SChannel, SRep
endin


instr BassShape1
iBassIndx = p4-1
iPointX = giPointXArr[iBassIndx]+10
      iRed,iGrn,iBlu RGB iBassIndx
      SBassShape  sprintf "bounds(%d, 160, 20, 21), channel(\"BassShape\"),visible(%d),colour(%d,%d,%d)", iPointX,1,iRed,iGrn,iBlu
      cabbageSet "BassShape", SBassShape
endin
instr BassShape0
iPointX = (p4*70)+30
      SBassShape  sprintf "bounds(%d, 250, 20, 21), channel(\"BassShape\"),visible(%d),colour(120,150,250)", iPointX,0
      cabbageSet "BassShape", SBassShape
endin

</CsInstruments>
<CsScore>
</CsScore>
</CsoundSynthesizer>

