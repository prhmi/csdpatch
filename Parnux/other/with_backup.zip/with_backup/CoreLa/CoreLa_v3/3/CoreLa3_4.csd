
<Cabbage>
form caption("CoreLa") size(880, 500)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")
;image bounds(0, 0, 250, 300) channel("img") file("CoreLa.jpg")
;;Sequencer

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


instr Create
  iCrt init 0
  iPointX init 50
  iPointY init 160
    while iCrt < 8 do
      SSteps  sprintf "bounds(%d, 200, 50, 51), shape(\"circle\"), channel(\"steps%d\")", iPointX, iCrt
      cabbageCreate "image", SSteps
      SRep  sprintf "bounds(60, %d, 20, 21), shape(\"circle\"), channel(\"Reps%d\"), visible(0)", iPointY, iCrt
      cabbageCreate "image", SRep
      iPointX += 70
      iPointY -= 30
    iCrt += 1
    od
     SBassShape  sprintf "bounds(100,100, 20, 21), shape(\"circle\"), channel(\"BassShape\"), visible(%d)", 0
      cabbageCreate "image", SBassShape
endin

instr StepsColor
iSeqArr[] fillarray 1,1,2,3,4,5,1,2
  iCrt init 0
    while iCrt < 8 do
      SChannel sprintf "steps%d", iCrt
      iSeq = iSeqArr[iCrt]
      if iSeq == 1 then
      iRed = 150
      iGrn = 200
      iBlu = 250
      elseif iSeq == 2 then
      iRed = 10
      iGrn = 250
      iBlu = 100
      elseif iSeq == 3 then
      iRed = 250
      iGrn = 250
      iBlu = 90
      elseif iSeq == 4 then
      iRed = 250
      iGrn = 80
      iBlu = 100
      elseif iSeq == 5 then
      iRed = 250
      iGrn = 0
      iBlu = 250
      endif
      SColor sprintf "colour:1(%d, %d, %d), channel(\"steps%d\")", iRed,iGrn,iBlu,iCrt
      cabbageSet SChannel,SColor
    iCrt += 1
    od
endin


instr Metro
kTime init 0
iSeqArr[] fillarray 1,1,2,4
kSeqIndx init 0
iBPM = 90/60
kRepNum = 4
kBassNum = 3

  if metro(1/kTime) == 1 then
  kTime = (iSeqArr[kSeqIndx]*iBPM)/5
  schedulek "StepsShape", 0, .2, kSeqIndx
    ;;rep
    if kSeqIndx+1 == kRepNum then
        if iSeqArr[kSeqIndx] == 1 then
        kRepT = 1
        elseif iSeqArr[kSeqIndx] == 2 then
       kRepT = random:k(0,100) > 50 ? 2:4
        elseif iSeqArr[kSeqIndx] > 2 then
        kRepT = int(random:k(2,5))
        endif
    kRep = 0
    kDelay = kTime/kRepT
    kTrig = kDelay
        while kRep < kRepT do
        schedulek "RepShape1", kTrig,0.1,kRep,kRepNum
        schedulek "RepShape0", kTrig+(kTime/kRepT),0.1,kRep,kRepNum
        kRep += 1
        kTrig += kTime/kRepT
        od
    endif
    ;;Bass
    if kSeqIndx+1 == kBassNum then
    schedulek "BassShape1", kTime/2,0.1,kBassNum
    schedulek "BassShape0", kTime  ,0.1,kBassNum
    endif
  kSeqIndx = (kSeqIndx+1)%lenarray(iSeqArr)
  endif

endin


instr StepsShape
iLightNumber = p4
kPointXIn linseg 40, p3, 50
kPointX = (iLightNumber*70)+kPointXIn
kPointY linseg 180, p3, 200
kSizeX linseg 80, p3, 50
SChannel sprintf "Lights%d", iLightNumber
SChnSh sprintf "steps%d", iLightNumber
      SShape sprintfk "bounds(%d, %d, %d, %d),shape(\"circle\"), channel(\"steps%d\")",kPointX,kPointY,kSizeX,kSizeX+1,iLightNumber
      cabbageSet metro(20),SChnSh,SShape
endin


instr RepShape1
iRepNumber = p4
iPointX = (p5*70)-5
iPointY = (iRepNumber*(-10))+150
SChannel sprintf "Reps%d", iRepNumber
      SRep  sprintf "bounds(%d, %d, 20, 21), channel(\"Reps%d\"),visible(%d),colour(250,120,250)", iPointX,iPointY, iRepNumber,1
      cabbageSet SChannel, SRep
endin
instr RepShape0
iRepNumber = p4
iPointX = (p5*70)
iPointY = (iRepNumber*(-20))+150
SChannel sprintf "Reps%d", iRepNumber
      SRep  sprintf "bounds(%d, %d, 20, 21), channel(\"Reps%d\"),visible(%d),colour(250,120,250)", iPointX,iPointY, iRepNumber,0
      cabbageSet SChannel, SRep
endin


instr BassShape1
iPointX = (p4*70)+30
      SBassShape  sprintf "bounds(%d, 250, 20, 21), channel(\"BassShape\"),visible(%d),colour(120,150,250)", iPointX,1
      cabbageSet "BassShape", SBassShape
endin
instr BassShape0
iPointX = (p4*70)+30
      SBassShape  sprintf "bounds(%d, 250, 20, 21), channel(\"BassShape\"),visible(%d),colour(120,150,250)", iPointX,0
      cabbageSet "BassShape", SBassShape
endin

</CsInstruments>
<CsScore>
i "Create" 0 1
i "StepsColor" 0 1
i "Metro" 0 80
</CsScore>
</CsoundSynthesizer>

