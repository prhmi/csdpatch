
<Cabbage>
form caption("CoreLa") size(1200, 700)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")
;image bounds(0, 0, 250, 300) channel("img") file("CoreLa.jpg")
;;Sequencer

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1



opcode RGB, iii,i
iNumber xin
      if iNumber == 1 then
      iRed = 150
      iGrn = 200
      iBlu = 250
      elseif iNumber == 2 then
      iRed = 100
      iGrn = 200
      iBlu = 100
      elseif iNumber == 3 then
      iRed = 100
      iGrn = 100
      iBlu = 200
      elseif iNumber == 4 then
      iRed = 200
      iGrn = 120
      iBlu = 250
      elseif iNumber == 5 then
      iRed = 100
      iGrn = 150
      iBlu = 150
      endif
xout iRed,iGrn,iBlu
endop

opcode RGB, kkk,k
kNumber xin
      if kNumber == 1 then
      kRed = 150
      kGrn = 200
      kBlu = 250
      elseif kNumber == 2 then
      kRed = 100
      kGrn = 200
      kBlu = 100
      elseif kNumber == 3 then
      kRed = 100
      kGrn = 100
      kBlu = 200
      elseif kNumber == 4 then
      kRed = 200
      kGrn = 120
      kBlu = 250
      elseif kNumber == 5 then
      kRed = 100
      kGrn = 150
      kBlu = 150
      endif
xout kRed,kGrn,kBlu
endop

opcode ArrTala, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr [] init iLen
 iRead = 0
 iWrite = iTalaCount+1
 while iRead < iLen do
 	iOutArr [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% iLen
 od
 xout iOutArr
endop

giSeqArrIn[] fillarray 1,1,2,3,4,5,1,2
giSeqArr[]   fillarray 1,1,2,3,4,5,1,2

instr Widget

endin

instr Create
iCrtShape init 0
iCrtRep init 0
iCrtBass init 0
    while iCrtShape < 8 do
      SSteps  sprintf "bounds(10, 10, 30, 30), shape(\"sharp\"), channel(\"steps%d\"), visible(0)",iCrtShape
      cabbageCreate "image", SSteps
    iCrtShape += 1
    od
    while iCrtRep < 4 do
      SRep  sprintf "bounds(60, 10, 20, 21), shape(\"circle\"), channel(\"Reps%d\"), visible(0)", iCrtRep
      cabbageCreate "image", SRep
    iCrtRep += 1
    od
    while iCrtBass < 2 do
      SBassShape  sprintf "bounds(100,100, 20, 21), shape(\"circle\"), channel(\"Bass%d\"), visible(0)",iCrtBass
      cabbageCreate "image", SBassShape
    iCrtBass += 1
    od
endin

instr StepsChange
iLen lenarray giSeqArr
gkPointXArr[] init iLen
gkStepSizeXArr[] init iLen
  kCrt init 0
  kPointX init 50
    while kCrt < 8 do
      gkPointXArr[kCrt] = kPointX
      kSeqValue = giSeqArr[kCrt]
      kRed,kGrn,kBlu RGB kSeqValue
      kStepSizeX = giSeqArr[kCrt]*30
      gkStepSizeXArr[kCrt] = kStepSizeX
      SStepsChnl sprintfk  "steps%d",kCrt
      SSteps  sprintfk "bounds(%d, 120, %d, 30), shape(\"sharp\"),visible(1),colour:1(%d, %d, %d)", kPointX, kStepSizeX,kRed,kGrn,kBlu
      cabbageSet metro(100), SStepsChnl, SSteps
      kPointX += kStepSizeX+10
    kCrt += 1
    od
endin



instr Metro
kTime init 0
kSeqIndx init 0
kSeqIndxTala init 0
kTalaCount init 0
iBPM = 90/60
kRepArr[] fillarray 4, 5
iLenRep lenarray kRepArr
kBassArr[] fillarray 3, 6
iLenBass lenarray kBassArr

  if metro(1/kTime) == 1 then
  kStepsValue = giSeqArr[kSeqIndx]
  kStepsValueTala = giSeqArr[kSeqIndxTala]
  kTime = (kStepsValue*iBPM)/10
  schedulek "StepsMotion", 0, 0.2, kSeqIndxTala,kStepsValueTala
    ;;rep
    kRepIndx = 0
    while kRepIndx < iLenRep do
        if kSeqIndx+1 == kRepArr[kRepIndx] then
            if giSeqArr[kSeqIndx] == 1 then
            kRepT = 1*kStepsValue
            elseif giSeqArr[kSeqIndx] == 2 then
            kRepT = random:k(0,100) > 50 ? kStepsValue:kStepsValue*2
            elseif giSeqArr[kSeqIndx] > 2 then
            kRepT = int(random:k(2,5))*kStepsValue
            endif
        kRep = 0
        kDelay = kTime/kRepT
        kTrig = kDelay
            while kRep < kRepT do
            ;schedulek "RepShape1", kTrig,0.1,kRep,kRepArr[kRepIndx]
            ;schedulek "RepShape0", kTrig+(kTime/kRepT),0.1,kRep,kRepArr[kRepIndx]
            kRep += 1
            kTrig += kTime/kRepT
            od
        endif
    kRepIndx += 1
    od
    ;;Bass
    kBassIndx = 0
    while kBassIndx < iLenBass do
        if kSeqIndx+1 == kBassArr[kBassIndx] then
        ;schedulek "BassShape1", kTime/2,0.1,kBassArr[kBassIndx]
        ;schedulek "BassShape0", kTime  ,0.1,kBassArr[kBassIndx]
        endif
    kBassIndx += 1
    od
              
  kSeqIndx = (kSeqIndx+1)%lenarray(giSeqArr)
  kSeqIndxTala = (kSeqIndxTala+1)%(lenarray(giSeqArr)-1)
            if kSeqIndx == 0 && changed(kSeqIndx) == 1 then
            schedulek "tala",0,0.1,kTalaCount
            schedulek "StepsChange", 0, 1
            kTalaCount = (kTalaCount+1) % lenarray(giSeqArrIn)
          endif
  endif

endin


instr tala
iTala = p4
giSeqArr[] ArrTala giSeqArrIn, iTala
endin

instr StepsMotion

endin






</CsInstruments>
<CsScore>
;i "Widget" 0 1
i "Create" 0 1
i "StepsChange" 0 5
i "Metro" 0 80
</CsScore>
</CsoundSynthesizer>

