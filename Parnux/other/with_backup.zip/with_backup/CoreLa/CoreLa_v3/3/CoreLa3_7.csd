
<Cabbage>
form caption("CoreLa") size(1200, 700)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")
;image bounds(0, 0, 250, 300) channel("img") file("CoreLa.jpg")
;;Sequencer

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


instr Create
iSeqArr[] fillarray 1,1,2,3,4,5,1,2
iLen lenarray iSeqArr
giPointXArr[] init iLen
  iCrt init 0
  iPointX init 50
  iPointY init 160
    while iCrt < 8 do
      giPointXArr[iCrt] = iPointX
      iStepSizeX = iSeqArr[iCrt]*30
      SSteps  sprintf "bounds(%d, 120, %d, 30), shape(\"sharp\"), channel(\"steps%d\")", iPointX, iStepSizeX,iCrt
      cabbageCreate "image", SSteps
      SRep  sprintf "bounds(60, %d, 20, 21), shape(\"circle\"), channel(\"Reps%d\"), visible(0)", iPointY, iCrt
      cabbageCreate "image", SRep
      iPointX += iStepSizeX+10
      iPointY -= 30
    iCrt += 1
    od
     SBassShape  sprintf "bounds(100,100, 20, 21), shape(\"circle\"), channel(\"BassShape\"), visible(%d)", 0
      cabbageCreate "image", SBassShape
endin

instr StepsColor
iSeqArr[] fillarray 1,1,2,3,4,5,1,2
  iCrt init 0
    while iCrt < 8 do
      SChannel sprintf "steps%d", iCrt
      iSeq = iSeqArr[iCrt]
      if iSeq == 1 then
      iRed = 150
      iGrn = 200
      iBlu = 250
      elseif iSeq == 2 then
      iRed = 100
      iGrn = 200
      iBlu = 100
      elseif iSeq == 3 then
      iRed = 100
      iGrn = 100
      iBlu = 200
      elseif iSeq == 4 then
      iRed = 200
      iGrn = 120
      iBlu = 250
      elseif iSeq == 5 then
      iRed = 100
      iGrn = 150
      iBlu = 150
      endif
      SColor sprintf "colour:1(%d, %d, %d), channel(\"steps%d\")", iRed,iGrn,iBlu,iCrt
      cabbageSet SChannel,SColor
    iCrt += 1
    od
endin


instr Metro
kTime init 0
iSeqArr[] fillarray 1,1,2,3,4,5,1,2
kSeqIndx init 0
iBPM = 90/60
kRepArr[] fillarray 4, 5
iLenRep lenarray kRepArr
kBassArr[] fillarray 3, 6
iLenBass lenarray kBassArr

  if metro(1/kTime) == 1 then
  kStepsValue = iSeqArr[kSeqIndx]
  kTime = (kStepsValue*iBPM)/10
  schedulek "StepsShape", 0, .1, kSeqIndx,kStepsValue
    ;;rep
    kRepIndx = 0
    while kRepIndx < iLenRep do
        if kSeqIndx+1 == kRepArr[kRepIndx] then
            if iSeqArr[kSeqIndx] == 1 then
            kRepT = 1*kStepsValue
            elseif iSeqArr[kSeqIndx] == 2 then
            kRepT = random:k(0,100) > 50 ? kStepsValue:kStepsValue*2
            elseif iSeqArr[kSeqIndx] > 2 then
            kRepT = int(random:k(2,5))*kStepsValue
            endif
        kRep = 0
        kDelay = kTime/kRepT
        kTrig = kDelay
            while kRep < kRepT do
            schedulek "RepShape1", kTrig,0.1,kRep,kRepArr[kRepIndx]
            schedulek "RepShape0", kTrig+(kTime/kRepT),0.1,kRep,kRepArr[kRepIndx]
            kRep += 1
            kTrig += kTime/kRepT
            od
        endif
    kRepIndx += 1
    od
    ;;Bass
    kBassIndx = 0
    while kBassIndx < iLenBass do
        if kSeqIndx+1 == kBassArr[kBassIndx] then
        schedulek "BassShape1", kTime/2,0.1,kBassArr[kBassIndx]
        schedulek "BassShape0", kTime  ,0.1,kBassArr[kBassIndx]
        endif
    kBassIndx += 1
    od
  kSeqIndx = (kSeqIndx+1)%lenarray(iSeqArr)
  endif

endin


instr StepsShape
iStepNumber = p4
iStepsValue = p5
iPointX = giPointXArr[iStepNumber]
kPointX linseg iPointX-5, p3, iPointX
kPointY linseg 115,p3,120
iSizeX = (iStepsValue*30)
kSizeX linseg iSizeX-10, p3 ,iSizeX
iSizeY = 30
kSizeY linseg iSizeY+10, p3 ,iSizeY
SChnSh sprintf "steps%d", iStepNumber
      SShape sprintfk "bounds(%d, %d, %d, %d),shape(\"sharp\"), channel(\"steps%d\")",kPointX,kPointY,kSizeX,kSizeY,iStepNumber
      cabbageSet metro(50), SChnSh,SShape
endin


instr RepShape1
iRepNumber = p4
iRepIndx = p5-1
iPointX = (iRepNumber*10)+giPointXArr[iRepIndx]
iPointY = 90

      if iRepIndx == 1 then
      iRed = 150
      iGrn = 200
      iBlu = 250
      elseif iRepIndx == 2 then
      iRed = 100
      iGrn = 200
      iBlu = 100
      elseif iRepIndx == 3 then
      iRed = 100
      iGrn = 100
      iBlu = 200
      elseif iRepIndx == 4 then
      iRed = 200
      iGrn = 120
      iBlu = 250
      elseif iRepIndx == 5 then
      iRed = 100
      iGrn = 150
      iBlu = 150
      endif
      
SChannel sprintf "Reps%d", iRepNumber
      SRep  sprintf "bounds(%d, %d, 17, 18), channel(\"Reps%d\"),visible(%d),colour(%d,%d,%d)", iPointX,iPointY, iRepNumber,1,iRed,iGrn,iBlu
      cabbageSet SChannel, SRep
endin
instr RepShape0
iRepNumber = p4
iPointX = (p5*70)
iPointY = (iRepNumber*(-20))+150
SChannel sprintf "Reps%d", iRepNumber
      SRep  sprintf "bounds(%d, %d, 20, 21), channel(\"Reps%d\"),visible(%d),colour(250,120,250)", iPointX,iPointY, iRepNumber,0
      cabbageSet SChannel, SRep
endin


instr BassShape1
iBassIndx = p4-1
iPointX = giPointXArr[iBassIndx]+10
      if iBassIndx == 1 then
      iRed = 150
      iGrn = 200
      iBlu = 250
      elseif iBassIndx == 2 then
      iRed = 100
      iGrn = 200
      iBlu = 100
      elseif iBassIndx == 3 then
      iRed = 100
      iGrn = 100
      iBlu = 200
      elseif iBassIndx == 4 then
      iRed = 200
      iGrn = 120
      iBlu = 250
      elseif iBassIndx == 5 then
      iRed = 100
      iGrn = 150
      iBlu = 150
      endif
      SBassShape  sprintf "bounds(%d, 160, 20, 21), channel(\"BassShape\"),visible(%d),colour(%d,%d,%d)", iPointX,1,iRed,iGrn,iBlu
      cabbageSet "BassShape", SBassShape
endin
instr BassShape0
iPointX = (p4*70)+30
      SBassShape  sprintf "bounds(%d, 250, 20, 21), channel(\"BassShape\"),visible(%d),colour(120,150,250)", iPointX,0
      cabbageSet "BassShape", SBassShape
endin

</CsInstruments>
<CsScore>
i "Create" 0 1
i "StepsColor" 0 1
i "Metro" 0 80
</CsScore>
</CsoundSynthesizer>

