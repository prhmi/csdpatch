
<Cabbage>
form caption("CoreLa") size(880, 500)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")
;image bounds(0, 0, 250, 300) channel("img") file("CoreLa.jpg")
;;Sequencer

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


instr Create
  iCrt init 0
  iPointX init 50
    while iCrt < 6 do
      SSteps  sprintf "bounds(%d, 100, 50, 51), shape(\"circle\"), channel(\"steps%d\")", iPointX, iCrt
      SLight  sprintf "bounds(%d, 170, 20, 21), shape(\"square\"), channel(\"Lights%d\"),colour:1(40,50,80)", iPointX+16, iCrt
      cabbageCreate "image", SSteps
      cabbageCreate "image", SLight
      iPointX += 70
    iCrt += 1
    od
endin

instr StepsColor
iSeqArr[] fillarray 1,1,2,3,4,5
iRed = 250
  iCrt init 0
    while iCrt < 6 do
      SChannel sprintf "steps%d", iCrt
      iRed = iSeqArr[iCrt]*70
      iGrn = iSeqArr[iCrt]*150
      iBlu = iSeqArr[iCrt]*50
      SColor sprintf "colour:1(%d, %d, %d), channel(\"steps%d\")", iRed,iGrn,iBlu,iCrt
      cabbageSet SChannel,SColor
    iCrt += 1
    od
endin


instr Metro
kCount init 0
kTime init 0
  if metro(1/kTime) == 1 then
  kTime = 0.3
  schedulek "LightsColor1", 0, 0.1, kCount
  schedulek "LightsColor0", kTime, 0.1, kCount
  kCount = (kCount+1) % 6
  endif

endin


instr LightsColor1
iLightNumber = p4
iPointX = (iLightNumber*70)+48
SChannel sprintf "Lights%d", iLightNumber
SChnSh sprintf "steps%d", iLightNumber
      SColor sprintf "colour:1(100, 250, 50), channel(\"Lights%d\")",iLightNumber
      SShape sprintf "bounds(%d, 95, 57, 58),shape(\"circle\"), channel(\"steps%d\")",iPointX,iLightNumber
      cabbageSet SChannel,SColor
      cabbageSet SChnSh,SShape
endin

instr LightsColor0
iLightNumber = p4
iPointX = (iLightNumber*70)+50
SChannel sprintf "Lights%d", iLightNumber
SChnSh sprintf "steps%d", iLightNumber
      SColor sprintf "colour:1(40, 50, 80), channel(\"Lights%d\")",iLightNumber
      SShape sprintf "bounds(%d, 100, 50, 51),shape(\"circle\"), channel(\"steps%d\")",iPointX,iLightNumber
      cabbageSet SChannel,SColor
      cabbageSet SChnSh,SShape
endin

</CsInstruments>
<CsScore>
i "Create" 0 1
i "StepsColor" 0 1
i "Metro" 0 80
</CsScore>
</CsoundSynthesizer>

