<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1



instr 1
 SIn = "12 324 4 56"
Snote     sprintf "%s ",SIn

iLen strlen Snote

iChStrt = 0
indx = 0
iChIndx = 0
while iChStrt < iLen do

Schar     strsub    Snote, 0, 1

	iChCount = 0
	until strcmp(Schar," ") == 0 do
	Schar     strsub    Snote, iChIndx, iChIndx+1
	iChIndx += 1
	iChCount += 1
	od
prints "start: %d, dur: %d\n" , iChStrt, iChCount-1

ScharOut     strsub    Snote, iChStrt, iChStrt+(iChCount-1)
iChStrt += (iChCount)
puts ScharOut,1
;print iChStrt
indx += 1
od
endin

</CsInstruments>
<CsScore>
i1 0 1
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
