<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>
sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

/*******************************************************/
/****************** BASIC EXAMPLE **********************/
/*******************************************************/




/*******************************************************/
/********* ONE POSSIBILITY TO PLAY WITH IT *************/
/*******************************************************/

  opcode IsOp, i, So
  ;returns 1 for (, 2 for +, 3 for -, 4 for *, 5 for /, 6 for %, 7 for ^
  ;0 for anything else
String, indx xin
Str strsub String, indx, indx+1
if strcmp(Str, "(") == 0 then
iRes = 1
elseif strcmp(Str, "+") == 0 then
iRes = 2
elseif strcmp(Str, "-") == 0 then
iRes = 3
elseif strcmp(Str, "*") == 0 then
iRes = 4
elseif strcmp(Str, "/") == 0 then
iRes = 5
elseif strcmp(Str, "%") == 0 then
iRes = 6
elseif strcmp(Str, "^") == 0 then
iRes = 7
else
iRes = 0
endif
xout iRes  
  endop

  opcode IsNum, i, So
  ;returns 1 if Schar is a number or point, 0 elsewhere
Schar, ipos xin
iNum strchar Schar, ipos
if iNum == 46 || (iNum > 47 && iNum < 58) then
iRes = 1
else
iRes = 0
endif
xout iRes
  endop
 
  opcode IsNoth, i, So
  ;returns 1 if Schar is a space or tab, 0 elsewhere
Schar, ipos xin
iNum strchar Schar, ipos
if iNum == 32 || iNum == 9 then
iRes = 1
else
iRes = 0
endif
xout iRes
  endop

  opcode StrExpr, i, S
Str xin
indx = 0

;look after each character
while indx < strlen(Str) do

 ;do nothing if part of a number or a space
 if IsNum(Str, indx) == 1 || IsNoth(Str, indx) == 1 then
		indx += 1

 ;if '(', look for the ')' and evaluate
 elseif IsOp(Str, indx) == 1 then
  ;position of second parenthesis
		iPosPar2 strindex Str, ")"
  ;is there an operator after 
  iSubIndx = iPosPar2
  iIsOp2 = 0
  until iIsOp2 > 0 || iSubIndx == strlen(Str) do
   iIsOp2 IsOp Str, iSubIndx
   iSubIndx += 1
  od 
  ;substring inside this parenthesis
		S1 strsub Str, indx+1, iPosPar2
  ;if this is the end of the string, simply evaluate this section
  if iIsOp2 == 0 then
   iNum StrExpr S1
   igoto end
  else
  ;if there is an operator after this parenthesis, evaluate both strings
  S2 strsub Str, iPosPar2+2
  if iIsOp2 == 2 then
   iNum = StrExpr(S1) + StrExpr(S2)
   igoto end
  elseif iIsOp2 == 3 then
   iNum = StrExpr(S1) - StrExpr(S2)
   igoto end    
  elseif iIsOp2 == 4 then
   iNum = StrExpr(S1) * StrExpr(S2)
   igoto end    
  elseif iIsOp2 == 5 then
   iNum = StrExpr(S1) / StrExpr(S2)
   igoto end    
  elseif iIsOp2 == 6 then
   iNum = StrExpr(S1) % StrExpr(S2)
   igoto end    
  else
   iNum = StrExpr(S1) ^ StrExpr(S2)
   igoto end    
  endif
     
 endif
 
 ;if operator, recursion with this operator
 else
  S1 strsub Str, 0, indx
  S2 strsub Str, indx+1
  if IsOp(Str, indx) == 2 then
   iNum = StrExpr(S1) + StrExpr(S2)
   igoto end
  elseif IsOp(Str, indx) == 3 then
   iNum = StrExpr(S1) - StrExpr(S2)
   igoto end
  elseif IsOp(Str, indx) == 4 then
   iNum = StrExpr(S1) * StrExpr(S2)
   igoto end
  elseif IsOp(Str, indx) == 5 then
   iNum = StrExpr(S1) / StrExpr(S2)
   igoto end
  elseif IsOp(Str, indx) == 6 then
   iNum = StrExpr(S1) % StrExpr(S2)
   igoto end
  else
   iNum = StrExpr(S1) ^ StrExpr(S2)
   igoto end
  endif
 endif
 
od

iNum strtod Str
end: xout iNum  
  endop

  opcode StrayLen, i, Sjj
;returns the number of elements in Stray. elements are defined by two seperators as ASCII coded characters: isep1 defaults to 32 (= space), isep2 defaults to 9 (= tab). if just one seperator is used, isep2 equals isep1
Stray, isepA, isepB xin
;;DEFINE THE SEPERATORS
isep1     =         (isepA == -1 ? 32 : isepA)
isep2     =         (isepA == -1 && isepB == -1 ? 9 : (isepB == -1 ? isep1 : isepB))
Sep1      sprintf   "%c", isep1
Sep2      sprintf   "%c", isep2
;;INITIALIZE SOME PARAMETERS
ilen      strlen    Stray
icount    =         0; number of elements
iwarsep   =         1
indx      =         0
 if ilen == 0 igoto end ;don't go into the loop if String is empty
loop:
Snext     strsub    Stray, indx, indx+1; next sign
isep1p    strcmp    Snext, Sep1; returns 0 if Snext is sep1
isep2p    strcmp    Snext, Sep2; 0 if Snext is sep2
 if isep1p == 0 || isep2p == 0 then; if sep1 or sep2
iwarsep   =         1; tell the log so
 else 				; if not 
  if iwarsep == 1 then	; and has been sep1 or sep2 before
icount    =         icount + 1; increase counter
iwarsep   =         0; and tell you are ot sep1 nor sep2 
  endif 
 endif	
          loop_lt   indx, 1, ilen, loop 
end:      xout      icount
  endop 

  opcode SToScaleArr, i[]i, Sjj
  ;fill a numerical string into an array and return also its length
Stray, isepA, isepB xin
;;DEFINE THE SEPERATORS
isep1     =         (isepA == -1 ? 32 : isepA)
isep2     =         (isepA == -1 && isepB == -1 ? 9 : (isepB == -1 ? isep1 : isepB))
Sep1      sprintf   "%c", isep1
Sep2      sprintf   "%c", isep2
;;WRITE ARRAY LENGTH
iarrlen   StrayLen  Stray, isep1, isep2
iOutArr[] init iarrlen
;;INITIALIZE SOME PARAMETERS
ilen      strlen    Stray
istartsel =         -1; startindex for searched element
iel       =         -1; number of element in Stray and ift
iwarleer  =         1; is this the start of a new element
indx      =         0 ;character index
inewel    =         0 ;new element to find
;;LOOP
 if ilen == 0 igoto end ;don't go into the loop if Stray is empty
loop:
Schar     strsub    Stray, indx, indx+1; this character
isep1p    strcmp    Schar, Sep1; returns 0 if Schar is sep1
isep2p    strcmp    Schar, Sep2; 0 if Schar is sep2
is_sep    =         (isep1p == 0 || isep2p == 0 ? 1 : 0) ;1 if Schar is a seperator
 ;END OF STRING AND NO SEPARATORS BEFORE?
 if indx == ilen && iwarleer == 0 then
Sel       strsub    Stray, istartsel, -1
inewel    =         1
 ;FIRST CHARACTER OF AN ELEMENT?
 elseif is_sep == 0 && iwarleer == 1 then
istartsel =         indx ;if so, set startindex
iwarleer  =         0 ;reset info about previous separator 
iel       =         iel+1 ;increment element count
 ;FIRST SEPERATOR AFTER AN ELEMENT?
 elseif iwarleer == 0 && is_sep == 1 then
Sel       strsub    Stray, istartsel, indx ;get element
inewel    =         1 ;tell about
iwarleer  =         1 ;reset info about previous separator
 endif
 ;WRITE THE ELEMENT TO THE ARRAY
 if inewel == 1 then
inum      StrExpr   Sel ;convert expression to number
iOutArr[iel] = inum
 endif
inewel    =         0
          loop_le   indx, 1, ilen, loop 
end:
  xout iOutArr, iarrlen
  endop 
  



instr Control

 //get the ratios via the line edit widget
 S_ratios = "55 6"

 //and put them into an array 
 iRatios[], iNumSteps SToScaleArr S_ratios
print iNumSteps

printarray iRatios,"%d"
endin

</CsInstruments>
<CsScore>
i "Control" 0 4
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>451</x>
 <y>250</y>
 <width>792</width>
 <height>424</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>202</r>
  <g>175</g>
  <b>155</b>
 </bgcolor>
 <bsbObject version="2" type="BSBLineEdit">
  <objectName>scale</objectName>
  <x>101</x>
  <y>82</y>
  <width>578</width>
  <height>38</height>
  <uuid>{9a309660-ae8b-47ef-88d3-895f70d4359c}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <label>1 2^(0.5/12) 4/3 6/5</label>
  <alignment>left</alignment>
  <font>Liberation Sans</font>
  <fontsize>20</fontsize>
  <precision>3</precision>
  <color>
   <r>0</r>
   <g>0</g>
   <b>0</b>
  </color>
  <bgcolor mode="nobackground">
   <r>240</r>
   <g>240</g>
   <b>240</b>
  </bgcolor>
  <background>nobackground</background>
 </bsbObject>
 <bsbObject version="2" type="BSBLabel">
  <objectName/>
  <x>101</x>
  <y>34</y>
  <width>321</width>
  <height>35</height>
  <uuid>{13214639-f7a2-411c-9263-f7fab13c78fd}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <label>1. Insert the ratios of a scale</label>
  <alignment>left</alignment>
  <valignment>top</valignment>
  <font>Liberation Sans</font>
  <fontsize>20</fontsize>
  <precision>3</precision>
  <color>
   <r>0</r>
   <g>0</g>
   <b>0</b>
  </color>
  <bgcolor mode="nobackground">
   <r>255</r>
   <g>255</g>
   <b>255</b>
  </bgcolor>
  <bordermode>false</bordermode>
  <borderradius>1</borderradius>
  <borderwidth>0</borderwidth>
 </bsbObject>
 <bsbObject version="2" type="BSBLabel">
  <objectName/>
  <x>101</x>
  <y>143</y>
  <width>488</width>
  <height>38</height>
  <uuid>{e7e1ee87-1430-48ba-9869-fb03763817ca}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <label>2. Press one of the keys (1-8) to play one of the steps</label>
  <alignment>left</alignment>
  <valignment>top</valignment>
  <font>Liberation Sans</font>
  <fontsize>20</fontsize>
  <precision>3</precision>
  <color>
   <r>0</r>
   <g>0</g>
   <b>0</b>
  </color>
  <bgcolor mode="nobackground">
   <r>255</r>
   <g>255</g>
   <b>255</b>
  </bgcolor>
  <bordermode>false</bordermode>
  <borderradius>1</borderradius>
  <borderwidth>0</borderwidth>
 </bsbObject>
 <bsbObject version="2" type="BSBDisplay">
  <objectName>step</objectName>
  <x>313</x>
  <y>202</y>
  <width>85</width>
  <height>75</height>
  <uuid>{2d3ef16c-c15f-4542-beb1-4e615e993312}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <label>2</label>
  <alignment>center</alignment>
  <valignment>top</valignment>
  <font>Liberation Sans</font>
  <fontsize>50</fontsize>
  <precision>0</precision>
  <color>
   <r>0</r>
   <g>0</g>
   <b>0</b>
  </color>
  <bgcolor mode="background">
   <r>255</r>
   <g>255</g>
   <b>255</b>
  </bgcolor>
  <bordermode>true</bordermode>
  <borderradius>1</borderradius>
  <borderwidth>1</borderwidth>
 </bsbObject>
 <bsbObject version="2" type="BSBButton">
  <objectName>_Play</objectName>
  <x>196</x>
  <y>302</y>
  <width>321</width>
  <height>54</height>
  <uuid>{e505cbcd-d94d-4099-97a8-13935abd3d5b}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>0</midicc>
  <description/>
  <type>value</type>
  <pressedValue>1.00000000</pressedValue>
  <stringvalue/>
  <text>Start Csound here</text>
  <image>/</image>
  <eventLine>i1 0 10</eventLine>
  <latch>false</latch>
  <latched>false</latched>
  <fontsize>20</fontsize>
 </bsbObject>
</bsbPanel>
<bsbPresets>
</bsbPresets>
