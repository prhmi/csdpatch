<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1





instr 1
 Snote = "3 23"
indx = 0 
ilen = 3

loop:
 Schar     strsub    Snote, indx, indx+2
puts Schar,1
  loop_le   indx, 1, ilen, loop 

 itest strindex Snote,"6"
  
;iArrNote[] StrToArr Snote
;printarray iArrNote,"%d"
endin

</CsInstruments>
<CsScore>
i1 0 1
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
