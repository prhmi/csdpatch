<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1





instr 1
 Snote = "12 "

ilen strlen Snote

iChIndx = 0
indxw = 0
Schar     strsub    Snote, 0, 1
	until strcmp(Schar," ") == 0 do
   Schar     strsub    Snote, iChIndx, iChIndx+1
	iChIndx += 1
	od
print iChIndx


ScharOut     strsub    Snote, 0, iChIndx-1
puts ScharOut,1
endin

</CsInstruments>
<CsScore>
i1 0 1
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
