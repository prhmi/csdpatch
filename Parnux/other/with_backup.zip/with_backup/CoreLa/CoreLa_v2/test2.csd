<Cabbage>
form caption("Texteditor Example") size(380, 300), guiMode("queue"), colour(2, 145, 209) pluginId("def1")

texteditor bounds(18, 20, 341, 204) fontSize(16), channel("orcText"), scrollbars(1), wrap(1),  fontColour(124, 210, 0), colour(0, 0, 0, 100)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-n -d -+rtmidi=NULL -M0 -m0d --midi-key=4 --midi-velocity-amp=5
</CsOptions>
<CsInstruments>
; Initialize the global variables. 
ksmps = 16
nchnls = 2
0dbfs = 1


; Rory Walsh 2021 
;
; License: CC0 1.0 Universal
; You can copy, modify, and distribute this file, 
; even for commercial purposes, all without asking permission. 

instr 1

    SW = "ss"
    
    cabbageSet "orcText", "text", SW

    Si cabbageGetValue "orcText"
prints Si
endin
</CsInstruments>
<CsScore>
i1 0 z
</CsScore>
</CsoundSynthesizer>