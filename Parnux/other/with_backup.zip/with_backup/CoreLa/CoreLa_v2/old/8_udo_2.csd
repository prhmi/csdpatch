<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0


#include "opcodes.udo"

giArrNote [] init 6
giWriteNote  init 0


instr GetMidi ;1
 iActive1 active 1
 kRel release
 iNum notnum
 iVel veloc 0,127
 schedule "WriteMidi",0,.001,iNum,iVel
 schedule "RySeq",0,-1
 	if kRel == 1 && changed(kRel) == 1 then
 	schedulek "WriteMidi", 0, .001,iNum,0
 	turnoff2 "RySeq",0,0
 	endif
endin
instr WriteMidi ;2
 iActive1 active 1
 iNote = p4
 iVel = p5
 iLen lenarray giArrNote
 ;prints "note: %d, veloc: %d\n", iNote,iVel
 if iVel != 0 then
		while giArrNote [giWriteNote] != 0 do
		giWriteNote += 1
		od
		print giWriteNote
 giArrNote [giWriteNote] = iNote
 ;giWriteNote = (giWriteNote+1) % iLen
 elseif iVel == 0 then
		indxw = 0
		while indxw < iLen do
			if giArrNote [indxw] == iNote then
			giArrNote [indxw] = 0
			giWriteNote = indxw-1
			endif
		indxw += 1
		od
 giWriteNote = (giWriteNote-1) <= 0 ? 0 : giWriteNote
 ;print giWriteNote
 endif
			if iActive1 == 0 then
			giWriteNote = 0
			endif
 giNote [] RmvZ giArrNote
 printarray giArrNote,"%d", "Array:"
 printarray giNote,"%d","Note:"
endin


instr RySeq ;3
 kTime init 0
 kTimeB init 0
 giArrSeq [] fillarray 1,2,1,2,1,1,2,4
 giArrSeqP [] = giArrSeq
 iLenSeq lenarray giArrSeq
 kSeqIndx init 0
 iTempo = 90
 iBPM = iTempo/60
 iTms = 3

 ;giArrNote [] fillarray 61,62,60,65,67
 iLenNote lenarray giArrNote
 kNoteIndx init 0
 giArrBass  [] fillarray 1,3,7
 giArrRep   [] fillarray 1,3
 kTalaCount init 0
 kRep init 0
 if metro(1/kTime) == 1 then
 kTime = (giArrSeqP[kSeqIndx])/(iBPM*iTms)
 kNote = giArrNote[kNoteIndx]
 schedulek "Sound",0,0.2,kNote
	;;Rep Seq:
	kndxRepCh = 0
	while kndxRepCh < lenarray(giArrRep) do
			if kSeqIndx == giArrRep[kndxRepCh] then
			kRepT = giArrSeqP[kSeqIndx]*(int(random:k(2,5)))
			kndxRep = 1
			kTrigRep = kTime/kRepT
					while kndxRep < kRepT do
					schedulek "Sound",kTrigRep,0.08,kNote
					kTrigRep += kTime/kRepT
					kndxRep += 1
					od			
			endif
	kndxRepCh += 1
	od
;;Bass
	kndxB = 0
	while kndxB < lenarray(giArrBass) do
			if kSeqIndx == giArrBass[kndxB] then
							kNoteBass = giArrNote[0]
					    	until kNoteBass < 45 do
  							kNoteBass = kNoteBass-12
  							enduntil
					if giArrSeqP [kSeqIndx] <= 2 then
					kTrigBass = kTime/2
					else
					kRndBass = int(random:k(1,4))
					kTrigBass = (kTime/4)*kRndBass
							if kRndBass == 1 then
								kndxRB = 0
								while kndxRB < int(random:k(0,2)) do
								schedulek "Sound",kTrigBass*int(random:k(2,4)),.1,kNoteBass
								kndxRB += 1
								od
							endif
					endif
			schedulek 2,kTrigBass,.1,kNoteBass
			endif
	kndxB += 1
	od
 kSeqIndx = (kSeqIndx+1) % (iLenSeq+kRep)
 		;;Tala
		if kSeqIndx == 0 then
		schedulek "tala",0,0.1,kTalaCount
		kTalaCount = (kTalaCount+1) % iLenSeq
		;kRep = 1
		endif
 kNoteIndx = (kNoteIndx+1) % iLenNote
 endif
endin


instr tala ;4
iTala = p4
;giArrSeqP [] ArrTala giArrSeq, iTala
;giArrSeqP [] ArrRep giArrSeq, iTala
;giArrSeqP [] ArrPlus giArrSeq, iTala
;giArrSeqP [] ArrChng giArrSeq
printarray giArrSeqP, "%d"
endin


instr Sound ;5
iMidiNote = p4
iBaseNote  ntom "0C"
iFrq pythagorean iBaseNote-12,iMidiNote
  	
 aEnv linseg 0, 0.005, 0.3, p3-0.005, 0
 a1 poscil aEnv, iFrq*4
 out a1,a1
endin



</CsInstruments>
<CsScore>
;i3 0 999
;i 2 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>144</width>
 <height>85</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
 <bsbObject type="BSBController" version="2">
  <objectName>hor0</objectName>
  <x>93</x>
  <y>56</y>
  <width>23</width>
  <height>29</height>
  <uuid>{8faa0994-023f-4ac0-98f1-975ad1f69ffe}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <objectName2>meter0</objectName2>
  <xMin>0.00000000</xMin>
  <xMax>1.00000000</xMax>
  <yMin>0.00000000</yMin>
  <yMax>1.00000000</yMax>
  <xValue>0.00000000</xValue>
  <yValue>1.00000000</yValue>
  <type>fill</type>
  <pointsize>1</pointsize>
  <fadeSpeed>0.00000000</fadeSpeed>
  <mouseControl act="press">jump</mouseControl>
  <bordermode>noborder</bordermode>
  <borderColor>#00FF00</borderColor>
  <color>
   <r>0</r>
   <g>234</g>
   <b>0</b>
  </color>
  <randomizable group="0" mode="both">false</randomizable>
  <bgcolor>
   <r>30</r>
   <g>30</g>
   <b>30</b>
  </bgcolor>
  <bgcolormode>true</bgcolormode>
 </bsbObject>
 <bsbObject type="BSBController" version="2">
  <objectName>hor1</objectName>
  <x>121</x>
  <y>56</y>
  <width>23</width>
  <height>29</height>
  <uuid>{8af272e8-0121-4864-bcbc-15f2cb305e98}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>0</midicc>
  <description/>
  <objectName2>meter1</objectName2>
  <xMin>0.00000000</xMin>
  <xMax>1.00000000</xMax>
  <yMin>0.00000000</yMin>
  <yMax>1.00000000</yMax>
  <xValue>0.00000000</xValue>
  <yValue>1.00000000</yValue>
  <type>fill</type>
  <pointsize>1</pointsize>
  <fadeSpeed>0.00000000</fadeSpeed>
  <mouseControl act="press">jump</mouseControl>
  <bordermode>noborder</bordermode>
  <borderColor>#00ff00</borderColor>
  <color>
   <r>0</r>
   <g>234</g>
   <b>0</b>
  </color>
  <randomizable group="0" mode="both">false</randomizable>
  <bgcolor>
   <r>30</r>
   <g>30</g>
   <b>30</b>
  </bgcolor>
  <bgcolormode>true</bgcolormode>
 </bsbObject>
</bsbPanel>
<bsbPresets>
</bsbPresets>
