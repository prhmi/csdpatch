<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0


opcode ArrTala, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr [] init iLen
 iRead = 0
 iWrite = iTalaCount
 while iRead < iLen do
 	iOutArr [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% iLen
 od
 xout iOutArr
endop
opcode ArrRep, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr[] init  iLen+1
 iRead = 0
 iWrite = 0
 while iRead < iLen+1 do
 iOutArr [iRead] = iInArr [iWrite]
 	if iRead != iTalaCount then
 	iWrite += 1
 	endif
 iRead += 1
 od
 iOutArr[iTalaCount+1] = iInArr[iTalaCount]
 xout iOutArr
endop
opcode ArrPlus, i[], i[]i
 iInArr[],iElm xin
 iLen lenarray iInArr
 iOutArr[] = iInArr
 iAdd = int(random:i( 1,4))
 iMines = random:i( 0,100) > 50 ? 1: -1
 iOutArr [iElm] = iInArr [iElm] + (iAdd*iMines)	
		 iOutArr[iElm] = ( iOutArr[iElm] < 1 ) ? 
 		 iInArr[iElm] :  iOutArr[iElm]
 xout iOutArr
endop
opcode ArrChng, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] = iInArr
 indx = 0 
 while indx < iLen do
 iAdd random  0, 3
 iMines = random:i( 0,100) > 50 ? 1: -1
 iOutArr [indx] = iInArr [indx] + (iAdd*iMines)
 		 iOutArr[indx] = ( iOutArr[indx] < 1 ) ? 
 		 iInArr[indx] :  iOutArr[indx]
 indx += 1
 od
 xout iOutArr
endop




instr RySeq
 kTime init 0
 kTimeB init 0
 giArrSeq [] fillarray 1,2,1,3,1,4
 giArrSeqP [] = giArrSeq
 iLenSeq lenarray giArrSeq
 kSeqIndx init 0
 iTempo = 122
 iBPM = iTempo/60
 iTms = 4

 giArrNote [] fillarray 61,62,60,65,67
 iLenNote lenarray giArrNote
 kNoteIndx init 0
 giArrBass  [] fillarray 1,3,7
 giArrRep   [] fillarray 1,3,5
 kTalaCount init 0
 kRep init 0
 if metro(1/kTime) == 1 then
 kTime = (giArrSeqP[kSeqIndx])/(iBPM*iTms)
 kNote = giArrNote[kNoteIndx]
 schedulek 2,0,0.2,kNote
	;;Rep Seq:
	kndxRepCh = 0
	while kndxRepCh < lenarray(giArrRep) do
			if kSeqIndx == giArrRep[kndxRepCh] then
			kRepT = giArrSeqP[kSeqIndx]* 3 ;(int(random:k(2,5)))
			kndxRep = 1
			kTrigRep = kTime/kRepT
			 			until kTrigRep > 0.1 do
  						kTrigRep = kTrigRep/2
  						enduntil
			printk2 kTrigRep
					while kndxRep < kRepT do
					schedulek 2,kTrigRep,0.08,kNote
					kTrigRep += kTime/kRepT
					kndxRep += 1
					od			
			endif
	kndxRepCh += 1
	od
;;Bass
	kndxB = 0
	while kndxB < lenarray(giArrBass) do
			if kSeqIndx == giArrBass[kndxB] then
							kNoteBass = giArrNote[0]
					    	until kNoteBass < 45 do
  							kNoteBass = kNoteBass-12
  							enduntil
					if giArrSeqP [kSeqIndx] <= 2 then
					kTrigBass = kTime/2
					else
					kRndBass = int(random:k(1,4))
					kTrigBass = (kTime/4)*kRndBass
							if kRndBass == 1 then
								kndxRB = 0
								while kndxRB < int(random:k(0,2)) do
								schedulek 2,kTrigBass*int(random:k(2,4)),.1,kNoteBass
								kndxRB += 1
								od
							endif
					endif
			schedulek 2,kTrigBass,.1,kNoteBass
			endif
	kndxB += 1
	od
 kSeqIndx = (kSeqIndx+1) % (iLenSeq+kRep)
 		;;Tala
		if kSeqIndx == 0 then
		schedulek 3,0,0.1,kTalaCount
		kTalaCount = (kTalaCount+1) % iLenSeq
		;kRep = 1
		endif
 kNoteIndx = (kNoteIndx+1) % iLenNote
 endif
endin

instr 2
iMidiNote = p4

  	
 iFrq mtof (iMidiNote)
 aEnv linseg 0, 0.005, 0.3, p3-0.005, 0
 a1 poscil aEnv, iFrq*4
 out a1,a1
endin

instr 3
iTala = p4
giArrSeqP [] ArrTala giArrSeq, iTala
;giArrSeqP [] ArrRep giArrSeq, iTala
;giArrSeqP [] ArrPlus giArrSeq, iTala
;giArrSeqP [] ArrChng giArrSeq
printarray giArrSeqP, "%d"
endin

</CsInstruments>
<CsScore>
i1 0 999
;i 2 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>144</width>
 <height>85</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
 <bsbObject type="BSBController" version="2">
  <objectName>hor0</objectName>
  <x>93</x>
  <y>56</y>
  <width>23</width>
  <height>29</height>
  <uuid>{8faa0994-023f-4ac0-98f1-975ad1f69ffe}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <objectName2>meter0</objectName2>
  <xMin>0.00000000</xMin>
  <xMax>1.00000000</xMax>
  <yMin>0.00000000</yMin>
  <yMax>1.00000000</yMax>
  <xValue>0.00000000</xValue>
  <yValue>1.00000000</yValue>
  <type>fill</type>
  <pointsize>1</pointsize>
  <fadeSpeed>0.00000000</fadeSpeed>
  <mouseControl act="press">jump</mouseControl>
  <bordermode>noborder</bordermode>
  <borderColor>#00FF00</borderColor>
  <color>
   <r>0</r>
   <g>234</g>
   <b>0</b>
  </color>
  <randomizable mode="both" group="0">false</randomizable>
  <bgcolor>
   <r>30</r>
   <g>30</g>
   <b>30</b>
  </bgcolor>
  <bgcolormode>true</bgcolormode>
 </bsbObject>
 <bsbObject type="BSBController" version="2">
  <objectName>hor1</objectName>
  <x>121</x>
  <y>56</y>
  <width>23</width>
  <height>29</height>
  <uuid>{8af272e8-0121-4864-bcbc-15f2cb305e98}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>0</midicc>
  <description/>
  <objectName2>meter1</objectName2>
  <xMin>0.00000000</xMin>
  <xMax>1.00000000</xMax>
  <yMin>0.00000000</yMin>
  <yMax>1.00000000</yMax>
  <xValue>0.00000000</xValue>
  <yValue>1.00000000</yValue>
  <type>fill</type>
  <pointsize>1</pointsize>
  <fadeSpeed>0.00000000</fadeSpeed>
  <mouseControl act="press">jump</mouseControl>
  <bordermode>noborder</bordermode>
  <borderColor>#00ff00</borderColor>
  <color>
   <r>0</r>
   <g>234</g>
   <b>0</b>
  </color>
  <randomizable mode="both" group="0">false</randomizable>
  <bgcolor>
   <r>30</r>
   <g>30</g>
   <b>30</b>
  </bgcolor>
  <bgcolormode>true</bgcolormode>
 </bsbObject>
</bsbPanel>
<bsbPresets>
</bsbPresets>
