 bounds(0, 0, 0, 0)
<Cabbage>
form caption("CoreLa") size(250, 340)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")

;;Sequencer
label    bounds(35, 35, 40, 12) text("On/Off") channel("label1")
checkbox bounds(10, 30, 20, 20) colour:0(100, 100, 100, 255) popupText("Start")  channel("sq") colour:1(100, 250, 60, 255) value(1)
checkbox bounds(12, 60, 15, 15) colour:0(100, 100, 100, 255) popupText("Hold")  channel("hold") colour:1(100, 250, 60, 255) value(1)
label    bounds(35, 62, 30, 12) text("Hold") channel("label2")
nslider  bounds(90, 35, 40, 31) range(50, 180, 90, 1, 1)  fontColour(208, 157, 253, 255) text("BPM") channel("BPM")
nslider  bounds(130, 35, 30, 31) range(1, 10, 4, 1, 1)  fontColour(208, 157, 253, 255) text("DV") channel("DV") 
combobox bounds(165, 30, 65, 25) text("Indian", "Tala", "Tala Rep", "Tala Plus", "Tala Change") channel("tala") 
hslider bounds(70, 93, 150, 28) range(0.05, 2, 0.7, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) channel("dur")
label    bounds(10, 100, 50, 12) text("Duration") channel("labe3")
texteditor bounds(40, 125, 200, 20) channel("SeqArr") colour(180, 140, 250, 150) colour:0(180, 140, 250, 150)fontSize(20)
label      bounds(0, 127, 35, 12) text("seq") channel("label4")
checkbox   bounds(225, 153, 15, 15) colour:0(100, 100, 100, 255)  channel("vlc") colour:1(100, 250, 60, 255)
texteditor bounds(40, 150, 180, 20) channel("VelocArr") colour(180, 140, 250, 150) colour:0(180, 140, 250, 150)fontSize(20)
label      bounds(0, 152, 35, 12) text("vel") channel("label5")
checkbox   bounds(125, 178, 15, 15) colour:0(100, 100, 100, 255)  channel("Bss") colour:1(100, 250, 60, 255)
texteditor bounds(40, 175, 80, 20) channel("BassArr") colour(180, 140, 250, 150) colour:0(180, 140, 250, 150)fontSize(20)
label      bounds(0, 177, 35, 12) text("Bss") channel("label6")
checkbox   bounds(125, 203, 15, 15) colour:0(100, 100, 100, 255)  channel("Rep") colour:1(100, 250, 60, 255)
texteditor bounds(40, 200, 80, 20) channel("RepArr") colour(180, 140, 250, 150) colour:0(180, 140, 250, 150)fontSize(20)
label      bounds(0, 202, 35, 12) text("Rep") channel("label7")


label    bounds(35, 281, 40, 12) text("On/Off")
checkbox bounds(10, 280, 15, 15) colour:0(100, 100, 100, 255) popupText("Synth")  channel("dng") colour:1(100, 250, 60, 255)
combobox bounds(100, 275, 65, 25) text("Scale", "Tala", "TalaRep", "TalaPlus", "TalaPlusR", "TalaPlusJ") channel("scale") 

label bounds(170, 60, 55, 28) channel("SeqCount") text("0")
label bounds(6, 228, 240, 16) channel("SeqArRy") ;text("1")
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0


#include "opcodes.udo"

giArrNote [] init 12
giArrEmpty [] init 12
giNote [] init 1
giWriteNote  init 0
giArrSeq [] fillarray 1


instr GetMidi ;1
 iActive1 active 1
 iHold cabbageGetValue "hold"
 print iHold
 kRel release
 iNum notnum
 iVel veloc 0,127
 if iActive1 == 1 then
 giArrNote [] = giArrEmpty
 endif
 schedule "WriteMidi",0,.1,iNum,iVel
 	if kRel == 1 && changed(kRel) == 1 && iHold == 0 then
 	schedulek "WriteMidi", 0, .1,iNum,0
 	endif
endin
instr WriteMidi ;2
 iActive1 active 1
 iNote = p4
 iVel = p5
 iLen lenarray giArrNote
 ;prints "note: %d, veloc: %d\n", iNote,iVel
 if iVel != 0 then
		while giArrNote [giWriteNote] != 0 do
		giWriteNote += 1
		od
		;print giWriteNote
 giArrNote [giWriteNote] = iNote
 ;giWriteNote = (giWriteNote+1) % iLen
 elseif iVel == 0 then
		indxw = 0
		while indxw < iLen do
			if giArrNote [indxw] == iNote then
			giArrNote [indxw] = 0
			giWriteNote = indxw-1
			endif
		indxw += 1
		od
 giWriteNote = (giWriteNote-1) <= 0 ? 0 : giWriteNote
 ;print giWriteNote
 endif
			if iActive1 == 0 then
			giWriteNote = 0
			endif
 giNote [] RmvZ giArrNote
 giLenNote lenarray giNote
 ;printarray giArrNote,"%d", "Array:"
 printarray giNote,"%d","Note:"
endin


instr RySeq ;3
 kActive1 active 1
 kHold cabbageGet "hold"
 kTala cabbageGet "tala"
 

 kTime init 0
 kTimeB init 0
 ;giArrSeq [] fillarray 1,2,3,1,2,2,4
 giArrSeqP [] = giArrSeq
 giLenSeq = 1;lenarray giArrSeq
 kSeqIndx init 0
 kTempo cabbageGet "BPM"
 kBPM = kTempo/60
 kTms cabbageGet "DV"
 
 kNoteIndx init 0
 giArrBass  [] fillarray 1,3,7
 giArrRep   [] fillarray 2
 kTalaCount init 0
 kRep init 0
 if metro(1/kTime) == 1 then
 kTime = (giArrSeqP[kSeqIndx])/(kBPM*kTms)
 kNoteIndx = (kNoteIndx+1) % giLenNote
 kNote = giNote[kNoteIndx]
 if kNote > 20  then
 schedulek "Sound",0,0.2,kNote
	;;Rep Seq:
	kndxRepCh = 0
	while kndxRepCh < lenarray(giArrRep) do
			if kSeqIndx == giArrRep[kndxRepCh] then
			 kTrigRep = 0
			 kRepR = ((int(random:k(0,16)))/4)+0.5
						until kTrigRep > .08 do
						kRepT = giArrSeqP[kSeqIndx]*kRepR
  						kRepR = kRepR-.25
  						kTrigRep = kTime/kRepT
  						enduntil
  								until kTrigRep < .3 do
								kRepT = giArrSeqP[kSeqIndx]*kRepR
  								kRepR = kRepR+.25
  								kTrigRep = kTime/kRepT
  								enduntil
					kndxRep = 1
				    ;printks "%.3f %.2f\n",-1,kTrigRep,kRepR
					while kndxRep < kRepT do
						;schedulek "Sound",kTrigRep,0.1,kNote
						kTrigRep += kTime/kRepT
						kndxRep += 1
					od			
			endif
	kndxRepCh += 1
	od
;;Bass
	kndxB = 0
	while kndxB < lenarray(giArrBass) do
			if kSeqIndx == giArrBass[kndxB] then
							kNoteBass = giArrNote[0]
					    	until kNoteBass < 45 do
  							kNoteBass = kNoteBass-12
  							enduntil
					if giArrSeqP [kSeqIndx] <= 2 then
					kTrigBass = kTime/2
					else
					kRndBass = int(random:k(1,4))
					kTrigBass = (kTime/4)*kRndBass
							if kRndBass == 1 then
								kndxRB = 0
								while kndxRB < int(random:k(0,2)) do
								;schedulek "Sound",kTrigBass*int(random:k(2,4)),.1,kNoteBass
								kndxRB += 1
								od
							endif
					endif
			;schedulek "Sound",kTrigBass,.1,kNoteBass
			endif
	kndxB += 1
	od
  SseqCount     sprintfk "text(%d)", kSeqIndx+1
  kTrig changed SseqCount
 cabbageSet kTrig,"SeqCount",SseqCount
if kActive1 == 0 && kHold == 0 then
 kSeqIndx = 0
 else
 kSeqIndx = (kSeqIndx+1) % (giLenSeq+kRep)
 endif
 		;;Tala
 ;printk2 kTala
		if kSeqIndx == 0 then
		schedulek "tala",0,0.1,kTalaCount,kTala
		kTalaCount = (kTalaCount+1) % giLenSeq
		    if kTala == 3 then
		    kRep = 1
		    else
		    kRep = 0
		    endif
		endif
 endif

endif
print 2
endin


instr tala ;4
iTala = p4
iChoose = p5
if iChoose == 1 then
giArrSeqP [] = giArrSeq
elseif iChoose == 2 then
giArrSeqP [] ArrTala giArrSeq, iTala
elseif iChoose == 3 then
giArrSeqP [] ArrRep giArrSeq, iTala
elseif iChoose == 4 then
giArrSeqP [] ArrPlus giArrSeq, iTala
elseif iChoose == 5 then
giArrSeqP [] ArrChng giArrSeq
endif
printarray giArrSeqP, "%.2f"
schedule "putstrng",0,0.1
endin


instr Sound ;5
iMidiNote = p4
iBaseNote  ntom "0C"
iFrq pythagorean iBaseNote-12,iMidiNote
  	
 aEnv linseg 0, 0.005, 0.3, p3-0.005, 0
 a1 poscil aEnv, iFrq*4
 out a1,a1
endin


instr Widgets ;6
kSeqOnOff cabbageGet "sq"
if kSeqOnOff == 1 && changed(kSeqOnOff) == 1 then
schedulek "RySeq",0,-1
elseif kSeqOnOff == 0 && changed(kSeqOnOff) == 1 then
turnoff2 "RySeq",0,0
endif

kHold cabbageGet "hold"
if kHold == 0 && changed(kHold) == 1 then
schedulek "Empty",0,0.1
endif

  Sseq  = "1 1 2 4"
  Svel  = "5 5 5 7 2 5 5 7"
  Sbss  = "1 3 5"
  Srp   = "2 3 4"
  cabbageSet "SeqArr", "text",  Sseq
  cabbageSet "VelocArr", "text",  Svel
  cabbageSet "BassArr", "text",  Sbss
  cabbageSet "RepArr", "text",  Srp
  SseqIn cabbageGet  "SeqArr"
  SvelIn cabbageGet  "VelocArr"
  SbssIn cabbageGet  "BassArr"
  SrpIn  cabbageGet  "RepArr"
  if changed(SseqIn) == 1 then
  schedulek "StrngSeq",0,0.1,SseqIn
;  elseif changed(SvelIn) == 1 then
;  schedulek "StrngVel",0,0.1,SvelIn
;  elseif changed(SbssIn) == 1 then
;  schedulek "StrngBass",0,0.1,SbssIn
;  elseif changed(SrpIn) == 1 then
;  schedulek "StrngRep",0,0.1,SrpIn
  endif
;printk2 kSeqOnOff
endin

instr Empty ;7
 giArrNote [] = giArrEmpty
 giNote    [] = giArrEmpty
endin

instr StrngSeq
 SIn = p4
giArrSeq  [] StrToArr SIn
giArrSeqP [] StrToArr SIn
giLenSeq lenarray giArrSeqP
Sscale     sprintf "text(Seq: %s)",SIn
  ;puts Sscale,1
  Sprint init ""
  Sprint strcat Sprint, Sscale
 cabbageSet 1, "SeqArRy",Sprint
endin
instr StrngVel
 SIn = p4
giArrVel [] StrToArr SIn
endin
instr StrngBass
 SIn = p4
giArrBass [] StrToArr SIn
endin
instr StrngRep
 SIn = p4
giArrRep [] StrToArr SIn
endin

instr putstrng
 Sout ArrToStrg giArrSeqP
 Sscale     sprintf "text(Seq: %s)",Sout
  ;puts Sscale,1
  Sprint init ""
  Sprint strcat Sprint, Sscale
 cabbageSet 1, "SeqArRy",Sprint
endin

</CsInstruments>
<CsScore>
i "Widgets" 0 9999
</CsScore>
</CsoundSynthesizer>

