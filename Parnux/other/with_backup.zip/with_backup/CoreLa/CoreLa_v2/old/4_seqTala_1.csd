<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0


opcode ArrTala, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr [] init iLen
 iRead = 0
 iWrite = iTalaCount
 while iRead < iLen do
 	iOutArr [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% iLen
 od
 xout iOutArr
endop
opcode ArrRep, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr[] init  iLen+1
 iRead = 0
 iWrite = 0
 while iRead < iLen+1 do
 iOutArr [iRead] = iInArr [iWrite]
 	if iRead != iTalaCount then
 	iWrite += 1
 	endif
 iRead += 1
 od
 iOutArr[iTalaCount+1] = iInArr[iTalaCount]
 xout iOutArr
endop
opcode ArrPlus, i[], i[]i
 iInArr[],iElm xin
 iLen lenarray iInArr
 iOutArr[] = iInArr
 iAdd = int(random:i( 1,4))
 iMines = random:i( 0,100) > 50 ? 1: -1
 iOutArr [iElm] = iInArr [iElm] + (iAdd*iMines)	
		 iOutArr[iElm] = ( iOutArr[iElm] < 1 ) ? 
 		 iInArr[iElm] :  iOutArr[iElm]
 xout iOutArr
endop
opcode ArrChng, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] = iInArr
 indx = 0 
 while indx < iLen do
 iAdd random  0, 3
 iMines = random:i( 0,100) > 50 ? 1: -1
 iOutArr [indx] = iInArr [indx] + (iAdd*iMines)
 		 iOutArr[indx] = ( iOutArr[indx] < 1 ) ? 
 		 iInArr[indx] :  iOutArr[indx]
 indx += 1
 od
 xout iOutArr
endop




instr RySeq
kTime init 0
kTimeB init 0
giArrSeq [] fillarray 1,2,1,2,2,1,4
giArrSeqP [] = giArrSeq
iLenSeq lenarray giArrSeq
kSeqIndx init 0
iTempo = 90
iBPM = iTempo/60
iTms = 3

giArrNote [] fillarray 60,61,62
iLenNote lenarray giArrNote
kNoteIndx init 0

;giArrBass [] init 2
giArrBass  [] slicearray giArrNote, 0,1
giArrBassQ [] fillarray 1,3,4
kTalaCount init 0
kRep init 0
if metro(kTime) == 1 then
kTime = 1/(giArrSeqP[kSeqIndx])*(iBPM)*iTms

kNote = giArrNote[kNoteIndx]
schedulek 2,0,0.1,kNote
	kndxB = 0
	while kndxB < lenarray(giArrBassQ) do
		if kSeqIndx == giArrBassQ [kndxB]  then
		schedulek 2,1/(iBPM*iTms),0.1,kNote-10
		endif
	kndxB += 1
	od
kSeqIndx = (kSeqIndx+1) % (iLenSeq+kRep)
		if kSeqIndx == 0 then
		schedulek 3,0,0.1,kTalaCount
		kTalaCount = (kTalaCount+1) % iLenSeq
		;kRep = 1
		endif
kNoteIndx = (kNoteIndx+1) % iLenNote
endif

endin

instr 2
iFrq mtof p4

aEnv linseg 0, 0.005, 0.3, p3-0.005, 0
a1 poscil aEnv, iFrq*4
out a1,a1
endin

instr 3
iTala = p4
;giArrSeqP [] ArrTala giArrSeq, iTala
;giArrSeqP [] ArrRep giArrSeq, iTala
;giArrSeqP [] ArrPlus giArrSeq, iTala
;giArrSeqP [] ArrChng giArrSeq
printarray giArrSeqP, "%.2f"
endin

</CsInstruments>
<CsScore>
i1 0 999
;i 2 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
