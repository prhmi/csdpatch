<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

seed 0 

instr 1
iArrNote [] genarray 60, 72
;rintarray iArrNote,"%d"
kndx init 0
kNote init 65
if metro(4) == 1 then
schedulek 2,0,2,iArrNote [kndx]
kNote random 65, 75
kndx = (kndx+1) % lenarray(iArrNote)
;printk2 kndx
endif
endin
		
instr 2
iSqr	ftgen	 1,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180

iMidiNote = p4
iMidi = iMidiNote
iOct = 0
iBaseNote = 5
     until iMidi < iBaseNote+12 do
  		iMidi = iMidi-12
  		iOct += 1
  		enduntil

 iMidiMin = (iMidi-iBaseNote);+(iOct*12)
;     until iMidiMin < 12 do
;  		iMidiMin = iMidiMin-12
;  		enduntil
; print iMidiMin
  	iRatio = 1
  	if iMidiMin == 0 then
  	iRatio = 1/1
  	elseif iMidiMin == 1 then
  	iRatio = 2187/2048
  	elseif iMidiMin == 2 then
  	iRatio = 9/8
  	elseif iMidiMin == 3 then
  	iRatio = 32/27
  	elseif iMidiMin == 4 then
  	iRatio = 81/64
  	elseif iMidiMin == 5 then
  	iRatio = 4/3
  	elseif iMidiMin == 6 then
  	iRatio = 729/512
  	elseif iMidiMin == 7 then
  	iRatio = 3/2
  	elseif iMidiMin == 8 then
  	iRatio = 6561/4096
  	elseif iMidiMin == 9 then
  	iRatio = 27/16
  	elseif iMidiMin == 10 then
  	iRatio = 16/9
  	elseif iMidiMin == 11 then
  	iRatio = 243/128
  	elseif iMidiMin == 12 then
  	iRatio = 2/1
  	endif
; iRatio = iRatio + iOct 
 ;print iRatio	
iBaseFrq mtof iBaseNote+(iOct*12)
iFrq1 = (iBaseFrq)*iRatio
;print iFrq1	
iFrq2 mtof p4;+9)+(5*12)

print iFrq1,iFrq2
fprints "frq.txt", "Equal = %.3f, ratio = %.3f\n",iFrq1,iFrq2
aSine1 poscil 0.3, iFrq1, iSqr
aSine2 poscil 0.3, iFrq2, iSqr
aSine = aSine1+aSine2
iAtt = 0.005
aEnv transeg 0, iAtt,2, 1, (p3/20)-iAtt, -2, 0

aFilter clfilt aSine, 800+(iFrq1), 0, 10
aSound = aFilter*aEnv
aRv,aRv reverbsc aSound,aSound, 0.45, 400
aout ntrpol aSound,aRv,0.5
out aout,aout
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
