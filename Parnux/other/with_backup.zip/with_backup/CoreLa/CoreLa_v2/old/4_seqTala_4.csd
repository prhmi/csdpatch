<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0


opcode ArrTala, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr [] init iLen
 iRead = 0
 iWrite = iTalaCount
 while iRead < iLen do
 	iOutArr [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% iLen
 od
 xout iOutArr
endop
opcode ArrRep, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr[] init  iLen+1
 iRead = 0
 iWrite = 0
 while iRead < iLen+1 do
 iOutArr [iRead] = iInArr [iWrite]
 	if iRead != iTalaCount then
 	iWrite += 1
 	endif
 iRead += 1
 od
 iOutArr[iTalaCount+1] = iInArr[iTalaCount]
 xout iOutArr
endop
opcode ArrPlus, i[], i[]i
 iInArr[],iElm xin
 iLen lenarray iInArr
 iOutArr[] = iInArr
 iAdd = int(random:i( 1,4))
 iMines = random:i( 0,100) > 50 ? 1: -1
 iOutArr [iElm] = iInArr [iElm] + (iAdd*iMines)	
		 iOutArr[iElm] = ( iOutArr[iElm] < 1 ) ? 
 		 iInArr[iElm] :  iOutArr[iElm]
 xout iOutArr
endop
opcode ArrChng, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] = iInArr
 indx = 0 
 while indx < iLen do
 iAdd random  0, 3
 iMines = random:i( 0,100) > 50 ? 1: -1
 iOutArr [indx] = iInArr [indx] + (iAdd*iMines)
 		 iOutArr[indx] = ( iOutArr[indx] < 1 ) ? 
 		 iInArr[indx] :  iOutArr[indx]
 indx += 1
 od
 xout iOutArr
endop




instr RySeq
 kTime init 0
 kTimeB init 0
 giArrSeq [] fillarray 1,2,1,4,2,4
 giArrSeqP [] = giArrSeq
 iLenSeq lenarray giArrSeq
 kSeqIndx init 0
 iTempo = 90
 iBPM = iTempo/60
 iTms = 3

 giArrNote [] fillarray 64,66,64,66
 iLenNote lenarray giArrNote
 kNoteIndx init 0
 giArrBass  [] fillarray 1,3,5
 kTalaCount init 0
 kRep init 0
 if metro(kTime) == 1 then
 kTime = 1/(giArrSeqP[kSeqIndx])*(iBPM)*iTms
 kNote = giArrNote[kNoteIndx]
 schedulek 2,0,0.1,kNote
	;;Bass Seq:
	kndxB = 0
	while kndxB < lenarray(giArrBass) do
			if kSeqIndx == giArrBass [kndxB]  then
					if giArrSeqP[kSeqIndx] <= 2 then
					kRySq = 2
					kT = 1
					else
					kRySq = int(random:k(1,4))
					printk2 kRySq
						if kRySq != 3 then
						kT = int(random:k(1,3))
						endif
					endif
			kBQ = giArrSeqP[kSeqIndx]*(1/(iBPM*iTms)/4)*kRySq
					kBB = 0
					kndxBT = 0
					while kndxBT < kT do
					kNoteRnd = int(random:k( 45, 48))
					schedulek 2,kBQ+kBB,0.1, kNoteRnd
						if kRySq == 1 then
						kBB += giArrSeqP[kSeqIndx]*(1/(iBPM*iTms)/4)*2
						else
						kBB += giArrSeqP[kSeqIndx]*(1/(iBPM*iTms)/4)
						endif
					kndxBT += 1
					od
			endif	
	kndxB += 1
	od
 kSeqIndx = (kSeqIndx+1) % (iLenSeq+kRep)
 		;;Tala
		if kSeqIndx == 0 then
		schedulek 3,0,0.1,kTalaCount
		kTalaCount = (kTalaCount+1) % iLenSeq
		;kRep = 1
		endif
 kNoteIndx = (kNoteIndx+1) % iLenNote
 endif
endin

instr 2
iMidiNote = 60
iMidi = iMidiNote
iBaseNote = 0
     until iMidi < iBaseNote+24 do
  		iMidi = iMidi-12
  		enduntil
  	print iMidi
 iFrq = 500; mtof p4
 aEnv linseg 0, 0.005, 0.3, p3-0.005, 0
 a1 poscil aEnv, iFrq*4
 out a1,a1
endin

instr 3
iTala = p4
;giArrSeqP [] ArrTala giArrSeq, iTala
;giArrSeqP [] ArrRep giArrSeq, iTala
;giArrSeqP [] ArrPlus giArrSeq, iTala
;giArrSeqP [] ArrChng giArrSeq
printarray giArrSeqP, "%d"
endin

</CsInstruments>
<CsScore>
i1 0 999
;i 2 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>783</x>
 <y>186</y>
 <width>400</width>
 <height>232</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
 <bsbObject version="2" type="BSBController">
  <objectName>hor0</objectName>
  <x>93</x>
  <y>56</y>
  <width>23</width>
  <height>29</height>
  <uuid>{8faa0994-023f-4ac0-98f1-975ad1f69ffe}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <objectName2>meter0</objectName2>
  <xMin>0.00000000</xMin>
  <xMax>1.00000000</xMax>
  <yMin>0.00000000</yMin>
  <yMax>1.00000000</yMax>
  <xValue>0.00000000</xValue>
  <yValue>1.00000000</yValue>
  <type>fill</type>
  <pointsize>1</pointsize>
  <fadeSpeed>0.00000000</fadeSpeed>
  <mouseControl act="press">jump</mouseControl>
  <bordermode>noborder</bordermode>
  <borderColor>#00FF00</borderColor>
  <color>
   <r>0</r>
   <g>234</g>
   <b>0</b>
  </color>
  <randomizable mode="both" group="0">false</randomizable>
  <bgcolor>
   <r>30</r>
   <g>30</g>
   <b>30</b>
  </bgcolor>
  <bgcolormode>true</bgcolormode>
 </bsbObject>
 <bsbObject version="2" type="BSBController">
  <objectName>hor1</objectName>
  <x>121</x>
  <y>56</y>
  <width>23</width>
  <height>29</height>
  <uuid>{8af272e8-0121-4864-bcbc-15f2cb305e98}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>0</midicc>
  <description/>
  <objectName2>meter1</objectName2>
  <xMin>0.00000000</xMin>
  <xMax>1.00000000</xMax>
  <yMin>0.00000000</yMin>
  <yMax>1.00000000</yMax>
  <xValue>0.00000000</xValue>
  <yValue>1.00000000</yValue>
  <type>fill</type>
  <pointsize>1</pointsize>
  <fadeSpeed>0.00000000</fadeSpeed>
  <mouseControl act="press">jump</mouseControl>
  <bordermode>noborder</bordermode>
  <borderColor>#00ff00</borderColor>
  <color>
   <r>0</r>
   <g>234</g>
   <b>0</b>
  </color>
  <randomizable mode="both" group="0">false</randomizable>
  <bgcolor>
   <r>30</r>
   <g>30</g>
   <b>30</b>
  </bgcolor>
  <bgcolormode>true</bgcolormode>
 </bsbObject>
</bsbPanel>
<bsbPresets>
</bsbPresets>
