<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

seed 0 

instr 1
giTableSize = 2048

gisine		ftgen 2, 0, 2048, 10,1, 4, 3

iFrq = int(random:i( 60, 80))
iFrq mtof iFrq
kpw = .5
a1 vco2 50, iFrq,gisine, kpw
;a1 vco2ft iFrq, itmp
iAtt = 0.001
aEnv linseg 0, iAtt,1,p3-iAtt, 0

aFilter clfilt a1*0.001, 1200+(iFrq), 0, 10
aout = aFilter*aEnv
out aout,aout
endin

</CsInstruments>
<CsScore>
{100 LOOP
i 1 [0.405*$LOOP] .9
}
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
