<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


opcode ArrTala, i[], i[]i
 iInArr[],iTalaCount xin
 iLen lenarray iInArr
 iOutArr [] init iLen
 iRead = 0
 iWrite = iTalaCount
 while iRead < iLen do
 	iOutArr [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% iLen
 od
 xout iOutArr
endop

instr RySeq
kTime init 0
;iArrSeq [] init 5
giArrSeq [] fillarray 1,2,3
giArrSeqP [] = giArrSeq
iLenSeq lenarray giArrSeq
kSeqIndx init 0
iTempo = 120
iBPM = iTempo/60
iTms = 2

giArrNote [] fillarray 60,61,62
iLenNote lenarray giArrNote
kNoteIndx init 0


kTalaCount init 0

if metro(kTime) == 1 then
kTime = 1/(giArrSeqP[kSeqIndx])* (iBPM) * iTms
kNote = giArrNote[kNoteIndx]
schedulek 2,0,0.1,kNote
kSeqIndx = (kSeqIndx+1) % iLenSeq
		if kSeqIndx == 0 then
		schedulek 3,0,0.1,kTalaCount
		kTalaCount = (kTalaCount+1) % iLenSeq
		endif
kNoteIndx = (kNoteIndx+1) % iLenNote
endif

endin


instr 2
print p4
endin

instr 3
iTala = p4
giArrSeqP [] ArrTala giArrSeq, iTala
printarray giArrSeqP, "%d"
endin

</CsInstruments>
<CsScore>
i1 0 999
;i 2 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
