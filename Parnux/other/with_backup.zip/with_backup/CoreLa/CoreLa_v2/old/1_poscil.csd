<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

seed 0 


		
instr 1
iSqr	ftgen	 1,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180

iFrq = int(random:i( 55, 90))
iFrq mtof iFrq
aSine poscil 0.1, iFrq, iSqr
iAtt = 0.005
aEnv transeg 0, iAtt,2, 1, (p3/7)-iAtt, -2, 0

aFilter clfilt aSine, 500+(iFrq), 0, 10
aSound = aFilter*aEnv
aRv,aRv reverbsc aSound,aSound, 0.45, 400
aout ntrpol aSound,aRv,0.5
out aout,aout
endin

</CsInstruments>
<CsScore>
{100 LOOP
i 1 [0.405*$LOOP] 1
}
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
