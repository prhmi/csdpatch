<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

seed 0 

instr 1
iArrNote [] genarray 69, 81
;rintarray iArrNote,"%d"
kndx init 0
kNote init 65
if metro(3) == 1 then
schedulek 2,0,2,iArrNote [kndx]
kNote random 65, 75
kndx = (kndx+1) % lenarray(iArrNote)
;printk2 kndx
endif
endin
		
instr 2
iSqr	ftgen	 1,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180

iMidiNote = p4
iMidi = iMidiNote
iBaseNote = 9
iBaseFrq mtof iBaseNote
iOct = 0
     until iMidi < 12 do
  		iMidi = iMidi-12
  		iOct += 1
  		enduntil
  		;print iMidi
;print iOct
iNotes = (iMidi-iBaseNote)+(iOct*12)
;print iNotes
iModLong = 12

;print iBaseFrq
iFrq1 = (iBaseFrq*2^(iNotes/iModLong))
	
iFrq2 mtof p4

print iFrq1,iFrq2,iNotes
fprints "frq.txt", "Equal = %.3f, ratio = %.3f\n",iFrq1,iFrq2
aSine poscil 0.3, iFrq1, iSqr
iAtt = 0.005
aEnv transeg 0, iAtt,2, 1, (p3/20)-iAtt, -2, 0

aFilter clfilt aSine, 800+(iFrq1), 0, 10
aSound = aFilter*aEnv
aRv,aRv reverbsc aSound,aSound, 0.45, 400
aout ntrpol aSound,aRv,0.5
out aout,aout
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>8</x>
 <y>31</y>
 <width>400</width>
 <height>300</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
