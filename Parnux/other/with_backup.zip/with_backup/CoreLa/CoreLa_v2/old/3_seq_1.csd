<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



instr RySeq
kTime init 0
;iArrSeq [] init 5
giArrSeq [] fillarray 1,1,2
iLenSeq lenarray giArrSeq
kSeqIndx init 0
iTempo = 80
iBPM = iTempo/60

if metro(kTime) == 1 then
kTime = 1/(giArrSeq[kSeqIndx])* (iBPM)
schedulek 2,0,0.1
kSeqIndx = (kSeqIndx+1) % iLenSeq
endif

endin


instr 2
print p2
endin
</CsInstruments>
<CsScore>
i1 0 999
;i 2 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
