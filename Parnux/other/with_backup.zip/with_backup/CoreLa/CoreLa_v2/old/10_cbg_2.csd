
<Cabbage>
form caption("CoreLa") size(250, 340), pluginId("crla") style("legacy")

;;Sequencer
groupbox bounds(0, 0, 250, 260), plant("seq") , text("sequencer") {
label    bounds(35, 35, 40, 12) text("On/Off") channel("label6")
checkbox bounds(10, 30, 20, 20) colour:0(100, 100, 100, 255) popupText("Start")  channel("sq") colour:1(100, 250, 60, 255)
checkbox bounds(12, 60, 15, 15) colour:0(100, 100, 100, 255) popupText("Hold")  channel("hold") colour:1(100, 250, 60, 255)
label    bounds(35, 62, 30, 12) text("Hold") channel("label9")
nslider  bounds(90, 35, 40, 31) range(50, 180, 90, 1, 1)  fontColour(208, 157, 253, 255) text("BPM") channel("BPM") identChannel("BPMID")
nslider  bounds(130, 35, 30, 31) range(1, 10, 4, 1, 1)  fontColour(208, 157, 253, 255) text("DV") channel("DV") identChannel("DVID")
combobox bounds(165, 30, 65, 25) text("Indian", "Tala", "Tala Rep", "Tala Plus", "Tala Change") channel("tala") 
hslider bounds(70, 93, 150, 28) range(0.05, 2, 0.7, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) channel("dur")
label    bounds(10, 100, 50, 12) text("Duration") channel("label14")
texteditor bounds(40, 125, 200, 20) channel("SeqArr") colour(180, 140, 250, 150) colour:0(180, 140, 250, 150)
label      bounds(0, 127, 50, 12) text("seq") channel("label16")
texteditor bounds(40, 150, 200, 20) channel("VelocArr") colour(180, 140, 250, 150) colour:0(180, 140, 250, 150)
label      bounds(0, 152, 50, 12) text("vel") channel("label18")
texteditor bounds(40, 175, 80, 20) channel("BassArr") colour(180, 140, 250, 150) colour:0(180, 140, 250, 150)
label      bounds(0, 177, 50, 12) text("Bss") channel("label20")
texteditor bounds(40, 200, 80, 20) channel("RepArr") colour(180, 140, 250, 150) colour:0(180, 140, 250, 150)
label      bounds(0, 202, 50, 12) text("Rep") channel("label22")
}
groupbox bounds(0, 260, 250, 80) plant("synth") text("Synth"){
label    bounds(35, 32, 40, 12) text("On/Off")
checkbox bounds(10, 30, 15, 15) colour:0(100, 100, 100, 255) popupText("Synth")  channel("dng") colour:1(100, 250, 60, 255)
combobox bounds(100, 30, 65, 25) text("Scale", "Tala", "TalaRep", "TalaPlus", "TalaPlusR", "TalaPlusJ") channel("scale") 
}
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0


#include "opcodes.udo"

giArrNote [] init 6
giNote [] init 1
giWriteNote  init 0


instr GetMidi ;1
 iActive1 active 1
 kRel release
 iNum notnum
 iVel veloc 0,127
 schedule "WriteMidi",0,.1,iNum,iVel
 	if kRel == 1 && changed(kRel) == 1 then
 	schedulek "WriteMidi", 0, .1,iNum,0
 	endif
endin
instr WriteMidi ;2
 iActive1 active 1
 iNote = p4
 iVel = p5
 iLen lenarray giArrNote
 ;prints "note: %d, veloc: %d\n", iNote,iVel
 if iVel != 0 then
		while giArrNote [giWriteNote] != 0 do
		giWriteNote += 1
		od
		;print giWriteNote
 giArrNote [giWriteNote] = iNote
 ;giWriteNote = (giWriteNote+1) % iLen
 elseif iVel == 0 then
		indxw = 0
		while indxw < iLen do
			if giArrNote [indxw] == iNote then
			giArrNote [indxw] = 0
			giWriteNote = indxw-1
			endif
		indxw += 1
		od
 giWriteNote = (giWriteNote-1) <= 0 ? 0 : giWriteNote
 ;print giWriteNote
 endif
			if iActive1 == 0 then
			giWriteNote = 0
			endif
 giNote [] RmvZ giArrNote
 giLenNote lenarray giNote
 ;printarray giArrNote,"%d", "Array:"
 printarray giNote,"%d","Note:"
endin


instr RySeq ;3
 kActive1 active 1
 kTime init 0
 kTimeB init 0
 giArrSeq [] fillarray 1,2,3,1,2,2,4
 giArrSeqP [] = giArrSeq
 iLenSeq lenarray giArrSeq
 kSeqIndx init 0
 iTempo cabbageGetValue "BPM"; 90
 iBPM = iTempo/60
 iTms cabbageGetValue "DV" ;4

 ;giArrNote [] fillarray 61,62,60,65,67
 ;iLenNote lenarray giArrNote
 kNoteIndx init 0
 giArrBass  [] fillarray 1,3,7
 giArrRep   [] fillarray 2
 kTalaCount init 0
 kRep init 0
 if metro(1/kTime) == 1 then
 kTime = (giArrSeqP[kSeqIndx])/(iBPM*iTms)
 kNoteIndx = (kNoteIndx+1) % giLenNote
 kNote = giNote[kNoteIndx]
 schedulek "Sound",0,0.2,kNote
	;;Rep Seq:
	kndxRepCh = 0
	while kndxRepCh < lenarray(giArrRep) do
			if kSeqIndx == giArrRep[kndxRepCh] then
			 kTrigRep = 0
			 kRepR = ((int(random:k(0,16)))/4)+0.5
						until kTrigRep > .08 do
						kRepT = giArrSeqP[kSeqIndx]*kRepR
  						kRepR = kRepR-.25
  						kTrigRep = kTime/kRepT
  						enduntil
  								until kTrigRep < .3 do
								kRepT = giArrSeqP[kSeqIndx]*kRepR
  								kRepR = kRepR+.25
  								kTrigRep = kTime/kRepT
  								enduntil
					kndxRep = 1
				;	printks "%.3f %.2f\n",-1,kTrigRep,kRepR
					while kndxRep < kRepT do
						;schedulek "Sound",kTrigRep,0.1,kNote
						kTrigRep += kTime/kRepT
						kndxRep += 1
					od			
			endif
	kndxRepCh += 1
	od
;;Bass
	kndxB = 0
	while kndxB < lenarray(giArrBass) do
			if kSeqIndx == giArrBass[kndxB] then
							kNoteBass = giArrNote[0]
					    	until kNoteBass < 45 do
  							kNoteBass = kNoteBass-12
  							enduntil
					if giArrSeqP [kSeqIndx] <= 2 then
					kTrigBass = kTime/2
					else
					kRndBass = int(random:k(1,4))
					kTrigBass = (kTime/4)*kRndBass
							if kRndBass == 1 then
								kndxRB = 0
								while kndxRB < int(random:k(0,2)) do
								;schedulek "Sound",kTrigBass*int(random:k(2,4)),.1,kNoteBass
								kndxRB += 1
								od
							endif
					endif
			;schedulek "Sound",kTrigBass,.1,kNoteBass
			endif
	kndxB += 1
	od
 if kActive1 == 0 then
 kSeqIndx = 0
 else
 kSeqIndx = (kSeqIndx+1) % (iLenSeq+kRep)
 endif
 		;;Tala
		if kSeqIndx == 0 then
		schedulek "tala",0,0.1,kTalaCount
		kTalaCount = (kTalaCount+1) % iLenSeq
		;kRep = 1
		endif
 endif
 printk2 kSeqIndx
endin


instr tala ;4
iTala = p4
;giArrSeqP [] ArrTala giArrSeq, iTala
;giArrSeqP [] ArrRep giArrSeq, iTala
;giArrSeqP [] ArrPlus giArrSeq, iTala
;giArrSeqP [] ArrChng giArrSeq
;printarray giArrSeqP, "%d"
endin


instr Sound ;5
iMidiNote = p4
iBaseNote  ntom "0C"
iFrq pythagorean iBaseNote-12,iMidiNote
  	
 aEnv linseg 0, 0.005, 0.3, p3-0.005, 0
 a1 poscil aEnv, iFrq*4
 out a1,a1
endin

instr test
 if metro(2) == 1 then
 schedulek "Sound",0,0.2,65
 endif
endin

instr Widgets
kSeqOnOff cabbageGet "sq"
if kSeqOnOff == 1 && changed(kSeqOnOff) == 1 then
schedulek "RySeq",0,-1
elseif kSeqOnOff == 0 && changed(kSeqOnOff) == 1 then
turnoff2 "RySeq",0,0
endif
kBPM cabbageGet "BPM"
kDV cabbageGet "DV"
kTtrig changed kBPM,kDV
if kTtrig == 1 then
turnoff2 "RySeq",0,0
schedulek "RySeq",0.01,-1
endif
printk2 kSeqOnOff
endin

</CsInstruments>
<CsScore>
i "Widgets" 0 9999
;i3 0 999
;i 2 0 999
</CsScore>
</CsoundSynthesizer>

