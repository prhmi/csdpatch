<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

giArrNote [] init 5
gindx init 0




instr 1
iActive1 active 1
kRel release
iNum notnum
iVel veloc 0,127
schedule 2,0,0.1,iNum,iVel
if kRel == 1 && changed(kRel) == 1 then
schedulek 2, 0, 0.1,iNum,0
endif
endin



instr 2
iNote = p4
iVel = p5
iLen lenarray giArrNote
;prints "note: %d, veloc: %d\n", iNote,iVel
if iVel != 0 then
		while giArrNote [gindx] != 0 do
			gindx += 1
		od
giArrNote [gindx] = iNote
gindx = (gindx+1) % iLen
elseif iVel == 0 then

	indxw = 0
	while indxw < iLen do
		if giArrNote [indxw] == iNote then
		giArrNote [indxw] = 0
		gindx = indxw-1
		endif
	indxw += 1
	od
;gindx -= 1
;if gindx <= 0 then
;gindx = 0
;endif
gindx = (gindx-1) <= 0 ? 0 : gindx
endif
;gindx = indxw-1

;printarray giNoteIn,"%d"
printarray giArrNote,"%d"
endin
</CsInstruments>
<CsScore>
;i1 0 1
;i 2 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>100</x>
 <y>100</y>
 <width>320</width>
 <height>240</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
