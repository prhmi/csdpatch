<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

seed 0 

instr 1
iArrNote1 [] fillarray 1, 5/4, 4/5
iArrNote2 [] fillarray 69, 73, 65
;rintarray iArrNote,"%d"
kndx init 0
kNote init 65
if metro(1) == 1 then
schedulek 2,0,2,iArrNote1 [kndx],1
schedulek 2,0,2,iArrNote2 [kndx],2
kNote random 65, 75
kndx = (kndx+1) % lenarray(iArrNote1)
;printk2 kndx
endif
endin
		
instr 2
iSqr	ftgen	 1,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180

iNotes = p4
;print iNotes
iModLong = 12

iBaseFrq = 440
if p5 == 1 then
iRatio = p4
iFrq1 = (iBaseFrq*iRatio)
elseif p5 == 2 then
iFrq1 mtof p4
endif
print iFrq1
aSine poscil 0.3, iFrq1, iSqr

iAtt = 0.005
aEnv transeg 0, iAtt,2, 1, (p3/20)-iAtt, -2, 0

aFilter clfilt aSine, 800+(iFrq1), 0, 10
aSound = aFilter*aEnv
aRv,aRv reverbsc aSound,aSound, 0.45, 400
aout ntrpol aSound,aRv,0.5
out aout,aout
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
