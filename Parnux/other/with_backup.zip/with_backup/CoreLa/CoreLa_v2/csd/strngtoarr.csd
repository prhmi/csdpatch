<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

opcode StrToArr, i[],S
SIn xin

iArrOut [] init 10
iArrRead [] init 10

iLen strlen SIn
iRead = 0
iWrite = 0
indx = 0
;iArr [] fillarray 0,3,5,9,11,0,0,0,0,0,0,0,0,0,0,0,0
while indx < iLen do
iCountChr = 0
	until strchar(SIn,indx) == 32 do
	indx += 1
	iCountChr += 1
	od
	
iRead += 1
;indx = iArr[iRead]
indx = (indx+1); % iLen
	print iCountChr,indx
;print iCountChr,iWrite
od

;printarray iArrRead, "%d"
xout iArrOut
endop


instr 1
  Sseq  = "23 6 333 1 22 "
giArrSeq [] StrToArr Sseq
  ;schedule 3,0.1,0.1
endin


</CsInstruments>
<CsScore>
i1 0 1
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
