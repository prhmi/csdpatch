<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

seed 63

instr 1
gitest = int(random:i( 40, 50))

endin


instr 2
;printk2 gktest
if changed(gitest) == 1 then
kRnd random 40, 80
endif
printk2 kRnd
endin

</CsInstruments>
<CsScore>
i1 0 .5
i1 + .5
i1 + .5
i1 + .5
i1 + .5

i2 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
