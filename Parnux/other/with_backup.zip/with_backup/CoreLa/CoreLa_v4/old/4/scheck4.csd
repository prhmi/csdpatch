<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



opcode rmvtxt, S,S
Sin xin
iLen strlen Sin
iArrChk[] fillarray 32,48,49,50,51,52,53,54,55,56,57
iNum1 strchar Sin, 0
iNum2 strchar Sin, iLen-1
	indxChk = 0
	iStartLetter = 0
	iEndLetter = 0
	while indxChk < lenarray(iArrChk) do
		if iNum1 == iArrChk[indxChk]  then
		iStartLetter += 1
		endif
		if iNum2 == iArrChk[indxChk]  then
		iEndLetter += 1
		endif
	indxChk += 1
	od
	if iStartLetter == 1 then
	iRmvStart = 0
	elseif iStartLetter == 0 then
	iRmvStart = 1
	endif	
	if iEndLetter == 1 then
	iRmvEnd = 0
	elseif iEndLetter == 0 then
	iRmvEnd = 1
	endif
Sout strsub Sin, iRmvStart, iLen-iRmvEnd
xout Sout
endop



instr 1
Sin = "e121"
Sout rmvtxt Sin
	puts Sout,1
endin

</CsInstruments>
<CsScore>
i1 0 1
</CsScore>
</CsoundSynthesizer>


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
