<Cabbage> bounds(0, 0, 0, 0)
form caption("Presets") size(700, 400), guiMode("queue"), colour(58, 110, 182), pluginId("MPre")
keyboard bounds(10, 90, 345, 95)
rslider bounds(12, 8, 85, 79), channel("att"), range(0, 1, 0.01), text("Att.")
rslider bounds(98, 8, 85, 79), channel("dec"), range(0, 1, 0.4), text("Dec.")
rslider bounds(184, 8, 85, 79), channel("sus"), range(0, 1, 0.7), text("Sus.")
rslider bounds(270, 8, 85, 79), channel("rel"), range(0, 1, 0.8), text("Rel.")
combobox bounds(74, 190, 100, 25), populate("*.snaps"), channelType("string")
filebutton bounds(12, 190, 60, 25), text("Save"), populate("*.snaps", "test"), mode("named preset")
filebutton bounds(12, 220, 60, 25), text("Remove"), populate("*.snaps", "test"), mode("remove preset")
nslider bounds(484, 68, 128, 54) channel("nslider10008") range(0, 100, 0, 1, 0.01)
texteditor bounds(473, 223, 199, 30) channel("seq") text("")
hslider bounds(105, 328, 252, 47) channel("out1") range(0, 1, 0, 1, 0.001)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 -n -d -+rtmidi=NULL -M0 --midi-key-cps=4 --midi-velocity-amp=5
</CsOptions>
<CsInstruments>
; Initialize the global variables. 
;sr is set by the host
ksmps = 32
nchnls = 2
0dbfs = 1



gkSpeaker1 init 0
gkSpeaker2 init 0
gkSpeaker3 init 0
gkSpeaker4 init 0


;massign 1,0

instr 1

i1 midichn
   print i1

iMidi notnum
iVel veloc 10, 200
;print iVel
iSpeed = iVel; 20
iStart1 = i(gkSpeaker1)
iStart2 = i(gkSpeaker2)
iStart3 = i(gkSpeaker3)
iStart4 = i(gkSpeaker4)

iBaseMidi = 60


if iMidi == iBaseMidi then
gkSpeaker1 line iStart1, 1/iSpeed, iStart1-1
elseif iMidi == iBaseMidi+2 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1+1))
endif
if iMidi == iBaseMidi+4 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2-1))
elseif iMidi == iBaseMidi+5 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2+1))
endif
if iMidi == iBaseMidi+7 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3-1))
elseif iMidi == iBaseMidi+9 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3+1))
endif
if iMidi == iBaseMidi+11 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4-1))
elseif iMidi == iBaseMidi+12 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4+1))
endif
cabbageSetValue  "out1", gkSpeaker1/127
cabbageSetValue  "outn1", gkSpeaker1
cabbageSetValue  "out2", gkSpeaker2+65
cabbageSetValue  "outn2", gkSpeaker2
cabbageSetValue  "out3", gkSpeaker3+65
cabbageSetValue  "outn3", gkSpeaker3
cabbageSetValue  "out4", gkSpeaker4+65
cabbageSetValue  "outn4", gkSpeaker4
endin


instr 2
k1,k2,k3,k4 midiin
;printk2 k4


endin

schedule 2, 0, 999

</CsInstruments>
<CsScore>
;causes Csound to run for about 7000 years...
i1 0 z
</CsScore>
</CsoundSynthesizer>