<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1







instr 1
Sin = "e121"

iLen strlen Sin
iArrChk[] fillarray 32,48,49,50,51,52,53,54,55,56,57

iNum1 strchar Sin, 0
iNum2 strchar Sin, iLen-1
print iNum1, iNum2



	indxChk = 0
	iStartLetter = 0
	iEndLetter = 0
	while indxChk < lenarray(iArrChk) do
		if iNum1 == iArrChk[indxChk]  then
		iStartLetter += 1
		endif
		if iNum2 == iArrChk[indxChk]  then
		iEndLetter += 1
		endif
	indxChk += 1
	od
	print iStartLetter
	if iStartLetter == 1 then
	iRmvStart = 0
	elseif iStartLetter == 0 then
	iRmvStart = 1
	endif
	
	if iEndLetter == 1 then
	iRmvEnd = 0
	elseif iEndLetter == 0 then
	iRmvEnd = 1
	endif
;	
			Svalue strsub Sin, iRmvStart, iLen-iRmvEnd
;		else
;		Svalue = Sin
	puts Svalue,1
;	print iCountValue 
iNum strchar "1 0", 1 ;48-57
;print iNum
;Sout stringCheck Sin
S1 = "j5"
S2 = "2"
S3	    strcat   S1, S2
;puts S3, 1

endin

</CsInstruments>
<CsScore>
i1 0 1
</CsScore>
</CsoundSynthesizer>


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
