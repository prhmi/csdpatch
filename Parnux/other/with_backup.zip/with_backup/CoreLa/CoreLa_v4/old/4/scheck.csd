<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1







instr 1
Sin = "1 2 3 4"

iLen strlen Sin
Sarr[] init iLen
iArrChk[] fillarray 32, 48,49,50,51,52,53,54,55,56,57
indx = 0 
while indx < iLen do
iNum strchar Sin, indx
	indxChk = 0
	while indxChk < lenarray(iArrChk) do
	if iArrChk[indxChk] == iNum then
	Svalue strsub Sin, indx, indx+1
	Sarr[indx] = Svalue
	endif
	indxChk += 1
	od
indx += 1
od


printarray Sarr, 1


iNum strchar "1 0", 1 ;48-57
;print iNum
;Sout stringCheck Sin
S1 = "j5"
S2 = "2"
S3	    strcat   S1, S2
;puts S3, 1

endin

</CsInstruments>
<CsScore>
i1 0 1
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
