;v4
<Cabbage>
form caption("CoreLa")    size(900, 500)   guiMode("queue") colour(10,45,35) pluginId("crla") ; style("legacy")

image bounds(428, 117, 15, 15) channel("metronom") colour(10, 10, 10, 255)

texteditor bounds(46, 115, 249, 20) channel("seqarr") colour:0(71, 137, 100, 255)fontSize(20) text("1 1 2 1 2 4") colour(71, 137, 100, 255)


combobox bounds(458, 112, 77, 25)   channel("BNote")   text("Note", "G", "A-", "Bb", "C", "E-", "D-", "F", "A", "B", "Gb", "D")  colour(49, 79, 62, 255)  value(2)
combobox bounds(426, 86, 109, 25)   channel("scale")   text("Scale", "pythagorean", "shur", "abuata", "bayat tork", "afshari", "dashti", "nava", "segah", "chargah", "homayun", "bayat esf") colour(49, 79, 62, 255) value(2) 
combobox bounds(458, 140, 77, 25)   channel("instrmod")   text("Instr", "sine1", "sine2", "sine3")  colour(49, 79, 62, 255)  value(2)


vslider bounds(620, 342, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(71, 137, 100, 255) 
vslider bounds(662, 342, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(0)
vslider bounds(702, 342, 50, 150) channel("out3") range(0, 80, 0, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(0)
vslider bounds(744, 342, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(0)
nslider bounds(794, 274, 93, 44) channel("gain") range(-90, 50, 0, 1, 1) colour(49, 79, 62, 255) text("Master Gain (dB)")
hslider bounds(46, 172, 238, 40) channel("dur") range(0.1, 10, 1, 1, 0.1) trackerColour(71, 137, 100, 255) valueTextBox(0)
hslider bounds(46, 194, 238, 40) channel("att") range(0.001, 1, 0.01, 1, 0.001) trackerColour(71, 137, 100, 255) valueTextBox(0)
hslider bounds(46, 250, 238, 40) channel("pos") range(0.3, 2, 1, 1, 0.01) trackerColour(71, 137, 100, 255) 
hslider bounds(62, 276, 222, 40) channel("spdstrngmin") range(0.7, 5, 2, 1, 0.1) trackerColour(71, 137, 100, 255) valueTextBox(0)
hslider bounds(65, 302, 219, 40) channel("spdstrngmax") range(1, 12, 5, 1, 0.01) trackerColour(71, 137, 100, 255) valueTextBox(0)
hslider bounds(65, 342, 219, 40) channel("pres") range(0.1, 5, 5, 1, 0.01) trackerColour(71, 137, 100, 255) valueTextBox(0)

vmeter bounds(798, 342, 15, 150) channel("meter1") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(822, 342, 15, 150) channel("meter2") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(846, 342, 15, 150) channel("meter3") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(870, 342, 15, 150) channel("meter4") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
image bounds(798, 328, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(822, 328, 15, 15) channel("clip2") colour(0,0,0)
image bounds(846, 328, 15, 15) channel("clip3") colour(0,0,0)
image bounds(870, 328, 15, 15) channel("clip4") colour(0,0,0)


label bounds(10, 118, 37, 15) channel("label1") text("seq")
combobox bounds(302, 115, 60, 20) channel("seqmod") colour(49, 79, 62, 255) text("ord", "tala", "Brk", "Rnd"), value(1)
checkbox bounds(366, 115, 20, 20) channel("hold") colour:0(99, 94, 94, 255) colour:1(71, 137, 100, 255), value(0)
label bounds(388, 117, 37, 15) channel("label2") text("hold")
nslider bounds(45, 65, 62, 49) channel("bpm") range(10, 210, 90, 1, 1) colour(71, 137, 100, 255) fontColour(0, 0, 0, 255)
nslider bounds(128, 84, 31, 30) channel("dv") range(1, 16, 4, 1, 1) colour(71, 137, 100, 255) fontColour(0, 0, 0, 255)
label bounds(112, 96, 10, 15) channel("label3") text("x")
label bounds(12, 184, 32, 16) channel("label4") text("dur")
label bounds(302, 182, 59, 18) channel("label5") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(12, 208, 32, 16) channel("label6") text("att")
label bounds(302, 206, 59, 18) channel("label7") text("CC-11") fontColour(224, 219, 219, 255)
label bounds(352, 76, 70, 33) channel("noteshow")  fontColour(135, 226, 127, 255) colour(53, 67, 60, 255) text("")
label bounds(44, 142, 409, 25) channel("narrshow")  fontColour(135, 226, 127, 255) colour(53, 67, 60, 255) align("left")  text(" ")
label bounds(694, 8, 70, 33) channel("data")  fontColour(135, 226, 127, 255) colour(53, 67, 60, 255) text(" ")
label bounds(712, 128, 31, 26) channel("activestring")  fontColour(135, 226, 127, 255) colour(53, 67, 60, 255) text(" ")
label bounds(12, 258, 32, 16) channel("label8") text("pos")
label bounds(302, 265, 59, 18) channel("label9") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(4, 288, 57, 14) channel("label10") text("spd min")
label bounds(0, 312, 65, 13) channel("label11") text("spd max")
label bounds(302, 288, 59, 18) channel("label12") text("CC-07") fontColour(224, 219, 219, 255)
label bounds(302, 310, 59, 18) channel("label13") text("CC-15") fontColour(224, 219, 219, 255)
nslider bounds(364, 266, 64, 42) channel("cent") range(0, 500, 0, 1, 1) colour(49, 79, 62, 255) fontColour(176, 231, 182, 255) text("Vib Cent")

nslider bounds(626, 307, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(49, 79, 62, 255)
nslider bounds(666, 307, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(49, 79, 62, 255)
nslider bounds(706, 307, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(49, 79, 62, 255)
nslider bounds(746, 307, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(49, 79, 62, 255)
label bounds(654, 44, 239, 66) channel("sec") text("00 : 01") fontColour(135, 226, 127, 255)
button bounds(774, 12, 116, 27) channel("start") text("S  T  A  R  T", "S  T  O  P") colour:0(53, 67, 60, 255) colour:1(96, 69, 69, 255) value(1)
image bounds(678, 126, 32, 30) channel("padlight") corners(5) colour(53, 67, 60, 255)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0

 
opcode CsdMeter, 0, SakS
 SClip, aSig, kTrig, Smeter	xin
 iDbRange = 60
 iHoldTim = 0.5
 kOn init 0
 kTim init 0
 kStart init 0
 kEnd init 0
 kMax max_k aSig, kTrig, 1
 cabbageSetValue Smeter, kMax, metro(20)
 
 if kTrig == 1 then
 kMeter = (iDbRange + dbfsamp(kMax)) / iDbRange
  if kOn == 0 && kMax > 1 then
   kTim = 0
   kEnd = iHoldTim
   cabbageSet 1,SClip,"colour(250,0, 0)"
   kOn = 1
  endif
  if kOn == 1 && kTim > kEnd then
   cabbageSet 1,SClip,"colour(0,0,0)"
   kOn =	0
  endif
 endif
 kTim += ksmps/sr
endop

opcode countValue, i,i[]
iArrIn[] xin
iLen lenarray iArrIn
indx = 0
iCountValue = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iCountValue += 1
	endif
indx += 1
od
xout iCountValue
endop


opcode rmvZ, i[],i[]
iArrIn[] xin
iLen lenarray iArrIn
indxc = 0
iLenA = 0
while indxc < iLen do
	if iArrIn[indxc] != 0 then
	iLenA += 1
	endif
indxc += 1
od
		if iLenA == 0 then
		iLenA = 1
		endif
iArrOut[] init iLenA
indx = 0
indxw = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iArrOut[indxw] = iArrIn[indx]
	indxw += 1
	endif
indx += 1
od
xout iArrOut
endop

opcode swapArr, i[],i[]
iArrIn[] xin
iArrIn[] rmvZ iArrIn
iLen lenarray iArrIn
iArrOut[] init iLen
iWrite = 0
iRead = iLen-1
while iWrite < iLen do
iArrOut[iWrite] = iArrIn[iRead]
iWrite += 1
iRead -= 1
od
xout iArrOut
endop

opcode skpZ, i[],i[]
iArrIn[] xin
iLen lenarray iArrIn
indxc = 0
iLenA = 0
while indxc < iLen do
	if iArrIn[indxc] != 0 then
	iLenA += 1
	endif
indxc += 1
od
		if iLenA == 0 then
		iLenA = 1
		endif
iArrOut[] init iLen
indx = 0
indxw = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iArrOut[indxw] = iArrIn[indx]
	indxw += 1
	endif
indx += 1
od
xout iArrOut
endop


opcode MtoNameInt, S,i
iMidi xin 
SNoteArr[] fillarray "C", "C#", "D", "D#","E","F", "F#", "G","G#", "A", "Bb", "B"
iAraziArr[] fillarray 1, 3, 6, 8, 10
iNoteIndex = (iMidi) % 12
iNoteIndxInt = int(iNoteIndex)
iSCent = int((iMidi-int(iMidi))*100.5)
if iSCent  == 0 then
Sout sprintf "%s",SNoteArr[iNoteIndex]
elseif iSCent == 100 then
Sout sprintf "%s",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
else
		if iSCent > 50 then
		Sout sprintf "%s-",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
		elseif iSCent <= 50 then
		Sout sprintf "%s+",SNoteArr[iNoteIndex]
			indx = 0			
			while indx < lenarray(iAraziArr) do
				if iNoteIndxInt = iAraziArr[indx] then
				Sout sprintf "%s-",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
				endif
			indx += 1
			od
		endif
endif
xout Sout
endop

opcode ArrToStrgN, S,i[]
  iArrIn[] xin
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    SNote MtoNameInt iArrIn[indx]
    Sscale     sprintf "%s ", SNote
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop

opcode StrToArr, i[],S
SIn xin
Snote     sprintf "%s ",SIn
iLenStr strlen SIn
iReadChar = 0
iCountChr = 0
while iReadChar < iLenStr do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	if strchar(Snote,iReadChar) == 32 then
	iCountChr += 1
	endif
	od	
iReadChar += 1
od

iArrOut[] init iCountChr

iWrite = 0
iRead = 0
while iRead < iLenStr do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
	Schar     strsub    Snote, iStart, iStart+iCountChr
	if strchar(Schar,0) != 0 then
	inum strtod Schar
	iArrOut[iWrite] = inum
	iWrite += 1
	endif
iRead += 1
od
xout iArrOut
endop



opcode ArrTala, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] init iLen
 iRead = 0
 iWrite = 1
 while iRead < iLen do
 	iOutArr[iRead] = iInArr[iWrite]
	iRead += 1
	iWrite = (iWrite+1) % (iLen)
 od
 xout iOutArr
endop

opcode ArrFl, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] = iInArr
 iRndIndx = int(random:i(0, iLen))
 iRndFl random -0.25, 0.25
 iOutArr[iRndIndx] = iOutArr[iRndIndx]+iRndFl
 if iOutArr[iRndIndx] <= 0.75 then
 iOutArr[iRndIndx] = 0.75
 endif
 xout iOutArr
endop



opcode ArrRnd, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] init iLen
 iRead = 0
 iSeq[] fillarray 1, 2, 4
 while iRead < iLen do
    iIndxSeq = int(random:i(0,3))
 	iOutArr[iRead] = iSeq[iIndxSeq]
	iRead += 1
 od
 xout iOutArr
endop


;;scale
giScaleArr[] init 12
giShurArr[] 			fillarray 0, 1.5, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1
giAbuataArr[] 		fillarray 0, 0.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
giBayattorkArr[] 	fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5
giAfshariArr[] 		fillarray 0, 1.5,0.5, 1, 1, 1, 1, 1, 1.5,0.5, 1, 1
giDashtiArr[] 		fillarray 0, 1, 1, 1, 1, 1, 1.5,0.5,  1, 1, 1, 1
giNavaArr[] 			fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5, 1, 1
gi3gahArr[] 			fillarray 0, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1, 1
gi4gahArr[] 			fillarray 0, 1.5, 0.5, 1, 1,1, 1, 1, 1.5, 0.5, 1, 1
giHomayunArr[]   	fillarray 0, 0.5, 1, 1, 1,1, 1, 1.5, 0.5, 1, 1, 1
giBayatEsArr[]   	fillarray 0, 1,1,1, 1, 1,1,1, 1.5, 0.5, 1.5, 0.5

opcode pythagorean,i,ii
iBaseNote,iNote xin
iMidi = iNote
		iOct = 0
     until iMidi < iBaseNote+12 do
  		iMidi = iMidi-12
  		iOct += 1
  		enduntil
 iMidiMin = (iMidi-iBaseNote)
  	iRatio = 1
  	if iMidiMin == 0 then
  	iRatio = 1/1
  	elseif iMidiMin == 1 then
  	iRatio = 2187/2048
  	elseif iMidiMin == 2 then
  	iRatio = 9/8
  	elseif iMidiMin == 3 then
  	iRatio = 32/27
  	elseif iMidiMin == 4 then
  	iRatio = 81/64
  	elseif iMidiMin == 5 then
  	iRatio = 4/3
  	elseif iMidiMin == 6 then
  	iRatio = 729/512
  	elseif iMidiMin == 7 then
  	iRatio = 3/2
  	elseif iMidiMin == 8 then
  	iRatio = 6561/4096
  	elseif iMidiMin == 9 then
  	iRatio = 27/16
  	elseif iMidiMin == 10 then
  	iRatio = 16/9
  	elseif iMidiMin == 11 then
  	iRatio = 243/128
  	elseif iMidiMin == 12 then
  	iRatio = 2/1
  	endif
  	
iBaseFrq mtof iBaseNote+(iOct*12)
iFrq = (iBaseFrq)*iRatio
iMidiOut ftom iFrq
xout iMidiOut
endop


opcode dastgah, i,i[]iii
  iInArr[],iBaseMidi,iMidiIn,iQ xin
  iLen lenarray iInArr
  iOutArr[] init iLen
  iNote = iBaseMidi
  indx = 0
	while indx < iLen do
	iNote = iNote+(iInArr[indx])
	iOutArr[indx] = iNote
	indx += 1
	od
	iMidi = int(iMidiIn)+iQ
	indxOct = 0
	     until iMidi < iBaseMidi+12 do
	     indxOct += 1
  		iMidi = iMidi-12
  		enduntil
  		iIntrval = (iMidi-iBaseMidi)
iMidiOut = iOutArr[iIntrval]+(12*indxOct)
SnoteOut mton iMidiOut
  xout iMidiOut
endop













giMyset1  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
;giMyset1  ftgen		0, 0, 2^10,10,1, 0.5, 0.3
giMyset2  ftgen		0, 0, 2^10,10,1, 0.7, 0, 0.1, 0, 0, 0.3, 0, 0, 0, 0.2
giMyset3  ftgen		0, 0, 2^10, 10, 1, 1/2, 1/4, 1/6, 1/7, 0, 1/9

 massign 1,1
 massign 2,10
 massign 16,12



iLenSeq init 32
giNoteArr[] init iLenSeq
giEmpty[] init iLenSeq
giIndxNote init 0

instr GetMidi ;1
 iActive active "GetMidi"
 iHold cabbageGetValue "hold"
 kHold cabbageGet "hold"
 kRel release
 iMidi notnum
  if iActive == 1 then
  giNoteArr[] = giEmpty
  giIndxNote = 0
  endif
 
 giNoteArr[giIndxNote] = iMidi
 giIndxNote = (giIndxNote+1) % lenarray(giNoteArr)
 gkMaxIndx = giIndxNote
 iNoteArrShow[] rmvZ giNoteArr
 SnArrShow ArrToStrgN iNoteArrShow
     SnoteShow     sprintf "text(%s)", SnArrShow
    cabbageSet "narrshow",SnoteShow
; puts SnArrShow,1
; printarray iNoteArrShow,"%d","Notes:"
 
 if kRel == 1 && kHold == 0  then
 schedulek "rmvMidi", 0, 0.1, iMidi
 endif
 
endin
instr rmvMidi ;2
 iRead = 0
    while iRead < lenarray(giNoteArr) do
        if giNoteArr[iRead] == p4 then
        giNoteArr[iRead] = 0
        endif
    iRead += 1
    od
 giNoteArr skpZ giNoteArr
  iNoteArrShow[] rmvZ giNoteArr
 SnArrShow ArrToStrgN iNoteArrShow
      SnoteShow     sprintf "text(%s)", SnArrShow
    cabbageSet "narrshow",SnoteShow
; puts SnArrShow,1
 
; printarray giNoteArr,"%d","Notes(R):"
 giIndxNote -= 1
endin



instr seq
kSeqMod cabbageGet "seqmod"
SIn = p4
iSeqArr[] StrToArr SIn
giSeqArr[] = iSeqArr
kNoteIndx init 0
kSeqIndx init 0
kTime init 1
kBPM cabbageGet "bpm"
kDv cabbageGet "dv"
kDurIn cabbageGet "dur"
kTempo = (kBPM/60)*kDv
    if metro(1/kTime) == 1 then
    kDur = kTime*kDurIn
        if kNoteIndx > (gkMaxIndx-1) then
        kNoteIndx = (gkMaxIndx-1)
        endif
    kNote = giNoteArr[kNoteIndx]
    schedulek "LED",0,0.1,1
    schedulek "LED",0.1,0.1,2
        if kNote != 0 then
        schedulek "sound", 0, kDur, kNote, -15
        endif
    kSeq = giSeqArr[kSeqIndx]
    kTime = kSeq/kTempo
        if kNote != 0 && kSeq >= 2 then
        kDelay = kTime/2
           kNoteBass = kNote
			until kNoteBass < 45 do
  			kNoteBass = kNoteBass-12
  			enduntil
        schedulek "sound", kDelay, kDur*0.6, kNoteBass, -15
        endif
        if kNote != 0 && kSeq == 4 then
        kNoteRep = kNote
        kRep = int(random:k(2, 8))
		    until kNoteRep > 80 do
  			kNoteRep = kNoteRep+12
  		    enduntil
            kRepIndx = 0
            kDelay = kTime/kRep
            while kRepIndx < (kRep/2) do
            schedulek "sound",kDelay, 0.1, kNoteRep, -25
            kDelay += (kTime/kRep)
            kRepIndx += 1
            od
        endif
    kNoteIndx = (kNoteIndx+1) % giIndxNote
    kSeqIndx = (kSeqIndx+1) % lenarray(giSeqArr) 
        if kSeqIndx == 0 && kSeqMod == 2 then
        schedulek "tala", 0, 1
        elseif kSeqIndx == 0 && kSeqMod == 3 then
        schedulek "arrFL", 0, 1
        elseif kSeqIndx == 0 && kSeqMod == 4 then
        schedulek "arrRnd", 0, 1
        endif
    endif

endin



instr tala
giSeqArr[] ArrTala giSeqArr
printarray giSeqArr, "%d"
endin


instr arrFL
giSeqArr[] ArrFl giSeqArr
printarray giSeqArr, "%.2f"
endin

instr arrRnd
giSeqArr[] ArrRnd giSeqArr
printarray giSeqArr, "%d"
endin



instr LED
if p4 == 1 then
Scolor = "colour(10, 250, 10)"
elseif p4 == 2 then
Scolor = "colour(10, 10, 10)"
endif
cabbageSet 1,"metronom",Scolor
endin


instr Empty ;7
iActive = p4
    if iActive == 0 then
    giNoteArr[] = giEmpty
    SnoteShow     sprintf "text(%s)", " "
    cabbageSet "narrshow",SnoteShow
    cabbageSet "noteshow",SnoteShow
    else
    endif
endin


instr sound
iMidiNote = p4
iBaseNoteIn cabbageGetValue "BNote"

if iBaseNoteIn == 2 then
SbaseNote = "0G"
iQ = 0
elseif iBaseNoteIn == 3 then
SbaseNote = "0A-"
iQ = 1
elseif iBaseNoteIn == 4 then
SbaseNote = "0Bb"
iQ = 0
elseif iBaseNoteIn == 5 then
SbaseNote = "0C"
iQ = 0
elseif iBaseNoteIn == 6 then
SbaseNote = "0E-"
iQ = 1
elseif iBaseNoteIn == 7 then
SbaseNote = "0D-"
iQ = 1
elseif iBaseNoteIn == 8 then
SbaseNote = "0F"
iQ = 0
elseif iBaseNoteIn == 9 then
SbaseNote = "0A"
iQ = 0
elseif iBaseNoteIn == 10 then
SbaseNote = "0B"
iQ = 0
elseif iBaseNoteIn == 11 then
SbaseNote = "0Gb"
iQ = 0
elseif iBaseNoteIn == 12 then
SbaseNote = "0D"
iQ = 0
endif
iBaseNote ntom SbaseNote
iScale      cabbageGetValue "scale"
if iScale == 1 then
iMidiOut = iMidiNote
elseif iScale == 2 then
iMidiOut pythagorean iBaseNote,iMidiNote
SnoteName mton iMidiOut
elseif iScale == 3 then
iMidiOut dastgah giShurArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 4 then
iMidiOut dastgah giAbuataArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 5 then
iMidiOut dastgah giBayattorkArr,iBaseNote,iMidiNote, iQ
elseif iScale == 6 then
iMidiOut dastgah giAfshariArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 7 then
iMidiOut dastgah giDashtiArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 8 then
iMidiOut dastgah giNavaArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 9 then
iMidiOut dastgah gi3gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 10 then
iMidiOut dastgah gi4gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 11 then
iMidiOut dastgah giHomayunArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 12 then
iMidiOut dastgah giBayatEsArr,  iBaseNote,iMidiNote, iQ
endif


Snote MtoNameInt iMidiOut
if changed(Snote) == 1 then
    SnoteShow     sprintf "text(%s)", Snote
    cabbageSet "noteshow",SnoteShow
endif



iMod cabbageGetValue "instrmod"
if iMod == 2 then
giWave = giMyset1
elseif iMod == 3 then
giWave = giMyset2
elseif iMod == 4 then
giWave = giMyset3
endif


iFrq mtof iMidiOut

iAtt cabbageGetValue "att"
iAmp ampdb p5
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq, giWave
kGain ampdb -10
aOut = aSound*kGain
outall aOut
endin


instr String
iActive active p1
cabbageSet 1,"padlight","colour(200, 150, 50) visible(1)"
Sactive     sprintf "text(%d)", iActive
cabbageSet "activestring",Sactive
kRelease release
    if kRelease == 1  then
    cabbageSet 1,"padlight","colour(53, 67, 60, 255) visible(1)"
    endif


iAttEnv = 0.1 ;cabbageGetValue "attpad"
iRelEnv = 0.5 ;cabbageGetValue "relpad"
iGain = 1 ;cabbageGetValue "ginpad"
kPosIn cabbageGet "pos"
iPresIn = 0.9 ;cabbageGetValue "pres"
iVibIn = 2 ;cabbageGetValue "vib"
 iNum notnum
  	iFrqIn mtof iNum
 	iFilter = 500 ;cabbageGetValue "pdfltr"
    kCent cabbageGet "cent"
    printk2 kCent
 	iFrqMin = iFrqIn*cent(5)
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"

	kAmp   rspline  0.2, 0.3, 0.7, 1
	kFrq    rspline  iFrqMin, iFrqIn*cent(kCent), kSpeedMin, kSpeedMax
	kPres   rspline  1, 5, kSpeedMin, kSpeedMax
	kRate   rspline 0.025, kPosIn, kSpeedMin, kSpeedMax
	kVib    rspline  0, 2, kSpeedMin, kSpeedMax
	aSound	wgbow    kAmp*iGain,kFrq,kPres,kRate,kVib,kSpeedMin/100,giMyset1, 200 ;iFrqMin
	aSound  tone     aSound,iFilter
	aSound  atone    aSound,500
	aAtt transeg 0, iAttEnv, 4, 1
    aRel transegr 1, iRelEnv, -4, 0
	aOut = aSound*aAtt*aRel*1.3
;	outall aOut
	chnmix aOut, "sndBow"
endin




instr FXs
aInBow chnget "sndBow"
aRvrb reverb aInBow, 5
aRvrbMix ntrpol aInBow, aRvrb, 0.3
outall aRvrbMix
chnclear "sndBow"
endin

gkSpeaker1 init -45
gkSpeaker2 init -45
gkSpeaker3 init -60
gkSpeaker4 init -60
instr Speaker
iMidi notnum
iVel veloc

;print iMidi,iVel
iSpeed = 20
iStart1 = i(gkSpeaker1)
iStart2 = i(gkSpeaker2)
iStart3 = i(gkSpeaker3)
iStart4 = i(gkSpeaker4)

if iMidi == 0 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1-1))
elseif iMidi == 1 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1+1))
endif

if iMidi == 2 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2-1))
elseif iMidi == 3 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2+1))
endif

if iMidi == 4 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3-1))
elseif iMidi == 5 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3+1))
endif

if iMidi == 6 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4-1))
elseif iMidi == 7 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4+1))
endif


if iMidi == 0 || iMidi == 1 then
cabbageSetValue  "out1", gkSpeaker1+65
cabbageSetValue  "outn1", gkSpeaker1
endif
if iMidi == 2 || iMidi == 3 then
cabbageSetValue  "out2", gkSpeaker2+65
cabbageSetValue  "outn2", gkSpeaker2
endif
if iMidi == 4 || iMidi == 5 then
cabbageSetValue  "out3", gkSpeaker3+65
cabbageSetValue  "outn3", gkSpeaker3
endif
if iMidi == 6 || iMidi == 7 then
cabbageSetValue  "out4", gkSpeaker4+65
cabbageSetValue  "outn4", gkSpeaker4
endif
endin



instr Time
kTimer line 0, 1, 1
kSec = int(kTimer)
kMin init 0
kSec = kSec % 60
if kSec == 0 && changed(kSec) == 1 then
kMin += 1
endif
STimer sprintfk "%02d : %02d", kMin, kSec
cabbageSet 1, "sec", "text", STimer

endin

instr Widgets
kStart init 0
kStart cabbageGet "start"
SseqIn cabbageGet "seqarr"
if kStart == 1 && changed(kStart) == 1  then
schedulek "Time", 0, 99999
schedulek "seq",0,9999,SseqIn
schedulek "FXs", 0, 99999
elseif kStart == 0 && changed(kStart) == 1 then
turnoff2 "Time", 0, 0
turnoff2 "seq", 0,0
turnoff2 "FXs", 0,0
endif






; schedule "seq",0,99999,SseqIn
    if changed(SseqIn) == 1 then
    turnoff2 "seq", 0,0
    schedulek "seq",0,9999,SseqIn
    endif
 kActive active "GetMidi"
 
 
 
 ;;bow setting
 kPos   ctrl7    2,23,0.3,2
    if changed(kPos) == 1 then
    cabbageSetValue  "pos", kPos
    endif
    
 kSpeedMin   ctrl7    2,27,0.7,5 
    if changed(kSpeedMin) == 1 then
    cabbageSetValue "spdstrngmin", kSpeedMin
    endif
 kSpeedMax   ctrl7     2,35,1,12
    if changed(kSpeedMax) == 1 then
    cabbageSetValue  "spdstrngmax", kSpeedMax
    endif
    
  kCent   ctrl7     2,34,0,500
    if changed(kCent) == 1 then
    cabbageSetValue  "cent", kCent
    endif
    
    
    
    
    
    
 kSlider2   ctrl7    1,26,0,80
    if changed(kSlider2) == 1 then
    cabbageSetValue  "out2", kSlider2
    kdB2 = kSlider2-65
    cabbageSetValue  "outn2", kdB2
    endif
 kSlider3   ctrl7    1,27,0,80
    if changed(kSlider3) == 1 then
    cabbageSetValue  "out3", kSlider3
    kdB3 = kSlider3-65
    cabbageSetValue  "outn3", kdB3
    endif
 kSlider4   ctrl7    1,28,0,80
    if changed(kSlider4) == 1 then
    cabbageSetValue  "out4", kSlider4
    kdB4 = kSlider4-65
    cabbageSetValue  "outn4", kdB4
    endif
 kPedal ctrl7 16,64,0,1
 printk2 kPedal
    if kPedal == 1 && changed(kPedal) == 1 then
    kSusB = 1
    cabbageSetValue "hold",kSusB
    elseif kPedal == 0 && changed(kPedal) == 1 then
    kSusB = 0
    cabbageSetValue "hold",kSusB
    elseif kPedal == 0 && changed(kPedal) == 1 && kActive == 0 then
    kSusB = 0
    schedulek "Empty",0,0.1,kActive
    cabbageSetValue "hold",kSusB
    endif
    if kActive == 0 && changed(kActive) == 1 && kPedal == 0 then
    schedulek "Empty",0,0.1,kActive
    endif
 kHold cabbageGet "hold"
    if kHold == 0 && changed(kHold) == 1 && kActive == 0 then
    schedulek "Empty",0,0.1,kActive
    endif
    
     
 kDurSlider   ctrl7    1,23,0,10
    if changed(kDurSlider) == 1 then
    cabbageSetValue  "dur", kDurSlider
    endif
    
  kAttSlider   ctrl7    1,31,0.005,0.1
    if changed(kAttSlider) == 1 then
    cabbageSetValue  "att", kAttSlider
    endif
    
  kBpmSlider   ctrl7    1,41,10,210
    if changed(kBpmSlider) == 1 then
    cabbageSetValue  "bpm", kBpmSlider
    endif
kstatus, kchan, kdata1, kdata2  midiin
;    if changed(kdata2) == 1 then
;printk2 kdata2
    SMidiShow     sprintfk "text(%d)", kdata2
    cabbageSet 1, "data",SMidiShow
;    cabbageSetValue "data", kdata2
;    endif
endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

