;v4
<Cabbage>
form caption("CoreLa")    size(1100, 650)   guiMode("queue") colour(10,45,35) pluginId("crla") ; style("legacy")

image bounds(278, 38, 20, 20) channel("metronom") colour(10, 10, 10, 255)

texteditor bounds(46, 64, 378, 37) channel("seqarr") colour:0(71, 137, 100, 255)fontSize(30) text("1 1 2 1 2 4") colour(71, 137, 100, 255)


combobox bounds(502, 64, 77, 37)   channel("BNote")   text("Note", "G", "A-", "Bb", "C", "E-", "D-", "F", "A", "B", "Gb", "D")  colour(49, 79, 62, 255)  value(2)
combobox bounds(470, 22, 109, 39)   channel("scale")   text("Scale", "pythagorean", "shur", "abuata", "bayat tork", "afshari", "dashti", "nava", "segah", "chargah", "homayun", "bayat esf") colour(49, 79, 62, 255) value(3) 
combobox bounds(502, 106, 77, 31)   channel("instrmod")   text("Instr", "sine1", "sine2", "sine3")  colour(49, 79, 62, 255)  value(2)
combobox bounds(502, 142, 77, 32)   channel("instramb")   text("Instr", "VCO", "Bow", "Flute")  colour(49, 79, 62, 255)  value(3)


vslider bounds(814, 484, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(71, 137, 100, 255) 
vslider bounds(856, 484, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(71, 137, 100, 255) 
vslider bounds(896, 484, 50, 150) channel("out3") range(0, 80, 0, 1, 1) trackerColour(71, 137, 100, 255) 
vslider bounds(938, 484, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(71, 137, 100, 255) 
nslider bounds(988, 416, 93, 44) channel("gain") range(-90, 50, 0, 1, 1) colour(49, 79, 62, 255) text("Master Gain (dB)")
hslider bounds(46, 182, 316, 40) channel("dur") range(0.1, 10, 3, 1, 0.1) trackerColour(71, 137, 100, 255) text("dur")
hslider bounds(46, 262, 316, 40) channel("vcoFilt") range(200, 3000, 300, 1, 1) trackerColour(71, 137, 100, 255) text("Filt")
hslider bounds(46, 222, 316, 40) channel("att") range(0.0001, 1, 0.01, 1, 0.0001) trackerColour(71, 137, 100, 255) text("Att")
label bounds(428, 608, 59, 18) channel("label22") text("CC-13") fontColour(224, 219, 219, 255)


nslider bounds(430, 180, 65, 35) channel("durs") range(0.1, 10, 3, 1, 0.1) colour(49, 79, 62, 255)
nslider bounds(430, 260, 65, 35) channel("vcoFilts") range(200, 3000, 300, 1, 1) colour(49, 79, 62, 255)
nslider bounds(430, 220, 65, 35) channel("atts") range(0.0001, 1, 0.01, 1, 0.0001) colour(49, 79, 62, 255)


label bounds(366, 270, 59, 18) channel("label7") text("CC-13") fontColour(224, 219, 219, 255)

hslider bounds(34, 398, 391, 40) channel("pos") range(0.025, 2, 1, 1, 0.001) trackerColour(71, 137, 100, 255) text("pos")
hslider bounds(5, 438, 420, 40) channel("spdstrngmin") range(0.7, 5, 2, 1, 0.1) trackerColour(71, 137, 100, 255) text("spd min")
hslider bounds(2, 478, 424, 40) channel("spdstrngmax") range(1, 12, 5, 1, 0.01) trackerColour(71, 137, 100, 255) text("spd max")
hslider bounds(38, 518, 388, 40) channel("bowvib") range(0, 1, 0, 1, 0.001) trackerColour(71, 137, 100, 255) text("vib")
hslider bounds(14, 558, 412, 40) channel("vibSpd") range(0, 0.27, 0.03, 1, 0.001) trackerColour(71, 137, 100, 255) text("vib rng")
hslider bounds(35, 598, 392, 40) channel("bowFilt") range(500, 7000, 700, 1, 1) trackerColour(71, 137, 100, 255) text("Filt")

vslider bounds(584, 22, 50, 202) channel("ampseq") range(0, 20, 10, 1, 1) trackerColour(71, 137, 100, 255) text("sAmp")
vslider bounds(634, 22, 50, 167) channel("delayTime") range(0.1, 2, 1.5, 1, 0.001) trackerColour(71, 137, 100, 255) text("delayT")

nslider bounds(492, 560, 65, 35) channel("poss") range(0.025, 2, 1, 1, 0.001) colour(49, 79, 62, 255)
nslider bounds(492, 520, 65, 35) channel("spdstrngmins") range(0.7, 5, 2, 1, 0.1) colour(49, 79, 62, 255)
nslider bounds(492, 478, 65, 35) channel("spdstrngmaxs") range(1, 12, 5, 1, 0.01) colour(49, 79, 62, 255)
nslider bounds(492, 438, 65, 35) channel("bowvibs") range(0, 1, 0, 1, 0.001) colour(49, 79, 62, 255)
nslider bounds(492, 398, 65, 35) channel("vibSpds") range(, 0.27, 0.03, 1, 0.001) colour(49, 79, 62, 255)
nslider bounds(492, 600, 65, 35) channel("bowFilts") range(500, 7000, 700, 1, 1) colour(49, 79, 62, 255)





checkbox bounds(646, 200, 25, 25) channel("delayt") colour:0(99, 94, 94, 255) colour:1(71, 137, 100, 255), value(1)

vmeter bounds(992, 484, 15, 150) channel("meter1")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1016, 484, 15, 150) channel("meter2")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1040, 484, 15, 150) channel("meter3")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1064, 484, 15, 150) channel("meter4")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
image bounds(992, 470, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(1016, 470, 15, 15) channel("clip2") colour(0, 0, 0, 255)
image bounds(1040, 470, 15, 15) channel("clip3") colour(0, 0, 0, 255)
image bounds(1064, 470, 15, 15) channel("clip4") colour(0, 0, 0, 255)


label bounds(10, 64, 37, 15) channel("label1") text("seq")
combobox bounds(428, 64, 71, 37) channel("seqmod") colour(49, 79, 62, 255) text("ord", "tala", "Brk", "Rnd"), value(4)
checkbox bounds(166, 32, 25, 25) channel("hold") colour:0(99, 94, 94, 255) colour:1(71, 137, 100, 255), 
checkbox bounds(566, 402, 25, 25) channel("posmin") colour:0(99, 94, 94, 255) colour:1(71, 137, 100, 255), 
checkbox bounds(502, 180, 25, 25) channel("pad") colour:0(99, 94, 94, 255) colour:1(71, 137, 100, 255), value(1)
label bounds(530, 182, 40, 18) channel("labelpad") text("pad")
nslider bounds(508, 214, 63, 53) channel("padcent") range(0, 500, 0, 1, 1) colour(49, 79, 62, 255) fontColour(176, 231, 182, 255) text("Pad Cent")
label bounds(510, 276, 59, 18) channel("label25") text("CC-00") fontColour(224, 219, 219, 255)

label bounds(594, 406, 61, 15) channel("label16") text("pos min")
label bounds(196, 34, 47, 19) channel("label2") text("hold")
nslider bounds(45, 11, 62, 49) channel("bpm") range(10, 210, 120, 1, 1) colour(71, 137, 100, 255) fontColour(0, 0, 0, 255)
nslider bounds(128, 30, 31, 30) channel("dv") range(1, 16, 4, 1, 1) colour(71, 137, 100, 255) fontColour(0, 0, 0, 255)
label bounds(112, 42, 10, 15) channel("label3") text("x")

label bounds(366, 190, 59, 18) channel("label5") text("CC-03") fontColour(224, 219, 219, 255)


label bounds(366, 232, 59, 18) channel("label80") text("CC-11") fontColour(224, 219, 219, 255)

label bounds(396, 24, 70, 33) channel("noteshow")  fontColour(135, 226, 127, 255) colour(53, 67, 60, 255), text(" ")
label bounds(46, 108, 452, 31) channel("narrshow")  fontColour(135, 226, 127, 255) colour(53, 67, 60, 255) align("left")  text("")
label bounds(46, 146, 452, 26) channel("sarrshow")  fontColour(135, 226, 127, 255) colour(53, 67, 60, 255) align("left")  text(" ")

label bounds(882, 14, 70, 33) channel("data")  fontColour(135, 226, 127, 255) colour(53, 67, 60, 255) text("")

label bounds(430, 410, 59, 18) channel("label9") text("CC-11") fontColour(224, 219, 219, 255)


label bounds(428, 446, 59, 18) channel("label12") text("CC-07") fontColour(224, 219, 219, 255)
label bounds(564, 512, 59, 18) channel("label17") text("CC-00") fontColour(224, 219, 219, 255)
label bounds(428, 488, 59, 18) channel("label13") text("CC-15") fontColour(224, 219, 219, 255)
label bounds(428, 526, 59, 18) channel("label23") text("CC-14") fontColour(224, 219, 219, 255)
label bounds(428, 568, 59, 18) channel("label24") text("CC-06") fontColour(224, 219, 219, 255)


nslider bounds(562, 456, 64, 52) channel("cent") range(0, 500, 0, 1, 1) colour(49, 79, 62, 255) fontColour(176, 231, 182, 255) text("Vib Cent")
vslider bounds(632, 436, 50, 196) channel("ampwg") range(0, 20, 10, 1, 1) trackerColour(71, 137, 100, 255) text("wgAmp")

nslider bounds(820, 448, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(49, 79, 62, 255)
nslider bounds(860, 448, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(49, 79, 62, 255)
nslider bounds(900, 448, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(49, 79, 62, 255)
nslider bounds(940, 448, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(49, 79, 62, 255)
label bounds(842, 50, 239, 66) channel("sec") text("00 : 01") fontColour(135, 226, 127, 255)
button bounds(962, 18, 116, 27) channel("start") text("S  T  A  R  T", "S  T  O  P") colour:0(53, 67, 60, 255) colour:1(96, 69, 69, 255) value(1)
image bounds(42, 360, 30, 30) channel("bowlight") corners(5) colour(53, 67, 60, 255)
image bounds(126, 360, 30, 30) channel("flutelight") corners(5) colour(53, 67, 60, 255)
label bounds(162, 360, 30, 30) channel("activeflute") corners(5) fontColour(135, 226, 127, 255) colour(53, 67, 60, 255) text(" ")
label bounds(76, 360, 30, 30) channel("activestring") corners(5) fontColour(135, 226, 127, 255) colour(53, 67, 60, 255) text(" ")



</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0

 
opcode CsdMeter, 0, SakS
 SClip, aSig, kTrig, Smeter	xin
 iDbRange = 60
 iHoldTim = 0.5
 kOn init 0
 kTim init 0
 kStart init 0
 kEnd init 0
 kMax max_k aSig, kTrig, 1
 cabbageSetValue Smeter, kMax, metro(20)
 
 if kTrig == 1 then
 kMeter = (iDbRange + dbfsamp(kMax)) / iDbRange
  if kOn == 0 && kMax > 1 then
   kTim = 0
   kEnd = iHoldTim
   cabbageSet 1,SClip,"colour(250,0, 0)"
   kOn = 1
  endif
  if kOn == 1 && kTim > kEnd then
   cabbageSet 1,SClip,"colour(0,0,0)"
   kOn =	0
  endif
 endif
 kTim += ksmps/sr
endop

opcode countValue, i,i[]
iArrIn[] xin
iLen lenarray iArrIn
indx = 0
iCountValue = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iCountValue += 1
	endif
indx += 1
od
xout iCountValue
endop


opcode rmvZ, i[],i[]
iArrIn[] xin
iLen lenarray iArrIn
indxc = 0
iLenA = 0
while indxc < iLen do
	if iArrIn[indxc] != 0 then
	iLenA += 1
	endif
indxc += 1
od
		if iLenA == 0 then
		iLenA = 1
		endif
iArrOut[] init iLenA
indx = 0
indxw = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iArrOut[indxw] = iArrIn[indx]
	indxw += 1
	endif
indx += 1
od
xout iArrOut
endop

opcode swapArr, i[],i[]
iArrIn[] xin
iArrIn[] rmvZ iArrIn
iLen lenarray iArrIn
iArrOut[] init iLen
iWrite = 0
iRead = iLen-1
while iWrite < iLen do
iArrOut[iWrite] = iArrIn[iRead]
iWrite += 1
iRead -= 1
od
xout iArrOut
endop

opcode skpZ, i[],i[]
iArrIn[] xin
iLen lenarray iArrIn
indxc = 0
iLenA = 0
while indxc < iLen do
	if iArrIn[indxc] != 0 then
	iLenA += 1
	endif
indxc += 1
od
		if iLenA == 0 then
		iLenA = 1
		endif
iArrOut[] init iLen
indx = 0
indxw = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iArrOut[indxw] = iArrIn[indx]
	indxw += 1
	endif
indx += 1
od
xout iArrOut
endop


opcode MtoNameInt, S,i
iMidi xin 
SNoteArr[] fillarray "C", "C#", "D", "D#","E","F", "F#", "G","G#", "A", "Bb", "B"
iAraziArr[] fillarray 1, 3, 6, 8, 10
iNoteIndex = (iMidi) % 12
iNoteIndxInt = int(iNoteIndex)
iSCent = int((iMidi-int(iMidi))*100.5)
if iSCent  == 0 then
Sout sprintf "%s",SNoteArr[iNoteIndex]
elseif iSCent == 100 then
Sout sprintf "%s",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
else
		if iSCent > 50 then
		Sout sprintf "%s-",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
		elseif iSCent <= 50 then
		Sout sprintf "%s+",SNoteArr[iNoteIndex]
			indx = 0			
			while indx < lenarray(iAraziArr) do
				if iNoteIndxInt = iAraziArr[indx] then
				Sout sprintf "%s-",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
				endif
			indx += 1
			od
		endif
endif
xout Sout
endop

opcode ArrToStrgN, S,i[]
  iArrIn[] xin
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    SNote MtoNameInt iArrIn[indx]
    Sscale     sprintf "%s ", SNote
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop

opcode ArrToStrgF, S,i[]
  iArrIn[] xin
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    Sscale     sprintf "%.2f ",iArrIn[indx]
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop
opcode ArrToStrg, S,i[]
  iArrIn[] xin
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    Sscale     sprintf "%d ",iArrIn[indx]
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop

opcode StrToArr, i[],S
SIn xin
Snote     sprintf "%s ",SIn
iLenStr strlen SIn
iReadChar = 0
iCountChr = 0
while iReadChar < iLenStr do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	if strchar(Snote,iReadChar) == 32 then
	iCountChr += 1
	endif
	od	
iReadChar += 1
od

iArrOut[] init iCountChr

iWrite = 0
iRead = 0
while iRead < iLenStr do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
	Schar     strsub    Snote, iStart, iStart+iCountChr
	if strchar(Schar,0) != 0 then
	inum strtod Schar
	iArrOut[iWrite] = inum
	iWrite += 1
	endif
iRead += 1
od
xout iArrOut
endop



opcode ArrTala, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] init iLen
 iRead = 0
 iWrite = 1
 while iRead < iLen do
 	iOutArr[iRead] = iInArr[iWrite]
	iRead += 1
	iWrite = (iWrite+1) % (iLen)
 od
 xout iOutArr
endop

opcode ArrFl, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] = iInArr
 iRndIndx = int(random:i(0, iLen))
 iRndFl random -0.25, 0.25
 iOutArr[iRndIndx] = iOutArr[iRndIndx]+iRndFl
 if iOutArr[iRndIndx] <= 0.75 then
 iOutArr[iRndIndx] = 0.75
 endif
 xout iOutArr
endop



opcode ArrRnd, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] init iLen
 iRead = 0
 iSeq[] fillarray 1, 2, 4
 while iRead < iLen do
    iIndxSeq = int(random:i(0,3))
 	iOutArr[iRead] = iSeq[iIndxSeq]
	iRead += 1
 od
 xout iOutArr
endop


;;scale
giScaleArr[] init 12
giNormal[] fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
giShurArr[] 			fillarray 0, 1.5, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1
giAbuataArr[] 		fillarray 0, 0.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
giBayattorkArr[] 	fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5
giAfshariArr[] 		fillarray 0, 1.5,0.5, 1, 1, 1, 1, 1, 1.5,0.5, 1, 1
giDashtiArr[] 		fillarray 0, 1, 1, 1, 1, 1, 1.5,0.5,  1, 1, 1, 1
giNavaArr[] 			fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5, 1, 1
gi3gahArr[] 			fillarray 0, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1, 1
gi4gahArr[] 			fillarray 0, 1.5, 0.5, 1, 1,1, 1, 1, 1.5, 0.5, 1, 1
giHomayunArr[]   	fillarray 0, 0.5, 1, 1, 1,1, 1, 1.5, 0.5, 1, 1, 1
giBayatEsArr[]   	fillarray 0, 1,1,1, 1, 1,1,1, 1.5, 0.5, 1.5, 0.5

opcode pythagorean,i,ii
iBaseNote,iNote xin
iMidi = iNote
		iOct = 0
     until iMidi < iBaseNote+12 do
  		iMidi = iMidi-12
  		iOct += 1
  		enduntil
 iMidiMin = (iMidi-iBaseNote)
  	iRatio = 1
  	if iMidiMin == 0 then
  	iRatio = 1/1
  	elseif iMidiMin == 1 then
  	iRatio = 2187/2048
  	elseif iMidiMin == 2 then
  	iRatio = 9/8
  	elseif iMidiMin == 3 then
  	iRatio = 32/27
  	elseif iMidiMin == 4 then
  	iRatio = 81/64
  	elseif iMidiMin == 5 then
  	iRatio = 4/3
  	elseif iMidiMin == 6 then
  	iRatio = 729/512
  	elseif iMidiMin == 7 then
  	iRatio = 3/2
  	elseif iMidiMin == 8 then
  	iRatio = 6561/4096
  	elseif iMidiMin == 9 then
  	iRatio = 27/16
  	elseif iMidiMin == 10 then
  	iRatio = 16/9
  	elseif iMidiMin == 11 then
  	iRatio = 243/128
  	elseif iMidiMin == 12 then
  	iRatio = 2/1
  	endif
  	
iBaseFrq mtof iBaseNote+(iOct*12)
iFrq = (iBaseFrq)*iRatio
iMidiOut ftom iFrq
xout iMidiOut
endop


opcode dastgah, i,i[]iii
  iInArr[],iBaseMidi,iMidiIn,iQ xin
  iLen lenarray iInArr
  iOutArr[] init iLen
  iNote = iBaseMidi
  indx = 0
	while indx < iLen do
	iNote = iNote+(iInArr[indx])
	iOutArr[indx] = iNote
	indx += 1
	od
	iMidi = int(iMidiIn)+iQ
	indxOct = 0
	     until iMidi < iBaseMidi+12 do
	     indxOct += 1
  		iMidi = iMidi-12
  		enduntil
  		iIntrval = (iMidi-iBaseMidi)
iMidiOut = iOutArr[iIntrval]+(12*indxOct)
SnoteOut mton iMidiOut
  xout iMidiOut
endop













giMyset1  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
;giMyset1  ftgen		0, 0, 2^10,10,1, 0.5, 0.3
giMyset2  ftgen		0, 0, 2^10,10,1, 0.7, 0, 0.1, 0, 0, 0.3, 0, 0, 0, 0.2
giMyset3  ftgen		0, 0, 2^10, 10, 1, 1/2, 1/4, 1/6, 1/7, 0, 1/9

 massign 1,1
 massign 2,13
 massign 3,14
 massign 16,16



iLenSeq init 32
giNoteArr[] init iLenSeq
giEmpty[] init iLenSeq
giIndxNote init 0

instr GetMidi ;1
 iActive active "GetMidi"
 iHold cabbageGetValue "hold"
 kHold cabbageGet "hold"
 kRel release
 iMidi notnum
  if iActive == 1 then
  giNoteArr[] = giEmpty
  giIndxNote = 0
  endif
 
 giNoteArr[giIndxNote] = iMidi
 giIndxNote = (giIndxNote+1) % lenarray(giNoteArr)
 gkMaxIndx = giIndxNote
 iNoteArrShow[] rmvZ giNoteArr
 SnArrShow ArrToStrgN iNoteArrShow
     SnoteShow     sprintf "text(%s)", SnArrShow
    cabbageSet "narrshow",SnoteShow
; puts SnArrShow,1
; printarray iNoteArrShow,"%d","Notes:"
 
 if kRel == 1 && kHold == 0  then
 schedulek "rmvMidi", 0, 0.1, iMidi
 endif
 
endin
instr rmvMidi ;2
 iRead = 0
    while iRead < lenarray(giNoteArr) do
        if giNoteArr[iRead] == p4 then
        giNoteArr[iRead] = 0
        endif
    iRead += 1
    od
 giNoteArr skpZ giNoteArr
  iNoteArrShow[] rmvZ giNoteArr
 SnArrShow ArrToStrgN iNoteArrShow
      SnoteShow     sprintf "text(%s)", SnArrShow
    cabbageSet "narrshow",SnoteShow
; puts SnArrShow,1
 
; printarray giNoteArr,"%d","Notes(R):"
 giIndxNote -= 1
endin



instr seq
kSeqMod cabbageGet "seqmod"
SIn = p4
iSeqArr[] StrToArr SIn
giSeqArr[] = iSeqArr

kNoteIndx init 0
kSeqIndx init 0
kTime init 1
kBPM cabbageGet "bpm"
kDv cabbageGet "dv"
kDurIn cabbageGet "dur"
kAmpdBIn cabbageGet "ampseq"
kPad cabbageGet "pad"
kAmpdB = kAmpdBIn - 20
kTempo = (kBPM/60)*kDv
    if metro(1/kTime) == 1 then
    kDur = kTime*kDurIn
        if kNoteIndx > (gkMaxIndx-1) then
        kNoteIndx = (gkMaxIndx-1)
        endif
    kNote = giNoteArr[kNoteIndx]
    schedulek "LED",0,0.1,1
    schedulek "LED",0.1,0.1,2
        if kNote != 0 then
        schedulek "sound", 0, kDur, kNote, kAmpdB
        endif
    kSeq = giSeqArr[kSeqIndx]
    kTime = kSeq/kTempo
        if kNote != 0 && kSeq >= 2 then
        kDelay = kTime/2
           kNoteBass = kNote
			until kNoteBass < 45 do
  			kNoteBass = kNoteBass-12
  			enduntil
        schedulek "sound", kDelay, kDur*0.6, kNoteBass, kAmpdB-5
        endif
        if kNote != 0 && kSeq == 4 then
        kNoteRep = kNote
        kRep = int(random:k(2, 8))
		    until kNoteRep > 80 do
  			kNoteRep = kNoteRep+12
  		    enduntil
            kRepIndx = 0
            kDelay = kTime/kRep
            while kRepIndx < (kRep/2) do
            schedulek "sound",kDelay, 0.1, kNoteRep, kAmpdB-15
            kDelay += (kTime/kRep)
            kRepIndx += 1
            od
        endif
    kNoteIndx = (kNoteIndx+1) % giIndxNote
    kSeqIndx = (kSeqIndx+1) % lenarray(giSeqArr) 
        if kSeqIndx == 0 && kSeqMod == 2 then
        schedulek "tala", 0, 1
        elseif kSeqIndx == 0 && kSeqMod == 3 then
        schedulek "arrFL", 0, 1
        elseif kSeqIndx == 0 && kSeqMod == 4 then
        schedulek "arrRnd", 0, 1
        elseif kSeqIndx == 0 && kNote != 0 && kPad == 1 && kSeqMod == 1 || kSeqMod == 2 || kSeqMod == 3 || kSeqMod == 4 then
        iDurSum sumarray giSeqArr
        kDurTime = iDurSum/kTempo
        schedulek "AmbientVCO", 0, iDurSum*0.3, kNote, -15
        endif
    endif

endin



instr tala
giSeqArr[] ArrTala giSeqArr
 SnArrShow ArrToStrg giSeqArr
      SnoteShow     sprintfk "text(%s)", SnArrShow
    cabbageSet 1, "sarrshow",SnoteShow
;printarray giSeqArr, "%d"
endin


instr arrFL
giSeqArr[] ArrFl giSeqArr
;printarray giSeqArr, "%.2f"
 SnArrShow ArrToStrgF giSeqArr
      SnoteShow     sprintfk "text(%s)", SnArrShow
    cabbageSet 1, "sarrshow",SnoteShow
endin

instr arrRnd
giSeqArr[] ArrRnd giSeqArr
 SnArrShow ArrToStrg giSeqArr
      SnoteShow     sprintfk "text(%s)", SnArrShow
    cabbageSet 1, "sarrshow",SnoteShow
;printarray giSeqArr, "%d"
endin



instr LED
if p4 == 1 then
Scolor = "colour(10, 250, 10)"
elseif p4 == 2 then
Scolor = "colour(10, 10, 10)"
endif
cabbageSet 1,"metronom",Scolor
endin


instr Empty ;7
iActive = p4
    if iActive == 0 then
    giNoteArr[] = giEmpty
    SnoteShow     sprintf "text(%s)", " "
    cabbageSet "narrshow",SnoteShow
    cabbageSet "noteshow",SnoteShow
    else
    endif
endin


instr sound
iMidiNote = p4
iBaseNoteIn cabbageGetValue "BNote"

if iBaseNoteIn == 2 then
SbaseNote = "0G"
iQ = 0
elseif iBaseNoteIn == 3 then
SbaseNote = "0A-"
iQ = 1
elseif iBaseNoteIn == 4 then
SbaseNote = "0Bb"
iQ = 0
elseif iBaseNoteIn == 5 then
SbaseNote = "0C"
iQ = 0
elseif iBaseNoteIn == 6 then
SbaseNote = "0E-"
iQ = 1
elseif iBaseNoteIn == 7 then
SbaseNote = "0D-"
iQ = 1
elseif iBaseNoteIn == 8 then
SbaseNote = "0F"
iQ = 0
elseif iBaseNoteIn == 9 then
SbaseNote = "0A"
iQ = 0
elseif iBaseNoteIn == 10 then
SbaseNote = "0B"
iQ = 0
elseif iBaseNoteIn == 11 then
SbaseNote = "0Gb"
iQ = 0
elseif iBaseNoteIn == 12 then
SbaseNote = "0D"
iQ = 0
endif
iBaseNote ntom SbaseNote
iScale      cabbageGetValue "scale"
if iScale == 1 then
iMidiOut = iMidiNote
elseif iScale == 2 then
iMidiOut pythagorean iBaseNote,iMidiNote
SnoteName mton iMidiOut
elseif iScale == 3 then
iMidiOut dastgah giShurArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 4 then
iMidiOut dastgah giAbuataArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 5 then
iMidiOut dastgah giBayattorkArr,iBaseNote,iMidiNote, iQ
elseif iScale == 6 then
iMidiOut dastgah giAfshariArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 7 then
iMidiOut dastgah giDashtiArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 8 then
iMidiOut dastgah giNavaArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 9 then
iMidiOut dastgah gi3gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 10 then
iMidiOut dastgah gi4gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 11 then
iMidiOut dastgah giHomayunArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 12 then
iMidiOut dastgah giBayatEsArr,  iBaseNote,iMidiNote, iQ
endif


Snote MtoNameInt iMidiOut
if changed(Snote) == 1 then
    SnoteShow     sprintf "text(%s)", Snote
    cabbageSet "noteshow",SnoteShow
endif



iMod cabbageGetValue "instrmod"
if iMod == 2 then
giWave = giMyset1
elseif iMod == 3 then
giWave = giMyset2
elseif iMod == 4 then
giWave = giMyset3
endif


iFrq mtof iMidiOut

iAtt cabbageGetValue "att"
iAmp ampdb p5
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq, giWave

aOut clfilt aSound, 1200, 0, 10
;outall aOut
chnmix aOut, "sndseq"
endin





instr AmbientMachine
kBPM cabbageGet "bpm"
kTempo = (kBPM/60)
;printk2 kTempo
kTime init 1
kDur init 1
    if metro(1/kTime) == 1 then
    kTime random 5, 12
    kDur = kTime*1.3
    schedulek "Ambient", 0, kDur
    endif
endin

;schedule "AmbientMachine", 0.1, 9999

instr Ambient
iBaseNoteIn cabbageGetValue "BNote"

if iBaseNoteIn == 2 then
SbaseNote = "0G"
iQ = 0
elseif iBaseNoteIn == 3 then
SbaseNote = "0A-"
iQ = 1
elseif iBaseNoteIn == 4 then
SbaseNote = "0Bb"
iQ = 0
elseif iBaseNoteIn == 5 then
SbaseNote = "0C"
iQ = 0
elseif iBaseNoteIn == 6 then
SbaseNote = "0E-"
iQ = 1
elseif iBaseNoteIn == 7 then
SbaseNote = "0D-"
iQ = 1
elseif iBaseNoteIn == 8 then
SbaseNote = "0F"
iQ = 0
elseif iBaseNoteIn == 9 then
SbaseNote = "0A"
iQ = 0
elseif iBaseNoteIn == 10 then
SbaseNote = "0B"
iQ = 0
elseif iBaseNoteIn == 11 then
SbaseNote = "0Gb"
iQ = 0
elseif iBaseNoteIn == 12 then
SbaseNote = "0D"
iQ = 0
endif
iBaseNote ntom SbaseNote
iMidiNote = iBaseNote+(12*4)



iScale      cabbageGetValue "scale"
if iScale == 1 then
iScaleArr[] = giShurArr
iMidiOut = iMidiNote
elseif iScale == 2 then
iScaleArr[] = giShurArr
iMidiOut pythagorean iBaseNote,iMidiNote
elseif iScale == 3 then
iScaleArr[] = giShurArr
elseif iScale == 4 then
iScaleArr[] = giAbuataArr
elseif iScale == 5 then
iScaleArr[] = giBayattorkArr
elseif iScale == 6 then
iScaleArr[] = giAfshariArr
elseif iScale == 7 then
iScaleArr[] = giDashtiArr
elseif iScale == 8 then
iScaleArr[] = giNavaArr
elseif iScale == 9 then
iScaleArr[] = gi3gahArr
elseif iScale == 10 then
iScaleArr[] = gi4gahArr
elseif iScale == 11 then
iScaleArr[] = giHomayunArr
elseif iScale == 12 then
iScaleArr[] = giBayatEsArr
endif

iInstr cabbageGetValue "instramb"
if iInstr == 2 then
SInstr = "AmbientVCO"
elseif iInstr == 3 then
SInstr = "Bow"
elseif iInstr == 4 then
SInstr = "Flute"
endif



iChord = int(random:i(3, 6))
iNumber = int(random:i(1, 5))
SChordArr[] init iNumber
indx = 0
iInterval = 0
iRndNote = int(random:i(-2, 2))
iNote = iMidiNote+iRndNote
iAmpdB = -15
while indx < iNumber do
iNote += iInterval
    until iNote < 72 do
  	iNote = iNote-12
  	enduntil
  	until iNote > 48 do
  	iNote = iNote+12
  	enduntil
iRndOctArr[] fillarray -12, 0, 12
iRndOtcIndx = int(random:i(0, 3))
iMidiOct = iNote+iRndOctArr[iRndOtcIndx]
iMidiOut dastgah iScaleArr, iBaseNote,iMidiOct, iQ
SNoteOct mton iMidiOut
SChordArr[indx] = iMidiOut
iMajor = int(random:i(0, 2))
iInterval += (iChord+iMajor)
iDelay random 0, p3*0.3
schedule SInstr, iDelay, p3, iMidiOut, iAmpdB-(indx*3)
indx += 1
od
;printarray SChordArr, 1

endin

instr AmbientVCO
kCentIn cabbageGet "padcent"
iFrq mtof p4-24
iAmp ampdb p5

kSpdMin cabbageGet "spdstrngmin"
kSpdMax cabbageGet "spdstrngmax"

kCent jspline kCentIn, kSpdMin, kSpdMax
kGliss cent kCent
;printk2 kGliss
kFrq = iFrq*kGliss
;printk2 int(kFrq)
aSound vco2 1, kFrq
aEnv linen aSound*iAmp, p3/2, p3, p3/2
kFilter cabbageGet "vcoFilt"
aOut clfilt aEnv, kFilter, 0, 10
aOut clfilt aOut, 150, 1, 10
;outall aOut
chnmix aOut, "sndBow"
endin



instr Bow
iActive active p1
cabbageSet 1,"bowlight","colour(200, 150, 50) visible(1)"
Sactive     sprintf "text(%d)", iActive
cabbageSet "activestring",Sactive
kRelease release
    if kRelease == 1  then
    cabbageSet 1,"bowlight","colour(53, 67, 60, 255) visible(1)"
    endif


iAttEnv = 0.1 ;cabbageGetValue "attpad"
iRelEnv = 1 ;cabbageGetValue "relpad"


kGainWGIn cabbageGet "ampwg"
kGainWG = ampdb:k(kGainWGIn-20)
iGaindB = ampdb:i(veloc:i( -7, 0))
if iGaindB == 0 then
iGaindB ampdb p5 ;cabbageGetValue "ginpad"
endif

kVibIn cabbageGet "bowvib"
iNum notnum
    if iNum == 0 then
    iNum = p4
    until iNum < 48 do
  	iNum = iNum-12
  	enduntil
  	until iNum > 36 do
  	iNum = iNum+12
  	enduntil       
    endif

  	iFrqIn mtof iNum
    kCent cabbageGet "cent"
 	iFrqMin = iFrqIn*cent(5)
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
 kVibSpeed cabbageGet "vibSpd"
	kAmp   rspline  0.2, 0.3, 0.7, 1
	kFrq    rspline  iFrqMin, iFrqIn*cent(kCent), kSpeedMin, kSpeedMax
	kPres   rspline  1, 5, kSpeedMin, kSpeedMax
;	kRate   rspline 0.025, kPosIn, kSpeedMin, kSpeedMax
kPosIn cabbageGet "pos"
kPosSwch cabbageGet "posmin"
    if kPosSwch == 0 then
    kPosMin = 0.025
    elseif kPosSwch == 1 then
    kPosMin = 0.001
    endif
	kRate   rspline kPosMin,kPosIn, kSpeedMin, kSpeedMax
	kVib   rspline  0, kVibIn, kSpeedMin, kSpeedMax
	aSound	wgbow    kAmp,kFrq,kPres,kRate,kVib,kVibSpeed,giMyset1, iFrqMin
	aAtt transeg 0, iAttEnv, 4, 1
    aRel transegr 1, iRelEnv, -4, 0
	kFilter cabbageGet "bowFilt"
    aFilt clfilt aSound, kFilter, 0, 10
    aFilt clfilt aFilt, 150, 1, 10
    aOut = aFilt*aAtt*aRel*iGaindB*kGainWG
	
;	outall aOut
	chnmix aOut, "sndBow"
endin


instr Flute
iActive active p1
cabbageSet 1,"flutelight","colour(150, 200, 50) visible(1)"
Sactive     sprintf "text(%d)", iActive
cabbageSet "activeflute",Sactive
kRelease release
    if kRelease == 1  then
    cabbageSet 1,"flutelight","colour(53, 67, 60, 255) visible(1)"
    endif

kGainWGIn cabbageGet "ampwg"
kGainWG = ampdb:k(kGainWGIn-20)
iGaindB = ampdb:i(veloc:i( -15, -7))
printk2 iGaindB
iNum notnum
  	iFrqIn mtof iNum
    kFrq init iFrqIn
    kFrq rspline iFrqIn, iFrqIn, 1, 3



iatt = 0.5
idetk = 0.1

 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
 
kPosIn cabbageGet "pos"
kPosSwch cabbageGet "posmin"
    if kPosSwch == 0 then
    kPosMin = 0.025
    elseif kPosSwch == 1 then
    kPosMin = 0.001
    endif
	kjet   rspline kPosMin,kPosIn, kSpeedMin, kSpeedMax
	
;kjet rspline 0.6, 0.8, kSpeedMin, kSpeedMax
kngain rspline 0.01, 0.03, kSpeedMin, kSpeedMax

kVibIn cabbageGet "bowvib"
;kvibf rspline 0.01, 0.1, kSpeedMin, kSpeedMax
kVib   rspline  0.01, kVibIn, kSpeedMin, kSpeedMax
kvamp rspline 0.01, 0.1, kSpeedMin, kSpeedMax

aSound wgflute iGaindB, kFrq, kjet, iatt, idetk, kngain, kVib, kvamp, giMyset1

    iAttEnv = 0.2
    iRelEnv = 0.5
	aAtt transeg 0, iAttEnv, 4, 1
    aRel transegr 1, iRelEnv, -4, 0
    
    kFilter cabbageGet "bowFilt"
    aFilt clfilt aSound, (kFilter*2)+1500, 0, 10
    aFilt clfilt aFilt, 150, 1, 10
    
    
    
    aOut = aFilt*aAtt*aRel*kGainWG

chnmix aOut, "sndBow"

;outall aFlute

endin


instr FXs
aInBow chnget "sndBow"
aRvrb reverb aInBow, 1
aRvrbMix ntrpol aInBow, aRvrb, 0.3
outall aRvrbMix
kBPM cabbageGet "bpm"
kDv cabbageGet "dv"
kTempo = (int(kBPM)/60);*kDv

kDelayT cabbageGet "delayt"
if kDelayT == 1 then
kDelayTime cabbageGet "delayTime"
elseif kDelayT == 0 then
kDelayTime = kTempo
endif


kPortTime linseg 0, 0.01, 0.3
kDelayTime portk kDelayTime, kPortTime
aInSeq chnget "sndseq"
kFeedback = 0.3
 	aTim	interp	kDelayTime
 	abuf	delayr	7
 	aDelay	deltapi	aTim	
 	delayw	aInSeq + (aDelay*kFeedback)
  	aDelMix		ntrpol	 aInSeq,aDelay,  .5
  outall aDelMix

chnclear "sndBow", "sndseq"
endin

gkSpeaker1 init -45
gkSpeaker2 init -45
gkSpeaker3 init -60
gkSpeaker4 init -60
instr Speaker
iMidi notnum
iVel veloc

;print iMidi,iVel
iSpeed = 20
iStart1 = i(gkSpeaker1)
iStart2 = i(gkSpeaker2)
iStart3 = i(gkSpeaker3)
iStart4 = i(gkSpeaker4)

if iMidi == 0 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1-1))
elseif iMidi == 1 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1+1))
endif

if iMidi == 2 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2-1))
elseif iMidi == 3 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2+1))
endif

if iMidi == 4 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3-1))
elseif iMidi == 5 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3+1))
endif

if iMidi == 6 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4-1))
elseif iMidi == 7 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4+1))
endif


if iMidi == 0 || iMidi == 1 then
cabbageSetValue  "out1", gkSpeaker1+65
cabbageSetValue  "outn1", gkSpeaker1
endif
if iMidi == 2 || iMidi == 3 then
cabbageSetValue  "out2", gkSpeaker2+65
cabbageSetValue  "outn2", gkSpeaker2
endif
if iMidi == 4 || iMidi == 5 then
cabbageSetValue  "out3", gkSpeaker3+65
cabbageSetValue  "outn3", gkSpeaker3
endif
if iMidi == 6 || iMidi == 7 then
cabbageSetValue  "out4", gkSpeaker4+65
cabbageSetValue  "outn4", gkSpeaker4
endif
endin



instr Time
kTimer line 0, 1, 1
kSec = int(kTimer)
kMin init 0
kSec = kSec % 60
if kSec == 0 && changed(kSec) == 1 then
kMin += 1
endif
STimer sprintfk "%02d : %02d", kMin, kSec
cabbageSet 1, "sec", "text", STimer

endin

instr Widgets
kStart init 0
kStart cabbageGet "start"
SseqIn cabbageGet "seqarr"
if kStart == 1 && changed(kStart) == 1  then
schedulek "Time", 0, 99999
schedulek "seq",0,9999,SseqIn
schedulek "FXs", 0, 99999
elseif kStart == 0 && changed(kStart) == 1 then
turnoff2 "Time", 0, 0
turnoff2 "seq", 0,0
turnoff2 "FXs", 0,0
endif






; schedule "seq",0,99999,SseqIn
    if changed(SseqIn) == 1 then
    turnoff2 "seq", 0,0
    schedulek "seq",0,9999,SseqIn
    endif
 kActive active "GetMidi"
 
 
 
 ;;bow setting
 kPos   ctrl7    2,31,0.025,2
    if changed(kPos) == 1 then
    cabbageSetValue  "pos", kPos
    endif
    
 kSpeedMin   ctrl7    2,27,0.7,5 
    if changed(kSpeedMin) == 1 then
    cabbageSetValue "spdstrngmin", kSpeedMin
    endif
 kSpeedMax   ctrl7     2,35,1,12
    if changed(kSpeedMax) == 1 then
    cabbageSetValue  "spdstrngmax", kSpeedMax
    endif
    
  kCent   ctrl7     2,0,0,500
    if changed(kCent) == 1 then
    cabbageSetValue  "cent", kCent
    endif
 kBowVib   ctrl7     2,34,0,1
    if changed(kBowVib) == 1 then
    cabbageSetValue  "bowvib", kBowVib ;0, 0.27
    endif
 kBowVibSpd  ctrl7     2,26,0,0.27
    if changed(kBowVibSpd) == 1 then
    cabbageSetValue  "vibSpd", kBowVibSpd ;0, 0.27
    endif
     
  kBowFilter   ctrl7     2,33,500,7000
    if changed(kBowFilter) == 1 then
    cabbageSetValue  "bowFilt", kBowFilter
    endif
 kAmpWG   ctrl7    2,29,0,20
    if changed(kAmpWG) == 1 then
    cabbageSetValue  "ampwg", kAmpWG
    endif  
  kFluteFilter   ctrl7     3,33,500,7000
    if changed(kFluteFilter) == 1 then
    cabbageSetValue  "bowFilt", kFluteFilter
    endif    
    
    
    
;;Ambient
; kStartAmbient cabbageGet "StartAmbient"
 kStartAmbient ctrl7 10, 62, 0, 1
 if kStartAmbient == 1 && changed(kStartAmbient) == 1 then
 schedulek "AmbientMachine", 0, 999999
 elseif kStartAmbient == 0 && changed(kStartAmbient) == 1 then
 turnoff2 "AmbientMachine", 0, 0
 endif
 
 kPad ctrl7 10, 63, 0, 1
    if changed(kPad) == 1 then
    cabbageSetValue  "pad", kPad
    endif
  kvcoFilt   ctrl7    1,33,300,3000
    if changed(kvcoFilt) == 1 then
    cabbageSetValue  "vcoFilt", kvcoFilt
    endif   
 kCentVco   ctrl7     1,0,0,500
    if changed(kCentVco) == 1 then
    cabbageSetValue  "padcent", kCentVco
    endif   
   
    
     
       
 kSlider2   ctrl7    1,26,0,80
    if changed(kSlider2) == 1 then
    cabbageSetValue  "out2", kSlider2
    kdB2 = kSlider2-65
    cabbageSetValue  "outn2", kdB2
    endif
 kSlider3   ctrl7    1,27,0,80
    if changed(kSlider3) == 1 then
    cabbageSetValue  "out3", kSlider3
    kdB3 = kSlider3-65
    cabbageSetValue  "outn3", kdB3
    endif
 kSlider4   ctrl7    1,28,0,80
    if changed(kSlider4) == 1 then
    cabbageSetValue  "out4", kSlider4
    kdB4 = kSlider4-65
    cabbageSetValue  "outn4", kdB4
    endif
 kPedal ctrl7 15,64,0,1
    if kPedal == 1 && changed(kPedal) == 1 then
    kSusB = 1
    cabbageSetValue "hold",kSusB
    elseif kPedal == 0 && changed(kPedal) == 1 then
    kSusB = 0
    cabbageSetValue "hold",kSusB
    elseif kPedal == 0 && changed(kPedal) == 1 && kActive == 0 then
    kSusB = 0
    schedulek "Empty",0,0.1,kActive
    cabbageSetValue "hold",kSusB
    endif
    if kActive == 0 && changed(kActive) == 1 && kPedal == 0 then
    schedulek "Empty",0,0.1,kActive
    endif
 kHold cabbageGet "hold"
    if kHold == 0 && changed(kHold) == 1 && kActive == 0 then
    schedulek "Empty",0,0.1,kActive
    endif
    
 
     
 ;;seq 
  kAmpSeq   ctrl7    1,21,0,20
    if changed(kAmpSeq) == 1 then
    cabbageSetValue  "ampseq", kAmpSeq
    endif       
                 
 kDurSlider   ctrl7    1,23,0,10
    if changed(kDurSlider) == 1 then
    cabbageSetValue  "dur", kDurSlider
    endif
    
  kAttSlider   ctrl7    1,31,0.005,0.1
    if changed(kAttSlider) == 1 then
    cabbageSetValue  "att", kAttSlider
    endif
    
  kBpmSlider   ctrl7    1,41,10,210
    if changed(kBpmSlider) == 1 then
    cabbageSetValue  "bpm", kBpmSlider
    endif
    
    
    
kstatus, kchan, kdata1, kdata2  midiin
;    if changed(kdata2) == 1 then
;printk2 kdata2
    SMidiShow     sprintfk "text(%d)", kdata2
    cabbageSet 1, "data",SMidiShow
;    cabbageSetValue "data", kdata2
;    endif
endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

