;v3
<Cabbage>
form caption("Puls")    size(900, 500)   guiMode("queue") colour(10,50,30) pluginId("puls") ; style("legacy")

image bounds(364, 117, 15, 15) channel("metronom") colour(10,10,10)

texteditor bounds(60, 115, 175, 20) channel("seqarr") colour:0(71, 137, 100, 255)fontSize(20) text("1 1 2 1 2") colour(71, 137, 100, 255)

vslider bounds(638, 342, 50, 150) channel("out1") range(0, 40, 25.1968, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)
vslider bounds(674, 342, 50, 150) channel("out2") range(0, 40, 25.1968, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)
vslider bounds(710, 342, 50, 150) channel("out3") range(0, 40, 0, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)
vslider bounds(744, 342, 50, 150) channel("out4") range(0, 40, 0, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)
vslider bounds(848, 166, 50, 150) channel("gain") range(0, 1.5, 1, 1, 0.1) trackerColour(71, 137, 100, 255) valueTextBox(1)

vmeter bounds(798, 342, 15, 150) channel("meter1") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(822, 342, 15, 150) channel("meter2") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(846, 342, 15, 150) channel("meter3") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(870, 342, 15, 150) channel("meter4") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
image bounds(798, 328, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(822, 328, 15, 15) channel("clip2") colour(0,0,0)
image bounds(846, 328, 15, 15) channel("clip3") colour(0,0,0)
image bounds(870, 328, 15, 15) channel("clip4") colour(0,0,0)


label bounds(24, 118, 37, 15) channel("label1") text("seq")
combobox bounds(238, 115, 60, 20) channel("seqmod") colour(71, 137, 100, 255) text("ord", "tala", "Brk", "Rnd"), value(1)
checkbox bounds(302, 115, 20, 20) channel("hold") colour:0(99, 94, 94, 255) colour:1(71, 137, 100, 255), value(1)
label bounds(324, 117, 37, 15) channel("label2") text("hold")
nslider bounds(62, 84, 43, 30) channel("bpm") range(30, 300, 90, 1, 1) colour(71, 137, 100, 255) fontColour(0, 0, 0, 255)
nslider bounds(126, 84, 31, 30) channel("dv") range(1, 16, 4, 1, 1) colour(71, 137, 100, 255) fontColour(0, 0, 0, 255)
label bounds(110, 96, 10, 15) channel("label3") text("x")
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0

 massign 1,1
 
opcode CsdMeter, 0, SakS
 SClip, aSig, kTrig, Smeter	xin
 iDbRange = 60 ;shows 60 dB
 iHoldTim = 0.5;seconds to "hold the red light"
 kOn init 0
 kTim init 0
 kStart init 0
 kEnd init 0
 kMax max_k aSig, kTrig, 1
 cabbageSetValue Smeter, kMax, metro(20)
 
 if kTrig == 1 then
 kMeter = (iDbRange + dbfsamp(kMax)) / iDbRange
  if kOn == 0 && kMax > 1 then
   kTim = 0
   kEnd = iHoldTim
   cabbageSet 1,SClip,"colour(250,0, 0)"
   kOn = 1
  endif
  if kOn == 1 && kTim > kEnd then
   cabbageSet 1,SClip,"colour(0,0,0)"
   kOn =	0
  endif
 endif
 kTim += ksmps/sr
endop

opcode countValue, i,i[]
iArrIn[] xin
iLen lenarray iArrIn
indx = 0
iCountValue = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iCountValue += 1
	endif
indx += 1
od
xout iCountValue
endop


opcode rmvZ, i[],i[]
iArrIn[] xin
iLen lenarray iArrIn
indxc = 0
iLenA = 0
while indxc < iLen do
	if iArrIn[indxc] != 0 then
	iLenA += 1
	endif
indxc += 1
od
		if iLenA == 0 then
		iLenA = 1
		endif
iArrOut[] init iLenA
indx = 0
indxw = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iArrOut[indxw] = iArrIn[indx]
	indxw += 1
	endif
indx += 1
od
xout iArrOut
endop

opcode swapArr, i[],i[]
iArrIn[] xin
iArrIn[] rmvZ iArrIn
iLen lenarray iArrIn
iArrOut[] init iLen
iWrite = 0
iRead = iLen-1
while iWrite < iLen do
iArrOut[iWrite] = iArrIn[iRead]
iWrite += 1
iRead -= 1
od
xout iArrOut
endop

opcode skpZ, i[],i[]
iArrIn[] xin
iLen lenarray iArrIn
indxc = 0
iLenA = 0
while indxc < iLen do
	if iArrIn[indxc] != 0 then
	iLenA += 1
	endif
indxc += 1
od
		if iLenA == 0 then
		iLenA = 1
		endif
iArrOut[] init iLen
indx = 0
indxw = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iArrOut[indxw] = iArrIn[indx]
	indxw += 1
	endif
indx += 1
od
xout iArrOut
endop


opcode StrToArr, i[],S
SIn xin
Snote     sprintf "%s ",SIn
iLenStr strlen SIn
iReadChar = 0
iCountChr = 0
while iReadChar < iLenStr do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	if strchar(Snote,iReadChar) == 32 then
	iCountChr += 1
	endif
	od	
iReadChar += 1
od

iArrOut[] init iCountChr

iWrite = 0
iRead = 0
while iRead < iLenStr do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
	Schar     strsub    Snote, iStart, iStart+iCountChr
	if strchar(Schar,0) != 0 then
	inum strtod Schar
	iArrOut[iWrite] = inum
	iWrite += 1
	endif
iRead += 1
od
xout iArrOut
endop



opcode ArrTala, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] init iLen
 iRead = 0
 iWrite = 1
 while iRead < iLen do
 	iOutArr[iRead] = iInArr[iWrite]
	iRead += 1
	iWrite = (iWrite+1) % (iLen)
 od
 xout iOutArr
endop

opcode ArrFl, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] = iInArr
 iRndIndx = int(random:i(0, iLen))
 iRndFl random -0.25, 0.25
 iOutArr[iRndIndx] = iOutArr[iRndIndx]+iRndFl
 if iOutArr[iRndIndx] <= 0.75 then
 iOutArr[iRndIndx] = 0.75
 endif
 xout iOutArr
endop



opcode ArrRnd, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] init iLen
 iRead = 0
 iSeq[] fillarray 1, 2, 4
 while iRead < iLen do
    iIndxSeq = int(random:i(0,3))
 	iOutArr[iRead] = iSeq[iIndxSeq]
	iRead += 1
 od
 xout iOutArr
endop


iLenSeq init 10
giNoteArr[] init iLenSeq
giEmptyArr[] init iLenSeq
giIndxNote init -1

instr GetMidi ;1
 iActive active "GetMidi"
 iHold cabbageGetValue "hold"
 kRel release
 iMidi notnum
; iVel veloc 0,127
 if iActive == 1 then
 giNoteArr[] = giEmptyArr
 giWriteNote = 0
 endif
 schedule "WriteMidi",0,.1,iNum,iVel
 	if kRel == 1 && changed(kRel) == 1 && iHold == 0 then
 	schedulek "WriteMidi", 0, .1,iNum,0
 	endif
endin
instr WriteMidi ;2
 iActive active "GetMidi"
 iNote = p4
 iVel = p5

 iLen lenarray giArrNote
 
 if iVel != 0 then
 					indxr = 0
 					iCountZero = 0
					while indxr < iLen do
						if giArrNote[indxr] != 0 then
						iCountZero += 1
						endif
					indxr += 1
					od
		if iCountZero != iLen then
			while giArrNote[giWriteNote] != 0 do
			giWriteNote = (giWriteNote+1) % iLen
			od
		else
			giWriteNote = (giWriteNote+1) % iLen
		endif
 giArrNote[giWriteNote] = iNote
 elseif iVel == 0 then
		indxw = 0
		while indxw < iLen do
			if giArrNote[indxw] == iNote then
			giArrNote[indxw] = 0
			giArrVeloc[indxw] = 0
			giWriteNote = indxw-1
			endif
		indxw += 1
		od
 giWriteNote = (giWriteNote-1) <= 0 ? 0 : giWriteNote
 endif
			if iActive1 == 0 then
			giWriteNote = 0
			endif
 giNote[] RmvZ giArrNote
 printarray giNote, "%d"
 giLenNote lenarray giNote
 gkLenNote lenarray giNote

  giArrVel[] RmvZ giArrVeloc
  giLenVel lenarray giArrVel

endin



instr seq
kSeqMod cabbageGet "seqmod"
printk2 kSeqMod
SIn = p4
iSeqArr[] StrToArr SIn
giSeqArr[] = iSeqArr
kNoteIndx init 0
kSeqIndx init 0
kTime init 1
kBPM cabbageGet "bpm"
kDv cabbageGet "dv"
kTempo = (kBPM/60)*kDv
if metro(1/kTime) == 1 then
kTime = giSeqArr[kSeqIndx]/kTempo
kNote = giNoteArr[kNoteIndx]

    schedulek "LED",0,0.1,1
    schedulek "LED",0.1,0.1,2
    schedulek "sound", 0, 0.5, kNote
    kNoteIndx = (kNoteIndx+1) % giLenValue
    kSeqIndx = (kSeqIndx+1) % lenarray(giSeqArr) 
        if kSeqIndx == 0 && kSeqMod == 2 then
        schedulek "tala", 0, 1
        elseif kSeqIndx == 0 && kSeqMod == 3 then
        schedulek "arrFL", 0, 1
        elseif kSeqIndx == 0 && kSeqMod == 4 then
        schedulek "arrRnd", 0, 1
        endif
endif

endin



instr tala
giSeqArr[] ArrTala giSeqArr
printarray giSeqArr, "%d"
endin


instr arrFL
giSeqArr[] ArrFl giSeqArr
printarray giSeqArr, "%.2f"
endin

instr arrRnd
giSeqArr[] ArrRnd giSeqArr
printarray giSeqArr, "%d"
endin



instr LED
if p4 == 1 then
Scolor = "colour(10, 250, 10)"
elseif p4 == 2 then
Scolor = "colour(10, 10, 10)"
endif
cabbageSet 1,"metronom",Scolor
endin

instr hold
 cabbageSetValue "hold",p4
endin

instr Empty ;7
giNoteArr[] = giEmpty
endin


instr sound
iNote = p4
iFrq mtof iNote
iAtt = 0.01
iAmp = 0.05
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq
outall aSound
endin

instr pulsPlay
kTime init 1
    if metro(kTime) == 1 then
    kTime random 2, 12
    kQ random 0, 3
    kFrq random 1000, 5000
    schedulek "puls", 0, 1, kFrq, kQ
    endif
endin


instr puls
iFrq = p4
	aSamp = mpulse:a(1/2, p3+1)
	iQ = p5
	aFilter = mode:a(aSamp, iFrq, iQ)	
	a1 dust 0.4, 2
	a2 gausstrig 0.5, 3, 0.9	
	aDust sum a1,a2,aFilter	
    iCh = int(random:i( 1, 5))
	SchnSend sprintf "snddust%d", iCh
	chnmix aDust, SchnSend
endin



instr OutSound
kGain cabbageGet "gain"
kAmpIn1 cabbageGet "out1"
kAmpIn2 cabbageGet "out2"
kAmpIn3 cabbageGet "out3"
kAmpIn4 cabbageGet "out4"

idB = 25
kAmp1 = kAmpIn1-idB
kAmp2 = kAmpIn2-idB
kAmp3 = kAmpIn3-idB
kAmp4 = kAmpIn4-idB
kAmpdB1 ampdb kAmp1
kAmpdB2 ampdb kAmp2
kAmpdB3 ampdb kAmp3
kAmpdB4 ampdb kAmp4


aInPlus1 chnget "snddust1"
aInPlus2 chnget "snddust2"
aInPlus3 chnget "snddust3"
aInPlus4 chnget "snddust4"

aOut1 = aInPlus1*kAmpdB1*kGain
aOut2 = aInPlus2*kAmpdB2*kGain
aOut3 = aInPlus3*kAmpdB3*kGain
aOut4 = aInPlus4*kAmpdB4*kGain



CsdMeter "clip1", aOut1, metro(20), "meter1"	
CsdMeter "clip2", aOut2, metro(20), "meter2"	
CsdMeter "clip3", aOut3, metro(20), "meter3"	
CsdMeter "clip4", aOut4, metro(20), "meter4"	

	outch 1, aOut1
	outch 2, aOut2
	outch 3, aOut3
	outch 4, aOut4
	
	chnclear "snddust1","snddust2","snddust3","snddust4"
endin



instr Widgets

SseqIn cabbageGet "seqarr"
schedule "seq",0,99999,SseqIn
if changed(SseqIn) == 1 then
turnoff2 "seq", 0,0
schedulek "seq",0,9999,SseqIn
endif


kTimePort linseg 0, 0.01, 0.05

kSlider1   ctrl7    1,27,0,40
kSlider1 portk kSlider1, kTimePort
cabbageSetValue  "out1", kSlider1

kSlider2   ctrl7    1,28,0,40
kSlider2 portk kSlider2, kTimePort
cabbageSetValue  "out2", kSlider2

kSlider3  ctrl7    1,35,0,40
kSlider3 portk kSlider3, kTimePort
cabbageSetValue  "out3", kSlider3

kSlider4   ctrl7    1,36,0,40
kSlider4 portk kSlider4, kTimePort
cabbageSetValue  "out4", kSlider4


  kPedal ctrl7 2,64,0,1
  if kPedal == 1 && changed(kPedal) == 1 then
  schedulek "hold", 0,0.1,1
  schedulek "GetMidi", 0, 1 
  elseif kPedal == 0 && changed(kPedal) == 1 then
  schedulek "Empty",0,0.1,1
  schedulek "hold",0,0.1,0
  endif
  kHold cabbageGet "hold"
  if kHold == 0 && changed(kHold) == 1 then
  schedulek "Empty",0,0.1,1
  endif
endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

