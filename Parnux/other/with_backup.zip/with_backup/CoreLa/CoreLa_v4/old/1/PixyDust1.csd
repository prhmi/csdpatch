;v3
<Cabbage>
form caption("PixyDust")    size(900, 500)   guiMode("queue") colour(45,10,35) pluginId("pxds") ; style("legacy")

;trackerColour(219, 120, 120, 255)


vslider bounds(620, 342, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(219, 120, 120, 255) 
vslider bounds(662, 342, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(219, 120, 120, 255)
vslider bounds(702, 342, 50, 150) channel("out3") range(0, 80, 0, 1, 1) trackerColour(219, 120, 120, 255)
vslider bounds(744, 342, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(219, 120, 120, 255)
nslider bounds(626, 307, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(80, 50, 50, 255)
nslider bounds(666, 307, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(80, 50, 50, 255)
nslider bounds(706, 307, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(80, 50, 50, 255)
nslider bounds(746, 307, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(80, 50, 50, 255)
nslider bounds(794, 274, 93, 44) channel("gain") range(-90, 50, 0, 1, 1) colour(80, 50, 50, 255) text("Master Gain (dB)")

label bounds(654, 44, 239, 66) channel("sec") text("00 : 02") fontColour(241, 178, 178, 255)
label bounds(694, 8, 70, 33) channel("data")  fontColour(241, 178, 178, 255) colour(80, 50, 50, 255) text("0")
button bounds(774, 12, 116, 27) channel("start") text("S  T  A  R  T", "S  T  O  P") colour:0(91, 161, 197, 255) colour:1(99, 85, 85, 255) value(1)

image bounds(100, 270, 30, 30) channel("flutelight") corners(5) colour(80, 50, 50, 255)
label bounds(136, 270, 30, 30) channel("activeflute")  corners(5) fontColour(135, 226, 127, 255) colour(80, 50, 50, 255) text("")


vmeter bounds(798, 342, 15, 150) channel("meter1") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(822, 342, 15, 150) channel("meter2") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(846, 342, 15, 150) channel("meter3") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(870, 342, 15, 150) channel("meter4") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
image bounds(798, 328, 15, 15) channel("clip1") colour(0,0,0)
image bounds(822, 328, 15, 15) channel("clip2") colour(0,0,0)
image bounds(846, 328, 15, 15) channel("clip3") colour(0,0,0)
image bounds(870, 328, 15, 15) channel("clip4") colour(0,0,0)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0


opcode CsdMeter, 0, SakS
 SClip, aSig, kTrig, Smeter	xin
 iDbRange = 60 ;shows 60 dB
 iHoldTim = 0.5;seconds to "hold the red light"
 kOn init 0
 kTim init 0
 kStart init 0
 kEnd init 0
 kMax max_k aSig, kTrig, 1
 cabbageSetValue Smeter, kMax, metro(20)
 
 if kTrig == 1 then
 kMeter = (iDbRange + dbfsamp(kMax)) / iDbRange
  if kOn == 0 && kMax > 1 then
   kTim = 0
   kEnd = iHoldTim
   cabbageSet 1,SClip,"colour(250,0, 0)"
   kOn = 1
  endif
  if kOn == 1 && kTim > kEnd then
   cabbageSet 1,SClip,"colour(0,0,0)"
   kOn =	0
  endif
 endif
 kTim += ksmps/sr
endop

opcode limiter, a,ai
aIn, iThrshhol xin
kThrsh rms aIn, 0.1
kTrig metro 10
kMax max_k aIn, kTrig, 1
kAmpdB dbamp kMax
if kAmpdB <= -50 then
kAmpdB = -90
elseif kAmpdB >= 1 then
kAmpdB = 1
endif
 kFctr = iThrshhol-kAmpdB
 kLimitdB ampdb kFctr
if kLimitdB >= 1 then
kLimitdB = 1
endif
 aLimiter interp kLimitdB
 aDelay delay aIn, 0.1
 aOut = aDelay*aLimiter
xout aOut
endop



 massign 1,16


instr seqMachine
SinstrArr[] fillarray "sineSound", "barSound", "bamSound", "bamSound", "shakeSound", "pluckSound"
 kTime init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 if metro(1/kTime) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 12))
 	trim kSeqArr, kLen
 		kIndx = 0 
 		while kIndx < kLen-1 do
 		kSeqValue random 1, 3
 		kSeqArr[kIndx] = kSeqValue
 		kIndx += 1
 		od
 	kMaxValue random 15, 20
 	kSeqArr[kLen-1] = kMaxValue
 	endif 
 kInstr = int(random:k(0, 6))
 Sinstr = SinstrArr[kInstr]
 schedulek Sinstr, 0, kTime
 kIndxSeq = (kIndxSeq+1) % kLen
 kTime = kSeqArr[kIndxSeq]/10
 endif
endin

instr sineSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
iFrq random 200, 1200
iAtt = 0.005
iAmp = 0.1
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq
chnmix aSound, "sndseq"
endin

instr barSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
iFrq random 10, 70
;kScan rspline 0.1, 0.8, p3*2, p3*4
iPoseMin random 0.001, 1
iPoseMax random 2, 10
iScan = random(0, 100) > 90 ? iPoseMin : iPoseMax
iRel = 0.5 ;random 0.01, 0.5
iPose = 0.005 ;random 0.001, 0.1
iPres random 0.1, 0.5
aSound    barmodel       1, 1, iFrq, iRel, iScan, 1, iPose, 50000, iPres
iAtt = 0.001
aEnv transeg 0, iAtt, 6, 1;, p3-iAtt, -6, 0
iFilter random 800, 3000
aFilt clfilt aSound*aEnv, iFilter, 1, 10
;outall aFilt
chnmix aFilt, "sndseq"
endin

instr bamSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
p3 random 0.05, 3
iFrq random 10, 50
iFilter random 3000, 8000
iAtt = 0.01
aEnv transeg 0, iAtt, 6, 0.5, p3-iAtt, -6, 0
iAmp = 2000
iNumber random 1, 7
iDamp random 0.0001, 0.05
iDecay random 0.001, 0.1
aSound  bamboo iAmp, iDecay, iNumber, iDamp, 1, iFrq, 400
aFilt clfilt aSound*aEnv, iFilter, 1, 10
aLimit limiter aFilt, -15
chnmix aLimit, "sndseq"
endin


instr shakeSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
p3 random 0.01, 0.1
iRel random 0.1, 1
aEnv linsegr 1, iRel, 0
knum  rspline 2, 15, 2, 7
kFrq rspline 700, 3000, 2, 15
asig shaker .03, kFrq, 8, 0.9, knum
iFilter random 300, 500
aFilt clfilt asig*aEnv, iFilter, 1, 10		
chnmix aFilt, "sndseq"
endin


instr pluckSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
giRvrbTime random 0.7, 0.9
iAmp random 0.3, 0.5
iAtt random 0.008, 0.01
iRel random 0.1, 1
aEnv linsegr 0, iAtt, 1, iRel, 0
iFrq random 30, 1500
iResample random 20, 1500
iMeth = random:i(0, 100) < 50 ? 1 : 6
aSound  pluck iAmp, iFrq, iResample, 0, iMeth;, 2, 1
iFilter random 300, 1500
aFilt clfilt aSound*aEnv, iFilter, 0, 10	
aFilt clfilt aSound*aEnv, 200, 1, 10	
chnmix aFilt, "sndseq"
endin





instr DustMachine
 kTimeG init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 kFrq init 7000
 if metro(kTimeG) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 3))
 	kSeqValue random 1/3, 1/2
 	trim kSeqArr, kLen
 		kIndx = 0
 		while kIndx < kLen-1 do
		kRndSeq random 0, 0.2
 		kSeqArr[kIndx] = kSeqValue+kRndSeq
 		kIndx += 1
 		od
 	kMaxValue random 1/7, 1/15
 	kSeqArr[kLen-1] = kMaxValue
 	kFrq random 1000, 9000
 	kLoop random 2, 4
 	endif 
 kLenOut random 1, 7
 kDur random 0.5, 3
 schedulek "guiroPlay", 0, 1, kFrq, kLoop,kLenOut
 	kIndx = 0
 	kFrq2 random 1000, 9000 
 	kNumber random 1, 6
 	while kIndx < int(kNumber) do
 	kStart random 1, 7
 	schedulek "guiroSound", kStart, 1, kFrq2, kLoop
 	kIndx += 1
 	od
 kTimeG = kSeqArr[kIndxSeq]
 kIndxSeq = (kIndxSeq+1) % kLen
 endif


kTimePulse init 1
if metro(kTimePulse) == 1 then
kTimePulse random 2, 5
    kQ random 0, 3
    schedulek "pulseSound", 0, 1, kFrq, kQ
endif


endin

instr noiseSound
iAmpdB ampdb -10
iDelayTime = 0.1
kFb rspline 50, 200, 1, 12
kGainRnd rspline 0, 1, 2, 13
aNoise noise 1, 0.5
aNoise = aNoise*5
aFb init 1
aNoise = (aNoise*kFb)+aFb
aSine poscil 1, aNoise
aPhas phasor aNoise
aSum sum aSine, aPhas
aFb delay aSum, iDelayTime
kHighCut = 15000
kLowCut = 5000
  aFilt clfilt aFb, kHighCut, 0, 10
  aFilt  clfilt aFilt, kLowCut, 1, 10
aOut = aFilt*kGainRnd*iAmpdB
outall aOut
endin





instr pulseSound
iFrq = p4
	aSamp = mpulse:a(1/2, p3+1)
	iQ = p5
	aFilter = mode:a(aSamp, iFrq, iQ)	
	a1 dust 0.4, 2
	a2 gausstrig 0.5, 3, 0.9	
	aDust sum a1,a2,aFilter	
;    iCh = int(random:i( 1, 5))
;	SchnSend sprintf "snddust%d", iCh
	chnmix aDust, "snddust"
endin


instr guiroPlay
iLen = int(p6)
indx = 0
iStart = 0
while indx < iLen do
schedule 3, iStart, 1,p4,p6
iStart += 0.175
indx += 1
od
endin

instr guiroSound
iFrqIn = p4
iFrq random iFrqIn, iFrqIn*1.01
iNum random 128, 128
iAmp = (iFrqIn/10000)^2
aSound  guiro iAmp*0.1, 0, 128, 0, 0, iFrq, iFrq*2
iLoopDur = p5
iRndLoop random 3, 10
iLoop = iLoopDur/iRndLoop
aComb comb aSound, iLoopDur, iLoop
iFrqRnd random 0, 100
iRel = 0.1
;aRel transegr 1, iRel, -6, 0
aRes reson aSound, iFrq*1.1+iFrqRnd, 200
chnmix aRes, "snddust"
;outall aSound
endin

instr wgMachine
kTimeBow init 1
if metro(1/kTimeBow) == 1 then
kTimeBow random 5, 7
kDurBow = kTimeBow*1.3
schedulek "bowSound", 0, kDurBow
endif
kTimeFlute init 1
if metro(1/kTimeFlute) == 1 then
kTimeFlute random 5, 7
kDurFlute = kTimeFlute*1.3
schedulek "fluteSound", 0, kDurFlute
endif
kTimeClr init 1
if metro(1/kTimeClr) == 1 then
kTimeClr random 5, 7
kDurClr = kTimeClr*1.3
;schedulek "clarinetSound", 0, kDurClr
endif
kTimeAmbWg init 1
if metro(1/kTimeAmbWg) == 1 then
kTimeAmbWg random 5, 7
kDurAmbWg = kTimeAmbWg*1.3
;schedulek "wgAmbSound", 0, kDurAmbWg
endif
endin

instr bowSound
iGain ampdb -15
;iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
iWave     ftgenonce 1,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
 	iBaseFrq random 100, 400
 	iFrqMin random 10, 1000
 print iBaseFrq,iFrqMin
 kSpeedMin  = 0.1
 kSpeedMax  = 0.7
 kVibIn     = 5
  kVibRng  = 5
 kPosIn     = 0.1
	kAmp   rspline  0.2, 0.7, 0.7, 1
	kCent = 10
	kCentFrq    jspline  kCent, kSpeedMin, kSpeedMax
	kFrq = iBaseFrq*cent(kCentFrq)
	kPres  rspline  3, 4, kSpeedMin, kSpeedMax
	kRate   rspline 0.025, kPosIn, kSpeedMin, kSpeedMax
	kVib   jspline  kVibIn/1000, kSpeedMin, kSpeedMax
	aBow	wgbow    kAmp,kFrq,kPres,kRate,kVib,kVibRng/100,iWave, iFrqMin
    kFilterBow = 12000
    aFiltBow clfilt aBow, kFilterBow, 0, 10
    aFiltBow clfilt aFiltBow, 150, 1, 10

    aOut linen aFiltBow*iGain, p3/2, p3, p3/2
	
;	outall aOut
	chnmix aOut, "sndwg"
endin



instr fluteSound
;iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
iBaseFrq random 10, 50
 kSpeedMin = 0.03
 kSpeedMax = 0.1
kAmp rspline 0.03, 0.2, kSpeedMin, kSpeedMax
kJet rspline 0.01, 0.9, kSpeedMin, kSpeedMax
kVib rspline 0, 2, kSpeedMin, kSpeedMax
kVamp rspline 0.1, 0.5, kSpeedMin, kSpeedMax
kCent = 0
kGliss jspline kCent, kSpeedMin, kSpeedMax
kFrq = iBaseFrq*cent(kGliss)
iAtt = 0.5
   aFlute  wgflute kAmp, kFrq, kJet, iAtt, 0.5, 0.4, kVib, kVamp, iWave

		kFilterFlute = 1200
    aFiltFlute clfilt aFlute, kFilterFlute, 0, 10
    aFiltFlute clfilt aFiltFlute, 250, 1, 10
    aOut linen aFiltFlute, p3/2, p3, p3/2
  chnmix aOut, "sndwg"
endin



instr clarinetSound
;iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
iBaseFrq random 100, 200

iMidi notnum
iFrqMin = (mtof:i(iMidi))/2

iFrqMin = 50
print iMidi
;iFrqMin = 10
 kSpeedMin = 0.03
 kSpeedMax = 0.1
kAmp rspline 0.03, 0.2, kSpeedMin, kSpeedMax
kCent = 0
kGliss jspline kCent, kSpeedMin, kSpeedMax
kFrq = iBaseFrq*cent(kGliss)
  kStiff rspline -0.4, -0.18, 2, 3
  iAtt1 = 1.2
  iDetk = 0.1
  kAirNoise rspline 0, 0.3, 2, 3
  kVibClr jspline 3, 0.4, 0.7
  kvAmpClr rspline 0.5, 2, 2, 7
  aClar wgclar kAmp, kFrq, kStiff, iAtt1, iDetk, \
  kAirNoise, kVibClr, kvAmpClr, iWave, iFrqMin

		kFilterClr = 7000
    aFiltClr clfilt aClar, kFilterClr, 0, 10
    aFiltClr clfilt aFiltClr, 250, 1, 10
    aOut linen aFiltClr, p3/2, p3, p3/2
  chnmix aOut, "sndwg"
;outall aFiltClr
endin




instr wgAmbSound
iGainMaster ampdb 0
iGainClr ampdb -7
iGainBw ampdb -10
iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
iMidi notnum
iFrqMin = (mtof:i(iMidi))/2
print iFrqMin
;iFrqMin = 50
	;;clr
  kAmpClr rspline 0.3, 0.4, 2, 5
  kFrqClrIn = 270
  kFrqClr rspline kFrqClrIn, kFrqClrIn*1.01, 0.4, 0.7
  kStiff rspline -0.4, -0.18, 2, 3
  iAtt1 = 1.2
  iDetk = 0.1
  kAirNoise rspline 0, 0.5, 2, 3
  kVibClr jspline 50, 0.4, 0.7
  kvAmpClr rspline 0.5, 2, 2, 7
  aClar wgclar kAmpClr*iGainClr, kFrqClr, kStiff, iAtt1, iDetk, \
  kAirNoise, kVibClr, kvAmpClr, iWave, iFrqMin
  ;;bow
   kAmpBw rspline 0.3, 0.4, 2, 5
   kPres rspline 0.01, 5, 5, 10
	kRate rspline 0.025, 0.225, 4, 13
	kVibBw jspline 0.1, 0.9, 1
	kvAmpBw = 0.02
	kFrqBwIn mtof iMidi; 320
	kCent = 50
	kFrqCent jspline kCent, 0.1, 0.4
	kFrqBw = kFrqBwIn*cent(kFrqCent)
   aBow  wgbow kAmpBw*iGainBw, kFrqBw, kPres, kRate, kVibBw, kvAmpBw,\
   iWave, iFrqMin
   ;;output
   aSum sum  aBow , aClar
   kFilt rspline 700, 5000, 0.4, 0.7
   aFilt clfilt aSum, kFilt, 0, 10
   aFilt clfilt aFilt, 150, 1, 10
   aDel delay aFilt, 0.4
   aMix ntrpol aFilt, aDel, 0.3  
   iAtt = 1
   iRel = 1
   aEnv linsegr 0, iAtt, iGainMaster, iRel, 0 
   aOut = aMix*aEnv
  outall aOut
endin

instr FxDust
aIn chnget "snddust"
aRvrb,aRvrb  reverbsc aIn,aIn, 0.65, 17000, sr, 1, 1
aMix ntrpol aIn, aRvrb, 0.4
outall aMix
chnclear "snddust"
endin

instr FxWg
aIn chnget "sndwg"
aRvrb,aRvrb  reverbsc aIn,aIn, 0.85, 17000, sr, 1, 1
aMix ntrpol aIn, aRvrb, 0.3
outall aMix
chnclear "sndwg"
endin

instr FxSeq
aIn chnget "sndseq"
	
 	aTim	interp	giDelayTime
 	abuf	delayr	15
 	aDelay	deltapi	aTim	
 	delayw	aIn + (aDelay*giFeedback)
 	kDelayMix rspline 0.2, 0.7, 1, 3
 	aDelayMix ntrpol aIn, aDelay, kDelayMix
 	aRvrb,aRvrb  reverbsc aDelayMix,aDelayMix, 0.7, 3000, sr, 0.3, 1
;	aRvrb reverb aDelayMix, 1
	kRvbMix rspline 0.3, 0.7, 2, 5
	aMix ntrpol aIn, aRvrb, kRvbMix
	aOut = aMix
outall aOut
chnclear "sndseq"
endin


instr time
kTimer line 0, 1, 1
kSec = int(kTimer)
kMin init 0
kSec = kSec % 60
if kSec == 0 && changed(kSec) == 1 then
kMin += 1
endif
STimer sprintfk "%02d : %02d", kMin, kSec
cabbageSet 1, "sec", "text", STimer

endin

instr Widgets
schedule "time", 0, 99999
schedule "seqMachine", 0, 9999
schedule "FxSeq", 0, 9999

;schedule "DustMachine", 0, 9999
;schedule "FxDust", 0, 9999
;schedule "noiseSound", 0, 1999

schedule "wgMachine", 0, 9999
schedule "FxWg", 0, 9999

endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

