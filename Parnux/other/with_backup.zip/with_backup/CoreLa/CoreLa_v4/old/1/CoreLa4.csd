;v3 
<Cabbage>
form caption("CoreLa")    size(900, 500)   guiMode("queue") colour(10,45,35) pluginId("crla") ; style("legacy")

image bounds(364, 117, 15, 15) channel("metronom") colour(10,10,10)

texteditor bounds(60, 115, 175, 20) channel("seqarr") colour:0(71, 137, 100, 255)fontSize(20) text("1 1 2 1 2") colour(71, 137, 100, 255)

checkbox bounds(868, 12, 20, 20) channel("midi") colour:0(99, 94, 94, 255) colour:1(71, 137, 100, 255), 
combobox bounds(394, 112, 77, 25)   channel("BNote")   text("Note", "G", "A-", "Bb", "C", "E-", "D-", "F", "A", "B", "Gb", "D")  colour(49, 79, 62, 255)  value(2)
combobox bounds(362, 86, 109, 25)   channel("scale")   text("Scale", "pythagorean", "shur", "abuata", "bayat tork", "afshari", "dashti", "nava", "segah", "chargah",  "homayun", "bayat esf") colour(49, 79, 62, 255) value(2) 


vslider bounds(620, 342, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(71, 137, 100, 255) 
vslider bounds(662, 342, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(0)
vslider bounds(702, 342, 50, 150) channel("out3") range(0, 80, 0, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(0)
vslider bounds(744, 342, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(0)
vslider bounds(848, 166, 50, 150) channel("gain") range(0, 1.5, 1, 1, 0.1) trackerColour(71, 137, 100, 255) valueTextBox(0)
hslider bounds(60, 138, 238, 40) channel("dur") range(0.1, 10, 1, 1, 0.1) trackerColour(71, 137, 100, 255) valueTextBox(0)
hslider bounds(60, 160, 238, 40) channel("att") range(0.001, 1, 0.01, 1, 0.001) trackerColour(71, 137, 100, 255) valueTextBox(0)

vmeter bounds(798, 342, 15, 150) channel("meter1") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(822, 342, 15, 150) channel("meter2") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(846, 342, 15, 150) channel("meter3") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(870, 342, 15, 150) channel("meter4") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
image bounds(798, 328, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(822, 328, 15, 15) channel("clip2") colour(0,0,0)
image bounds(846, 328, 15, 15) channel("clip3") colour(0,0,0)
image bounds(870, 328, 15, 15) channel("clip4") colour(0,0,0)


label bounds(24, 118, 37, 15) channel("label1") text("seq")
combobox bounds(238, 115, 60, 20) channel("seqmod") colour(49, 79, 62, 255) text("ord", "tala", "Brk", "Rnd"), value(1)
checkbox bounds(302, 115, 20, 20) channel("hold") colour:0(99, 94, 94, 255) colour:1(71, 137, 100, 255), 
label bounds(324, 117, 37, 15) channel("label2") text("hold")
nslider bounds(62, 84, 43, 30) channel("bpm") range(10, 210, 90, 1, 1) colour(71, 137, 100, 255) fontColour(0, 0, 0, 255)
nslider bounds(126, 84, 31, 30) channel("dv") range(1, 16, 4, 1, 1) colour(71, 137, 100, 255) fontColour(0, 0, 0, 255)
label bounds(110, 96, 10, 15) channel("label3") text("x")
label bounds(26, 150, 32, 16) channel("label4") text("dur")
label bounds(302, 148, 59, 18) channel("label5") text("CC-10") fontColour(224, 219, 219, 255)
label bounds(26, 174, 32, 16) channel("label6") text("att")
label bounds(302, 172, 59, 18) channel("label7") text("CC-11") fontColour(224, 219, 219, 255)



nslider bounds(626, 307, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(49, 79, 62, 255)
nslider bounds(666, 307, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(49, 79, 62, 255)
nslider bounds(706, 307, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(49, 79, 62, 255)
nslider bounds(746, 307, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(49, 79, 62, 255)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0

 massign 1,1
 
opcode CsdMeter, 0, SakS
 SClip, aSig, kTrig, Smeter	xin
 iDbRange = 60
 iHoldTim = 0.5
 kOn init 0
 kTim init 0
 kStart init 0
 kEnd init 0
 kMax max_k aSig, kTrig, 1
 cabbageSetValue Smeter, kMax, metro(20)
 
 if kTrig == 1 then
 kMeter = (iDbRange + dbfsamp(kMax)) / iDbRange
  if kOn == 0 && kMax > 1 then
   kTim = 0
   kEnd = iHoldTim
   cabbageSet 1,SClip,"colour(250,0, 0)"
   kOn = 1
  endif
  if kOn == 1 && kTim > kEnd then
   cabbageSet 1,SClip,"colour(0,0,0)"
   kOn =	0
  endif
 endif
 kTim += ksmps/sr
endop

opcode countValue, i,i[]
iArrIn[] xin
iLen lenarray iArrIn
indx = 0
iCountValue = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iCountValue += 1
	endif
indx += 1
od
xout iCountValue
endop


opcode rmvZ, i[],i[]
iArrIn[] xin
iLen lenarray iArrIn
indxc = 0
iLenA = 0
while indxc < iLen do
	if iArrIn[indxc] != 0 then
	iLenA += 1
	endif
indxc += 1
od
		if iLenA == 0 then
		iLenA = 1
		endif
iArrOut[] init iLenA
indx = 0
indxw = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iArrOut[indxw] = iArrIn[indx]
	indxw += 1
	endif
indx += 1
od
xout iArrOut
endop

opcode swapArr, i[],i[]
iArrIn[] xin
iArrIn[] rmvZ iArrIn
iLen lenarray iArrIn
iArrOut[] init iLen
iWrite = 0
iRead = iLen-1
while iWrite < iLen do
iArrOut[iWrite] = iArrIn[iRead]
iWrite += 1
iRead -= 1
od
xout iArrOut
endop

opcode skpZ, i[],i[]
iArrIn[] xin
iLen lenarray iArrIn
indxc = 0
iLenA = 0
while indxc < iLen do
	if iArrIn[indxc] != 0 then
	iLenA += 1
	endif
indxc += 1
od
		if iLenA == 0 then
		iLenA = 1
		endif
iArrOut[] init iLen
indx = 0
indxw = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iArrOut[indxw] = iArrIn[indx]
	indxw += 1
	endif
indx += 1
od
xout iArrOut
endop


opcode StrToArr, i[],S
SIn xin
Snote     sprintf "%s ",SIn
iLenStr strlen SIn
iReadChar = 0
iCountChr = 0
while iReadChar < iLenStr do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	if strchar(Snote,iReadChar) == 32 then
	iCountChr += 1
	endif
	od	
iReadChar += 1
od

iArrOut[] init iCountChr

iWrite = 0
iRead = 0
while iRead < iLenStr do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
	Schar     strsub    Snote, iStart, iStart+iCountChr
	if strchar(Schar,0) != 0 then
	inum strtod Schar
	iArrOut[iWrite] = inum
	iWrite += 1
	endif
iRead += 1
od
xout iArrOut
endop



opcode ArrTala, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] init iLen
 iRead = 0
 iWrite = 1
 while iRead < iLen do
 	iOutArr[iRead] = iInArr[iWrite]
	iRead += 1
	iWrite = (iWrite+1) % (iLen)
 od
 xout iOutArr
endop

opcode ArrFl, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] = iInArr
 iRndIndx = int(random:i(0, iLen))
 iRndFl random -0.25, 0.25
 iOutArr[iRndIndx] = iOutArr[iRndIndx]+iRndFl
 if iOutArr[iRndIndx] <= 0.75 then
 iOutArr[iRndIndx] = 0.75
 endif
 xout iOutArr
endop



opcode ArrRnd, i[], i[]
 iInArr[] xin
 iLen lenarray iInArr
 iOutArr[] init iLen
 iRead = 0
 iSeq[] fillarray 1, 2, 4
 while iRead < iLen do
    iIndxSeq = int(random:i(0,3))
 	iOutArr[iRead] = iSeq[iIndxSeq]
	iRead += 1
 od
 xout iOutArr
endop


;;scale
giScaleArr[] init 12
giShurArr[] 			fillarray 0, 1.5, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1
giAbuataArr[] 		fillarray 0, 0.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
giBayattorkArr[] 	fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5
giAfshariArr[] 		fillarray 0, 1.5,0.5, 1, 1, 1, 1, 1, 1.5,0.5, 1, 1
giDashtiArr[] 		fillarray 0, 1, 1, 1, 1, 1, 1.5,0.5,  1, 1, 1, 1
giNavaArr[] 			fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5, 1, 1
gi3gahArr[] 			fillarray 0, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1, 1
gi4gahArr[] 			fillarray 0, 1.5, 0.5, 1, 1,1, 1, 1, 1.5, 0.5, 1, 1
giHomayunArr[]   	fillarray 0, 0.5, 1, 1, 1,1, 1, 1.5, 0.5, 1, 1, 1
giBayatEsArr[]   	fillarray 0, 1,1,1, 1, 1,1,1, 1.5, 0.5, 1.5, 0.5

opcode pythagorean,i,ii
iBaseNote,iNote xin
iMidi = iNote
		iOct = 0
     until iMidi < iBaseNote+12 do
  		iMidi = iMidi-12
  		iOct += 1
  		enduntil
 iMidiMin = (iMidi-iBaseNote)
  	iRatio = 1
  	if iMidiMin == 0 then
  	iRatio = 1/1
  	elseif iMidiMin == 1 then
  	iRatio = 2187/2048
  	elseif iMidiMin == 2 then
  	iRatio = 9/8
  	elseif iMidiMin == 3 then
  	iRatio = 32/27
  	elseif iMidiMin == 4 then
  	iRatio = 81/64
  	elseif iMidiMin == 5 then
  	iRatio = 4/3
  	elseif iMidiMin == 6 then
  	iRatio = 729/512
  	elseif iMidiMin == 7 then
  	iRatio = 3/2
  	elseif iMidiMin == 8 then
  	iRatio = 6561/4096
  	elseif iMidiMin == 9 then
  	iRatio = 27/16
  	elseif iMidiMin == 10 then
  	iRatio = 16/9
  	elseif iMidiMin == 11 then
  	iRatio = 243/128
  	elseif iMidiMin == 12 then
  	iRatio = 2/1
  	endif
  	
iBaseFrq mtof iBaseNote+(iOct*12)
iFrq = (iBaseFrq)*iRatio
iMidiOut ftom iFrq
xout iMidiOut
endop


opcode dastgah, i,i[]iii
  iInArr[],iBaseMidi,iMidiIn,iQ xin
  iLen lenarray iInArr
  iOutArr[] init iLen
  iNote = iBaseMidi
  indx = 0
	while indx < iLen do
	iNote = iNote+(iInArr[indx])
	iOutArr[indx] = iNote
	indx += 1
	od
	iMidi = int(iMidiIn)+iQ
	indxOct = 0
	     until iMidi < iBaseMidi+12 do
	     indxOct += 1
  		iMidi = iMidi-12
  		enduntil
  		iIntrval = (iMidi-iBaseMidi)
iMidiOut = iOutArr[iIntrval]+(12*indxOct)
SnoteOut mton iMidiOut
  xout iMidiOut
endop











iLenSeq init 10
giNoteArr[] init iLenSeq
giEmpty[] init iLenSeq
giIndxNote init 0

instr GetMidi ;1
 iActive active "GetMidi"
 iHold cabbageGetValue "hold"
 kHold cabbageGet "hold"
 kRel release
 iMidi notnum
  if iActive == 1 then
  giNoteArr[] = giEmpty
  giIndxNote = 0
  endif
 
 giNoteArr[giIndxNote] = iMidi
 giIndxNote = (giIndxNote+1) % lenarray(giNoteArr)
 gkMaxIndx = giIndxNote
 printarray giNoteArr,"%d","Notes:"
 
 if kRel == 1 && kHold == 0  then
 schedulek "rmvMidi", 0, 0.1, iMidi
 endif
 
endin
instr rmvMidi ;2
 iRead = 0
    while iRead < lenarray(giNoteArr) do
        if giNoteArr[iRead] == p4 then
        giNoteArr[iRead] = 0
        endif
    iRead += 1
    od
 giNoteArr skpZ giNoteArr
 printarray giNoteArr,"%d","Notes(R):"
 giIndxNote -= 1
endin



instr seq
kSeqMod cabbageGet "seqmod"
SIn = p4
iSeqArr[] StrToArr SIn
giSeqArr[] = iSeqArr
kNoteIndx init 0
kSeqIndx init 0
kTime init 1
kBPM cabbageGet "bpm"
kDv cabbageGet "dv"
kDurIn cabbageGet "dur"
kTempo = (kBPM/60)*kDv
    if metro(1/kTime) == 1 then
    kDur = kTime*kDurIn
        if kNoteIndx > (gkMaxIndx-1) then
        kNoteIndx = (gkMaxIndx-1)
        endif
    kNote = giNoteArr[kNoteIndx]
    schedulek "LED",0,0.1,1
    schedulek "LED",0.1,0.1,2
        if kNote != 0 then
        schedulek "sound", 0, kDur, kNote
        endif
    kTime = giSeqArr[kSeqIndx]/kTempo
    kNoteIndx = (kNoteIndx+1) % giIndxNote
    kSeqIndx = (kSeqIndx+1) % lenarray(giSeqArr) 
        if kSeqIndx == 0 && kSeqMod == 2 then
        schedulek "tala", 0, 1
        elseif kSeqIndx == 0 && kSeqMod == 3 then
        schedulek "arrFL", 0, 1
        elseif kSeqIndx == 0 && kSeqMod == 4 then
        schedulek "arrRnd", 0, 1
        endif
    endif

endin



instr tala
giSeqArr[] ArrTala giSeqArr
printarray giSeqArr, "%d"
endin


instr arrFL
giSeqArr[] ArrFl giSeqArr
printarray giSeqArr, "%.2f"
endin

instr arrRnd
giSeqArr[] ArrRnd giSeqArr
printarray giSeqArr, "%d"
endin



instr LED
if p4 == 1 then
Scolor = "colour(10, 250, 10)"
elseif p4 == 2 then
Scolor = "colour(10, 10, 10)"
endif
cabbageSet 1,"metronom",Scolor
endin


instr Empty ;7
iActive = p4
    if iActive == 0 then
    giNoteArr[] = giEmpty
    else
    endif
endin


instr sound
;print 1
iMidiNote = p4


iBaseNoteIn cabbageGetValue "BNote"

if iBaseNoteIn == 2 then
SbaseNote = "0G"
iQ = 0
elseif iBaseNoteIn == 3 then
SbaseNote = "0A-"
iQ = 1
elseif iBaseNoteIn == 4 then
SbaseNote = "0Bb"
iQ = 0
elseif iBaseNoteIn == 5 then
SbaseNote = "0C"
iQ = 0
elseif iBaseNoteIn == 6 then
SbaseNote = "0E-"
iQ = 1
elseif iBaseNoteIn == 7 then
SbaseNote = "0D-"
iQ = 1
elseif iBaseNoteIn == 8 then
SbaseNote = "0F"
iQ = 0
elseif iBaseNoteIn == 9 then
SbaseNote = "0A"
iQ = 0
elseif iBaseNoteIn == 10 then
SbaseNote = "0B"
iQ = 0
elseif iBaseNoteIn == 11 then
SbaseNote = "0Gb"
iQ = 0
elseif iBaseNoteIn == 12 then
SbaseNote = "0D"
iQ = 0
endif
iBaseNote ntom SbaseNote
iScale      cabbageGetValue "scale"
if iScale == 1 then
iMidiOut = iMidiNote
elseif iScale == 2 then
iMidiOut pythagorean iBaseNote,iMidiNote
SnoteName mton iMidiOut
elseif iScale == 3 then
iMidiOut dastgah giShurArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 4 then
iMidiOut dastgah giAbuataArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 5 then
iMidiOut dastgah giBayattorkArr,iBaseNote,iMidiNote, iQ
elseif iScale == 6 then
iMidiOut dastgah giAfshariArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 7 then
iMidiOut dastgah giDashtiArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 8 then
iMidiOut dastgah giNavaArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 9 then
iMidiOut dastgah gi3gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 10 then
iMidiOut dastgah gi4gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 11 then
iMidiOut dastgah giHomayunArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 12 then
iMidiOut dastgah giBayatEsArr,  iBaseNote,iMidiNote, iQ
endif


Snote mton iMidiOut
Snote strsub Snote, 1
if changed(Snote) == 1 then
    SnoteShow     sprintf "text(%s)", Snote
    cabbageSet "noteshow1",SnoteShow
endif




iFrq mtof iMidiOut
;iAtt = 0.01
iAtt cabbageGetValue "att"
iAmp = 0.05
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq
outall aSound
endin

instr pulsPlay
kTime init 1
    if metro(kTime) == 1 then
    kTime random 2, 12
    kQ random 0, 3
    kFrq random 1000, 5000
    schedulek "puls", 0, 1, kFrq, kQ
    endif
endin


instr puls
iFrq = p4
	aSamp = mpulse:a(1/2, p3+1)
	iQ = p5
	aFilter = mode:a(aSamp, iFrq, iQ)	
	a1 dust 0.4, 2
	a2 gausstrig 0.5, 3, 0.9	
	aDust sum a1,a2,aFilter	
    iCh = int(random:i( 1, 5))
	SchnSend sprintf "snddust%d", iCh
	chnmix aDust, SchnSend
endin



instr OutSound
kGain cabbageGet "gain"
kAmpIn1 cabbageGet "out1"
kAmpIn2 cabbageGet "out2"
kAmpIn3 cabbageGet "out3"
kAmpIn4 cabbageGet "out4"

idB = 25
kAmp1 = kAmpIn1-idB
kAmp2 = kAmpIn2-idB
kAmp3 = kAmpIn3-idB
kAmp4 = kAmpIn4-idB
kAmpdB1 ampdb kAmp1
kAmpdB2 ampdb kAmp2
kAmpdB3 ampdb kAmp3
kAmpdB4 ampdb kAmp4


aInPlus1 chnget "snddust1"
aInPlus2 chnget "snddust2"
aInPlus3 chnget "snddust3"
aInPlus4 chnget "snddust4"

aOut1 = aInPlus1*kAmpdB1*kGain
aOut2 = aInPlus2*kAmpdB2*kGain
aOut3 = aInPlus3*kAmpdB3*kGain
aOut4 = aInPlus4*kAmpdB4*kGain



CsdMeter "clip1", aOut1, metro(20), "meter1"	
CsdMeter "clip2", aOut2, metro(20), "meter2"	
CsdMeter "clip3", aOut3, metro(20), "meter3"	
CsdMeter "clip4", aOut4, metro(20), "meter4"	

	outch 1, aOut1
	outch 2, aOut2
	outch 3, aOut3
	outch 4, aOut4
	
	chnclear "snddust1","snddust2","snddust3","snddust4"
endin



instr Widgets
 SseqIn cabbageGet "seqarr"
 schedule "seq",0,99999,SseqIn
    if changed(SseqIn) == 1 then
    turnoff2 "seq", 0,0
    schedulek "seq",0,9999,SseqIn
    endif
 kActive active "GetMidi"
 kSlider1   ctrl7    1,25,0,80
    if changed(kSlider1) == 1 then
    cabbageSetValue  "out1", kSlider1
    kdB1 = kSlider1-65
    cabbageSetValue  "outn1", kdB1
    endif
 kSlider2   ctrl7    1,26,0,80
    if changed(kSlider2) == 1 then
    cabbageSetValue  "out2", kSlider2
    kdB2 = kSlider2-65
    cabbageSetValue  "outn2", kdB2
    endif
 kSlider3   ctrl7    1,27,0,80
    if changed(kSlider3) == 1 then
    cabbageSetValue  "out3", kSlider3
    kdB3 = kSlider3-65
    cabbageSetValue  "outn3", kdB3
    endif
 kSlider4   ctrl7    1,28,0,80
    if changed(kSlider4) == 1 then
    cabbageSetValue  "out4", kSlider4
    kdB4 = kSlider4-65
    cabbageSetValue  "outn4", kdB4
    endif
 kPedal ctrl7 2,64,0,1
    if kPedal == 1 && changed(kPedal) == 1 then
    kSusB = 1
    cabbageSetValue "hold",kSusB
    elseif kPedal == 0 && changed(kPedal) == 1 then
    kSusB = 0
    cabbageSetValue "hold",kSusB
    elseif kPedal == 0 && changed(kPedal) == 1 && kActive == 0 then
    kSusB = 0
    schedulek "Empty",0,0.1,kActive
    cabbageSetValue "hold",kSusB
    endif
    if kActive == 0 && changed(kActive) == 1 && kPedal == 0 then
    schedulek "Empty",0,0.1,kActive
    endif
 kHold cabbageGet "hold"
    if kHold == 0 && changed(kHold) == 1 && kActive == 0 then
    schedulek "Empty",0,0.1,kActive
    endif
   
    
     
 kDurSlider   ctrl7    1,30,0,10
    if changed(kDurSlider) == 1 then
    cabbageSetValue  "dur", kDurSlider
    endif
    
  kAttSlider   ctrl7    1,31,0.005,0.1
    if changed(kAttSlider) == 1 then
    cabbageSetValue  "att", kAttSlider
    endif
    
  kBpmSlider   ctrl7    1,41,10,210
    if changed(kBpmSlider) == 1 then
    cabbageSetValue  "bpm", kBpmSlider
    endif
; printk2 kSliderT
endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

