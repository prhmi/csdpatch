<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

opcode pythaArr, i,i[]iii
;  iInArr[],iBaseMidi,iMidiIn,iQ xin
;  xout iFrqRatio
endop

;giTable ftgen

chn_k "slider0", 2

instr 1

iResTable1 ftgen 1, 0, 100, 8, 0, 40, 8, 2, 10, 5, 0, 5, 1, 30, 0
iResTable2 ftgen 2, 0, 100, 8, 0, 30, 2, 10, 0, 5, 1, 5, 1, 50, 0

iFrq = 440
kFrqRnd rspline 0, 500, 2, 7
kFrq table kFrqRnd, 1

itest table 120, 1
print itest


chnset kFrq, "slider0"
aSound poscil 0.2, iFrq+(kFrq*100)
outall aSound

endin

</CsInstruments>
<CsScore>
;f 2 0 size  	genNum  a	n1		b	n2		c		n3		d		n4		e		n5		f
;f 	2 	0 100  	8  		0	40		8	2		10		5		0		5		1		30		0



;f 3 0 100 8 -1 32 1 2 0 14 0 17 0 
i1 0 999
</CsScore>
</CsoundSynthesizer>




<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>603</width>
 <height>268</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
 <bsbObject version="2" type="BSBVSlider">
  <objectName>slider0</objectName>
  <x>74</x>
  <y>168</y>
  <width>20</width>
  <height>100</height>
  <uuid>{f0330c35-691d-4be9-a241-1789dcdeb602}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>0</midicc>
  <description/>
  <minimum>0.00000000</minimum>
  <maximum>1.00000000</maximum>
  <value>0.00000000</value>
  <mode>lin</mode>
  <mouseControl act="jump">continuous</mouseControl>
  <resolution>-1.00000000</resolution>
  <randomizable group="0">false</randomizable>
 </bsbObject>
 <bsbObject version="2" type="BSBGraph">
  <objectName/>
  <x>253</x>
  <y>112</y>
  <width>350</width>
  <height>150</height>
  <uuid>{05b106aa-2f6c-4a35-8b8d-7d3fd6902718}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <value>0</value>
  <objectName2/>
  <zoomx>1.00000000</zoomx>
  <zoomy>1.00000000</zoomy>
  <dispx>1.00000000</dispx>
  <dispy>1.00000000</dispy>
  <modex>lin</modex>
  <modey>lin</modey>
  <showSelector>true</showSelector>
  <showGrid>true</showGrid>
  <showTableInfo>true</showTableInfo>
  <showScrollbars>true</showScrollbars>
  <enableTables>true</enableTables>
  <enableDisplays>true</enableDisplays>
  <all>true</all>
 </bsbObject>
</bsbPanel>
<bsbPresets>
</bsbPresets>
