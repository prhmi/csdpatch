<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


gisine1		ftgen	0,0,4096,10,1, 0.7, 0.5
seed 0
instr 1
kFrq = 100
iHarmonics random 10, 50
asig	buzz 1, kFrq, iHarmonics, gisine1
outall asig
endin


</CsInstruments>
<CsScore>
i1 0 999

</CsScore>
</CsoundSynthesizer>






















<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>420</width>
 <height>424</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
 <bsbObject type="BSBScope" version="2">
  <objectName/>
  <x>70</x>
  <y>274</y>
  <width>350</width>
  <height>150</height>
  <uuid>{44c5a075-5ff4-4024-8d08-0fdd7a4c378f}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <value>-255.00000000</value>
  <type>scope</type>
  <zoomx>2.00000000</zoomx>
  <zoomy>1.00000000</zoomy>
  <dispx>1.00000000</dispx>
  <dispy>1.00000000</dispy>
  <mode>0.00000000</mode>
  <triggermode>NoTrigger</triggermode>
 </bsbObject>
</bsbPanel>
<bsbPresets>
</bsbPresets>
