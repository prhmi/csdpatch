<Cabbage>
form caption("Label Example") size(380, 500), guiMode("queue"), colour(2, 145, 209) pluginId("def1")
label bounds(36, 60, 303, 26) channel("test"), text("1 2 3 4 5"), fontColour(77, 14, 14, 255) colour(149, 135, 135, 255) 
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-n -d -+rtmidi=NULL -M0 -m0d --midi-key=4 --midi-velocity-amp=5
</CsOptions>e
<CsInstruments>
; Initialize the global variables. 
ksmps = 16
nchnls = 2
0dbfs = 1


instr 1
Scolor    sprintf " text(1 2 %d 4)", 3

cabbageSet "test", Scolor

endin

                
</CsInstruments>
<CsScore>
;causes Csound to run for about 7000 years...
f0 z
;starts instrument 1 and runs it for a week
i1 0 z
</CsScore>
</CsoundSynthesizer>
