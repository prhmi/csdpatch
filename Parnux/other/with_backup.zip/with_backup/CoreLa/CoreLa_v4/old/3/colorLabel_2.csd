<Cabbage>
form caption("Label Example") size(400, 300), guiMode("queue"), colour(10, 10, 10) pluginId("def1")
label bounds(30, 222, 303, 26) channel("test"), text("1 2 3 4 5"), fontColour(77, 14, 14, 255) colour(149, 135, 135, 255) 
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-n -d -+rtmidi=NULL -M0 -m0d --midi-key=4 --midi-velocity-amp=5
</CsOptions>e
<CsInstruments>
; Initialize the global variables. 
ksmps = 16
nchnls = 2
0dbfs = 1




seed 0


opcode StrSprd, S[],S
SIn xin
Snote     sprintf "%s ",SIn
iLenStr strlen SIn
iReadChar = 0
iCountChr = 0
while iReadChar < iLenStr do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	if strchar(Snote,iReadChar) == 32 then
	iCountChr += 1
	endif
	od	
iReadChar += 1
od

SArrOut[] init iCountChr

iWrite = 0
iRead = 0
while iRead < iLenStr do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
Schar     strsub    Snote, iStart, iStart+iCountChr
SArrOut[iWrite] = Schar
iWrite += 1
iRead += 1
od
xout SArrOut
endop








instr 1
indx init 0
while indx < 16 do
SWidget sprintf "bounds(%d, 20, 20, 20), channel(\"label%d\"), text(\"%d\"),fontColour(100,100,100) visible(1)",\
indx*20, indx, rnd(9)
cabbageCreate "label", SWidget
indx += 1
od
endin





instr 2
iLen = 4
Sseq = "1 2 1 1 4"
Sarr[] StrSprd Sseq
iLen lenarray Sarr
print iLen
;puts Sarr[1], 1



indx = 0
while indx < iLen do
StxtOut  sprintf "text(%s) visible(1)", Sarr[indx]
Schn  sprintf "label%d", indx
cabbageSet Schn,StxtOut
indx += 1
od
endin






instr 3
kCount init 0
if metro(2) == 1 then
schedulek 4, 0, 0.2, kCount
kCount = (kCount+1) % 4
endif
endin


instr 4
indx = p4
Schn  sprintf "label%d", indx
Scolor = "fontColour(100,200,100)"
cabbageSet Schn,Scolor
kRel release
    if kRel == 1 then
    Scolor = "fontColour(100,100,100)"
    cabbageSet 1, Schn,Scolor
    endif
endin
                
</CsInstruments>
<CsScore>
i1 0 1
i2 1 1
i3 3 999
</CsScore>
</CsoundSynthesizer>
