<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

giwave    ftgen    1,0, 512, 8, 0, 16, rnd(2)-1;, 16, 1, 16, 0, 17, 0



instr 1

#define    str   # kstr #


iftlen = 512
;#define    N    #1#
;kstr$N = 200
;kPrint = $N
;printk2 kstr1
;printk2 kstr2
;kstr1 init 1
;kstr2 init 1
;     giwave    ftgen    1,0, iftlen, 8, 0, iftlen/($N+1),i(kstr1), iftlen/($N+1),i(kstr2),   iftlen/($N+1),   0
;aSound oscil 0.2, 400, giwave
;outall aSound
endin

</CsInstruments>
<CsScore>
i1 0 1 1
</CsScore>
</CsoundSynthesizer>




<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
