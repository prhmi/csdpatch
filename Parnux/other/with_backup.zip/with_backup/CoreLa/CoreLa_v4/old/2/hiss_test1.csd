<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1





seed 0 
instr 1
iSound ftgen 1,0,2^20,1,"voice.wav",0,0,1
ilength = nsamp(iSound)/sr
print ilength
kStart init 0
kTime init 50
kVoice linseg 50, 20, 7
kRndPch linseg 500, 20, 10
kDur = (1/kTime)*2
kMainSpd = (sr/kTime/100000)*2
kSpdLine rspline 0.7, 2, 2, 5
kSpeed = kMainSpd*kSpdLine
if metro(kTime) == 1 then
schedulek 2, 0, kDur, kStart,kVoice, kRndPch
kStart = (kStart+kSpeed) % ilength
endif

endin

instr 2
iSound ftgen 1,0,2^20,1,"voice.wav",0,0,1
;ivoiceIn random 1, 15
ivoice = int(p5)
iAmp = -5-(ivoice*0.5)
if ivoice < 5 then
endif

kamp ampdb iAmp ;jspline 0.1, 2, 13
iratio = 15
ipshift = 4
igskip = p4 ;0.01
igskip_os = 0.1
ilength = nsamp(iSound)/sr
kgap = 0.1 ; rspline 0.1, 1, 2, 7
igap_os = 10
kgsize = 7 ;rspline 2, 50, 2, 7
igsize_os = 1
iAtt = 1
idec = 1
iseed    random 0, 3
ipitch1 cent 0
ipitch2 = cent:i(birnd:i(p6))
ipitch3 = cent:i(birnd:i(p6))
ipitch4 = cent:i(birnd:i(p6))
aSig  granule  kamp,ivoice,iratio,0,0,iSound,ipshift,igskip,\
     igskip_os,ilength,kgap,igap_os,kgsize,igsize_os,iAtt,idec,iseed,\
     ipitch1,ipitch2,ipitch3,ipitch4
aOut linen aSig, p3/2, p3, p3/2
chnmix aOut, "snd"
;outall aOut
endin


instr 3
aIn chnget "snd"
;
aRvrb nreverb aIn, 0.2, 0.7
aMix ntrpol aIn, aRvrb, 0.3

outall aMix
chnclear "snd"
endin

</CsInstruments>
<CsScore>
i1 0 999
i3 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
