<CsoundSynthesizer>

<CsOptions>
--env:SSDIR+=../SourceMaterials -odac -m0
; activate real-time audio output and suppress note printing
</CsOptions>

<CsInstruments>
; example written by Iain McCurdy

sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

;waveforms used for granulation
giSound1 ftgen 1,0,2^20,1,"singhiss1.wav",0,0,1
giSound2 ftgen 2,0,2^20,1,"singhiss2.wav",0,0,1
giSound3 ftgen 2,0,2^20,1,"singhiss3.wav",0,0,1
giSound4 ftgen 2,0,2^20,1,"singhiss5.wav",0,0,1

seed 0; seed the random generators from the system clock





  instr 1 ; generates granular synthesis textures

;define the input variables
kamp  = 1;linseg     0,1,0.1,p3-1.2,0.1,0.2,0
ivoice      =          27
iratio      =          15
imode       =          0
ithd        =          0
if ivoice > 4 then
ipshift     =          4
else
ipshift = ivoice
endif

igskip      =          0.01
igskip_os   =          0.1
ilength1     =          nsamp(giSound1)/sr
ilength2     =          nsamp(giSound2)/sr
ilength3     =          nsamp(giSound3)/sr
ilength4     =          nsamp(giSound4)/sr

igap_os     =         50


kgap1 rspline 0.1, 1, 2, 7
kgap2 rspline 0.1, 50, 5, 12
kgap3 rspline 0.1, 10, 2, 7
kgap4 rspline 0.1, 1, 1, 5


kgsize1 rspline 2, 50, 2, 7
kgsize2 rspline 2, 50, 1, 3
kgsize3 rspline 2, 27, 5, 17
kgsize4 rspline 2, 37, 2, 7



igsize_os = 1
iAtt1 random 1, 2
iAtt2 random 1, 2
iAtt3 random 1, 2
iAtt4 random 1, 2

idec1 random 1, 4
idec2 random 1, 4
idec3 random 1, 4
idec4 random 1, 4

iseed1      random 0 , 1
iseed2      random 0 , 1
iseed3      random 0 , 1
iseed4      random 0 , 1

ipitch1 cent 0
ipitch2 = cent:i(random:i(-700, 700))
ipitch3 = cent:i(random:i(-700, 700))
ipitch4 = cent:i(random:i(-700, 700))
;create the granular synthesis textures; one for each channel
aSig1  granule  kamp,ivoice,iratio,imode,ithd,giSound1,ipshift,igskip,\
     igskip_os,ilength1,kgap1,igap_os,kgsize1,igsize_os,iAtt1,idec1,iseed1,\
     ipitch1,ipitch2,ipitch3,ipitch4
aSig2  granule  kamp,ivoice,iratio,imode,ithd,giSound2,ipshift,igskip,\
     igskip_os,ilength2,kgap2,igap_os,kgsize2,igsize_os,iAtt2,idec2,iseed2,\
     ipitch1,ipitch2,ipitch3,ipitch4
     
aSig3  granule  kamp,ivoice,iratio,imode,ithd,giSound3,ipshift,igskip,\
     igskip_os,ilength3,kgap3,igap_os,kgsize3,igsize_os,iAtt3,idec3,iseed3,\
     ipitch1,ipitch2,ipitch3,ipitch4
     
aSig4  granule  kamp,ivoice,iratio,imode,ithd,giSound4,ipshift,igskip,\
     igskip_os,ilength4,kgap4,igap_os,kgsize4,igsize_os,iAtt4,idec4,iseed4,\
     ipitch1,ipitch2,ipitch3,ipitch4
;send a little to the reverb effect
aSum sum aSig1,aSig2,aSig3,aSig4


iAtt = 0.5
iAmp ampdb -30
iRel = 1
aEnv transegr 0, iAtt, 2, iAmp, iRel, -6, 0

aOut = aSum*aEnv
            outall aOut
            

            fout "recordhiss6.wav", 8, aOut
  endin


</CsInstruments>

<CsScore>

i 1  0   15 

</CsScore>

</CsoundSynthesizer>














<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
