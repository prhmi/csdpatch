<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



#define    test(N) 
# 
$N = 500
#
seed 0
instr 1
iftlen = 2048
kRndFrq1 jspline 200, 2, 5
kRndFrq2 jspline 200, 2, 5
kRndFrq3 jspline 200, 2, 5
kRndFrq4 jspline 200, 2, 5
kRndFrq5 jspline 200, 2, 5
if metro(200) == 1 then
     reinit    UPDATE
endif
    UPDATE:
giwave    ftgen    1,0, iftlen, 10, 0, iftlen/5,i(kRndFrq1), iftlen/5,i(kRndFrq2), iftlen/5,i(kRndFrq3),iftlen/5,i(kRndFrq4),iftlen/5,i(kRndFrq5)
rireturn
endin

instr 2
iftlen = 512

kstr1    rspline    -0.9,0.9,2,7
kstr2    rspline    -0.9,0.9,2,7


if metro(100) == 1 then
     reinit    UPDATE
     endif
    UPDATE:
     giwave    ftgen    1,0, iftlen, 8, 0, iftlen/(2+1),i(kstr1), iftlen/(2+1),i(kstr2),   iftlen/(2+1),   0

rireturn
endin

instr 3
kFrq rspline 80, 90, 0.1, 0.7
kAmp1 rspline 0.3, 0.5, 0.1, 0.7
kAmp2 rspline 0.3, 0.5, 0.1, 0.7
kRndAm rspline 0.01, 1, 0.4, 0.7
kRndFm rspline 0.7, 1.5, 0.4, 0.7
a1 oscil kAmp1, kFrq, giwave
aFm oscil kFrq*kRndAm, kFrq*kRndFm, giwave
a2 oscil kAmp2, kFrq+aFm, giwave
ad delay -a2, 0.12
a1 *= ad

ar reverb2 a1, 5, 0.2
ar ntrpol ad,ar, 0.3

a3 atone ar, 200
a3 tone a3, 1300

outall a3
endin

</CsInstruments>
<CsScore>
i1 0 999
;i2 0 999
i3 0 999
</CsScore>
</CsoundSynthesizer>




















<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>420</width>
 <height>424</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
 <bsbObject version="2" type="BSBScope">
  <objectName/>
  <x>70</x>
  <y>274</y>
  <width>350</width>
  <height>150</height>
  <uuid>{44c5a075-5ff4-4024-8d08-0fdd7a4c378f}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <value>-255.00000000</value>
  <type>scope</type>
  <zoomx>2.00000000</zoomx>
  <zoomy>1.00000000</zoomy>
  <dispx>1.00000000</dispx>
  <dispy>1.00000000</dispy>
  <mode>0.00000000</mode>
  <triggermode>NoTrigger</triggermode>
 </bsbObject>
</bsbPanel>
<bsbPresets>
</bsbPresets>
