<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



seed 0

gisine		ftgen	0,0,4096,10,1

instr 1
kTime init 1
if metro(1/kTime) == 1 then
kTime random 10, 20
kDur = kTime*1.2
schedulek 2, 0, kDur
endif

endin

instr 2
indx = 0
iBaseFrq random 120, 700
iFrq = iBaseFrq
iRndLen = int(random:i( 4, 8))
iRndArr[] init iRndLen
iAmpdB = -3
while indx < iRndLen do
schedule 3, 0, p3, iFrq, iBaseFrq, iAmpdB-(iRndLen*3)
iRndCent random 50, 200
iFrq += iBaseFrq*cent(iRndCent)
indx += 1
od
endin

instr 3
iAmpdB ampdb p6
iCent random 10, 200
kCent jspline iCent, 0.2, 0.7
kFrq = p4*cent(kCent)
kAmp rspline 0, 1, 0.3, 0.7
kAmp1 rspline 0, 1, 0.3, 0.7
kAmp2 rspline 0, 1, 0.7, 2
aSound poscil kAmp, kFrq
kRndAm1 rspline 0.1, 0.3, 0.4, 0.7
kRndFm1 rspline 0.7, 1.5, 0.7, 2
kRndAm2 rspline 0.2, 0.7, 0.4, 0.7
kRndFm2 rspline 0.7, 3, 0.4, 0.7
iRndFm1 random 2, 10
iRndFm2 random 2, 10
aFm1 poscil p4/iRndFm1*kRndAm1, p5/iRndFm2*kRndFm1
aFm2 poscil p4/iRndFm2*kRndAm2, p5/iRndFm1*kRndFm2
a1 poscil kAmp1, p5*cent(kCent)+aFm1
a2 poscil kAmp2, p5*cent(kCent)+aFm2
iDel random 0.1, 0.5
 	aTim	interp	iDel
 	abuf	delayr	3
 	ad	deltapi	aTim	
 	delayw	-a1*a2 + (ad*0.3)
aSound *= ad
iAtt random 2, 3
aEnv linseg 0, iAtt, 1, p3-iAtt, 0

iMode = int(random:i(1, 3))
if iMode == 1 then
iFrqRnd random 400, 500
aRing poscil 1, iFrqRnd
elseif iMode == 2 then
aRing init 1
endif
	aOut	= aSound*aEnv*iAmpdB*aRing

chnmix aOut, "snd"
endin


instr 4
aSound chnget "snd"
aRvrb nreverb aSound, 5, 0.3
aMix ntrpol aSound, aRvrb, 0.3
outall aMix
chnclear "snd"
endin

</CsInstruments>
<CsScore>
i1 0 999
;i2 0 999
i4 0 999
</CsScore>
</CsoundSynthesizer>




















<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>420</width>
 <height>424</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
 <bsbObject version="2" type="BSBScope">
  <objectName/>
  <x>70</x>
  <y>274</y>
  <width>350</width>
  <height>150</height>
  <uuid>{44c5a075-5ff4-4024-8d08-0fdd7a4c378f}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <value>-255.00000000</value>
  <type>scope</type>
  <zoomx>2.00000000</zoomx>
  <zoomy>1.00000000</zoomy>
  <dispx>1.00000000</dispx>
  <dispy>1.00000000</dispy>
  <mode>0.00000000</mode>
  <triggermode>NoTrigger</triggermode>
 </bsbObject>
</bsbPanel>
<bsbPresets>
</bsbPresets>
