<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

gisine    ftgen    0,0,4096,10,1
seed 0
instr 1
schedkwhen metro(2),0,0,2,0,2
endin

instr 2
iAmp = 0.5
iFrq = 400
kCent randi 40, 12, 20
icar = 1
aNse    gauss    0.8
iMod = 2.5
kIEnv = 1 ;linseg 1, p3, 0
asig        foscil    iAmp, iFrq*cent(kCent), icar+aNse, iMod, kIEnv, gisine
aEnv transeg 1, p3, -6, 0
aOut = asig*aEnv  
outall aOut
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
