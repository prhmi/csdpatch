<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0 

gisine    ftgen    0,0,4096,10,1

instr 1
schedkwhen metro(10),0,0,2,0,1
endin



opcode bass, a,i
iAmpIn xin
p3 = 0.2
iAmp ampdb iAmpIn
aEnv linseg 1,p3,0.001 
iFrq random 120, 150
kFrq expon iFrq,p3,30
aSound poscil aEnv*iAmp,kFrq 
xout aSound
endop


opcode snare, a,i
iAmpIn xin
p3 = 0.3
iAmp ampdb iAmpIn
aEnv expon 1, p3, 0.001
aNse noise 1, 0
iFilt random 700, 8000
aNse tone aNse, iFilt
iFrq random 100, 200
iHigh random 0, 100
kFrq expon iFrq, p3, iFrq+iHigh
aJit randomi 0.2, 1.3, 50000
aSound poscil aEnv, kFrq*aJit
iNoise random 0.01, 0.1
aSum sum aNse*iNoise, aSound
aRes comb aSum, 0.01, 0.003
aOut = aRes*iAmp*aEnv
xout aOut
endop




opcode hihat, a,i
iAmpIn xin
iAmp ampdb iAmpIn
p3 = 0.1
aEnv expon 1,p3,0.001
aNse noise aEnv, 0
iFilt random 10000, 15000
aFilt buthp aNse*iAmp*0.5, iFilt
aSound buthp aFilt, iFilt 
xout aSound
endop


opcode chbang, a,i
iAmpIn xin
p3 random 0.1, 2
iAmp ampdb iAmpIn
iFrq random 70, 75
kCent randi 40, 12, 20
icar = 1
aNse    gauss    0.1
iMod random 2.5, 2.6
kIEnv = 1 ;linseg 1, p3, 0
asig        foscil    iAmp, iFrq*cent(kCent), icar+aNse, iMod, kIEnv, gisine
aEnv transeg 1, p3, -6, 0
iJit random 0.001, 0.1
aJit randomi 0.02, iJit, 10000
iRes random 0.001, 0.05
aRes comb asig*aJit, 0.01, iRes
iNoise random 0.01, 0.05
aEnvB linseg 1,0.2,0.001 
iFrqB random 120, 150
kFrqB expon iFrqB,0.2,30
aBass poscil aEnvB*iAmp,kFrqB
aSum sum asig, aRes, aNse*iNoise,aBass
aOut = aSum*aEnv 
xout aOut
endop




instr 2
iDrum = int(random:i(2,4))
iMode = int(random:i(0,100)) < 5 ? 1 : iDrum

if iMode == 1 then
aSound bass -15
elseif iMode == 2 then
aSound snare -12
elseif iMode == 3 then
aSound hihat -7
elseif iMode == 4  then
aSound chbang -20
endif
outall aSound
endin


</CsInstruments>
<CsScore>
i1 0 9999
</CsScore>
</CsoundSynthesizer>


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
