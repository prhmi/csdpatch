
<CsoundSynthesizer>
<CsOptions>
-odac -m128  -W -d
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0
gkTime init 0
giTalaCount1 = 0
giTalaCount2 = 0
giTalaCount3 = 0
giCountAll = 0


opcode strToArr, i[],S
SIn xin
Snote     sprintf "%s ",SIn
iLen strlen SIn
iReadChar = 0
iLenCount = 0
while iReadChar < iLen do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	od	
	iReadChar2 = iReadChar+1
			while strchar(Snote,iReadChar2) == 32 do
			iReadChar2 += 1
			iReadChar += 1
			od
iReadChar += 1
iLenCount += 1
od
iArrOut [] init iLenCount

iWrite = 0
iRead = 0
while iRead < iLen do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
		Schar     strsub    Snote, iStart, iStart+iCountChr
	if strchar(Schar,0) != 0 then
	inum strtod Schar
	;print inum
	iArrOut [iWrite] = inum
	iWrite += 1
	endif
iRead += 1
od
xout iArrOut
endop


opcode ArrToStrg, S,i[]
  iArrIn [] xin
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    Sscale     sprintf "%d ",iArrIn[indx]
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop

;;tala
opcode ArrTala, i[], i[]
 iInArr[] xin
 iTalaCount = 1
 iLen lenarray iInArr
 iOutArr [] init iLen
 iRead = 0
 iWrite = iTalaCount
 while iRead < iLen do
 	iOutArr [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% iLen
 od
 iTalaCount += 1
 xout iOutArr
endop

	/* 3F#+ = 190.418  Hz: 2 1 1 4 
		4Bb  = 466.164  Hz: 4 8 10 2 
		6C#+ = 1141.219 Hz: 2 8 10 2 
		7D#  = 2489.016 Hz: 4 4 1 8 
		8G#+ = 6839.585 Hz: 4 4 8 4 */







;;instrument
instr 1
	iSeqArr1[] fillarray 1,1,1,2
	iSeqArr2[] fillarray 1,1,2,1
	iSeqArr3[] fillarray 1,2,1,1
	
	
	Sseq1 ArrToStrg iSeqArr1
	Sseq2 ArrToStrg iSeqArr2
	Sseq3 ArrToStrg iSeqArr3
	Snote1 = "6F"
	Snote2 = "5B"
	Snote3 = "4D"
	SseqArr[] fillarray Sseq1,Sseq2,Sseq3
	SNoteArr[] fillarray Snote1, Snote2, Snote3


	iInterval = 2
	iBPM = 90
	iTempo = (iBPM/60)*4
	
		indx = 0
		while indx < p4 do
		iDelay = (indx/iTempo)
		iMidi ntom SNoteArr[indx]
		iFrq mtof iMidi
;		schedule 2, iDelay,9999, SseqArr[indx],iAmpArr[indx],iFrq, iTempo,iHarmonic, p4
		schedule 2, iDelay,9999, iTempo,-10,iMidi,SseqArr[indx],iInterval
		indx += 1
		od 
endin

instr 2
iTempo = p4
iAmpIn = p5
iMidi = p6
Sseq = p7
iInterval = p8
iSeqArr[] strToArr Sseq
;printarray iSeqArr, "%d", "long="
iSeqLen lenarray iSeqArr



kTime init 0
kSeqIndx init 0
	if metro(1/kTime) == 1 then
;	printk2 kSeqIndx
	kTime = iSeqArr[kSeqIndx]/iTempo
	schedulek 3, 0,0.1, kTime*1.5, iAmpIn, iMidi,iInterval
		if kSeqIndx == iSeqLen-1 then
		schedulek 10,0,0.01,iTempo,iAmpIn,iMidi,Sseq,iInterval
		turnoff
		endif
	kSeqIndx += 1
	endif
endin


instr 3
iActive active 3
iDur = p4
iAmp = p5
iInterval = p7
iMidi random p6, p6+iInterval
iFrqIn mtof iMidi
iFrqRatioArr[] fillarray 1, 1.439, 1.918, 2, 2.32, 2.918, 3.561, 4.160, 5.123
iLen lenarray iFrqRatioArr
iChn = (int(random:i(0,100)) < 50 ) ? 0 : 1
indx = 0
while indx < iLen do
iFrq = iFrqIn* iFrqRatioArr[indx]
if iActive <= 1 then
schedule 5, 0, iDur, p6
schedule 4, 0, iDur, iAmp, iFrq,iChn
endif
iAmp -= random:i(3, 10)
indx += 1
od

endin



instr 4
iAmp = ampdb(p4)
iFrq = p5
iAtt random 1/1000, 3/1000 
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq
outall aSound

iChn = p6
if iChn == 0 then
chnmix aSound, "sndL"
elseif iChn == 1 then
chnmix aSound, "sndR"
endif
endin


instr 5 ;12
inum = p4
ivel = 50
;print inum,ivel
midion 1, inum, ivel
endin


instr 10

iTimeLine = i(gkTime)
iTempo = p4
iAmpIn = p5
iMidi = p6
Sseq = p7
iInterval = p8
iSeqArr[] strToArr Sseq
iLen lenarray iSeqArr 
iStart = (1/iTempo)*1

iSeqArr2[] ArrTala iSeqArr
SseqOut ArrToStrg iSeqArr2

schedule 2, iStart, 9999,iTempo,iAmpIn,iMidi,SseqOut,iInterval

endin


instr 99
gkTime timeinsts
kTime = int(gkTime)
	aInL chnget "sndL"
	aInR chnget "sndR"
	fout "record_stereo.wav", 8, aInL,aInR
	out aInL,aInR
	chnclear "sndL"
	chnclear "sndR"
endin


schedule 1,  0, 1, 1
;schedule 99, 0, 999
</CsInstruments>
<CsScore>
</CsScore>
</CsoundSynthesizer>





















































<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
