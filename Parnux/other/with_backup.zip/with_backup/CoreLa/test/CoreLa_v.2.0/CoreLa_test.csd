
<Cabbage>
form caption("CoreLa") size(400, 300)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crla")
;image bounds(-2, 2, 400, 300) channel("img") file("CoreLa.jpg")
;;Sequencer
label    bounds(35, 15, 40, 12) text("On/Off") channel("label1")
checkbox bounds(10, 10, 20, 20) colour:0(100, 100, 100, 255) popupText("Start")  channel("strt") colour:1(100, 250, 60, 255) value(0)


nslider  bounds(90, 15, 40, 31) range(50, 180, 90, 1, 1)  fontColour(208, 157, 253, 255) text("BPM") channel("bpm")
nslider  bounds(222, 15, 30, 31) range(1, 3, 1, 1, 1)  fontColour(208, 157, 253, 255) text("tt") channel("tt") 
nslider  bounds(254, 16, 30, 31) range(1, 10, 2, 1, 1)  fontColour(208, 157, 253, 255) text("interval") channel("interval") 
nslider  bounds(132, 14, 30, 31) range(1, 10, 4, 1, 1)  fontColour(208, 157, 253, 255) text("DV") channel("dv") 

hslider bounds(70, 73, 150, 28) range(0.05, 2, 0.7, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) channel("dur")
label    bounds(10, 80, 50, 12) text("Duration") channel("labe3")

texteditor bounds(38, 114, 200, 20) channel("SeqArr1") colour(180, 140, 250, 150) colour:0(180, 140, 250, 200)fontSize(20)
texteditor bounds(38, 142, 200, 20) channel("SeqArr2") colour(180, 140, 250, 150) colour:0(180, 140, 250, 200)fontSize(20)
texteditor bounds(38, 170, 200, 20) channel("SeqArr3") colour(180, 140, 250, 150) colour:0(180, 140, 250, 200)fontSize(20)

label      bounds(0, 118, 35, 12) text("seq1") channel("seq1L")
label      bounds(0, 146, 35, 12) text("seq2") channel("seq2L")
label      bounds(0, 174, 35, 12) text("seq3") channel("seq3L")
texteditor bounds(246, 114, 57, 20) channel("Note1") colour(180, 140, 250, 150) colour:0(180, 140, 250, 200)fontSize(20)
texteditor bounds(246, 142, 57, 20) channel("Note2") colour(180, 140, 250, 150) colour:0(180, 140, 250, 200)fontSize(20)
texteditor bounds(246, 170, 57, 20) channel("Note3") colour(180, 140, 250, 150) colour:0(180, 140, 250, 200)fontSize(20)

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



seed 0
gkTime init 0
giTalaCount1 = 0
giTalaCount2 = 0
giTalaCount3 = 0
giCountAll = 0


opcode strToArr, i[],S
SIn xin
Snote     sprintf "%s ",SIn
iLen strlen SIn
iReadChar = 0
iLenCount = 0
while iReadChar < iLen do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	od	
	iReadChar2 = iReadChar+1
			while strchar(Snote,iReadChar2) == 32 do
			iReadChar2 += 1
			iReadChar += 1
			od
iReadChar += 1
iLenCount += 1
od
iArrOut[] init iLenCount

iWrite = 0
iRead = 0
while iRead < iLen do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
		Schar     strsub    Snote, iStart, iStart+iCountChr
	if strchar(Schar,0) != 0 then
	inum strtod Schar
	;print inum
	iArrOut [iWrite] = inum
	iWrite += 1
	endif
iRead += 1
od
xout iArrOut
endop


opcode ArrToStrg, S,i[]
  iArrIn [] xin
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    Sscale     sprintf "%d ",iArrIn[indx]
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop

;;tala
opcode ArrTala, i[], i[]
 iInArr[] xin
 iTalaCount = 1
 iLen lenarray iInArr
 iOutArr [] init iLen
 iRead = 0
 iWrite = iTalaCount
 while iRead < iLen do
 	iOutArr [iRead] = iInArr[iWrite]
	iRead +=1
	iWrite = (iWrite+1)% iLen
 od
 iTalaCount += 1
 xout iOutArr
endop

	/* 3F#+ = 190.418  Hz: 2 1 1 4 
		4Bb  = 466.164  Hz: 4 8 10 2 
		6C#+ = 1141.219 Hz: 2 8 10 2 
		7D#  = 2489.016 Hz: 4 4 1 8 
		8G#+ = 6839.585 Hz: 4 4 8 4 */







;;instrument
instr 1
;	iSeqArr1[] fillarray 1, 1, 2, 1, 1
;	iSeqArr2[] fillarray 1, 1, 2, 1, 1
;	iSeqArr3[] fillarray 1, 1, 2, 1, 1
;	
;	
;	Sseq1 ArrToStrg iSeqArr1
;	Sseq2 ArrToStrg iSeqArr2
;	Sseq3 ArrToStrg iSeqArr3
Sseq1 cabbageGet "SeqArr1"
Sseq2 cabbageGet "SeqArr2"
Sseq3 cabbageGet "SeqArr3"
;	Snote1 = "6F"
;	Snote2 = "5B"
;	Snote3 = "4D"
    Snote1 cabbageGet "Note1"
	Snote2 cabbageGet "Note2"
	Snote3 cabbageGet "Note3"
	SseqArr[] fillarray Sseq1,Sseq2,Sseq3
	SNoteArr[] fillarray Snote1, Snote2, Snote3


	iInterval = p5
	iBPM = p6
	iTempo = (iBPM/60)*p7
	
		indx = 0
		while indx < p4 do
		iDelay = (indx/iTempo)
		iMidi ntom SNoteArr[indx]
		iFrq mtof iMidi
;		schedule 2, iDelay,9999, SseqArr[indx],iAmpArr[indx],iFrq, iTempo,iHarmonic, p4
		schedule 2, iDelay,9999, iTempo,-20,iMidi,SseqArr[indx],iInterval
		indx += 1
		od 
endin

instr 2

iTempo = p4
iAmpIn = p5
iMidi = p6
Sseq = p7
iInterval = p8
iSeqArr[] strToArr Sseq
;printarray iSeqArr, "%d", "long="
iSeqLen lenarray iSeqArr



kTime init 0
kSeqIndx init 0
	if metro(1/kTime) == 1 then
;	printk2 kSeqIndx
	kTime = iSeqArr[kSeqIndx]/iTempo
	schedulek 3, 0,0.1, kTime*1.5, iAmpIn, iMidi,iInterval
		if kSeqIndx == iSeqLen-1 then
		schedulek 10,0,0.01,iTempo,iAmpIn,iMidi,Sseq,iInterval
		turnoff
		endif
	kSeqIndx += 1
	endif
endin


instr 3
iActive active 3
iDur = p4
iAmp = p5
iInterval = p7
iMidi random p6, p6+iInterval
iFrqIn mtof iMidi
iFrqRatioArr[] fillarray 1, 1.439, 1.918, 2, 2.32, 2.918, 3.561, 4.160, 5.123
iLen lenarray iFrqRatioArr
iChn = (int(random:i(0,100)) < 50 ) ? 0 : 1
indx = 0
while indx < iLen do
iFrq = iFrqIn* iFrqRatioArr[indx]
if iActive <= 1 then
;schedule 5, 0, iDur, p6
schedule 4, 0, iDur, iAmp, iFrq,iChn
endif
iAmp -= random:i(3, 10)
indx += 1
od

endin



instr 4

iAmp ampdb p4
iFrq = p5
iAtt random 1/1000, 3/1000 
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq
out aSound,aSound

endin


instr 5 ;12
inum = p4
ivel = 50
;print inum,ivel
midion 1, inum, ivel
endin


instr 10

iTimeLine = i(gkTime)
iTempo = p4
iAmpIn = p5
iMidi = p6
Sseq = p7
iInterval = p8
iSeqArr[] strToArr Sseq
iLen lenarray iSeqArr 
iStart = (1/iTempo)*1

iSeqArr2[] ArrTala iSeqArr
SseqOut ArrToStrg iSeqArr2

schedule 2, iStart, 9999,iTempo,iAmpIn,iMidi,SseqOut,iInterval

endin





instr 88 ;6
kInterval cabbageGet "interval"
kTempo cabbageGet "bpm"
kDV cabbageGet "dv"
  Sseq1  = "1 1 2 1 1 1"
  Sseq2  = "1 2 2 4 1 1 2 1 4"
  Sseq3  = "1 2 2 4 1 1 2 1 4"
  cabbageSet "SeqArr1"  , "text",  Sseq1
  cabbageSet "SeqArr2"  , "text",  Sseq2
  cabbageSet "SeqArr3"  , "text",  Sseq3
  
  Snote1  = "4F"
  Snote2  = "6G"
  Snote3  = "4B"
  cabbageSet "Note1"  , "text",  Snote1
  cabbageSet "Note2"  , "text",  Snote2
  cabbageSet "Note3"  , "text",  Snote3
kTt cabbageGet "tt"
kStart cabbageGet "strt"
;printk2 kStart
if changed(kStart) == 1 && kStart == 1 then
;printk2 kStart
schedulek 1, 0, 9999, kTt,kInterval,kTempo,kDV
elseif kStart == 0 then
turnoff2 1,0,0
turnoff2 2,0,0
turnoff2 3,0,0
endif

endin



instr 99
gkTime timeinsts
kTime = int(gkTime)
	aInL chnget "sndL"
	aInR chnget "sndR"
	fout "record_stereo.wav", 8, aInL,aInR
	out aInL,aInR
	chnclear "sndL"
	chnclear "sndR"
endin

</CsInstruments>
<CsScore>
i 88 0 9999
</CsScore>
</CsoundSynthesizer>

<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>100</x>
 <y>100</y>
 <width>320</width>
 <height>240</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
