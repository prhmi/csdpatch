<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


massign 0, 0

gkCCArr[] init 6
gkCCIndx init 0

opcode setcc, kk, kk
kNum, kData xin
kCCnum = kNum
if kData == 0 goto skip
kIndx = gkCCIndx
kTurnOff = 0
	kndx = 0
	while kndx < lenarray(gkCCArr) do
		if gkCCArr[kndx] == kCCnum then
		gkCCArr[kndx] = 0
		kCConOff = 0
		gkCCIndx = kndx
		kTurnOff = 1
		endif 
	kndx += 1
	od
if kTurnOff == 0 then
		kndx = 0 
		kSkip = 1
		while kndx < lenarray(gkCCArr) do
			if gkCCArr[kndx] == 0 then
			kSkip = 0
			endif
		kndx += 1
		od
	if kSkip == 0 then
		while gkCCArr[kIndx] != 0 do
		kIndx = (kIndx+1) % lenarray(gkCCArr)
		od
	gkCCArr[kIndx] = kCCnum
	kCConOff = 1
	gkCCIndx = (gkCCIndx+1) % lenarray(gkCCArr)
	endif
endif
skip:
if kNum >= 81 && kNum <= 88 then
kCConOff = kData
	if kData != 0 then
	kCConOff = 1
	endif
endif
	xout kCCnum, kCConOff
endop
gkPrgRepArr[] init 2
gkPrgmIndx init 0
opcode setprgm, kk, kk
kPrgNum,kTime xin
iDur = 1.5
if kTime >= iDur then
kTime = 0
gkPrgmIndx = 0
gkPrgRepArr[0] = 0
gkPrgRepArr[1] = 0
endif
gkPrgRepArr[gkPrgmIndx] = kPrgNum
if gkPrgmIndx == 0 then
kTime = 0
endif
kPrgNumOut = kPrgNum
if gkPrgmIndx == 0 then
gkPrgRepArr[1] = 0
endif
if gkPrgmIndx == 1 && kTime < iDur then
	if gkPrgRepArr[0] != gkPrgRepArr[1] then
	kPrgNumOut = (gkPrgRepArr[0]*100)+gkPrgRepArr[1]
	endif
endif
gkPrgmIndx = (gkPrgmIndx+1) % 2
xout kPrgNumOut, kTime
skip:
endop


opcode setoct, kkkk, k
kPrgNum xin

xout kccOct, kPrgOct, kNoteOct, kKnobOct
endop

instr GetMidi
kTime init 0
if metro(100) == 1 then
kTime += 0.01
endif
kType, kChn, kNum, kData midiin
kDataOut init -1
if kType == 176 then
kNumOut, kDataOut setcc kNum,kData
	if changed(kNumOut,kDataOut) == 1 then
	printks  "num=%d, value=%d\\n", -1, kNumOut,kDataOut
	endif
elseif kType == 192 then
	if kNum <= 8 then
	kNumOut, kTime setprgm kNum, kTime
	printks  "num=%d,	value=%.2f\\n", -1, kNumOut,kTime
	else
	
	endif
endin


</CsInstruments>
<CsScore>
i 1 0 9999 
 </CsScore>
</CsoundSynthesizer>




















<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
