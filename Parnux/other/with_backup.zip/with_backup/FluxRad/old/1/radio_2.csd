
<Cabbage>
form caption("FluxRad")    size(1200, 650)   guiMode("queue") colour(20,20,40) pluginId("flrd") ; style("legacy")
label bounds(934, 62, 239, 66) channel("sec") fontColour(169, 196, 219, 255) text("00 : 04")
button bounds(1062, 24, 110, 35) channel("start") colour:0(102, 102, 113, 255) colour:1(5, 86, 128, 255) text("S  T  A  R  T", "S  T  O  P") value(1)
;rslider bounds(338, 264, 75, 75) channel("slider1") range(0, 1, 0.5, 1, 0.001) colour(115, 135, 152, 255) markerColour(255, 255, 255, 255) trackerColour(147, 180, 221, 255) fontColour(255, 255, 255, 255) valueTextBox(1) text("tempo")

nslider bounds(306, 184, 100, 40) channel("shwnum1") range(0, 100, 0, 1, 0.01) colour(37, 56, 75, 255)
nslider bounds(410, 184, 100, 40) channel("shwnum2") range(0, 100, 0, 1, 0.01) colour(37, 56, 75, 255)
nslider bounds(514, 184, 100, 40) channel("shwnum3") range(0, 100, 0, 1, 0.01) colour(37, 56, 75, 255)
nslider bounds(618, 184, 100, 40) channel("shwnum4") range(0, 100, 0, 1, 0.01) colour(37, 56, 75, 255)
nslider bounds(722, 184, 100, 40) channel("shwnum5") range(0, 100, 0, 1, 0.01) colour(37, 56, 75, 255)

vslider bounds(892, 466, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(55, 113, 152, 255)
vslider bounds(934, 466, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(55, 113, 152, 255)
vslider bounds(974, 466, 50, 150) channel("out3") range(0, 80, 0, 1, 1) trackerColour(55, 113, 152, 255)
vslider bounds(1016, 466, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(55, 113, 152, 255)
vslider bounds(68, 58, 50, 150) channel("out5") range(0, 80, 0, 1, 1) trackerColour(55, 113, 152, 255)

nslider bounds(898, 432, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(37, 56, 75, 255)
nslider bounds(938, 432, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(37, 56, 75, 255)
nslider bounds(978, 432, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(37, 56, 75, 255)
nslider bounds(1018, 432, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(37, 56, 75, 255)
nslider bounds(68, 24, 40, 35) channel("outn5") range(-90, 50, -60, 1, 1) colour(37, 56, 75, 255)
nslider bounds(1072, 396, 93, 44) channel("gain") range(-90, 50, 0, 1, 1) colour(37, 56, 75, 255) text("Master Gain (dB)")
nslider bounds(1094, 352, 49, 38) channel("chnls") range(1, 8, 2, 1, 1) colour(37, 56, 75, 255) text("chns")

vmeter bounds(1076, 464, 15, 150) channel("meter1")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1100, 464, 15, 150) channel("meter2")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1124, 464, 15, 150) channel("meter3")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1148, 464, 15, 150) channel("meter4")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(120, 62, 15, 137) channel("meter5")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(32, 26, 15, 176) channel("meter6")  outlineColour(0, 0, 0, 255), overlayColour(71, 74, 84, 255)    outlineThickness(0) meterColour:0(89, 183, 141, 255)

image bounds(1076, 450, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(1100, 450, 15, 15) channel("clip2") colour(0, 0, 0, 255)
image bounds(1124, 450, 15, 15) channel("clip3") colour(0, 0, 0, 255)
image bounds(1148, 450, 15, 15) channel("clip4") colour(0, 0, 0, 255)
image bounds(120, 48, 15, 15) channel("clip5") colour(0, 0, 0, 255)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


giTableSize = 10 ;sec
giTable ftgen 0, 0, giTableSize*sr, 2, 0
giTableLen = ftlen(giTable) / sr

seed 0





instr radioRec
gkTableTime line 0, 1, 1
;aIn inch 1
aIn soundin "allgrn.wav"
aLine linseg 0, giTableLen, giTableLen*sr
tablew aIn, aLine, giTable
schedule "radioRec", giTableSize, giTableSize
endin


instr rvsMachine
kTime init 1
kTime cabbageGet "rvsdur"
if metro(1/kTime) == 1 then
schedulek "radioRvrs", 0, kTime/2
endif
endin

instr radioRvrs
iStart = i(gkTableTime)
iPhase = iStart/giTableLen
aSound poscil 1, (1/giTableLen),  giTable,iPhase
aRvrs  poscil 1, (-1/giTableLen), giTable,iPhase
aMix ntrpol aSound,aRvrs, 1
aOut linen aMix, 0.05, p3, 0.05
outall aOut
endin


instr widgetWrite
 iX = 0
 iY = 0
 indx = 0
 while indx < 24 do
 SmPad    sprintf "bounds(%d, %d, 50, 50),\
 channel(\"mpad%d\") colour(70, 70, 70)", \
 iX+30, iY+250, indx+1
 cabbageCreate "image", SmPad 
 iX = (iX+55)
 indx += 1
    if (indx%4) == 0 then
    iY += 55
    iX = 0
    endif
    if (indx%8) == 0 then
    iY += 20
    endif
 od
 iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 while indx < 24 do
 SmSlider    sprintf "bounds(%d, %d, 70, 70),valueTextBox(0)\
 channel(\"slider%d\") range(0, 1, 0.5, 1, 0.001), text(%d)\
 colour(115, 135, 152, 255) markerColour(255, 255, 255, 255)\
 trackerColour(147, 180, 221, 255) fontColour(255, 255, 255, 255)",\
 iX+275+ispcx, iY+280, indx+1, indx+1
 cabbageCreate "rslider", SmSlider 
 iX = (iX+70)
 indx += 1
    if (indx%4) == 0 then
    ispcx += 25
    endif
    if (indx%8) == 0 then
    iY += 130
    iX = 0
    ispcx = 0
    endif
 od
 iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 ispcy = 0
 while indx < 144 do
 SLED    sprintf "bounds(%d, %d, 15, 15),\
 channel(\"led%d\") colour(70, 70, 70)", \
 308+iX+ispcx, iY+35+ispcy, indx+1
 cabbageCreate "image", SLED 
  iX += 20
  indx += 1
    if (indx%3) == 0 then
    ispcx += 5
    endif
    if (indx%24) == 0 then
    iY += 20
    iX = 0
    ispcx = 0
    endif
    if (indx%72) == 0 then
    ispcy += 5
    endif
 od
endin

instr time
 kTimer line 0, 1, 1
 kSec = int(kTimer)
 kMin init 0
 kSec = kSec % 60
    if kSec == 0 && changed(kSec) == 1 then
    kMin += 1
    endif
 STimer sprintfk "%02d : %02d", kMin, kSec
 cabbageSet 1, "sec", "text", STimer
endin

instr widgets
 iDurMaster = 9^9
 schedule "widgetWrite", 0, 1
 kStart cabbageGet "start"
    iRvsDur = 2
    if kStart == 1 && changed(kStart) == 1 then
    schedulek "radioRec", 0, giTableSize
    schedulek "rvsMachine", 0.1, iDurMaster, iRvsDur
    schedulek "time", 0, iDurMaster
    elseif kStart == 0 && changed(kStart) == 1 then
    turnoff2 "radioRec",0,0
    turnoff2 "rvsMachine",0,0
    turnoff2 "time",0,0
    endif
endin

</CsInstruments>
<CsScore>
i "widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

