<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


instr 1
 aPink pinker
 kRngMin rspline 1, 2, 1, 3
 kRngMax randomh 200, 250, 10
 kFrq rspline 20, 50, 1, 5
 kRng = randomh:k(0,100,1) > 50 ? kRngMin : kRngMax
 aGauss gaussi kRng, 0.2, kFrq
 aNoise = (aGauss)*5
 aFb init 1
 aNoise = (aNoise*20)+aFb
    aSine poscil 1, aNoise
    aPhas phasor aNoise
    aSum sum aSine, aPhas
    aFb delay aSum, 0.2
    aOut dcblock2 aFb
outall aOut*0.2
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>






<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
