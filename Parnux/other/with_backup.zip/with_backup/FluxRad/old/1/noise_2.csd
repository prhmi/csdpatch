<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


instr 1
 kRngMin rspline 1, 20, 1, 3
 kRngMax rspline 50, 100, 10, 20
 kFrq rspline 20, 50, 1, 5
 kRng = randomh:k(0,100,1) > 50 ? kRngMin : kRngMax
 aGauss1 gausstrig 10, kRng, 0.8
 aGauss2 gaussi kRng/10, 0.2, kFrq
 aNoise = (aGauss1+aGauss2)*50
 aFb init 1
 aNoise = (aNoise*20)+aFb
    aSine poscil 1, aNoise
    aPhas phasor aNoise
    aSum sum aSine, aPhas
    aFb delay aSum, 0.2
    aOut dcblock2 aFb
outall aOut*0.2
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>






<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
