<CsoundSynthesizer>
<CsOptions>
; Select audio/midi flags here according to platform
-odac  -iadc    ;;;RT audio out and in
; For Non-realtime ouput leave only the line below:
; -o compress2.wav -W ;;; for file output any platform
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs  = 1 


opcode limiter, a,ai
aIn, iThresh xin
krms rms aIn
;printk2 krms
iThdB ampdb iThresh+12
kamp = (iThdB-krms) <= iThdB ? iThdB : (iThdB-krms)
aOut = aIn*kamp
xout aOut
endop


opcode makeup, a,ai
aIn, iThresh xin
krms rms aIn
iThdB ampdb iThresh+12
kamp = iThdB-krms
if kamp >= iThdB then
kamp = iThdB 
endif
aOut = aIn*kamp
xout aOut
endop

opcode gater, a,ai
aIn, iThresh xin
krms rms aIn
iThdB ampdb iThresh
kamp = 1
if krms <= iThdB then
kamp = 0 
endif
aOut = aIn*kamp
xout aOut
endop


instr 1

;asig   diskin2 "radio.wav", 1, 0, 1
aIn inch 1
aIn = aIn
aOut limiter aIn, -10
krms rms aOut
printk2 int(dbamp(krms))
;printk2 krms
;aOut gater aOut, -40
outall aOut*0.3
endin

</CsInstruments>
<CsScore>

i 1 0 330

</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
