<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


opcode MirrorMe,k,ki
kValue,iThr xin
if kValue > iThr then
kOut = iThr - kValue
elseif kValue < iThr then
kOut = iThr + kValue
elseif kValue == iThr then
kOut = iThr
endif
xout kOut
endop

instr 1
iValue = 2
iThr = 0.5
if iValue > iThr then
iOut = iThr - iValue
elseif iValue < iThr then
iOut = iThr + iValue
elseif iValue == iThr then
iOut = iThr
endif
print iOut
aNoise noise ampdb(0), 0.9
krms rms aNoise
kMax max_k aNoise, metro(20), 1

printk2 dbamp(kMax)

endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>




<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
