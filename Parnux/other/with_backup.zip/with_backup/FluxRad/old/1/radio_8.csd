
<Cabbage>
form caption("FluxRad")    size(1200, 700)   guiMode("queue") colour(20,20,40) pluginId("flrd") ; style("legacy")
label bounds(934, 62, 239, 66) channel("sec") fontColour(169, 196, 219, 255) text("00 : 04")
button bounds(1062, 24, 110, 35) channel("start") colour:0(102, 102, 113, 255) colour:1(5, 86, 128, 255) text("S  T  A  R  T", "S  T  O  P") value(1)

nslider bounds(882, 290, 90, 40) channel("shwnum1") range(0, 100, 0, 1, 0.01) colour(37, 56, 75, 255)
nslider bounds(978, 290, 90, 40) channel("shwnum2") range(0, 100, 0, 1, 0.01) colour(37, 56, 75, 255)
nslider bounds(1074, 290, 90, 40) channel("shwnum3") range(0, 100, 0, 1, 0.01) colour(37, 56, 75, 255)
nslider bounds(882, 336, 90, 40) channel("shwnum4") range(0, 100, 0, 1, 0.01) colour(37, 56, 75, 255)
nslider bounds(978, 336, 90, 40) channel("shwnum5") range(0, 100, 0, 1, 0.01) colour(37, 56, 75, 255)
nslider bounds(1074, 336, 90, 40) channel("shwnum6") range(0, 100, 0, 1, 0.01) colour(37, 56, 75, 255)
nslider bounds(88, 228, 45, 45) channel("prgoct") range(1, 3, 1, 1, 1) colour(37, 56, 75, 255) text("Prgm")
nslider bounds(144, 228, 45, 45) channel("noteoct") range(-7, 7, 0, 1, 1) colour(37, 56, 75, 255) text("Note")
nslider bounds(30, 228, 45, 45) channel("ccoct") range(1, 7, 1, 1, 1) colour(37, 56, 75, 255) text("CC")
nslider bounds(200, 228, 45, 45) channel("knoboct") range(1, 7, 1, 1, 1) colour(37, 56, 75, 255) text("knob")
label bounds(882, 212, 298, 31) channel("data2") fontColour(219, 169, 206, 255) colour(37, 56, 75, 255) align("left")  text("")
label bounds(882, 176, 298, 31) channel("data1") fontColour(219, 169, 206, 255) colour(37, 56, 75, 255) align("left")  text("")

vslider bounds(904, 530, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(55, 113, 152, 255)
vslider bounds(946, 530, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(55, 113, 152, 255)
vslider bounds(986, 530, 50, 150) channel("out3") range(0, 80, 0, 1, 1) trackerColour(55, 113, 152, 255)
vslider bounds(1028, 530, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(55, 113, 152, 255)
vslider bounds(16, 54, 50, 150) channel("out5") range(0, 80, 50, 1, 1) trackerColour(55, 113, 152, 255)
vslider bounds(140, 58, 30, 150) channel("out6") range(0, 80, 30, 1, 1) trackerColour(55, 113, 152, 255)
vslider bounds(174, 58, 30, 150) channel("out7") range(0, 80, 60, 1, 1) trackerColour(55, 113, 152, 255)
vslider bounds(210, 58, 30, 150) channel("out8") range(0, 80, 40, 1, 1) trackerColour(55, 113, 152, 255)

nslider bounds(910, 496, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(37, 56, 75, 255)
nslider bounds(950, 496, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(37, 56, 75, 255)
nslider bounds(990, 496, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(37, 56, 75, 255)
nslider bounds(1030, 496, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(37, 56, 75, 255)
nslider bounds(16, 20, 40, 35) channel("outn5") range(-90, 50, -10, 1, 1) colour(37, 56, 75, 255)
nslider bounds(138, 24, 35, 30) channel("outn6") range(-90, 50, -30, 1, 1) colour(37, 56, 75, 255)
nslider bounds(172, 24, 35, 30) channel("outn7") range(-90, 50, 0, 1, 1) colour(37, 56, 75, 255)
nslider bounds(206, 24, 35, 30) channel("outn8") range(-90, 50, -20, 1, 1) colour(37, 56, 75, 255)

nslider bounds(1084, 460, 93, 44) channel("gain") range(-90, 50, 0, 1, 1) colour(37, 56, 75, 255) text("Master Gain (dB)")
nslider bounds(1106, 416, 49, 38) channel("chnls") range(1, 8, 2, 1, 1) colour(37, 56, 75, 255) text("chns")

vmeter bounds(1088, 528, 15, 150) channel("meter1")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1112, 528, 15, 150) channel("meter2")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1136, 528, 15, 150) channel("meter3")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1160, 528, 15, 150) channel("meter4")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(66, 64, 15, 137) channel("meter5")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(880, 502, 15, 176) channel("meter6")  outlineColour(0, 0, 0, 255), overlayColour(71, 74, 84, 255)    outlineThickness(0) meterColour:0(89, 183, 141, 255)

image bounds(1088, 514, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(1112, 514, 15, 15) channel("clip2") colour(0, 0, 0, 255)
image bounds(1136, 514, 15, 15) channel("clip3") colour(0, 0, 0, 255)
image bounds(1160, 514, 15, 15) channel("clip4") colour(0, 0, 0, 255)
image bounds(66, 50, 15, 15) channel("clip5") colour(0, 0, 0, 255)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


giTableSize = 10 ;sec
giTable ftgen 0, 0, giTableSize*sr, 2, 0
giTableLen = ftlen(giTable) / sr

seed 0





opcode FrzMono,a,ak
 aIn,kTrig xin
 iFFTsize = 1024
 ioverlap = iFFTsize/4 ;256
 iwinsize = iFFTsize
 iwintype = 1 
 f_anal  	pvsanal	aIn, iFFTsize, ioverlap, iwinsize, iwintype
 f_freeze	pvsfreeze f_anal, kTrig, kTrig
 aFrz	    pvsynth f_freeze
 aOut = aFrz
 xout aOut
endop





instr radioRec
gkTableTime line 0, 1, 1
;aIn inch 1
aIn soundin "radio.wav"
aRadio linen aIn, 0.01, p3, 0.01
chnmix aRadio, "snd"
aLine linseg 0, giTableLen, giTableLen*sr
tablew aRadio, aLine, giTable
schedule "radioRec", giTableSize, giTableSize
endin


instr rvsMachine
kTime init 1
;kTime cabbageGet "rvsdur"
if metro(1/kTime) == 1 then
schedulek "radioRvrs", 0, kTime/2
endif
endin

instr radioRvrs
iStart = i(gkTableTime)
iPhase = iStart/giTableLen
aSound poscil 1, (1/giTableLen),  giTable,iPhase
aRvrs  poscil 1, (-1/giTableLen), giTable,iPhase
aMix ntrpol aSound,aRvrs, 1
aOut linen aMix, 0.05, p3, 0.05
;outall aOut
chnmix aOut, "out"
endin




instr radioFrz
iStart = i(gkTableTime)
iPhase = iStart/giTableLen
aIn poscil 1, (1/giTableLen),  giTable,iPhase
kTrig randomh 0, 2, 2
aFrz FrzMono aIn,int(kTrig)
aOut linen aFrz, 0.05, p3, 0.05
;outall aFrz
chnmix aOut, "out"
endin


instr loopMachine
iStart = i(gkTableTime)
kTime init 0.7
;kTime cabbageGet "rvsdur"
if metro(1/kTime) == 1 then
schedulek "loopRadio", 0, kTime/2, iStart
endif
endin

instr loopRadio
iStart = p4
iPhase = iStart/giTableLen
aSound poscil 1, (1/giTableLen),  giTable,iPhase
aRvrs  poscil 1, (-1/giTableLen), giTable,iPhase
aMix ntrpol aSound,aRvrs, 1
aOut linen aMix, 0.05, p3, 0.05
;outall aOut
chnmix aOut, "out"
endin


instr tunerRadio
 aIn chnget "snd"
 kfr, kamp 	ptrack 		aIn, 1024,10
 kFrq = kfr
 kFrqFltrUp = 400
 kFrqFltrDown = 250
 until kFrq < kFrqFltrUp do
 kFrq = kFrq/2
 od
 until kFrq > kFrqFltrDown do
 kFrq = kFrq*2
 od
 kPortTime linseg 0, 0.01, 0.05
 kFrq portk kFrq, kPortTime
 kamp portk kamp, kPortTime*2
 aSine poscil ampdb(kamp), kFrq
 aOut linen aSine, 0.01, p3, 0.01
; outall aSine*0.5
Schn sprintf "out%d", 1
chnmix aOut, "out"
 chnclear "snd"
endin



instr pchRadio
 aIn chnget "snd"
 iFFTsize = 1024
 kCent jspline 700, 5, 12
 kPitch cent kCent
 fSound pvsanal aIn, 1024, 256, 1024, 1
 fTranspose pvscale fSound, kPitch, 1
 aOut pvsynth fTranspose
 outall aOut
 chnclear "snd"
endin

instr widgetWrite
 iX = 0
 iY = 0
 indx = 0
 while indx < 24 do
 SmPad    sprintf "bounds(%d, %d, 50, 50),\
 channel(\"mpad%d\") colour(70, 70, 70)", \
 iX+30, iY+290, indx+1
 cabbageCreate "image", SmPad 
 iX = (iX+55)
 indx += 1
    if (indx%4) == 0 then
    iY += 55
    iX = 0
    endif
    if (indx%8) == 0 then
    iY += 20
    endif
 od
 iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 while indx < 24 do
 SKnob    sprintf "bounds(%d, %d, 70, 70),valueTextBox(0)\
 channel(\"slider%d\") range(0, 1, 0.5, 1, 0.001), text(%d)\
 colour(115, 135, 152, 255) markerColour(255, 255, 255, 255)\
 trackerColour(147, 180, 221, 255) fontColour(255, 255, 255, 255)",\
 iX+275+ispcx, iY+280, indx+1, indx+1
 cabbageCreate "rslider", SKnob 
 iX = (iX+70)
 indx += 1
    if (indx%4) == 0 then
    ispcx += 25
    endif
    if (indx%8) == 0 then
    iY += 130
    iX = 0
    ispcx = 0
    endif
 od
 iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 ispcy = 0
 while indx < 24 do
 SLED    sprintf "bounds(%d, %d, 27, 27),\
 channel(\"led%d\") colour(70, 70, 70)", \
 295+iX+ispcx, iY+30+ispcy, indx+1
 cabbageCreate "image", SLED 
  iX += 31
  indx += 1
    if (indx%4) == 0 then
    ispcx += 5
    endif
    if (indx%4) == 0 then
    iY += 31
    iX = 0
    ispcx = 0
    endif
    if (indx%8) == 0 then
    ispcy += 5
    endif
 od
 iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 ispcy = 0
 while indx < 128 do
 Smtrx    sprintf "bounds(%d, %d, 20, 20),\
 channel(\"mtrx%d\") colour(70, 70, 70)", \
 435+iX+ispcx, iY+30+ispcy, indx+1
 cabbageCreate "image", Smtrx 
  iX += 24
  indx += 1
    if (indx%4) == 0 then
    ispcx += 5
    endif
    if (indx%16) == 0 then
    iY += 24
    iX = 0
    ispcx = 0
    endif
    if (indx%64) == 0 then
    ispcy += 5
    endif
 od
 iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 ispcy = 0
 while indx < 96 do
 SLEDknob    sprintf "bounds(%d, %d, 15, 15),\
 channel(\"ledknob%d\") colour(70, 70, 70)", \
 292+iX+ispcx, iY+360+ispcy, indx+1
 cabbageCreate "image", SLEDknob 
  iX += 20
  indx += 1
    if (indx%16) == 0 then
    iX = 0
    iY += 20
    ispcx = -55
    endif
    if (indx%2) == 0 then
    ispcx += 30
    endif
    if (indx%8) == 0 then
    ispcx += 25
    endif
    if (indx%32) == 0 then
    ispcy += 92
    endif
 od
endin



instr speakers
aIn chnget "out"
outall aIn
chnclear "out"
endin

instr time
 kTimer line 0, 1, 1
 kSec = int(kTimer)
 kMin init 0
 kSec = kSec % 60
    if kSec == 0 && changed(kSec) == 1 then
    kMin += 1
    endif
 STimer sprintfk "%02d : %02d", kMin, kSec
 cabbageSet 1, "sec", "text", STimer
endin

instr widgets
 iDurMaster = 9^9
 schedule "widgetWrite", 0, 1
 kStart cabbageGet "start"
    iRvsDur = 2
    if kStart == 1 && changed(kStart) == 1 then
    schedulek "speakers", 0, giTableSize
    schedulek "radioRec", 0, giTableSize
;    schedulek "rvsMachine", 0.1, iDurMaster, iRvsDur
;    schedulek "radioFrz", 0.1, iDurMaster
;    schedulek "loopMachine", 2.1, iDurMaster
    schedulek "tunerRadio", 0.1, iDurMaster
;    schedulek "pchRadio", 0.1, iDurMaster
    schedulek "time", 0, iDurMaster
    elseif kStart == 0 && changed(kStart) == 1 then
    turnoff2 "radioRec",0,0
    turnoff2 "rvsMachine",0,0
    turnoff2 "time",0,0
    endif
endin

</CsInstruments>
<CsScore>
i "widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

