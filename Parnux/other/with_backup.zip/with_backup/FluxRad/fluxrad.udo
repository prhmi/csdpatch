giTableSize = 15;sec
giTable ftgen 0, 0, giTableSize*sr, 2, 0
giTableLen = ftlen(giTable) / sr


giTabRec1 ftgen 0, 0, giTableSize*sr, 2, 0
giTabRec2 ftgen 0, 0, giTableSize*sr, 2, 0
giTabRec3 ftgen 0, 0, giTableSize*sr, 2, 0
giTabRec4 ftgen 0, 0, giTableSize*sr, 2, 0

seed 0
massign 0, 0

opcode FrzMono,a,ak
 aIn,kTrig xin
 iFFTsize = 1024
 ioverlap = iFFTsize/4
 iwinsize = iFFTsize
 iwintype = 1 
 f_anal  	pvsanal	aIn, iFFTsize, ioverlap, iwinsize, iwintype
 f_freeze	pvsfreeze f_anal, kTrig, kTrig
 aFrz	    pvsynth f_freeze
 aOut = aFrz
 xout aOut
endop


gkCCArr[] init 6
gkCCIndx init 0
opcode setcc, kk, kk
kNum, kData xin
kCCnum = kNum
if kData == 0 goto skip
kIndx = gkCCIndx
kTurnOff = 0
	kndx = 0
	while kndx < lenarray(gkCCArr) do
		if gkCCArr[kndx] == kCCnum then
		gkCCArr[kndx] = 0
		kCConOff = 0
		gkCCIndx = kndx
		kTurnOff = 1
		endif 
	kndx += 1
	od
if kTurnOff == 0 then
		kndx = 0 
		kSkip = 1
		while kndx < lenarray(gkCCArr) do
			if gkCCArr[kndx] == 0 then
			kSkip = 0
			endif
		kndx += 1
		od
	if kSkip == 0 then
		while gkCCArr[kIndx] != 0 do
		kIndx = (kIndx+1) % lenarray(gkCCArr)
		od
	gkCCArr[kIndx] = kCCnum
	kCConOff = 1
	gkCCIndx = (gkCCIndx+1) % lenarray(gkCCArr)
	endif
endif
skip:
if kNum >= 81 && kNum <= 88 then
kCConOff = kData
	if kData != 0 then
	kCConOff = 1
	endif
endif
	xout kCCnum, kCConOff
endop
gkPrgRepArr[] init 2
gkPrgmIndx init 0
opcode setprgm, kk, kki
kPrgNum,kTime,iDur xin
if kTime >= iDur then
kTime = 0
gkPrgmIndx = 0
gkPrgRepArr[0] = 0
gkPrgRepArr[1] = 0
endif
gkPrgRepArr[gkPrgmIndx] = kPrgNum
if gkPrgmIndx == 0 then
kTime = 0
endif
kPrgNumOut = kPrgNum
if gkPrgmIndx == 0 then
gkPrgRepArr[1] = 0
endif
if gkPrgmIndx == 1 && kTime < iDur then
	if gkPrgRepArr[0] != gkPrgRepArr[1] then
	kPrgNumOut = (gkPrgRepArr[0]*100)+gkPrgRepArr[1]
	endif
endif
gkPrgmIndx = (gkPrgmIndx+1) % 2
xout kPrgNumOut, kTime
endop

gkUpDownPrg1 init 1
gkUpDownPrg2 init 1
gkUpDownPrg3 init 0
gkUpDownPrg4 init 1
gkOctArr[] init 2
gkOctIndx init -1
opcode setoct, kkkk, kk
kPrgNum,kTime xin
iDurReset = 0.1
if changed(kPrgNum) == 1 then
gkOctIndx = (gkOctIndx+1) % 2
endif
gkOctArr[gkOctIndx] = kTime
kMidiTime abs gkOctArr[1]-gkOctArr[0]
if kPrgNum == 29 then
gkUpDownPrg1 -= 1
	if gkUpDownPrg1 <= 1 then
	gkUpDownPrg1 = 1
	endif
elseif kPrgNum == 25 then
gkUpDownPrg1 += 1
	if gkUpDownPrg1 >= 7 then
	gkUpDownPrg1 = 7
	endif
endif
if (kPrgNum == 25 || kPrgNum == 29) && kMidiTime < iDurReset then
gkUpDownPrg1 = 1
endif
if kPrgNum == 30 then
gkUpDownPrg2 -= 1
	if gkUpDownPrg2 <= 1 then
	gkUpDownPrg2 = 1
	endif
elseif kPrgNum == 26 then
gkUpDownPrg2 += 1
	if gkUpDownPrg2 >= 7 then
	gkUpDownPrg2 = 7
	endif
endif
if (kPrgNum == 26 || kPrgNum == 30) && kMidiTime < iDurReset then
gkUpDownPrg2 = 1
endif
if kPrgNum == 31 then
gkUpDownPrg3 -= 1
	if gkUpDownPrg3 <= -7 then
	gkUpDownPrg3 = -7
	endif
elseif kPrgNum == 27 then
gkUpDownPrg3 += 1
	if gkUpDownPrg3 >= 7 then
	gkUpDownPrg3 = 7
	endif
endif
if (kPrgNum == 31 || kPrgNum == 27) && kMidiTime < iDurReset then
gkUpDownPrg3 = 0
endif
if kPrgNum == 32 then
gkUpDownPrg4 -= 1
	if gkUpDownPrg4 <= 1 then
	gkUpDownPrg4 = 1
	endif
elseif kPrgNum == 28 then
gkUpDownPrg4 += 1
	if gkUpDownPrg4 >= 7 then
	gkUpDownPrg4 = 7
	endif
endif
if (kPrgNum == 32 || kPrgNum == 28) && kMidiTime < iDurReset then
gkUpDownPrg4 = 1
endif
xout gkUpDownPrg1, gkUpDownPrg2, gkUpDownPrg3, gkUpDownPrg4
endop


opcode  switchColor, S, k
kTrig xin
kIndx init 0
if kTrig == 1 then
kIndx = (kIndx+1)%2
endif
if kIndx == 0 then
kColor = 70
elseif kIndx == 1 then
kColor = 200
endif
Sout sprintfk "colour(%d,70,70)",kColor
xout Sout
endop

opcode  switchColork, k, k
kTrig xin
kIndx init 0
if kTrig == 1 then
kIndx = (kIndx+1)%2
endif
kOut = kIndx
xout kOut
endop

opcode rateCCk, k, kii
 kValue, iMin, iMax xin
 iDiff = iMax-iMin
 kOut = (kValue*iDiff)+iMin
 xout kOut
endop 
