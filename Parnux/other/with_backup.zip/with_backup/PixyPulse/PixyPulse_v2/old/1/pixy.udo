gkCCArr[] init 6
gkCCIndx init 0
opcode setcc, kk, kk
kNum, kData xin
kCCnum = kNum
if kData == 0 goto skip
kIndx = gkCCIndx
kTurnOff = 0
	kndx = 0
	while kndx < lenarray(gkCCArr) do
		if gkCCArr[kndx] == kCCnum then
		gkCCArr[kndx] = 0
		kCConOff = 0
		gkCCIndx = kndx
		kTurnOff = 1
		endif 
	kndx += 1
	od
if kTurnOff == 0 then
		kndx = 0 
		kSkip = 1
		while kndx < lenarray(gkCCArr) do
			if gkCCArr[kndx] == 0 then
			kSkip = 0
			endif
		kndx += 1
		od
	if kSkip == 0 then
		while gkCCArr[kIndx] != 0 do
		kIndx = (kIndx+1) % lenarray(gkCCArr)
		od
	gkCCArr[kIndx] = kCCnum
	kCConOff = 1
	gkCCIndx = (gkCCIndx+1) % lenarray(gkCCArr)
	endif
endif
skip:
if kNum >= 75 && kNum <= 82 then
kCConOff = kData
	if kData != 0 then
	kCConOff = 1
	endif
endif
	xout kCCnum, kCConOff
endop
gkPrgRepArr[] init 2
gkPrgmIndx init 0
opcode setprgm, kk, kki
kPrgNum,kTime,iDur xin
if kTime >= iDur then
kTime = 0
gkPrgmIndx = 0
gkPrgRepArr[0] = 0
gkPrgRepArr[1] = 0
endif
gkPrgRepArr[gkPrgmIndx] = kPrgNum
if gkPrgmIndx == 0 then
kTime = 0
endif
kPrgNumOut = kPrgNum
if gkPrgmIndx == 0 then
gkPrgRepArr[1] = 0
endif
if gkPrgmIndx == 1 && kTime < iDur then
	if gkPrgRepArr[0] != gkPrgRepArr[1] then
	kPrgNumOut = (gkPrgRepArr[0]*100)+gkPrgRepArr[1]
	endif
endif
gkPrgmIndx = (gkPrgmIndx+1) % 2
xout kPrgNumOut, kTime
endop

gkUpDownPrg1 init 1
gkUpDownPrg2 init 1
gkUpDownPrg3 init 0
gkUpDownPrg4 init 1
gkOctArr[] init 2
gkOctIndx init -1
opcode setoct, kkkk, kk
kPrgNum,kTime xin
iDurReset = 0.1
if changed(kPrgNum) == 1 then
gkOctIndx = (gkOctIndx+1) % 2
endif
gkOctArr[gkOctIndx] = kTime
kMidiTime abs gkOctArr[1]-gkOctArr[0]
if kPrgNum == 29 then
gkUpDownPrg1 -= 1
	if gkUpDownPrg1 <= 1 then
	gkUpDownPrg1 = 1
	endif
elseif kPrgNum == 25 then
gkUpDownPrg1 += 1
	if gkUpDownPrg1 >= 7 then
	gkUpDownPrg1 = 7
	endif
endif
if (kPrgNum == 25 || kPrgNum == 29) && kMidiTime < iDurReset then
gkUpDownPrg1 = 1
endif
if kPrgNum == 30 then
gkUpDownPrg2 -= 1
	if gkUpDownPrg2 <= 1 then
	gkUpDownPrg2 = 1
	endif
elseif kPrgNum == 26 then
gkUpDownPrg2 += 1
	if gkUpDownPrg2 >= 7 then
	gkUpDownPrg2 = 7
	endif
endif
if (kPrgNum == 26 || kPrgNum == 30) && kMidiTime < iDurReset then
gkUpDownPrg2 = 1
endif
if kPrgNum == 31 then
gkUpDownPrg3 -= 1
	if gkUpDownPrg3 <= -7 then
	gkUpDownPrg3 = -7
	endif
elseif kPrgNum == 27 then
gkUpDownPrg3 += 1
	if gkUpDownPrg3 >= 7 then
	gkUpDownPrg3 = 7
	endif
endif
if (kPrgNum == 31 || kPrgNum == 27) && kMidiTime < iDurReset then
gkUpDownPrg3 = 0
endif
if kPrgNum == 32 then
gkUpDownPrg4 -= 1
	if gkUpDownPrg4 <= 1 then
	gkUpDownPrg4 = 1
	endif
elseif kPrgNum == 28 then
gkUpDownPrg4 += 1
	if gkUpDownPrg4 >= 7 then
	gkUpDownPrg4 = 7
	endif
endif
if (kPrgNum == 32 || kPrgNum == 28) && kMidiTime < iDurReset then
gkUpDownPrg4 = 1
endif
xout gkUpDownPrg1, gkUpDownPrg2, gkUpDownPrg3, gkUpDownPrg4
endop



opcode morseLetter, i[],i
iChar xin
 iMorseArr_A[] fillarray 1,2
 iMorseArr_B[] fillarray 2,1,1,1
 iMorseArr_C[] fillarray 2,1,2,1
 iMorseArr_D[] fillarray 2,1,1
 iMorseArr_E[] fillarray 1
 iMorseArr_F[] fillarray 1,1,2,1
 iMorseArr_G[] fillarray 2,2,1
 iMorseArr_H[] fillarray 1,1,1,1
 iMorseArr_I[] fillarray 1,1
 iMorseArr_J[] fillarray 1,2,2,2
 iMorseArr_K[] fillarray 2,1,2
 iMorseArr_L[] fillarray 1,2,1,1
 iMorseArr_M[] fillarray 2,2
 iMorseArr_N[] fillarray 2,1
 iMorseArr_O[] fillarray 2,2,2
 iMorseArr_P[] fillarray 1,2,2,1
 iMorseArr_Q[] fillarray 2,2,1,2
 iMorseArr_R[] fillarray 1,2,1
 iMorseArr_S[] fillarray 1,1,1
 iMorseArr_T[] fillarray 2
 iMorseArr_U[] fillarray 1,1,2
 iMorseArr_V[] fillarray 1,1,1,2
 iMorseArr_W[] fillarray 1,2,2
 iMorseArr_X[] fillarray 2,1,1,2
 iMorseArr_Y[] fillarray 2,1,2,2
 iMorseArr_Z[] fillarray 2,2,1,1
    if iChar == 97 then
    iMorseArr[] = iMorseArr_A
    elseif iChar == 98 then
    iMorseArr[] = iMorseArr_B
    elseif iChar == 99 then
    iMorseArr[] = iMorseArr_C
    elseif iChar == 100 then
    iMorseArr[] = iMorseArr_D
    elseif iChar == 101 then
    iMorseArr[] = iMorseArr_E
    elseif iChar == 102 then
    iMorseArr[] = iMorseArr_F
    elseif iChar == 103 then
    iMorseArr[] = iMorseArr_G
    elseif iChar == 104 then
    iMorseArr[] = iMorseArr_H
    elseif iChar == 105 then
    iMorseArr[] = iMorseArr_I
    elseif iChar == 106 then
    iMorseArr[] = iMorseArr_J
    elseif iChar == 107 then
    iMorseArr[] = iMorseArr_K
    elseif iChar == 108 then
    iMorseArr[] = iMorseArr_L
    elseif iChar == 109 then
    iMorseArr[] = iMorseArr_M
    elseif iChar == 110 then
    iMorseArr[] = iMorseArr_N
    elseif iChar == 111 then
    iMorseArr[] = iMorseArr_O
    elseif iChar == 112 then
    iMorseArr[] = iMorseArr_P
    elseif iChar == 113 then
    iMorseArr[] = iMorseArr_Q
    elseif iChar == 114 then
    iMorseArr[] = iMorseArr_R
    elseif iChar == 115 then
    iMorseArr[] = iMorseArr_S
    elseif iChar == 116 then
    iMorseArr[] = iMorseArr_T
    elseif iChar == 117 then
    iMorseArr[] = iMorseArr_U
    elseif iChar == 118 then
    iMorseArr[] = iMorseArr_V
    elseif iChar == 119 then
    iMorseArr[] = iMorseArr_W
    elseif iChar == 120 then
    iMorseArr[] = iMorseArr_X
    elseif iChar == 121 then
    iMorseArr[] = iMorseArr_Y
    elseif iChar == 122 then
    iMorseArr[] = iMorseArr_Z
    elseif iChar == 32 then
    iMorseArr[] fillarray 5
    else
    iMorseArr[] fillarray 1
    endif
  xout iMorseArr  
 endop

opcode rateCCk, k, kii
kValue, iMin, iMax xin
iDiff = iMax-iMin
kOut = (kValue*iDiff)+iMin
xout kOut
endop 



;;drum
opcode bass, a,i
iAmpIn xin
p3 = 0.15
iAmp ampdb iAmpIn
aEnv linseg 1,p3,0.001 
iFrq random 120, 150
kFrq expon iFrq,p3,30
aSound poscil aEnv*iAmp,kFrq 
xout aSound
endop


opcode snare, a,i
iAmpIn xin
p3 = 0.3
iAmp ampdb iAmpIn
aEnv expon 1, p3, 0.001
aNse noise 1, 0
iFilt random 700, 8000
aNse tone aNse, iFilt
iFrq random 100, 200
iHigh random 0, 100
kFrq expon iFrq, p3, iFrq+iHigh
aJit randomi 0.2, 1.3, 50000
aSound poscil aEnv, kFrq*aJit
iNoise random 0.01, 0.1
aSum sum aNse*iNoise, aSound
aRes comb aSum, 0.01, 0.003
aOut = aRes*iAmp*aEnv
xout aOut
endop

opcode hihat, a,i
iAmpIn xin
iAmp ampdb iAmpIn
p3 = 0.1
aEnv expon 1,p3,0.001
aNse noise aEnv, 0
iFilt random 10000, 12000
aFilt buthp aNse*iAmp*0.5, iFilt
aSound buthp aFilt, iFilt 
xout aSound
endop