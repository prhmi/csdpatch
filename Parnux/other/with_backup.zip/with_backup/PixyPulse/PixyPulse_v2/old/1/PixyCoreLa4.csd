 bounds(0, 0, 0, 0)
<Cabbage>
form caption("PixyCoreLa")    size(1075, 600)   guiMode("queue") colour(45,20,45) pluginId("pxcr") ; style("legacy")
vslider bounds(786, 432, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(245,230,245)
vslider bounds(828, 432, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(245,230,245)
vslider bounds(868, 432, 50, 150) channel("out3") range(0, 80, 0, 1, 1) trackerColour(245,230,245)
vslider bounds(910, 432, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(245,230,245)
nslider bounds(792, 398, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(70, 50, 70)
nslider bounds(832, 398, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(70, 50, 70)
nslider bounds(872, 398, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(70, 50, 70)
nslider bounds(912, 398, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(70, 50, 70)
nslider bounds(960, 364, 93, 44) channel("gain") range(-90, 50, 0, 1, 1)    colour(70, 50, 70) text("Master Gain (dB)")
label bounds(802, 50, 239, 66) channel("sec") text("00 : 03") fontColour(245, 220, 245)
button bounds(922, 18, 116, 27) channel("start") value(1) text("S  T  A  R  T", "S  T  O  P")  colour:0(171, 81, 152, 255) colour:1(99, 85, 85, 255)


image bounds(1024, 258, 20, 20) channel("morseplight") corners(2) colour(10, 10, 10)
vslider bounds(442, 412, 50, 150)   channel("amp1") range(0, 30, 20, 1, 1) trackerColour(245, 230, 245, 255) text("nAmp")
vslider bounds(496, 412, 50, 150)   channel("amp2") range(0, 20, 10, 1, 1) trackerColour(245, 230, 245, 255) text("wgAmp")
vslider bounds(550, 412, 50, 150)   channel("amp3") range(0, 20, 10, 1, 1) trackerColour(245, 230, 245, 255) text("wgAmp")
vslider bounds(602, 412, 50, 150)   channel("amp4") range(0, 20, 10, 1, 1) trackerColour(245, 230, 245, 255) text("wgAmp")
label bounds(456, 214, 90, 40) channel("data1") fontColour(245, 220, 245) colour(70, 50, 70) text("")  
label bounds(552, 214, 90, 40) channel("data2") fontColour(245, 220, 245) colour(70, 50, 70) text("")  
label bounds(456, 274, 90, 40) channel("data3") fontColour(245, 220, 245) colour(70, 50, 70) text("")  
label bounds(552, 274, 90, 40) channel("data4") fontColour(245, 220, 245) colour(70, 50, 70) text("")  
label bounds(456, 334, 90, 40) channel("data5") fontColour(245, 220, 245) colour(70, 50, 70) text("")  
label bounds(552, 334, 90, 40) channel("data6") fontColour(245, 220, 245) colour(70, 50, 70) text("")  
nslider bounds(904, 354, 49, 38) channel("chnls") range(1, 8, 2, 1, 1) colour(70, 50, 70) text("chns")
texteditor bounds(680, 214, 364, 40) channel("morsetxt") colour(200, 170, 200, 200) colour:0(200, 170, 200, 200)fontSize(26) text("some one")
nslider bounds(686, 262, 70, 44) channel("morsebpm") range(30, 200, 124, 1, 1) colour(70, 50, 70) fontColour(241, 178, 178, 255) text("Tempo")
nslider bounds(758, 262, 68, 43) channel("morsefrq") range(200, 2000, 1200, 1, 1) colour(70, 50, 70, 255) fontColour(241, 178, 178, 255) text("Frq")
nslider bounds(830, 262, 68, 43) channel("morseamp") range(-90, -15, -22, 1, 1) colour(70, 50, 70) fontColour(241, 178, 178, 255) text("Amp")
nslider bounds(900, 262, 68, 43) channel("morsefilt") range(500, 9000, 5000, 1, 1) colour(70, 50, 70) fontColour(241, 178, 178, 255) text("lopF")




vmeter bounds(964, 432, 15, 150) channel("meter1")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(988, 432, 15, 150) channel("meter2")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1012, 432, 15, 150) channel("meter3")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1036, 432, 15, 150) channel("meter4")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
image bounds(964, 418, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(988, 418, 15, 15) channel("clip2") colour(0, 0, 0, 255)
image bounds(1012, 418, 15, 15) channel("clip3") colour(0, 0, 0, 255)
image bounds(1036, 418, 15, 15) channel("clip4") colour(0, 0, 0, 255)

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0

 giSine ftgen 0, 0, 2^12, 10, 1 

#include "pixy.udo"

instr noisePlay
; kMessIn   cabbageGet "slider2"
; kRngIn    cabbageGet "slider3"
; kFrqIn    cabbageGet "slider4"
; kFilMinIn cabbageGet "slider5"
;kFilMaxIn  cabbageGet "slider6"
; kMess     rateCCk kMessIn, 5, 70
; kRng      rateCCk kRngIn, 10, 150
; kFrq      rateCCk kFrqIn, 20, 100
; kFilMinIn rateCCk kFilMin, 200, 3000
; kFilMaxIn rateCCk kFilMax, 600, 8000

    kRngMin rspline 1, 20, 1, 3
    kRngMax rspline 50, 100, 10, 20
    kRng = randomh:k(0,100,1) > 30 ? kRngMin : kRngMax
    kFrq rspline 20, 50, 1, 5
    kMess rspline 10, 50, 3, 7

 aGauss1 gausstrig 10, kRng, 0.8
 aGauss2 gaussi kRng/10, 0.2, kFrq
 aNoise = (aGauss1+aGauss2)*20
 aFb init 1
 aNoise = (aNoise*kMess)+aFb
    aSine poscil 1, aNoise
    aPhas phasor aNoise
    aSum sum aSine, aPhas
    aFb delay aSum, 0.2
    aDc dcblock2 aFb
    kFilterMax = 8000
    kFilterMin = 500
 aFilt clfilt aDc, kFilterMax, 0, 10
 aOut  clfilt aFilt, kFilterMin, 1, 10
chnmix aOut*0.3, "out"
endin

instr morseRead
 Stype = p4
 puts Stype, 1
 iLenLetter       strlen     Stype 
 iTypeArr[] init iLenLetter
 indx = 0	
 while indx < iLenLetter do
 ichr       strchar    Stype, indx
 iTypeArr[indx]  = ichr
 indx += 1
 od
 iLetterIndx = p5
 iChr = iTypeArr[iLetterIndx]
 iMorseArr[] morseLetter iChr
    kMorseIndx init 0
    kTime init 1
    iBPM cabbageGetValue "morsebpm" ; 120
    iTempo = iBPM/60
    if metro(1/kTime) == 1 then
    kTime = (iMorseArr[kMorseIndx])/(iTempo*4)
    schedulek "morseSound", 0, kTime*0.5, iChr
    kMorseIndx += 1
    endif
    if kMorseIndx == lenarray(iMorseArr) && changed(kMorseIndx) == 1 then  
        if iLetterIndx < iLenLetter-1 then
        schedulek "morseRead", 0.5, 9999, Stype, iLetterIndx+1 
        endif
        if iLetterIndx >= iLenLetter-1 then
        schedulek "morseSound", 0.1, 0.1, 200
        endif
    turnoff    
    endif

endin


instr morseSound
 iFrq cabbageGetValue "morsefrq"
 iMorseNoise cabbageGetValue "morsenoise"
 iMorseSine cabbageGetValue "morsesine"
 iNoiseGain = iMorseNoise
 iSineGain = iMorseSine
 iAmpIn cabbageGetValue "morseamp"
 iAmp ampdb iAmpIn
    if p4 == 32 then
    iGain = 0
    elseif p4 == 200 then
    iGain = 0
    cabbageSet 1,"morseplight","colour(10, 10, 10)"
    else
     cabbageSet "morseplight","colour(245, 150, 245)"
    iGain = 1
    endif
 iAtt = 0.01
 iTest = (p3-iAtt)-(iAtt*2)
 aEnv linseg 0,iAtt,iAmp,(p3-iAtt)-(iAtt*2),iAmp,iAtt,0
 aSound poscil aEnv, iFrq
 aNoise noise aEnv, 0.9
 iFilter cabbageGetValue "morsefilt"
 aNoiseF clfilt  aNoise, iFilter, 0, 10
 aNoiseOut clfilt aNoiseF, iFilter*0.9, 1, 10
 aOut = ((aSound*0.7)+(aNoiseOut*0.5))*iGain
 chnmix aOut, "out"
 ;outall aOut

if release() == 1 && p4 != 200 then
cabbageSet 1,"morseplight","colour(120, 100, 120)"
endif
endin

instr widgetWrite
 iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 while indx < 16 do
 SKnob    sprintf "bounds(%d, %d, 70, 70),valueTextBox(0)\
 channel(\"slider%d\") range(0, 1, 0.5, 1, 0.01), text(%d)\
 markerColour(255, 255, 255, 255) trackerColour(245,230,245) colour(150, 120, 150)",\
 iX+50+ispcx, iY+30, indx+1, indx+1
 cabbageCreate "rslider", SKnob 
 iX = (iX+100)
 indx += 1
    if (indx%8) == 0 then
    iY += 220
    iX = 0
    ispcx = 0
    endif
    if (indx%4) == 0 then
    iY += 80
    iX = 0
    ispcx = 0
    endif
 od
 iX = 0
 iY = 0
 indx = 0
 while indx < 32 do
 SmPad    sprintf "bounds(%d, %d, 40, 40),\
 channel(\"mpad%d\") colour:0(70, 70, 70) colour:1(180,100,180) text()", \
 iX+42, iY+200, indx+1
 cabbageCreate "button", SmPad 
 iX = (iX+45)
 indx += 1
    if (indx%2) == 0 then
    iX += 10
    endif
    if (indx%16) == 0 then
    iY += 10
    endif
    if (indx%8) == 0 then
    iY += 30
    iX = 0
    endif
    if (indx%8) == 0 then
    iY += 15
    endif
 od
  iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 ispcy = 0
 while indx < 48 do
 Smtrx    sprintf "bounds(%d, %d, 20, 20),\
 channel(\"mtrx%d\") colour(70, 70, 70)", \
 453+iX+ispcx, iY+35+ispcy, indx+1
 cabbageCreate "image", Smtrx 
  iX += 24
  indx += 1
    if (indx%4) == 0 then
    ispcx += 5
    endif
    if (indx%8) == 0 then
    iY += 24
    iX = 0
    ispcx = 0
    endif
    if (indx%16) == 0 then
    ispcy += 5
    endif
 od
 
endin
schedule "widgetWrite", 0, 1


instr speaker
aIn chnget "out"
outall aIn
chnclear "out"
endin

instr record
SFilenames[] directory "./record", ".wav"
iLen lenarray SFilenames
print iLen
SrecordFile sprintf "record/record%d.wav", iLen
aInArr[] monitor
aIn = aInArr[0]
fout SrecordFile, 8, aIn
endin

instr time
 kTimer line 0, 1, 1
 kSec = int(kTimer)
 kMin init 0
 kSec = kSec % 60
    if kSec == 0 && changed(kSec) == 1 then
    kMin += 1
    endif
 STimer sprintfk "%02d : %02d", kMin, kSec
 cabbageSet 1, "sec", "text", STimer
endin

instr Widgets
 iDurMaster = 9^9
 kStart cabbageGet "start"
    if kStart == 1 && changed(kStart) == 1  then
    schedulek "time", 0, iDurMaster
    schedulek "speaker", 0, iDurMaster
    elseif kStart == 0 && changed(kStart) == 1 then
    turnoff2 "time", 0, 0
    endif
  Stype cabbageGet "morsetxt"
  
  
  kType, kChn, kNum, kData midiin
  printk2 kNum
if kType == 176 && kNum > 50 then ;;cc
kNumCC, kDataCC setcc kNum,kData
	if changed(kNumCC,kDataCC) == 1 then
	printks  "num=%d, value=%d\\n", -1, kNumCC,kDataCC
	SCCnum sprintfk "mpad%d",(kNumCC-50)
	cabbageSetValue SCCnum, kDataCC
	endif
elseif kType == 176 && kNum <= 34 then
SsliderNum sprintfk "slider%d",kNum-10
cabbageSetValue SsliderNum , kData/127
endif


  
  
 if kStart == 1 then
    if changed(cabbageGet:S("morsetxt")) == 1  then
    schedulek "morseRead", 0, 9999, Stype, 0
    endif 
    
 endif  
endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

