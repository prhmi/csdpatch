<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0

instr 1
kTime init 1
kPlus rspline 0.1, 70, 2, 7
if metro(kTime) == 1 then
kTime random 2, 7
schedulek 2, 0, 5,kPlus
endif

endin

instr 2
iFrq random 10, 80
;kScan rspline 0.1, 0.8, p3*2, p3*4
iPoseMin random 0.001, 0.3
iPoseMax random 40, 70
iScan = random(0, 100) > 50 ? iPoseMin : iPoseMax
iRel random 0.001, 0.2
iPose random 0.001, 0.999
aSound    barmodel       1, 1, iFrq, iRel, iScan, 5, iPose, 2000, 0.05
outall aSound
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>










<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
