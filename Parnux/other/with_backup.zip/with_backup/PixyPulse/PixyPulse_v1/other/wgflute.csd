<CsoundSynthesizer>
<CsOptions>
; Select audio/midi flags here according to platform
-odac      ;;;realtime audio out
;-iadc    ;;;uncomment -iadc if realtime audio input is needed too
; For Non-realtime ouput leave only the line below:
; -o wgflute.wav -W ;;; for file output any platform
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs  = 1

instr 1
kFrq init 150
kFrq rspline 300, 320, 1, 3
kjet rspline 0.6, 0.8, 2, 7
iatt = 0.1
idetk = 0.1
kngain rspline 0.01, 0.03, 3, 7
kvibf rspline 0.01, 0.1, 2, 5
kvamp rspline 0.01, 0.1, 2, 5

aFlute wgflute .2, kFrq, kjet, iatt, idetk, kngain, kvibf, kvamp, 1

aRvrb reverb aFlute, 0.6

aMix ntrpol aFlute, aRvrb, 0.3

outall aMix

endin
</CsInstruments>
<CsScore>
f 1 0 16384 10 1		;sine wave
i 1 0 999
e
</CsScore>
</CsoundSynthesizer>
