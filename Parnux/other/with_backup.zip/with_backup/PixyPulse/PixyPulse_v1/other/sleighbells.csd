<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs  = 1


instr 1

if metro(1) == 1 then
schedulek 2, 0, 1
endif
endin


instr 2

idamp = 0.29
iNum = 32 ;random 2, 20
aSound  sleighbells .5, 1, iNum, idamp, 0.7

kFilt transeg 7000, p3, -4, 3000
aFilt clfilt aSound, kFilt, 0, 10

outall aFilt

endin
</CsInstruments>
<CsScore>
i 1 0 999

</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
