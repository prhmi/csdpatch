;v3
<Cabbage>
form caption("Puls")    size(900, 500)   guiMode("queue") colour(10,50,30) pluginId("puls") ; style("legacy")



vslider bounds(638, 342, 50, 150) channel("out1") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100) value(-90)
vslider bounds(674, 342, 50, 150) channel("out2") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100)
vslider bounds(710, 342, 50, 150) channel("out3") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100)
vslider bounds(744, 342, 50, 150) channel("out4") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100)

vmeter bounds(798, 342, 15, 150) channel("meter1") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(822, 342, 15, 150) channel("meter2") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(846, 342, 15, 150) channel("meter3") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(870, 342, 15, 150) channel("meter4") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
image bounds(798, 328, 15, 15) channel("clip1") colour(0,0,0)
image bounds(822, 328, 15, 15) channel("clip2") colour(0,0,0)
image bounds(846, 328, 15, 15) channel("clip3") colour(0,0,0)
image bounds(870, 328, 15, 15) channel("clip4") colour(0,0,0)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0



instr pulsPlay
kTime init 1
    if metro(kTime) == 1 then
    kTime random 2, 5
    kQ random 0, 3
    kFrq random 1000, 5000
;    schedulek "puls", 0, 1, kFrq, kQ
    schedulek "noise", 0, 1, kFrq, kQ
    endif
endin


instr noise
aNoise noise 0.1, 0.5
aFilter clfilt aNoise, 250, 1, 10
aFilter clfilt aNoise, p4*0.5, 0, 10
iAtt random 0.02, 0.1
iAmp = 0.5
aEnv transeg 0, iAtt, 2, iAmp, p3-iAtt, -6, 0
aOut = aFilter*aEnv
outall aOut
	
endin




</CsInstruments>
<CsScore>
 i "pulsPlay" 0 999
</CsScore>
</CsoundSynthesizer>

