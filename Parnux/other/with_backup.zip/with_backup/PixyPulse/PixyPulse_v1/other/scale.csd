;v3
<Cabbage>
form caption("Puls")    size(900, 500)   guiMode("queue") colour(10,50,30) pluginId("puls") ; style("legacy")



vslider bounds(638, 342, 50, 150) channel("out1") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100) value(-90)
vslider bounds(674, 342, 50, 150) channel("out2") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100)
vslider bounds(710, 342, 50, 150) channel("out3") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100)
vslider bounds(744, 342, 50, 150) channel("out4") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100)

vmeter bounds(798, 342, 15, 150) channel("meter1") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(822, 342, 15, 150) channel("meter2") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(846, 342, 15, 150) channel("meter3") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(870, 342, 15, 150) channel("meter4") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
image bounds(798, 328, 15, 15) channel("clip1") colour(0,0,0)
image bounds(822, 328, 15, 15) channel("clip2") colour(0,0,0)
image bounds(846, 328, 15, 15) channel("clip3") colour(0,0,0)
image bounds(870, 328, 15, 15) channel("clip4") colour(0,0,0)
button bounds(26, 448, 80, 40) channel("play")
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0



instr pulsPlay
kPlay cabbageGet "play"
if changed(kPlay) == 1 then
schedulek "scaleNote", 0, 1
turnoff2 "soundOut", 0, 1
schedulek "soundOut", 0, 20
endif
endin


instr scaleNote
iLen random 3, 12
iBaseNote = 52
indx = 0
iStart = 0
while indx < iLen do
iNote random iBaseNote, iBaseNote+9
iQT = random:i(0,100) < 50 ? int(iNote) : int(iNote)+0.5
schedule "playH", iStart, 1, iQT
iRndPlus random 0.3, 1.2
iStart += iRndPlus
indx += 1
od

endin



instr playH
iLen = 8
iRatioArr[] init iLen
indxRatio = 0
while indxRatio < iLen do
iRndRatio random 1, 5
iRatioArr[indxRatio] = iRndRatio
indxRatio += 1
od
;printarray iRatioArr

iFrq mtof p4
indx = 0
while indx < iLen do
iFrqOut = iFrq*iRatioArr[indx]
schedule "play", 0, 5, iFrqOut

indx += 1
od
endin

instr play
iAmpdB random -30, -20
iAmp ampdb iAmpdB
iAtt = 0.005
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
iFrq = p4
kRndFrq jspline 0.05, 2, 13
aSound poscil aEnv, iFrq*(kRndFrq+1)

chnmix aSound, "snd"
endin



instr soundOut
aIn chnget "snd"
    iFeedback random 0.1, 0.7
    iDelayTime random 0.5, 1.5
 	abuf	delayr	p3
 	aDelay	deltapi	iDelayTime	
 	delayw	aIn + (aDelay*iFeedback)
  	aDelMix		ntrpol	 aIn,aDelay,  0.5
outall aDelMix
chnclear "snd"
endin

</CsInstruments>
<CsScore>
 i "pulsPlay" 0 999
; i "soundOut" 0 999
</CsScore>
</CsoundSynthesizer>

