<CsoundSynthesizer>
<CsOptions>
; Select audio/midi flags here according to platform
; Audio out   Audio in    No messages
-odac           -iadc     -d     ;;;RT audio I/O
; For Non-realtime ouput leave only the line below:
; -o wgbrass.wav -W ;;; for file output any platform
</CsOptions>
<CsInstruments>

; Initialize the global variables.
sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0
; Instrument #1.
instr 1
  iAmp ampdb -10; = 0.7
  iFrq = 1200 ; = p4
  ktens rspline 0.1, 0.2, 2, 3
  iatt = 0.1

  aSound wgbrass iAmp, iFrq, ktens, iatt, 0,0
  outall aSound
endin


</CsInstruments>
<CsScore>
f 1 0 1024 10 1
i1 0 999


</CsScore>
</CsoundSynthesizer>


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>100</x>
 <y>100</y>
 <width>320</width>
 <height>240</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
