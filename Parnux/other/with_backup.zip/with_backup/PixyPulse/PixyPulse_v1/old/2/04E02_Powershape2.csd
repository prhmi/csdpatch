<CsoundSynthesizer>
<CsOptions>
-o dac
</CsOptions>
<CsInstruments>
sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1



#include "D:\Learning\Music\Electronic\Csound\include\basic.udo"

instr 1
trigeri 2, 2, 5, 1.3
endin

instr 2
 iAmp = 0.5
 iFrq random 200, 1200
kRndTime1 randomh 0.1, 0.4, 1
kRndTime2 randomh 0.1, 0.4, 1
kFrqRnd1 randomh 1.2, 1.5, kRndTime1
kFrqRnd2 randomh 1.3, 1.8, kRndTime2
kPortTime linseg 0, 0.0001, 0.01
kFrqRnd1 portk kFrqRnd1, kPortTime
kFrqRnd2 portk kFrqRnd2, kPortTime
 aIn1 poscil iAmp, iFrq
 aIn2 poscil iAmp, iFrq*kFrqRnd1
 aIn3 poscil iAmp, iFrq*kFrqRnd2
 aIn = (aIn1+aIn2+aIn3)/3
 kShape rspline 1, 10, 4, 17
 aSound powershape aIn, kShape, iAmp
 aOut linen aSound, p3/5, p3, p3/5
 chnmix aOut, "snd"
 endin
 
 
 instr 3
 iFrq random 400, 700
 sineSound, iFrq
 endin
 
instr 99
 mreverb
endin
</CsInstruments>
<CsScore>
i1 0 9999
i99 0 9999
</CsScore>
</CsoundSynthesizer>
;example by joachim heintz

 </bgcolor>
</bsbPanel>
</bsbPresets>
