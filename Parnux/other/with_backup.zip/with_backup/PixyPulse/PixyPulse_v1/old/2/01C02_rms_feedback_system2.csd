<CsoundSynthesizer>
<CsOptions>
-odac
</CsOptions>
<CsInstruments>
sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

giSine    ftgen     0, 0, 2^10, 10, 1, 0.2, 0.5 ;table with a sine wave
seed 0
instr 1
 a3        init      1
 kamp      linseg    0, 1.5, 0.2, 1.5, 0       ;envelope for initial input
 asnd      poscil    kamp, 1200, giSine         ;initial input
 if p4 == 1 then    
 
 kRnd1 rspline 0.01, 0.2, 12, 17 
 kRnd2 rspline 0.02, 0.1, 2, 7                           ;choose between two sines ...
  adel1     poscil    0.021, kRnd1, giSine
  adel2     poscil    0.073, kRnd2, giSine,.0015
 else                                          ;... or a random movement 
                                               ;for the delay lines
  adel1     randi     0.7, 7, 12
  adel2     randi     0.1, 5, 12
 endif
 a0        delayr    0.7                  ;delay line of 1 second
 a1        deltapi   adel1 + 0.7                ;first reading
 a2        deltapi   adel2 + 0.1             ;second reading
 krms      rms       a3          ;rms measurement
           delayw    asnd + exp(-krms) * a3     ;feedback depending on rms
 a3        reson     -(a1+a2), 1000, 7000, 2    ;calculate a3
 aout      linen     a1/3, 1, p3, 1             ;apply fade in and fade out
           outs      aout, aout
endin
</CsInstruments>
<CsScore>
i 1 0 60 1          ;two sine movements of delay with feedback
i 1 61 . 2          ;two random movements of delay with feedback
</CsScore>
</CsoundSynthesizer>
;example by Martin Neukom, adapted by Joachim Heintz


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
