;v3
<Cabbage>
form caption("PixyDust")    size(1350, 700)   guiMode("queue") colour(45,10,35) pluginId("pxds") ; style("legacy")

vslider bounds(1052, 536, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(219, 120, 120, 255) 
vslider bounds(1094, 536, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(219, 120, 120, 255)
vslider bounds(1134, 536, 50, 150) channel("out3") range(0, 80, 0, 1, 1) trackerColour(219, 120, 120, 255)
vslider bounds(1176, 536, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(219, 120, 120, 255)
nslider bounds(1058, 502, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(80, 50, 50, 255)
nslider bounds(1098, 502, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(80, 50, 50, 255)
nslider bounds(1138, 502, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(80, 50, 50, 255)
nslider bounds(1178, 502, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(80, 50, 50, 255)
nslider bounds(1226, 468, 93, 44) channel("gain") range(-90, 50, 0, 1, 1) colour(80, 50, 50, 255) text("Master Gain (dB)")

label bounds(1068, 50, 239, 66) channel("sec") text("00 : 12") fontColour(241, 178, 178, 255)
label bounds(1108, 14, 70, 33) channel("data")  fontColour(241, 178, 178, 255) colour(80, 50, 50, 255) text("0")
button bounds(1188, 18, 116, 27) channel("start") text("S  T  A  R  T", "S  T  O  P")  colour:0(171, 81, 152, 255) colour:1(99, 85, 85, 255) value(1)
image bounds(1048, 424, 30, 30) channel("dustlight") corners(5) colour(80, 50, 50, 255)
image bounds(1088, 424, 30, 30) channel("seqlight") corners(5) colour(80, 50, 50, 255)
image bounds(1126, 424, 30, 30) channel("bowlight") corners(5) colour(80, 50, 50, 255)
image bounds(1164, 424, 30, 30) channel("flutelight") corners(5) colour(80, 50, 50, 255)
image bounds(1202, 424, 30, 30) channel("clarinetlight") corners(5) colour(80, 50, 50, 255)
image bounds(1242, 424, 30, 30) channel("wgamblight") corners(5) colour(80, 50, 50, 255)
image bounds(1276, 190, 50, 25) channel("morselight") corners(5) colour(80, 50, 50, 255)
image bounds(1280, 424, 30, 30) channel("analoglight") corners(5) colour(80, 50, 50, 255)




label bounds(320, 400, 59, 18) channel("label4") text("CC-11") fontColour(224, 219, 219, 255)
label bounds(320, 444, 59, 18) channel("label5") text("CC-07") fontColour(224, 219, 219, 255)
label bounds(320, 486, 59, 18) channel("label6") text("CC-15") fontColour(224, 219, 219, 255)
label bounds(320, 526, 59, 18) channel("label7") text("CC-14") fontColour(224, 219, 219, 255)
label bounds(320, 566, 59, 18) channel("label8") text("CC-06") fontColour(224, 219, 219, 255)
label bounds(322, 68, 59, 18) channel("label9") text("CC-01") fontColour(224, 219, 219, 255)
label bounds(390, 210, 59, 18) channel("label10") text("CC-09") fontColour(224, 219, 219, 255)
label bounds(322, 104, 59, 18) channel("label11") text("CC-13") fontColour(224, 219, 219, 255)
label bounds(322, 606, 59, 18) channel("label12") text("CC-13") fontColour(224, 219, 219, 255)
label bounds(390, 508, 59, 18) channel("label13") text("CC-00") fontColour(224, 219, 219, 255)

hslider bounds(38, 390, 281, 40) channel("pos") range(0.025, 2, 1, 1, 0.001) trackerColour(219, 120, 120, 255) text("pos")
hslider bounds(11, 432, 307, 40) channel("spdstrngmin") range(0.1, 5, 2, 1, 0.1) trackerColour(219, 120, 120, 255) text("spd min")
hslider bounds(9, 474, 310, 40) channel("spdstrngmax") range(0.5, 12, 5, 1, 0.1) trackerColour(219, 120, 120, 255) text("spd max")
hslider bounds(46, 516, 273, 40) channel("wgvib") range(0, 1, 0, 1, 0.001) trackerColour(219, 120, 120, 255)  text("vib")
hslider bounds(16, 558, 303, 40) channel("vibSpd") range(0, 0.27, 0.03, 1, 0.001) trackerColour(219, 120, 120, 255) text("vib rng")
hslider bounds(40, 598, 279, 40) channel("wgfilt") range(500, 5000, 700, 1, 1) trackerColour(219, 120, 120, 255) text("Filt")
hslider bounds(40, 96, 279, 40) channel("nfilt") range(200, 9000, 700, 1, 1) trackerColour(219, 120, 120, 255) text("Filt")

nslider bounds(388, 462, 64, 42) channel("wgcent") range(0, 500, 0, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("wgCent")
label bounds(326, 210, 59, 18) channel("label25") text("CC-00") fontColour(224, 219, 219, 255)
nslider bounds(324, 158, 64, 42) channel("noiserng") range(0, 1200, 50, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("nRng")

vslider bounds(476, 472, 50, 150) channel("wgamp") range(0, 30, 25, 1, 1) trackerColour(219, 120, 120, 255) text("wgAmp")
vslider bounds(396, 56, 50, 150) channel("noiseamp") range(0, 30, 25, 1, 1) trackerColour(219, 120, 120, 255) text("nAmp")
hslider bounds(40, 56, 281, 40) channel("noisepress") range(30, 400, 30, 1, 0.001) trackerColour(219, 120, 120, 255) text("nPres")


checkbox bounds(992, 96, 30, 30) channel("morsestart") colour:0(111, 103, 103, 255) colour:1(0, 255, 154, 255)
checkbox bounds(958, 96, 25, 25) channel("morsesine") colour:0(111, 103, 103, 255) colour:1(0, 255, 154, 255) value(0)
checkbox bounds(1030, 96, 25, 25) channel("morsenoise") colour:0(111, 103, 103, 255) colour:1(0, 255, 154, 255) value(0)
label bounds(957, 68, 27, 22) channel("labelmorse1") text("S")
label bounds(1029, 68, 27, 22) channel("labelmorse2") text("N")

texteditor bounds(953, 134, 387, 40) channel("morsetxt") colour(180, 140, 250, 200) colour:0(200, 170, 200, 200)fontSize(26) text("some one")
nslider bounds(958, 182, 70, 44) channel("morsebpm") range(30, 200, 124, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("Tempo")
nslider bounds(1030, 182, 68, 43) channel("morsefrq") range(200, 2000, 1200, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("Frq")
nslider bounds(1102, 182, 68, 43) channel("morseamp") range(-90, 12, -7, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("Amp")
nslider bounds(1172, 182, 68, 43) channel("morsefilt") range(500, 9000, 7000, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("Frq")
nslider bounds(390, 534, 65, 44) channel("wgfrq") colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) range(10, 9000, 300, 1, 1) text("wgFrq")

vmeter bounds(1230, 536, 15, 150) channel("meter1")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1254, 536, 15, 150) channel("meter2")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1278, 536, 15, 150) channel("meter3")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1302, 536, 15, 150) channel("meter4")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
image bounds(1230, 522, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(1254, 522, 15, 15) channel("clip2") colour(0, 0, 0, 255)
image bounds(1278, 522, 15, 15) channel("clip3") colour(0, 0, 0, 255)
image bounds(1302, 522, 15, 15) channel("clip4") colour(0, 0, 0, 255)

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0


opcode CsdMeter, 0, SakS
 SClip, aSig, kTrig, Smeter	xin
 iDbRange = 60 ;shows 60 dB
 iHoldTim = 0.5;seconds to "hold the red light"
 kOn init 0
 kTim init 0
 kStart init 0
 kEnd init 0
 kMax max_k aSig, kTrig, 1
 cabbageSetValue Smeter, kMax, metro(20)
 
 if kTrig == 1 then
 kMeter = (iDbRange + dbfsamp(kMax)) / iDbRange
  if kOn == 0 && kMax > 1 then
   kTim = 0
   kEnd = iHoldTim
   cabbageSet 1,SClip,"colour(250,0, 0)"
   kOn = 1
  endif
  if kOn == 1 && kTim > kEnd then
   cabbageSet 1,SClip,"colour(0,0,0)"
   kOn =	0
  endif
 endif
 kTim += ksmps/sr
endop

opcode limiter, a,ai
aIn, iThrshhol xin
kThrsh rms aIn, 0.1
kTrig metro 10
kMax max_k aIn, kTrig, 1
kAmpdB dbamp kMax
if kAmpdB <= -50 then
kAmpdB = -90
elseif kAmpdB >= 1 then
kAmpdB = 1
endif
 kFctr = iThrshhol-kAmpdB
 kLimitdB ampdb kFctr
if kLimitdB >= 1 then
kLimitdB = 1
endif
 aLimiter interp kLimitdB
 aDelay delay aIn, 0.1
 aOut = aDelay*aLimiter
xout aOut
endop



massign 1,1
massign 2,8
massign 3,18
massign 4,19
massign 5,20
massign 6,20
massign 7,22
massign 16,31


instr noisePlay
kAmpdBIn cabbageGet "noiseamp"
kAmpdB ampdb kAmpdBIn-30
kPortTime linseg 0, 0.01, 0.1
kAmpdB portk kAmpdB, kPortTime
iAtt random 0.2, 0.5
iRel random 0.2, 0.5
aEnv linsegr 0, iAtt, 1, iRel, 0


kSpeedMin cabbageGet "spdstrngmin"
kSpeedMax cabbageGet "spdstrngmax"

iDelayTime  = 0.1 ;random 0.1, 0.25

kFb cabbageGet "noisepress"

aNoise noise 1, 0.5
aNoise = aNoise*5
aFb init 1
aNoise = (aNoise*kFb)+aFb
aSine poscil 1, aNoise
aPhas phasor aNoise
aSum sum aSine, aPhas
aFb delay aSum, iDelayTime

iMidi notnum
iFrq mtof iMidi

kRngIn cabbageGet "noiserng"
kRng = cent(kRngIn)-1
kFilterMin = (iFrq*(1-kRng))*2
if kFilterMin <= 200 then
kFilterMin = 200
endif
kFilterMax = (iFrq*(1+kRng))*2
    if kFilterMax >= 12000 then
    kFilterMax = 12000
    endif
kFilt cabbageGet "nfilt"
  aFilt clfilt aFb, kFilterMax+kFilt, 0, 10
  aFilt  clfilt aFilt, kFilterMin, 1, 10
  ;
aOut = aFilt*kAmpdB*aEnv*0.1
;outall aOut
chnmix aOut, "snddust"
endin



instr dustMachine
 kTimeG init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 kFrq init 7000
 if metro(kTimeG) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 3))
 	kSeqValue random 1/3, 1/2
 	trim kSeqArr, kLen
 		kIndx = 0
 		while kIndx < kLen-1 do
		kRndSeq random 0, 0.2
 		kSeqArr[kIndx] = kSeqValue+kRndSeq
 		kIndx += 1
 		od
 	kMaxValue random 1/7, 1/15
 	kSeqArr[kLen-1] = kMaxValue
 	kFrq random 1000, 9000
 	kLoop random 2, 4
 	endif 
 kLenOut random 1, 7
 kDur random 0.5, 3
 schedulek "guiroPlay", 0, 1, kFrq, kLoop,kLenOut
 	kIndx = 0
 	kFrq2 random 1000, 9000 
 	kNumber random 1, 6
 	while kIndx < int(kNumber) do
 	kStart random 1, 7
 	schedulek "guiroSound", kStart, 1, kFrq2, kLoop
 	kIndx += 1
 	od
 kTimeG = kSeqArr[kIndxSeq]
    if kIndxSeq == 0 then
    kDurNoise = 1/kMaxValue
    schedulek "noiseSound", 0, kDurNoise*1.5
    endif
 kIndxSeq = (kIndxSeq+1) % kLen
 endif

endin

instr noiseSound
iAmpdB ampdb -10
aNoise noise 1, 0.5
aEnv linseg 0, p3/2, 1, p3/2, 0
iFrq random 100, 400

kRngIn cabbageGet "noiserng"
kRng = cent(kRngIn)-1
kFilterMin = (iFrq*(1-kRng))*2
if kFilterMin <= 200 then
kFilterMin = 200
endif
kFilterMax = (iFrq*(1+kRng))*2
    if kFilterMax >= 12000 then
    kFilterMax = 12000
    endif
  aFilt  clfilt aNoise, kFilterMax, 0, 10
  aFilt  clfilt aFilt, kFilterMin, 1, 10
  
aOut = aFilt*iAmpdB*aEnv
chnmix aOut, "snddust"
endin




instr guiroPlay
iFrq = p4
iLoop = p5
iLen = int(p6)
indx = 0
iStart = 0
while indx < iLen do
schedule "guiroSound", iStart, 1,iFrq,iLoop
iStart += 0.175
indx += 1
od
endin

instr guiroSound
kDustMachine ctrl7 10, 57, 0, 1
    if kDustMachine == 0 then
    turnoff
    endif
iFrqIn = p4
iFrq random iFrqIn, iFrqIn*1.01
iNum random 128, 128
iAmp = (iFrqIn/10000)^2
aSound  guiro iAmp*0.1, 0, 128, 0, 0, iFrq, iFrq*2
iLoopDur = p5
iLoop random 0.1, 0.4
aComb comb aSound, iLoopDur, iLoop
iFrqRnd random 0, 100
iRel = 0.1
;aRel transegr 1, iRel, -6, 0
aRes reson aSound, iFrq*1.1+iFrqRnd, 200
chnmix aRes, "snddust"
;outall aSound
endin


instr seqMachine
SinstrArr[] fillarray "sineSound", "barSound", "bamSound", "bamSound", "shakeSound", "pluckSound"
 kTime init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 if metro(1/kTime) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 12))
 	trim kSeqArr, kLen
 		kIndx = 0 
 		while kIndx < kLen-1 do
 		kSeqValue random 1, 3
 		kSeqArr[kIndx] = kSeqValue
 		kIndx += 1
 		od
 	kMaxValue random 15, 20
 	kSeqArr[kLen-1] = kMaxValue
 	endif 
 kInstr = int(random:k(0, 6))
 Sinstr = SinstrArr[kInstr]
 schedulek Sinstr, 0, kTime
 kIndxSeq = (kIndxSeq+1) % kLen
 kTime = kSeqArr[kIndxSeq]/10
 endif

endin

instr sineSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
iAmp = 0.1
    iFrq random 200, 1200
    iAtt = 0.005
    aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq
chnmix aSound, "sndseq"
;outall aSound
endin

instr sineSoundMidi
;giDelayTime random 0.1, 1
;giFeedback random 0.1, 0.5
iAmp = 0.1
    inum notnum
    iVel veloc 0.5, 0.0005
    iFrq mtof inum
    iAtt = iVel^1.7
    print iAtt
    iRel = iAtt*10
    if iRel <= 0.1 then
    iRel = 0.1
    endif
    aEnv transegr 0, iAtt, 4, iAmp, iRel, -6, 0
iMyset  ftgen		0, 0, 2^10,10,1, 0.7, 0, 0.2
iRndF random 1.2, 1.3
aSound poscil aEnv, iFrq,iMyset
iFiltr = iFrq*1.7
aFilt clfilt aSound, iFiltr, 0, 30
aFilt clfilt aFilt, 200, 1, 10
chnmix aFilt, "sndseq"
;outall aFilt
endin

instr barSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
iFrq random 10, 70
;kScan rspline 0.1, 0.8, p3*2, p3*4
iPoseMin random 0.001, 1
iPoseMax random 2, 10
iScan = random(0, 100) > 90 ? iPoseMin : iPoseMax
iRel = 0.5 ;random 0.01, 0.5
iPose = 0.005 ;random 0.001, 0.1
iPres random 0.1, 0.5
aSound    barmodel       1, 1, iFrq, iRel, iScan, 1, iPose, 50000, iPres
iAtt = 0.001
aEnv transeg 0, iAtt, 6, 1;, p3-iAtt, -6, 0
iFilter random 800, 3000
aFilt clfilt aSound*aEnv, iFilter, 1, 10
;outall aFilt
chnmix aFilt, "sndseq"
endin

instr bamSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
p3 random 0.05, 3
iFrq random 10, 50
iFilter random 3000, 8000
iAtt = 0.01
aEnv transeg 0, iAtt, 6, 0.5, p3-iAtt, -6, 0
iAmp = 2000
iNumber random 1, 7
iDamp random 0.0001, 0.05
iDecay random 0.001, 0.1
aSound  bamboo iAmp, iDecay, iNumber, iDamp, 1, iFrq, 400
aFilt clfilt aSound*aEnv, iFilter, 1, 10
aLimit limiter aFilt, -15
chnmix aLimit, "sndseq"
endin


instr shakeSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
p3 random 0.01, 0.1
iRel random 0.1, 1
aEnv linsegr 1, iRel, 0
knum  rspline 2, 15, 2, 7
kFrq rspline 700, 3000, 2, 15
asig shaker .03, kFrq, 8, 0.9, knum
iFilter random 300, 500
aFilt clfilt asig*aEnv, iFilter, 1, 10		
chnmix aFilt, "sndseq"
endin


instr pluckSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
giRvrbTime random 0.7, 0.9
iAmp random 0.3, 0.5
iAtt random 0.008, 0.01
iRel random 0.1, 1
aEnv linsegr 0, iAtt, 1, iRel, 0
iFrq random 30, 1500
iResample random 20, 1500
iMeth = random:i(0, 100) < 50 ? 1 : 6
aSound  pluck iAmp, iFrq, iResample, 0, iMeth;, 2, 1
iFilter random 300, 1500
aFilt clfilt aSound*aEnv, iFilter, 0, 10	
aFilt clfilt aSound*aEnv, 200, 1, 10	
chnmix aFilt, "sndseq"
endin






instr bowMachine
kTimeBow init 1
if metro(1/kTimeBow) == 1 then
kTimeBow random 5, 7
kDurBow = kTimeBow*1.3
schedulek "bowSound", 0, kDurBow
endif
endin

instr fltMachine
kTimeFlute init 1
if metro(1/kTimeFlute) == 1 then
kTimeFlute random 5, 7
kDurFlute = kTimeFlute*1.3
schedulek "fluteSound", 0, kDurFlute
endif
endin
instr clrMachine
kTimeClr init 1
if metro(1/kTimeClr) == 1 then
kTimeClr random 5, 7
kDurClr = kTimeClr*1.3
schedulek "clarinetSound", 0, kDurClr
endif
endin
instr ambwgMachine
kTimeAmbWg init 1
if metro(1/kTimeAmbWg) == 1 then
kTimeAmbWg random 5, 7
kDurAmbWg = kTimeAmbWg*1.3
schedulek "wgAmbSound", 0, kDurAmbWg
endif
endin

instr analogMachine
kTime init 1
if metro(1/kTime) == 1 then
kTime random 5, 7
kDur = kTime*1.3
    kIndx = 0
    while kIndx < 5 do
    kStart random 0, 3
    schedulek "analogSound", kStart, kDur
    kIndx += 1
    od
endif
endin


instr bowSound
iAtt = 1
iRel = 1
iMidi notnum
if iMidi != 0 then
cabbageSet 1,"bowlight","colour(200, 150, 100)"
kRelease release
    if kRelease == 1 then
    cabbageSet 1,"bowlight","colour(80, 50, 50, 255)"
    endif
aEnv linsegr 0, iAtt, 1, iRel, 0
 iFrq mtof iMidi
 iFrqMin = iFrq/2
elseif iMidi == 0 then
aEnv linseg 0, p3/2, 1, p3/2, 0
 	iFrqMin random 10, 1000
endif

iGain ampdb -15
;iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
iWave     ftgenonce 1,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
 	iBaseFrq random 100, 400

 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
 kVibIn     = 5
  kVibRng  = 5
 kPosIn     = 0.1
	kAmp   rspline  0.2, 0.7, 0.7, 1
	kCent = 10
	kCentFrq    jspline  kCent, kSpeedMin, kSpeedMax
	kFrq = iBaseFrq*cent(kCentFrq)
	kPres  rspline  3, 4, kSpeedMin, kSpeedMax
	kRate   rspline 0.025, kPosIn, kSpeedMin, kSpeedMax
	kVib   jspline  kVibIn/1000, kSpeedMin, kSpeedMax
	aBow	wgbow    kAmp,kFrq,kPres,kRate,kVib,kVibRng/100,iWave, iFrqMin
    kFilterBow = 12000
    aFiltBow clfilt aBow, kFilterBow, 0, 10
    aFiltBow clfilt aFiltBow, 150, 1, 10

;    aOut linen aFiltBow*iGain, p3/2, p3, p3/2
	aOut = aFiltBow*iGain*aEnv
;	outall aOut
	chnmix aOut, "sndwg"
endin



instr fluteSound
iGain ampdb -1
iMidi notnum
if iMidi != 0 then
iAtt = 1
iRel = 1
aEnv linsegr 0, iAtt, 1, iRel, 0
 iFrq mtof iMidi
 iFrqMin = iFrq/2
elseif iMidi == 0 then
aEnv linseg 0, p3/2, 1, p3/2, 0
 	iFrqMin random 10, 1000
endif
iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
;iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
iBaseFrq random 100, 500
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
kAmp rspline 0.03, 0.2, kSpeedMin, kSpeedMax
kJet rspline 0.01, 0.9, kSpeedMin, kSpeedMax
kVib rspline 0, 1, kSpeedMin, kSpeedMax
kVamp rspline 0.1, 0.5, kSpeedMin, kSpeedMax
kAirSound rspline 0, 0.4, kSpeedMin, kSpeedMax
kCent = 0
kGliss jspline kCent, kSpeedMin, kSpeedMax
kFrq = iBaseFrq*cent(kGliss)
iAtt = 0.5
iDecay = 0.2
   aFlute  wgflute kAmp, kFrq, kJet, iAtt, iDecay, kAirSound, kVib, kVamp, iWave,iFrqMin
		kFilterFlute = 7000
    aFiltFlute clfilt aFlute, kFilterFlute, 0, 10
    aFiltFlute clfilt aFiltFlute, 250, 1, 10
;    aOut linen aFiltFlute, p3/2, p3, p3/2
    aOut = aFiltFlute*iGain*aEnv
  chnmix aOut, "sndwg"
endin



instr clarinetSound

iGain ampdb -1
iMidi notnum
if iMidi != 0 then
iAtt = 1
iRel = 1
aEnv linsegr 0, iAtt, 1, iRel, 0
 iFrq mtof iMidi
 iFrqMin = iFrq/2
elseif iMidi == 0 then
aEnv linseg 0, p3/2, 1, p3/2, 0
 	iFrqMin random 10, 1000
endif


;iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
iBaseFrq random 100, 200
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
kAmp rspline 0.03, 0.2, kSpeedMin, kSpeedMax
kCent = 0
kGliss jspline kCent, kSpeedMin, kSpeedMax
kFrq = iBaseFrq*cent(kGliss)
  kStiff rspline -0.4, -0.18, kSpeedMin, kSpeedMax
  iAtt1 = 1.2
  iDetk = 0.1
  kAirNoise rspline 0, 0.3, kSpeedMin, kSpeedMax
  kVibClr jspline 3, 0.4, 0.7
  kvAmpClr rspline 0.5, 2, 2, 7
  aClar wgclar kAmp, kFrq, kStiff, iAtt1, iDetk, \
  kAirNoise, kVibClr, kvAmpClr, iWave, iFrqMin

		kFilterClr = 7000
    aFiltClr clfilt aClar, kFilterClr, 0, 10
    aFiltClr clfilt aFiltClr, 250, 1, 10
;    aOut linen aFiltClr, p3/2, p3, p3/2
    aOut = aFiltClr*iGain*aEnv
  chnmix aOut, "sndwg"
;outall aFiltClr
endin




instr wgAmbSound
kGainIn cabbageGet "wgamp"
kGain ampdb kGainIn-20
iMidi notnum
    if iMidi != 0 then
    iAtt = 1
    iRel = 1
    aEnv linsegr 0, iAtt, 1, iRel, 0
    kFrqBwIn mtof iMidi
    kFrqClrIn mtof iMidi
    elseif iMidi == 0 then
    aEnv linseg 0, p3/2, 1, p3/2, 0
    iFrqBwIn random 200, 800
    iFrqClrIn random 200, 800
    endif
iGainClr ampdb -7
iGainBw ampdb -10
iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0

iFrqMin cabbageGetValue "wgfrq"
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
	;;clr
  kAmpClr rspline 0.3, 0.4, kSpeedMin, kSpeedMax
  
  kFrqClr rspline iFrqClrIn*0.5, iFrqClrIn*0.6, 0.4, 0.7
  kStiff rspline -0.4, -0.18, kSpeedMin, kSpeedMax
  iAtt1 = 1.2
  iDetk = 0.1
  kAirNoise rspline 0, 0.5, kSpeedMin, kSpeedMax
  kVibClr jspline 50, 0.4, 0.7
  kvAmpClr rspline 0.5, 2, 2, 7
  aClar wgclar kAmpClr*iGainClr, kFrqClr, kStiff, iAtt1, iDetk, \
  kAirNoise, kVibClr, kvAmpClr, iWave, iFrqMin
  ;;bow
   kAmpBw rspline 0.3, 0.4, kSpeedMin, kSpeedMax
   kPres rspline 0.01, 5, kSpeedMin*2, kSpeedMax*2
	kRate rspline 0.025, 0.225, kSpeedMin*3, kSpeedMax*3
	kVibBw jspline 0.1, 0.9, 1
	kvAmpBw = 0.02
	kCent cabbageGet "wgcent"
	kFrqCent jspline kCent, kSpeedMin, kSpeedMax*0.8
	kFrqBw = iFrqBwIn*cent(kFrqCent)
   aBow  wgbow kAmpBw*iGainBw, kFrqBw, kPres, kRate, kVibBw, kvAmpBw,\
   iWave, iFrqMin
   ;;output
   aSum sum  aBow , aClar
   kFilterIn cabbageGet "wgfilt"
   kFilt rspline kFilterIn*0.9, kFilterIn*1.1, 0.4, 0.7
   aFilt clfilt aSum, kFilt, 0, 10
   aFilt clfilt aFilt, 150, 1, 10
   aDel delay aFilt, 0.4
   aMix ntrpol aFilt, aDel, 0.3  
   aOut = aMix*kGain*aEnv
   chnmix aOut, "sndwg"
;  outall aOut
endin







instr analogSound
kAnalog ctrl7 10, 63, 0, 1
if kAnalog == 0 then
turnoff
endif
kGainIn = 40 ;cabbageGet "gnpd"
kGain ampdb kGainIn-60
 iMidi notnum
 if iMidi != 0 then
 iFrq mtof iMidi
 iAtt random 1, 2
 iRel random 1, 1
 aEnv linsegr 0, iAtt, 1, iRel, 0
 cabbageSet 1,"analoglight","colour(200, 70, 200)"
 kRelease release
    if kRelease == 1 then
    cabbageSet 1,"analoglight","colour(70, 62, 68, 255)"
    endif
 elseif iMidi == 0 then
 iFrq random 400, 700 
 aEnv linseg 0, p3/2, 1, p3/2, 0
 endif
 
 kCent cabbageGet "wgcent"
 kFilterIn cabbageGet "wgfilt"
  
kPlusF1 cabbageGet "spdstrngmin"
kPlusF2 cabbageGet "pos"
kPlusF3 cabbageGet "vib"
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
 
iWave  	  	 ftgen		0, 0, 2^10,10,1, 0.5
 	kAmp1    rspline  0.2, 0.3, 0.7, 1
    kAmp2    rspline  0.2, 0.3, 0.7, 1
    kAmp3    rspline  0.2, 0.3, 0.7, 1
    kAmp4    rspline  0.2, 0.3, 0.7, 1
 	kFrq    rspline  iFrq, iFrq*cent(kCent), kSpeedMin,kSpeedMax

kFmAmp rspline 1, 10, kSpeedMin, kSpeedMax
kFmFrq rspline 20, 50, kSpeedMin, kSpeedMax
aFM poscil kFmAmp, kFmFrq
aSound1 poscil kAmp1, kFrq+aFM, iWave
aSound2 poscil kAmp2*0.2, kFrq+(kPlusF1*10)
aSound3 poscil kAmp3*0.1, kFrq+(kPlusF2*10)
aSound4 poscil kAmp4*0.3, kFrq+(kPlusF3*10)

aSound sum aSound1,aSound2,aSound3,aSound4

if kSpeedMin <= 0.7 then
aSound = aSound1
endif
	kFilter rspline kFilterIn*0.9, kFilterIn*1.1, 2, 3
    aFilt clfilt aSound, kFilter, 0, 10
    aFilt clfilt aFilt, 250, 1, 10


    aGain interp kGain
	aOut = aFilt*aEnv*aGain
;	outall aOut
	chnmix aOut, "sndwg"
endin




;;morse
gkMorse init 0
instr morse
if gkMorse == 0 then
cabbageSet 1,"morselight","colour(80, 50, 50, 255)"
elseif gkMorse == 1 then
cabbageSet 1,"morselight","colour(70, 200, 100)"
endif
Stype cabbageGet "morsetxt"
puts Stype,1
if changed(Stype) == 1 && gkMorse == 0 then
schedulek "morseR", 0, 1, Stype
schedulek "morseLetter", 0.1, 1
endif
endin

instr morseR
gkMorse = 1
giIndx init 0
index = 0
Stype = p4
iLen       strlen     Stype 
giLen = iLen
giTypeArr[] init iLen	
while index < iLen do
ichr       strchar    Stype, index
giTypeArr[index]  = ichr
index += 1
od
;printarray giTypeArr

endin

instr morseLetter
iChar = giTypeArr[giIndx]
iMorseArr_A[] fillarray 1,2
iMorseArr_B[] fillarray 2,1,1,1
iMorseArr_C[] fillarray 2,1,2,1
iMorseArr_D[] fillarray 2,1,1
iMorseArr_E[] fillarray 1
iMorseArr_F[] fillarray 1,1,2,1
iMorseArr_G[] fillarray 2,2,1
iMorseArr_H[] fillarray 1,1,1,1
iMorseArr_I[] fillarray 1,1
iMorseArr_J[] fillarray 1,2,2,2
iMorseArr_K[] fillarray 2,1,2
iMorseArr_L[] fillarray 1,2,1,1
iMorseArr_M[] fillarray 2,2
iMorseArr_N[] fillarray 2,1
iMorseArr_O[] fillarray 2,2,2
iMorseArr_P[] fillarray 1,2,2,1
iMorseArr_Q[] fillarray 2,2,1,2
iMorseArr_R[] fillarray 1,2,1
iMorseArr_S[] fillarray 1,1,1
iMorseArr_T[] fillarray 2
iMorseArr_U[] fillarray 1,1,2
iMorseArr_V[] fillarray 1,1,1,2
iMorseArr_W[] fillarray 1,2,2
iMorseArr_X[] fillarray 2,1,1,2
iMorseArr_Y[] fillarray 2,1,2,2
iMorseArr_Z[] fillarray 2,2,1,1

if iChar == 97 then
giMorseArr[] = iMorseArr_A
elseif iChar == 98 then
giMorseArr[] = iMorseArr_B
elseif iChar == 99 then
giMorseArr[] = iMorseArr_C
elseif iChar == 100 then
giMorseArr[] = iMorseArr_D
elseif iChar == 101 then
giMorseArr[] = iMorseArr_E
elseif iChar == 102 then
giMorseArr[] = iMorseArr_F
elseif iChar == 103 then
giMorseArr[] = iMorseArr_G
elseif iChar == 104 then
giMorseArr[] = iMorseArr_H
elseif iChar == 105 then
giMorseArr[] = iMorseArr_I
elseif iChar == 106 then
giMorseArr[] = iMorseArr_J
elseif iChar == 107 then
giMorseArr[] = iMorseArr_K
elseif iChar == 108 then
giMorseArr[] = iMorseArr_L
elseif iChar == 109 then
giMorseArr[] = iMorseArr_M
elseif iChar == 110 then
giMorseArr[] = iMorseArr_N
elseif iChar == 111 then
giMorseArr[] = iMorseArr_O
elseif iChar == 112 then
giMorseArr[] = iMorseArr_P
elseif iChar == 113 then
giMorseArr[] = iMorseArr_Q
elseif iChar == 114 then
giMorseArr[] = iMorseArr_R
elseif iChar == 115 then
giMorseArr[] = iMorseArr_S
elseif iChar == 116 then
giMorseArr[] = iMorseArr_T
elseif iChar == 117 then
giMorseArr[] = iMorseArr_U
elseif iChar == 118 then
giMorseArr[] = iMorseArr_V
elseif iChar == 119 then
giMorseArr[] = iMorseArr_W
elseif iChar == 120 then
giMorseArr[] = iMorseArr_X
elseif iChar == 121 then
giMorseArr[] = iMorseArr_Y
elseif iChar == 122 then
giMorseArr[] = iMorseArr_Z
elseif iChar == 32 then
giMorseArr[] fillarray 5
endif

schedule "morseMachine",0.3,99999,iChar
endin



instr morseMachine
iBPM cabbageGetValue "morsebpm" ; 120
iTempo = iBPM/60
kTime init iTempo
kMorseIndx init 0
if metro(1/kTime) == 1 then
kTime = (giMorseArr[kMorseIndx])/(iTempo*4)
schedulek "morseSound", 0, kTime*0.5,p4

kMorseIndx += 1
endif

if kMorseIndx == lenarray(giMorseArr) && changed(kMorseIndx) == 1 then

giIndx += 1
	if giIndx >= giLen then
	gkMorse = 0
	turnoff
	endif
schedulek "morseLetter",0,1
turnoff
endif

endin




instr morseSound
iFrq cabbageGetValue "morsefrq"
iMorseNoise cabbageGetValue "morsenoise"
iMorseSine cabbageGetValue "morsesine"
iNoiseGain = iMorseNoise
iSineGain = iMorseSine

iAmpIn cabbageGetValue "morseamp"
iAmp ampdb iAmpIn
if p4 == 32 then
iGain = 0
else
iGain = 1
endif
iAtt = 0.01
iTest = (p3-iAtt)-(iAtt*2)
aEnv linseg 0,iAtt,iAmp,(p3-iAtt)-(iAtt*2),iAmp,iAtt,0
aSound poscil aEnv, iFrq
aNoise noise aEnv, 0.9
iFilter cabbageGetValue "morsefilt"
aNoise clfilt  aNoise, iFilter, 0, 10
aNoiseOut clfilt aNoise*ampdb(3), iFilter*0.9, 1, 10
aOut = ((aSound*iSineGain)+(aNoise*iNoiseGain))*iGain
out aOut,aOut
endin

; Effects
instr FxDust
aIn chnget "snddust"
aRvrb,aRvrb  reverbsc aIn,aIn, 0.65, 17000, sr, 1, 1
aMix ntrpol aIn, aRvrb, 0.4
	iRel = 2
	aEnv linsegr 1, iRel, 0
	aOut = aMix*aEnv
outall aOut
chnclear "snddust"
endin

instr FxSeq
aIn chnget "sndseq"
	giDelayTime init 0.4
	giFeedback init 0.3
 	aTim	interp	giDelayTime
 	abuf	delayr	15
 	aDelay	deltapi	aTim	
 	delayw	aIn + (aDelay*giFeedback)
 	kDelayMix rspline 0.2, 0.7, 1, 3
 	aDelayMix ntrpol aIn, aDelay, kDelayMix
 	aRvrb,aRvrb  reverbsc aDelayMix,aDelayMix, 0.7, 3000, sr, 0.3, 1
;	aRvrb reverb aDelayMix, 1
	kRvbMix rspline 0.3, 0.7, 2, 5
	aMix ntrpol aIn, aRvrb, kRvbMix
	iRel = 2
	aEnv linsegr 1, iRel, 0
	aOut = aMix*aEnv
outall aOut
chnclear "sndseq"
endin


instr FxWg
aIn chnget "sndwg"
aRvrb,aRvrb  reverbsc aIn,aIn, 0.85, 17000, sr, 1, 1
aMix ntrpol aIn, aRvrb, 0.3
	iRel = 2
	aEnv linsegr 1, iRel, 0
	aOut = aMix*aEnv
outall aOut
chnclear "sndwg"
endin

gkSpeaker1 init -45
gkSpeaker2 init -45
gkSpeaker3 init -60
gkSpeaker4 init -60
instr speaker
iMidi notnum
iVel veloc

;print iMidi,iVel
iSpeed = 20
iStart1 = i(gkSpeaker1)
iStart2 = i(gkSpeaker2)
iStart3 = i(gkSpeaker3)
iStart4 = i(gkSpeaker4)

if iMidi == 0 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1-1))
    if gkSpeaker1 <= -90 then
    gkSpeaker1 = -90
    endif
elseif iMidi == 1 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1+1))
    if gkSpeaker1 >= 20 then
    gkSpeaker1 = 20
    endif
endif

if iMidi == 2 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2-1))
    if gkSpeaker2 <= -90 then
    gkSpeaker2 = -90
    endif
elseif iMidi == 3 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2+1))
    if gkSpeaker2 >= 20 then
    gkSpeaker2 = 20
    endif
endif

if iMidi == 4 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3-1))
    if gkSpeaker3 <= -90 then
    gkSpeaker3 = -90
    endif
elseif iMidi == 5 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3+1))
    if gkSpeaker3 >= 20 then
    gkSpeaker3 = 20
    endif
endif

if iMidi == 6 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4-1))
    if gkSpeaker4 <= -90 then
    gkSpeaker4 = -90
    endif
elseif iMidi == 7 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4+1))
    if gkSpeaker4 >= 20 then
    gkSpeaker4 = 20
    endif
endif


if iMidi == 0 || iMidi == 1 then
cabbageSetValue  "out1", gkSpeaker1+65
cabbageSetValue  "outn1", gkSpeaker1
endif
if iMidi == 2 || iMidi == 3 then
cabbageSetValue  "out2", gkSpeaker2+65
cabbageSetValue  "outn2", gkSpeaker2
endif
if iMidi == 4 || iMidi == 5 then
cabbageSetValue  "out3", gkSpeaker3+65
cabbageSetValue  "outn3", gkSpeaker3
endif
if iMidi == 6 || iMidi == 7 then
cabbageSetValue  "out4", gkSpeaker4+65
cabbageSetValue  "outn4", gkSpeaker4
endif
endin

instr time
kTimer line 0, 1, 1
kSec = int(kTimer)
kMin init 0
kSec = kSec % 60
if kSec == 0 && changed(kSec) == 1 then
kMin += 1
endif
STimer sprintfk "%02d : %02d", kMin, kSec
cabbageSet 1, "sec", "text", STimer

endin

instr Widgets
iDurMaster = 9^9
kStart init 0
kStart cabbageGet "start"

if kStart == 1 && changed(kStart) == 1  then
schedulek "time", 0, iDurMaster
schedulek "FxWg", 0, iDurMaster
schedulek "FxDust", 0, iDurMaster
schedulek "FxSeq", 0, iDurMaster
elseif kStart == 0 && changed(kStart) == 1 then
turnoff2 "time", 0, 0
turnoff2 "FxWg", 0, 0
turnoff2 "FxDust", 0, 0
endif

;;DustMachine
 kDustMachine ctrl7 10, 57, 0, 1
    if kDustMachine == 1 && changed(kDustMachine) == 1 then
    cabbageSet 1,"dustlight","colour(200, 70, 200)"
    schedulek "dustMachine", 0, iDurMaster
    elseif kDustMachine == 0 && changed(kDustMachine) == 1 then
    cabbageSet 1,"dustlight","colour(80, 50, 50, 255)"
    turnoff2 "dustMachine", 0, 0
;    turnoff2 "noiseSound", 1, 1
    turnoff2 "guiroPlay", 0, 0
    turnoff2 "guiroSound", 0, 0
    endif

;;seqMachine
 kSeqMachine ctrl7 10, 58, 0, 1
    if kSeqMachine == 1 && changed(kSeqMachine) == 1 then
    cabbageSet 1,"seqlight","colour(100, 200, 100)"
    schedulek "seqMachine", 0, iDurMaster
;    schedulek "FxSeq", 0, iDurMaster
    elseif kSeqMachine == 0 && changed(kSeqMachine) == 1 then
    cabbageSet 1,"seqlight","colour(80, 50, 50, 255)"
    turnoff2 "seqMachine", 0, 0
    turnoff2 "sineSound", 0, 0
    turnoff2 "barSound", 0, 0
    turnoff2 "bamSound", 0, 0
    turnoff2 "shakeSound", 0, 0
    turnoff2 "pluckSound", 0, 0
;    turnoff2 "FxSeq", 0, 1
    endif



;;wgMachin
 kwgBow ctrl7 10, 59, 0, 1
    if kwgBow == 1 && changed(kwgBow) == 1 then
    cabbageSet 1,"bowlight","colour(200, 150, 100)"
    schedulek "bowMachine", 0, iDurMaster
    elseif kwgBow == 0 && changed(kwgBow) == 1 then
    cabbageSet 1,"bowlight","colour(80, 50, 50, 255)"
    turnoff2 "bowMachine", 0, 0
    turnoff2 "bowSound", 0, 0
    endif
 kwgFlute ctrl7 10, 60, 0, 1
    if kwgFlute == 1 && changed(kwgFlute) == 1 then
    cabbageSet 1,"flutelight","colour(100, 200, 100)"
    schedulek "fltMachine", 0, iDurMaster
    elseif kwgFlute == 0 && changed(kwgFlute) == 1 then
    cabbageSet 1,"flutelight","colour(80, 50, 50, 255)"
    turnoff2 "fltMachine", 0, 1
    turnoff2 "fluteSound", 0, 0
    endif
 kwgClr ctrl7 10, 61, 0, 1
    if kwgClr == 1 && changed(kwgClr) == 1 then
    cabbageSet 1,"clarinetlight","colour(70, 200, 250)"
    schedulek "clrMachine", 0, iDurMaster
    elseif kwgClr == 0 && changed(kwgClr) == 1 then
    cabbageSet 1,"clarinetlight","colour(80, 50, 50, 255)"
    turnoff2 "clrMachine", 0, 1
    turnoff2 "clarinetSound", 0, 0
    endif
 kwgAmb ctrl7 10, 62, 0, 1
    if kwgAmb == 1 && changed(kwgAmb) == 1 then
    cabbageSet 1,"wgamblight","colour(50, 50, 250)"
    schedulek "ambwgMachine", 0, iDurMaster
    elseif kwgAmb == 0 && changed(kwgAmb) == 1 then
    cabbageSet 1,"wgamblight","colour(80, 50, 50, 255)"
    turnoff2 "ambwgMachine", 0, 1
    turnoff2 "wgAmbSound", 0, 0
    endif
  kAnalog ctrl7 10, 63, 0, 1
    if kAnalog == 1 && changed(kAnalog) == 1 then
    cabbageSet 1,"analoglight","colour(200, 70, 200)"
    schedulek "analogMachine", 0, iDurMaster
    elseif kAnalog == 0 && changed(kAnalog) == 1 then
    cabbageSet 1,"analogblight","colour(80, 50, 50, 255)"
    turnoff2 "analogMachine", 0, 0
    turnoff2 "analogSound", 0, 0
    endif




;;noise
  kNoiseRng   ctrl7     1,0,0,500
    if changed(kNoiseRng) == 1 then
    cabbageSetValue  "noiserng", kNoiseRng
    endif
  kAmpNoise   ctrl7    1,29,0,30
    if changed(kAmpNoise) == 1 then
    cabbageSetValue  "noiseamp", kAmpNoise
    endif  
  kNoisePress   ctrl7     1,21,30,400
    if changed(kNoisePress) == 1 then
    cabbageSetValue  "noisepress", kNoisePress
    endif  
  knFilter   ctrl7     1,33,200,9000
    if changed(knFilter) == 1 then
    cabbageSetValue  "nfilt", knFilter
    endif
    

 ;;wg setting
 kPos   ctrl7    2,31,0.025,2
    if changed(kPos) == 1 then
    cabbageSetValue  "pos", kPos
    endif
    
 kSpeedMin   ctrl7    2,27,0.1,5 
    if changed(kSpeedMin) == 1 then
    cabbageSetValue "spdstrngmin", kSpeedMin
    endif
 kSpeedMax   ctrl7     2,35,0.5,12
    if changed(kSpeedMax) == 1 then
    cabbageSetValue  "spdstrngmax", kSpeedMax
    endif
    
 kwgVib   ctrl7     2,34,0,1
    if changed(kwgVib) == 1 then
    cabbageSetValue  "wgvib", kwgVib ;0, 0.27
    endif
 kwgVibSpd  ctrl7     2,26,0,0.27
    if changed(kwgVibSpd) == 1 then
    cabbageSetValue  "vibSpd", kwgVibSpd ;0, 0.27
    endif
     
  kwgFilter   ctrl7     2,33,500,5000
    if changed(kwgFilter) == 1 then
    cabbageSetValue  "wgfilt", kwgFilter
    endif
    
 kAmpWg   ctrl7    2,29,0,30
    if changed(kAmpWg) == 1 then
    cabbageSetValue  "wgamp", kAmpWg
    endif  


;; morse
kMorseStart cabbageGet "morsestart"
if kMorseStart == 1 && changed(kMorseStart) == 1 then
schedulek "morse", 0, iDurMaster
elseif kMorseStart == 0 && changed(kMorseStart) == 1 then
turnoff2 "morse", 0, 0
turnoff2 "morseLetter", 0, 0
turnoff2 "morseMachine", 0, 0
turnoff2 "morseSound", 0, 0
endif

;schedule "seqMachine", 0, 9999
;schedule "FxSeq", 0, 9999

;schedule "DustMachine", 0, 9999
;schedule "FxDust", 0, 9999
;schedule "noiseSound", 0, 1999

;schedule "wgMachine", 0, 9999
;schedule "FxWg", 0, 9999

endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

