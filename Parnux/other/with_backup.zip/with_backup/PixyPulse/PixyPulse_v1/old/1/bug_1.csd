<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

massign 1, 1




instr 1
gkRel release
iActive active 1
iAmp = 0.1
print p3, iActive
    if p3 == -1 then
    inum notnum
    iFrq mtof inum
    iAtt = 0.1
    iRel = 0.1
    aEnv transegr 0, iAtt, 4, iAmp, iRel, -6, 0
    elseif p3 >= 0 then
    iFrq random 200, 1200
    iAtt = 0.005
    aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
    endif

aSound poscil aEnv, iFrq
outall aSound
endin




instr 2
;	if gkRel == 1 then
schedkwhen metro(1), 0, 0, 1, 0, 0.0001
;endif
endin

schedule 2, 0, 9999


</CsInstruments>
<CsScore>

</CsScore>
</CsoundSynthesizer>




<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>269</width>
 <height>312</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
 <bsbObject version="2" type="BSBButton">
  <objectName>start</objectName>
  <x>169</x>
  <y>282</y>
  <width>100</width>
  <height>30</height>
  <uuid>{e8640a44-09cf-40e8-873d-b67552b46829}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>0</midicc>
  <description/>
  <type>event</type>
  <pressedValue>1.00000000</pressedValue>
  <stringvalue/>
  <text>button0</text>
  <image>/</image>
  <eventLine>i2 0 1</eventLine>
  <latch>false</latch>
  <momentaryMidiButton>false</momentaryMidiButton>
  <latched>false</latched>
  <fontsize>10</fontsize>
 </bsbObject>
</bsbPanel>
<bsbPresets>
</bsbPresets>
