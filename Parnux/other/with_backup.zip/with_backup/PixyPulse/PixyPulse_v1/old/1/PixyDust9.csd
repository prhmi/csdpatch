;v3
<Cabbage>
form caption("PixyDust")    size(1200, 600)   guiMode("queue") colour(45,10,35) pluginId("pxds") ; style("legacy")

vslider bounds(890, 392, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(219, 120, 120, 255) 
vslider bounds(932, 392, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(219, 120, 120, 255)
vslider bounds(972, 392, 50, 150) channel("out3") range(0, 80, 0, 1, 1) trackerColour(219, 120, 120, 255)
vslider bounds(1014, 392, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(219, 120, 120, 255)
nslider bounds(896, 358, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(80, 50, 50, 255)
nslider bounds(936, 358, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(80, 50, 50, 255)
nslider bounds(976, 358, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(80, 50, 50, 255)
nslider bounds(1016, 358, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(80, 50, 50, 255)
nslider bounds(1064, 324, 93, 44) channel("gain") range(-90, 50, 0, 1, 1) colour(80, 50, 50, 255) text("Master Gain (dB)")

label bounds(906, 50, 239, 66) channel("sec") text("00 : 12") fontColour(241, 178, 178, 255)
label bounds(946, 14, 70, 33) channel("data")  fontColour(241, 178, 178, 255) colour(80, 50, 50, 255) text("0")
label bounds(895, 14, 49, 33) channel("datach")  fontColour(241, 178, 178, 255) colour(80, 50, 50, 255) text("0")
button bounds(1026, 18, 116, 27) channel("start") text("S  T  A  R  T", "S  T  O  P")  colour:0(171, 81, 152, 255) colour:1(99, 85, 85, 255) value(1)
image bounds(854, 280, 30, 30) channel("dustlight") corners(5) colour(80, 50, 50, 255)
image bounds(894, 280, 30, 30) channel("seqlight") corners(5) colour(80, 50, 50, 255)
image bounds(932, 280, 30, 30) channel("bowlight") corners(5) colour(80, 50, 50, 255)
image bounds(970, 280, 30, 30) channel("flutelight") corners(5) colour(80, 50, 50, 255)
image bounds(1008, 280, 30, 30) channel("clarinetlight") corners(5) colour(80, 50, 50, 255)
image bounds(1048, 280, 30, 30) channel("wgamblight") corners(5) colour(80, 50, 50, 255)
image bounds(1106, 190, 50, 25) channel("morselight") corners(5) colour(80, 50, 50, 255)
image bounds(1086, 280, 30, 30) channel("analoglight") corners(5) colour(80, 50, 50, 255)
image bounds(1128, 280, 30, 30) channel("suslight") corners(5) colour(80, 50, 50, 255)




label bounds(456, 312, 59, 18) channel("label4") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(456, 356, 59, 18) channel("label5") text("CC-07") fontColour(224, 219, 219, 255)
label bounds(456, 398, 59, 18) channel("label6") text("CC-15") fontColour(224, 219, 219, 255)
label bounds(456, 478, 59, 18) channel("label7") text("CC-14") fontColour(224, 219, 219, 255)
label bounds(456, 438, 59, 18) channel("label8") text("CC-06") fontColour(224, 219, 219, 255)
label bounds(450, 68, 59, 18) channel("label9") text("CC-02") fontColour(224, 219, 219, 255)
label bounds(598, 210, 59, 18) channel("label10") text("CC-01") fontColour(224, 219, 219, 255)
label bounds(654, 210, 59, 18) channel("labes2") text("CC-01") fontColour(224, 219, 219, 255)

label bounds(450, 104, 59, 18) channel("label11") text("CC-11") fontColour(224, 219, 219, 255)
label bounds(458, 518, 59, 18) channel("label12") text("CC-13") fontColour(224, 219, 219, 255)
label bounds(606, 420, 59, 18) channel("label13") text("CC-04") fontColour(224, 219, 219, 255)

label bounds(306, 214, 59, 18) channel("labelm1") text("CC-01s") fontColour(224, 219, 219, 255)
label bounds(382, 216, 59, 18) channel("labelm2") text("CC-16") fontColour(224, 219, 219, 255)
label bounds(16, 206, 139, 32) channel("labelm3") text("Machine") fontColour(224, 219, 219, 255)
label bounds(16, 12, 92, 37) channel("labeln3") text("Dust") fontColour(224, 219, 219, 255)



nslider bounds(302, 234, 72, 53) channel("machinespdmin") range(0.1, 10, 5, 1, 0.1) colour(80, 50, 50, 255)
nslider bounds(376, 234, 81, 52) channel("machinespdmax") range(0.2, 15, 7, 1, 0.1) colour(80, 50, 50, 255) text("spd max")


hslider bounds(44, 302, 406, 40) channel("pos") range(0.025, 2, 1, 1, 0.001) trackerColour(219, 120, 120, 255) text("pos")
hslider bounds(16, 344, 434, 40) channel("spdstrngmin") range(0.1, 5, 2, 1, 0.1) trackerColour(219, 120, 120, 255) text("spd min")
hslider bounds(11, 386, 439, 40) channel("spdstrngmax") range(0.5, 12, 5, 1, 0.1) trackerColour(219, 120, 120, 255) text("spd max")
hslider bounds(49, 428, 402, 40) channel("wgvib") range(0, 1, 0, 1, 0.001) trackerColour(219, 120, 120, 255)  text("vib")
hslider bounds(22, 470, 429, 40) channel("vibSpd") range(0, 0.27, 0.03, 1, 0.001) trackerColour(219, 120, 120, 255) text("vib rng")
hslider bounds(43, 510, 409, 40) channel("wgfilt") range(500, 12000, 700, 1, 1) trackerColour(219, 120, 120, 255) text("Filt")
nslider bounds(520, 302, 72, 35) channel("poss") range(0.025, 2, 1, 1, 0.001) colour(80, 50, 50, 255)
nslider bounds(520, 346, 72, 35) channel("spdstrngmins") range(0.1, 5, 2, 1, 0.1) colour(80, 50, 50, 255)
nslider bounds(520, 388, 72, 35) channel("spdstrngmaxs") range(0.5, 12, 5, 1, 0.1) colour(80, 50, 50, 255)
nslider bounds(520, 428, 72, 35) channel("wgvibs") range(0, 1, 0, 1, 0.001) colour(80, 50, 50, 255)
nslider bounds(520, 468, 72, 35) channel("vibSpds") range(0, 0.27, 0.03, 1, 0.001) colour(80, 50, 50, 255)
nslider bounds(520, 508, 72, 35) channel("wgfilts") range(500, 12000, 700, 1, 1) colour(80, 50, 50, 255)

nslider bounds(604, 374, 64, 42) channel("wgcent") range(0, 500, 0, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("wgCent")
label bounds(526, 190, 59, 18) channel("label25") text("CC-00") fontColour(224, 219, 219, 255)
nslider bounds(524, 138, 64, 42) channel("noiserng") range(0, 1200, 50, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("nRng")

vslider bounds(692, 384, 50, 150) channel("wgamp") range(0, 30, 25, 1, 1) trackerColour(219, 120, 120, 255) text("wgAmp")
vslider bounds(604, 56, 50, 150) channel("noiseamp") range(0, 30, 20, 1, 1) trackerColour(219, 120, 120, 255) text("nAmp")
vslider bounds(658, 56, 50, 150) channel("seqamp") range(0, 30, 20, 1, 1) trackerColour(219, 120, 120, 255) text("sAmp")

label bounds(686, 538, 59, 18) channel("labelw10") text("CC-09") fontColour(224, 219, 219, 255)
hslider bounds(40, 96, 396, 40) channel("nfilt") range(200, 9000, 700, 1, 1) trackerColour(219, 120, 120, 255) text("Filt")
hslider bounds(40, 56, 395, 40) channel("noisepress") range(30, 400, 30, 1, 1) trackerColour(219, 120, 120, 255) text("nPres")
nslider bounds(520, 56, 72, 35) channel("noisepresss") range(30, 400, 30, 1, 1) colour(80, 50, 50, 255)
nslider bounds(520, 96, 72, 35) channel("nfilts") range(200, 9000, 700, 1, 1) colour(80, 50, 50, 255)

checkbox bounds(830, 96, 30, 30) channel("morsestart") colour:0(111, 103, 103, 255) colour:1(0, 255, 154, 255)
checkbox bounds(796, 96, 25, 25) channel("morsesine") colour:0(111, 103, 103, 255) colour:1(0, 255, 154, 255) 
checkbox bounds(868, 96, 25, 25) channel("morsenoise") colour:0(111, 103, 103, 255) colour:1(0, 255, 154, 255) value(0)
label bounds(795, 68, 27, 22) channel("labelmorse1") text("S")
label bounds(867, 68, 27, 22) channel("labelmorse2") text("N")

texteditor bounds(791, 134, 364, 40) channel("morsetxt") colour(180, 140, 250, 200) colour:0(200, 170, 200, 200)fontSize(26) text("some one")
nslider bounds(796, 182, 70, 44) channel("morsebpm") range(30, 200, 124, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("Tempo")
nslider bounds(868, 182, 68, 43) channel("morsefrq") range(200, 2000, 1200, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("Frq")
nslider bounds(940, 182, 68, 43) channel("morseamp") range(-90, -15, -22, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("Amp")
nslider bounds(1010, 182, 68, 43) channel("morsefilt") range(500, 9000, 5000, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("Frq")
nslider bounds(606, 446, 65, 44) channel("wgfrq") colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) range(10, 900, 70, 1, 1) text("wgFrq")
checkbox bounds(610, 496, 25, 25) channel("wgrndf") colour:0(111, 103, 103, 255) colour:1(0, 255, 154, 255) value(1)
label bounds(636, 500, 50, 16) channel("labelwg1") text("RndF")

vmeter bounds(1068, 392, 15, 150) channel("meter1")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1092, 392, 15, 150) channel("meter2")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1116, 392, 15, 150) channel("meter3")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1140, 392, 15, 150) channel("meter4")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
image bounds(1068, 378, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(1092, 378, 15, 15) channel("clip2") colour(0, 0, 0, 255)
image bounds(1116, 378, 15, 15) channel("clip3") colour(0, 0, 0, 255)
image bounds(1140, 378, 15, 15) channel("clip4") colour(0, 0, 0, 255)

</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null; -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0


opcode CsdMeter, 0, SakS
 SClip, aSig, kTrig, Smeter	xin
 iDbRange = 60 ;shows 60 dB
 iHoldTim = 0.5;seconds to "hold the red light"
 kOn init 0
 kTim init 0
 kStart init 0
 kEnd init 0
 kMax max_k aSig, kTrig, 1
 cabbageSetValue Smeter, kMax, metro(20)
 
 if kTrig == 1 then
 kMeter = (iDbRange + dbfsamp(kMax)) / iDbRange
  if kOn == 0 && kMax > 1 then
   kTim = 0
   kEnd = iHoldTim
   cabbageSet 1,SClip,"colour(250,0, 0)"
   kOn = 1
  endif
  if kOn == 1 && kTim > kEnd then
   cabbageSet 1,SClip,"colour(0,0,0)"
   kOn =	0
  endif
 endif
 kTim += ksmps/sr
endop

opcode limiter, a,ai
aIn, idB xin

xout aIn
endop



massign 1,1
massign 3,18
massign 5,19
massign 7,20
massign 8,21
massign 10,22

massign 2,31
massign 4,31
massign 6,31
massign 9,31
massign 11,31
massign 12,31
massign 13,31
massign 14,31
massign 15,31
massign 16,32



instr noisePlay
 kAmpdBIn cabbageGet "noiseamp"
 kAmpdB ampdb kAmpdBIn-25
 kPortTime linseg 0, 0.01, 0.1
 kAmpdB portk kAmpdB, kPortTime
 iAtt random 0.2, 0.5
 iRel random 0.2, 0.5
 aEnv linsegr 0, iAtt, 1, iRel, 0
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
 iDelayTime  random 0.1, 0.25
 kFb cabbageGet "noisepress"
 aNoise noise 1, 0.5
 aNoise = aNoise*5
 aFb init 1
 aNoise = (aNoise*kFb)+aFb
    aSine poscil 1, aNoise
    aPhas phasor aNoise
    aSum sum aSine, aPhas
    aFb delay aSum, iDelayTime
 iMidi notnum
 if p3 != -1 then
 iMidi random 40, 80
 aEnv linseg 0, iAtt, 1, p3-iAtt, 0
 endif
 iFrq mtof iMidi
 kRngIn cabbageGet "noiserng"
 kRng = cent(kRngIn)-1
 kFilterMin = (iFrq*(1-kRng))*2
    if kFilterMin <= 200 then
    kFilterMin = 200
    endif
 kFilterMax = (iFrq*(1+kRng))*2
    if kFilterMax >= 12000 then
    kFilterMax = 12000
    endif
 kFilt cabbageGet "nfilt"
 aFilt clfilt aFb, kFilterMax+kFilt, 0, 10
 aFilt  clfilt aFilt, kFilterMin, 1, 10
 aOut = aFilt*kAmpdB*aEnv*ampdb(-10)
 ;outall aOut
 chnmix aOut, "snddust"
endin



instr dustMachine
 kTimeG init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 kFrq init 7000
 if metro(kTimeG) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 3))
 	kSeqValue random 1/3, 1/2
 	trim kSeqArr, kLen
 		kIndx = 0
 		while kIndx < kLen-1 do
		kRndSeq random 0, 0.2
 		kSeqArr[kIndx] = kSeqValue+kRndSeq
 		kIndx += 1
 		od
 	kMaxValue random 1/7, 1/15
 	kSeqArr[kLen-1] = kMaxValue
 	kFrq random 1000, 9000
 	kLoop random 2, 4
 	endif 
 kLenOut random 1, 7
 kDur random 0.5, 3
 schedulek "guiroPlay", 0, 1, kFrq, kLoop,kLenOut
 	kIndx = 0
 	kFrq2 random 1000, 9000 
 	kNumber random 1, 6
 	while kIndx < int(kNumber) do
 	kStart random 1, 7
 	schedulek "guiroSound", kStart, 1, kFrq2, kLoop
 	kIndx += 1
 	od
 kTimeG = kSeqArr[kIndxSeq]
    if kIndxSeq == 0 then
    kDurNoise = 1/kMaxValue
    kDurDust random 1, 2
    schedulek "noiseSound", 0, kDurNoise*1.5
    schedulek "noisePlay", 0.1, kDurDust
    endif
 kIndxSeq = (kIndxSeq+1) % kLen
 endif
endin

instr noiseSound
 iAmpdB ampdb -10
 aNoise noise 1, 0.5
 aEnv linseg 0, p3/2, 1, p3/2, 0
 iFrq random 100, 400
 kRngIn cabbageGet "noiserng"
 kRng = cent(kRngIn)-1
 kFilterMin = (iFrq*(1-kRng))*2
    if kFilterMin <= 200 then
    kFilterMin = 200
    endif
 kFilterMax = (iFrq*(1+kRng))*2
    if kFilterMax >= 12000 then
    kFilterMax = 12000
    endif
 aFilt  clfilt aNoise, kFilterMax, 0, 10
 aFilt  clfilt aFilt, kFilterMin, 1, 10 
 aOut = aFilt*iAmpdB*aEnv
 chnmix aOut, "snddust"
endin




instr guiroPlay
 iFrq = p4
 iLoop = p5
 iLen = int(p6)
 indx = 0
 iStart = 0
 while indx < iLen do
 schedule "guiroSound", iStart, 1,iFrq,iLoop
 iStart += 0.175
 indx += 1
 od
endin

instr guiroSound
 kDustMachine ctrl7 10, 57, 0, 1
    if kDustMachine == 0 then
    turnoff
    endif
 iFrqIn = p4
 iFrq random iFrqIn, iFrqIn*1.01
 iAmp ampdb -15
 aSound  guiro iAmp, 0, 128, 0, 0, iFrq, iFrq*2
 iLoopDur = p5
 iLoop random 0.1, 0.4
 aComb comb aSound, iLoopDur, iLoop
 iFrqRnd random 0, 100
 iRel = 0.1
 ;aRel transegr 1, iRel, -6, 0
 aRes reson aSound, iFrq*1.1+iFrqRnd, 200
 chnmix aComb, "snddust"
 ;outall aSound
endin


instr seqMachine
 SinstrArr[] fillarray "sineSound", "barSound", "bamSound", "shakeSound", "pluckSound", "bangSound"
 kTime init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 if metro(1/kTime) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 12))
 	trim kSeqArr, kLen
 		kIndx = 0 
 		while kIndx < kLen-1 do
 		kSeqValue random 1, 3
 		kSeqArr[kIndx] = kSeqValue
 		kIndx += 1
 		od
 	kMaxValue random 15, 20
 	kSeqArr[kLen-1] = kMaxValue
 	endif 
 kInstr = int(random:k(0,lenarray(SinstrArr)))
 Sinstr = SinstrArr[5]
    if kIndxSeq == kLen-2 then
    kMod = 1
    else
    kMod = 0
    endif
 schedulek Sinstr, 0, kTime,kMod
 kIndxSeq = (kIndxSeq+1) % kLen
 kTime = kSeqArr[kIndxSeq]/10
 endif
endin

instr sineSound
 isAmp cabbageGetValue "seqamp"
 iAmp ampdb -15
 iFrq random 200, 1200
 iAtt = 0.005
 iMod = p4 
    if iMod == 0 then
    aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
    elseif iMod == 1 then
    aEnv linseg 0, iAtt, iAmp, p3-(iAtt*2), iAmp, iAtt, 0
    endif
 aSound poscil aEnv, iFrq
 aOut = aSound*ampdb(isAmp-20)
 chnmix aSound, "sndseq"
 ;outall aSound
endin

instr barSound
    giDelayTime random 0.1, 1
    giFeedback random 0.1, 0.5
 p3 random 2, 5
 isAmp cabbageGetValue "seqamp"
 iMod = int(random:i(1, 6))
 iFrq random 10, 200
    if iMod == 1 then
    iDur1 = 0.077
    iscan  = 0.175
    iDur2 = 20
    aRing poscil 1, iFrq
    elseif iMod == 2 then
    iDur1 = 0.4
    iscan  = 70
    iDur2 =  1
    aRing init 1
    elseif iMod == 3 then
    iDur1 random 0.1, 0.7
    iscan  random 50, 70
    iDur2 random 1, 10
    aRing poscil 1, iFrq
    elseif iMod == 4 then
    iDur1 = 1
    iscan = 0.008
    iDur2 random 0.1, 1
    aRing init 1
    elseif iMod == 5 then
    iDur1 = 0.077
    iscan  random 30, 50
    iDur2 random 0.1, 20
    aRing init 1
    endif
 iK = 125
 ipos =  0.837 
 ivel = 18000
 iwid = 0.016
 aSound 	barmodel 	1, 1, iK, iDur1, iscan,   iDur2, ipos, ivel, iwid
 aOut = aSound*aRing*ampdb(isAmp-20)
 chnmix aOut, "sndseq"
endin

instr bamSound
    giDelayTime random 0.1, 1
    giFeedback random 0.1, 0.5
 isAmp cabbageGetValue "seqamp"
 p3 random 0.05, 1
 iAmpdB ampdb -15
 iFrq random 400, 500
 iFilter random 3000, 4000
 iAtt = 0.1
 aEnv transeg 0, iAtt, 6, 1, p3-iAtt, -6, 0
 iAmp = 1000
 iNumber random 0.4, 5
 iDamp = 0.1 ;random 0.0001, 0.05
 iDecay = 0.1 ;random 0.001, 0.1
 aSound  bamboo iAmp, iDecay, iNumber, iDamp, 1, iFrq, 20
 aFilt clfilt aSound, iFilter, 1, 10
 aClip clip aFilt, ampdb(-10), 2
 aOut = aClip*aEnv*iAmpdB*ampdb(isAmp-20)
 chnmix aOut, "sndseq"
endin


instr shakeSound
    giDelayTime random 0.1, 1
    giFeedback random 0.1, 0.5
 isAmp cabbageGetValue "seqamp"
 p3 random 0.05, 0.5
 iRel random 0.1, 1
 aEnv linsegr 1, iRel, 0
 knum  rspline 2, 15, 2, 7
 kFrq rspline 700, 3000, 2, 15
 asig shaker .05, kFrq, 8, 0.9, knum
 iFilter random 300, 1200
 aFilt clfilt asig*aEnv, iFilter, 1, 10	
 aOut = aFilt*ampdb(isAmp-20)	
 chnmix aFilt, "sndseq"
endin


instr pluckSound
    giDelayTime random 0.1, 1
    giFeedback random 0.1, 0.5
    giRvrbTime random 0.7, 0.9
 isAmp cabbageGetValue "seqamp"
 iAmp ampdb -15
 iAtt random 0.008, 0.01
 iRel random 0.1, 1
 aEnv linsegr 0, iAtt, 1, iRel, 0
 iFrq random 30, 1500
 iResample random 20, 1500
 iMeth = random:i(0, 100) < 50 ? 1 : 6
 aSound  pluck iAmp, iFrq, iResample, 0, iMeth;, 2, 1
 iFilter random 300, 1500
 aFilt clfilt aSound*aEnv, iFilter, 0, 10	
 aFilt clfilt aSound*aEnv, 200, 1, 10
 aOut = aFilt*ampdb(isAmp-20)	
 chnmix aOut, "sndseq"
endin


 
 giwave1 ftgen 0, 0, 131073, 9, 1000,1.000,0,     1002,0.833,0, \
					    1794,0.694,0,     1801,0.579,0,     2520,0.482,0,    \
					    2522,0.402,0,     2991,0.335,0,     2994,0.279,0,     \
					    3786,0.233,0,     3806,0.194,0,     4569,0.162,0,     \
					    4575,0.135,0,     5030,0.112,0,     5046,0.093,0,     \
					    6076,0.078,0,     5909,0.065,0,     6412,0.054,0,     \
					    6443,0.045,0,     7083,0.038,0,     7092,0.031,0,     \
					    7319,0.026,0,     7555,0.022,0
 giwave2 ftgen 0, 0, 131073, 9, 1000,1.000,0,     1027,1.000,0,\
					     1422,1.000,0,     1448,1.000,0,     1466,1.000,0,     \
					     1499,1.000,0,     1789,1.000,0,     1877,1.000,0,     \
					     1965,1.000,0,     1979,1.000,0,     2033,1.000,0,     \
					     2145,1.000,0,     2156,1.000,0,     2253,1.000,0,     \
					     2291,1.000,0,     2333,1.000,0,     2457,1.000,0,     \
					     2493,1.000,0,     2566,1.000,0,     2606,1.000,0,     \
					     2669,1.000,0,     2714,1.000,0
 giSine ftgen 0, 0, 2^12, 10, 1 					
instr bangSound
 isAmp cabbageGetValue "seqamp"
 iAmp ampdb -20
 iFrq random 70, 700
 iAtt = 0.003
 p3 random 0.3, 2
 aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
    iwave = random:i(0, 100) > 50 ? giwave1 : giwave2
 aSound poscil3 aEnv, iFrq/1000,iwave
 ;Bass
 iAmpBass ampdb -15
 aEnvBass transeg 0, 0.01, 6, iAmpBass, p3*0.3, -6, 0     
 iFrqBass random 100, 200
 kGliss        linseg       iFrqBass,p3/2,iFrqBass*0.7
 aBass        oscil       aEnvBass,kGliss,giSine
 ;Snare 
 iAmpSnare ampdb -15
 aEnvSnare        expon      iAmpSnare, 0.3, 0.001   
 aNse        noise      1, 0 
 iRndFilter random 7000, 8000
 aNseFilter clfilt aNse, iRndFilter*1.1, 0, 10   
 aNseFilter clfilt aNseFilter, iRndFilter*0.9, 1, 10              
 iCps        exprand    20                     
 kCps        expon      250 + iCps,0.3, 200+iCps
 aJit        randomi    0.2, 1.8, 10000         
 aTne        oscil      aEnvSnare, kCps, giSine       
 aSnare = aTne*aNseFilter
 aOut sum aSound,aBass, aSnare
 aOutv = aOut*ampdb(isAmp-20)
 chnmix aOutv, "sndseq"
endin

 gkMidiBow init 0
instr bowMachine
 cabbageSet 1,"bowlight","colour(200, 150, 100)"
 
 kSpeedMin cabbageGet "machinespdmin"
 kSpeedMax cabbageGet "machinespdmax"
    if gkMidiBow == 1 then
    turnoff
    elseif gkMidiBow == 0 then
        kTimeBow init 1
        if metro(1/kTimeBow) == 1 then
        kTimeBow random kSpeedMin, kSpeedMax
        kDurBow = kTimeBow*1.3
        schedulek "bowSound", 0, kDurBow
        endif
    endif
endin

 gkMidiFlt init 0
instr fltMachine
    if gkMidiFlt == 1 then
    turnoff
    elseif gkMidiFlt == 0 then
    cabbageSet 1,"flutelight","colour(100, 200, 100)"
        kTimeFlute init 1
        if metro(1/kTimeFlute) == 1 then
        kTimeFlute random 5, 7
        kDurFlute = kTimeFlute*1.3
        schedulek "fluteSound", 0, kDurFlute
        endif
    endif
endin

 gkMidiClr init 0
instr clrMachine
 cabbageSet 1,"clarinetlight","colour(70, 200, 250)"
    if gkMidiClr == 1 then
    turnoff
    elseif gkMidiClr == 0 then
        kTimeClr init 1
        if metro(1/kTimeClr) == 1 then
        kTimeClr random 5, 7
        kDurClr = kTimeClr*1.3
        schedulek "clarinetSound", 0, kDurClr
        endif
    endif
endin

 gkMidiAmb init 0
instr ambwgMachine
    if gkMidiAmb == 1 then
    turnoff
    elseif gkMidiAmb == 0 then
    cabbageSet 1,"wgamblight","colour(50, 50, 250)"
        kTimeAmbWg init 1
        if metro(1/kTimeAmbWg) == 1 then
        kTimeAmbWg random 5, 7
        kDurAmbWg = kTimeAmbWg*1.3
        schedulek "wgAmbSound", 0, kDurAmbWg
        endif
    endif
endin


 gkMidiAnalog init 0
instr analogMachine
    if gkMidiAnalog == 1 then
    turnoff
    elseif gkMidiAnalog == 0 then
    cabbageSet 1,"analoglight","colour(200, 70, 200)"
        kTime init 1
        if metro(1/kTime) == 1 then
        kTime random 5, 7
        kDur = kTime*1.3
        kMidi = int(random:k(50, 60))
        kLen random 1, 3
            kIndx = 0
            while kIndx < int(kLen) do
            kStart random 0, 3
            schedulek "analogSound", kStart, kDur, kMidi
            kRndInterval random 7, 24
            kMidi += int(kRndInterval)
            kIndx += 1
            od
        endif
    endif
endin

instr bowSound
 iActive active "bowMachine"
    if p3 == -1 && iActive >= 1 then
    turnoff
    endif
 kGainIn cabbageGet "wgamp"
 kGain ampdb kGainIn-20
 aGain interp kGain
 iRndFrq cabbageGetValue "wgrndf"
    if iRndFrq == 1 then
    iFrqRndOut random 20, 500
    cabbageSetValue "wgfrq",iFrqRndOut
    endif
 iFrqMin cabbageGetValue "wgfrq"
; print iFrqMin, iFrqRndOut
    if p3 == -1 && iActive == 0 then
    cabbageSet 1, "bowlight", "colour(200, 150, 100)"
    gkMidiBow = 1
    iMidi notnum
        if iMidi <= 7 then
        turnoff
        endif
    iFrq mtof iMidi
    iAtt = 1
    iRel = 1
    aEnv linsegr 0, iAtt, 1, iRel, 0
    aEnvR init 1
        kRelease release
        if kRelease == 1 then
        gkMidiBow = 0
        cabbageSet 1,"bowlight","colour(80, 50, 50, 255)"
        endif
    elseif p3 >= 0 then
    iFrq random 80, 400
    aEnv linseg 0, p3/2, 1, p3/2, 0
    aEnvR linsegr 1, 0.1, 0
    endif
 iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
 kVibIn cabbageGet "wgvib"
 kVibRng cabbageGet "vibSpd"
 kPosIn cabbageGet "pos"
 kPortTime linseg 0, 0.01, 0.1
 kPosIn portk kPosIn, kPortTime
 kAmp   rspline  0.2, 0.4, 0.7, 1
 kCent cabbageGet "wgcent"
 kCentFrq    jspline  kCent, kSpeedMin, kSpeedMax
 kFrq = iFrq*cent(kCentFrq)
 kPresIn cabbageGet "pres"
 kPres  rspline  3, 4, kSpeedMin, kSpeedMax
 kRate   rspline 0.025, kPosIn, kSpeedMin, kSpeedMax
 kVib   jspline  kVibIn, kSpeedMin, kSpeedMax
 aBow	wgbow    kAmp,kFrq,kPres,kRate,kVib,kVibRng/10,iWave, iFrqMin
 kFilterBow cabbageGet "wgfilt"
 aFiltBow clfilt aBow, kFilterBow, 0, 10
 aFiltBow clfilt aFiltBow, 150, 1, 10
 aOut = aFiltBow*aGain*aEnv*aEnvR
 ;outall aOut
 chnmix aOut, "sndwg"
endin



instr fluteSound
 iActive active "fltMachine"
    if p3 == -1 && iActive >= 1 then
    turnoff
    endif
 kGainIn cabbageGet "wgamp"
 kGain ampdb kGainIn-20
 aGain interp kGain
 iRndFrq cabbageGetValue "wgrndf"
    if iRndFrq == 1 then
    iFrqRndOut random 30, 120
    cabbageSetValue "wgfrq",iFrqRndOut
    endif
 iFrqMin cabbageGetValue "wgfrq"
    if p3 == -1 && iActive == 0 then
    cabbageSet 1,"flutelight","colour(100, 200, 100)"
    gkMidiFlt = 1
    iMidi notnum
        if iMidi <= 7 then
        turnoff
        endif
    iAtt = 1
    iRel = 1
    aEnv linsegr 0, iAtt, 1, iRel, 0
    aEnvR init 1
    iFrq mtof iMidi
        kRelease release
        if kRelease == 1 then
        cabbageSet 1,"flutelight","colour(80, 50, 50, 255)"
        gkMidiFlt = 0
        endif
    elseif p3 >= 0 then
    aEnv linseg 0, p3/2, 1, p3/2, 0
    aEnvR linsegr 1, 0.1, 0
 	iFrq random 100, 500
    endif
 iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
 kVibIn cabbageGet "wgvib"
 kAmp rspline  0.2, 0.3, 0.7, 1
 kJetMaxIn cabbageGet "pos"
 kJetMax = kJetMaxIn*0.3
    if kJetMax <= 0.01 then
    kJetMax = 0.01
    endif
 kJet rspline 0.01, kJetMax, kSpeedMin, kSpeedMax
 kVib   jspline  kVibIn/1000, kSpeedMin, kSpeedMax
 kVibRng cabbageGet "vibSpd"
 kAirSound rspline 0, 0.05, kSpeedMin, kSpeedMax
 kCent cabbageGet "wgcent"
 kGliss jspline kCent, kSpeedMin, kSpeedMax
 kFrq = iFrq*cent(kGliss)
 iAtt = 0.1
 iDecay = 0.2
 aFlute  wgflute kAmp*0.6, kFrq, kJet, iAtt, iDecay, kAirSound, kVib, kVibRng*0.00001, iWave,iFrqMin
 kFilterFlute cabbageGet "wgfilt"
 aFiltFlute clfilt aFlute, kFilterFlute, 0, 10
 aFiltFlute clfilt aFiltFlute, 250, 1, 10
 aOut = aFiltFlute*aGain*aEnv*aEnvR
 chnmix aOut, "sndwg"
endin



instr clarinetSound
 iActive active "clrMachine"
    if p3 == -1 && iActive >= 1 then
    turnoff
    endif
 kGainIn cabbageGet "wgamp"
 kGain ampdb kGainIn-20
 aGain interp kGain
 iRndFrq cabbageGetValue "wgrndf"
    if iRndFrq == 1 then
    iFrqRndOut random 30, 120
    cabbageSetValue "wgfrq",iFrqRndOut
    endif
 iFrqMin cabbageGetValue "wgfrq"
    if p3 == -1 && iActive == 0 then
    cabbageSet 1,"clarinetlight","colour(70, 200, 250)"
    gkMidiClr = 1
    iMidi notnum
        if iMidi <= 7 then
        turnoff
        endif
    iAtt = 1
    iRel = 1
    aEnv linsegr 0, iAtt, 1, iRel, 0
    aEnvR init 1
    iFrq mtof iMidi
        kRelease release
        if kRelease == 1 then
        gkMidiClr = 0
        cabbageSet 1,"clarinetlight","colour(80, 50, 50, 255)"
        endif
    elseif p3 >= 0 then
    aEnv linseg 0, p3/2, 1, p3/2, 0
    aEnvR linsegr 1, 0.1, 0
 	iFrq random 100, 700
    endif
 iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
 kVibIn cabbageGet "wgvib"
 kVibRng cabbageGet "vibSpd"
 kAmp rspline  0.2, 0.3, 0.7, 1
 kCent cabbageGet "wgcent" 
 kGliss jspline kCent, kSpeedMin, kSpeedMax
 kFrq = iFrq*cent(kGliss)
 kStiff rspline -0.4, -0.18, kSpeedMin, kSpeedMax
 iAtt1 = 1.2
 iDetk = 0.1
 kAir cabbageGet "pos"
 kAirNoise rspline 0, kAir, kSpeedMin, kSpeedMax
 kVibClr jspline kVibIn*5, kSpeedMin, kSpeedMax
 kvAmpClr rspline kVibRng, kVibRng*3, kSpeedMin, kSpeedMax
 aClar wgclar kAmp*0.7, kFrq, kStiff, iAtt1, iDetk, \
 kAirNoise, kVibClr, kVibRng, iWave, iFrqMin
 kFilterClr cabbageGet "wgfilt"
 aFiltClr clfilt aClar, kFilterClr, 0, 10
 aFiltClr clfilt aFiltClr, 250, 1, 10
 aOut = aFiltClr*aGain*aEnv
 chnmix aOut, "sndwg"
 ;outall aFiltClr
endin




instr wgAmbSound
 iActive active "ambwgMachine"
    if p3 == -1 && iActive == 1 then
    turnoff
    endif
 kGainIn cabbageGet "wgamp"
 kGain ampdb kGainIn-20
 aGain interp kGain
 iFrqMin cabbageGetValue "wgfrq"
    if p3 == -1 && iActive == 0 then
    cabbageSet 1,"wgamblight","colour(50, 50, 250)"
    gkMidiAmb = 1
    iMidi notnum
        if iMidi <= 7 then
        turnoff
        endif
    iAtt = 1
    iRel = 1
    aEnv linsegr 0, iAtt, 1, iRel, 0
    aEnvR init 1
    iFrqBwIn mtof iMidi
    iRndNote = int(random:i(-2,2))
    iFrqClrIn = iFrqBwIn ;iMidi+iRndNote
        kRelease release
        if kRelease == 1 then
        cabbageSet 1,"wgamblight","colour(80, 50, 50, 255)"
        gkMidiAmb = 0
        endif
    elseif p3 >= 0 then
    aEnv linseg 0, p3/2, 1, p3/2, 0
    aEnvR linsegr 1, 0.1, 0
    iFrqBwIn random 200, 800
    iCentClr = (int(random:i(-5, 5)))*50
    iFrqClrIn = iFrqBwIn*cent(iCentClr)
    endif
 iGainClr ampdb -10
 iGainBw ampdb -7
 iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
 kCent cabbageGet "wgcent"
 kVibIn cabbageGet "wgvib"
 kVibRng cabbageGet "vibSpd"
 kPosIn cabbageGet "pos"
; print iFrqClrIn
    ;;clr
    kAmpClr rspline  0.2, 0.4, 0.7, 1 
	kFrqClr = iFrqClrIn
    kStiff rspline -0.4, -0.18, kSpeedMin, kSpeedMax
    iAtt1 = 1.2
    iDetk = 0.1
    kAirNoise rspline 0, 0.1, 0.4, 2
    kVibClr jspline kVibIn*50, 0.4, 2
    kVibMin = abs:k(log:k(kSpeedMin*10))
    kVibMax = abs:k(log:k(kSpeedMax*10))
    kvAmpClr rspline kSpeedMin/10, kSpeedMax/10, 1, 3
    aClar wgclar kAmpClr*iGainClr, kFrqClr, kStiff, iAtt1, iDetk, \
    kAirNoise, kVibClr, kvAmpClr, iWave, iFrqMin
    idBClip ampdb -7
    aClar clip aClar, 1, idBClip, 0.1
    ;;bow
    kAmpBw rspline  0.2, 0.4, 0.7, 1
    kPos = kPosIn*10
        if kPos <= 0.1 then
        kPos = 0.1
        endif
    kPres rspline 0.01, kPos, kSpeedMin*2, kSpeedMax*2
	kRate rspline 0.025, 0.225, kSpeedMin*3, kSpeedMax*3
	kVibBw jspline kVibRng, 0.9, 1
	kvAmpBw = 0.02
	kFrqCent2 jspline kCent, kSpeedMin, kSpeedMax*0.8
	kFrqBw = iFrqBwIn*cent(kFrqCent2)
    aBow  wgbow kAmpBw*iGainBw, kFrqBw, kPres, kRate, kVibBw, kvAmpBw,\
    iWave, iFrqMin
   ;;output
    aSum   sum aBow, aClar
    kFilterIn cabbageGet "wgfilt"
    kFilt rspline kFilterIn*0.9, kFilterIn*1.1, 0.4, 0.7
    aFilt clfilt aSum, kFilt, 0, 10
    aFilt clfilt aFilt, 150, 1, 10
    aDel delay aFilt, 0.4
    aMix ntrpol aFilt, aDel, 0.3  
    aOut = aMix*aGain*aEnv*aEnvR
    chnmix aOut, "sndwg"
;   outall aClar
endin




instr analogSound
 iActive active "analogMachine"
    if p3 == -1 && iActive == 1 then
    turnoff
    endif  
 kAnalog ctrl7 10, 63, 0, 1
 kGainIn cabbageGet "wgamp"
 kGain ampdb kGainIn-25
 aGain interp kGain
    if p3 == -1 && iActive == 0 then
    gkMidiAnalog = 1
    iMidi notnum
        if iMidi <= 7 then
        turnoff
        endif
    iFrq mtof iMidi
    iAtt random 1, 2
    iRel random 1, 1
    aEnv linsegr 0, iAtt, 1, iRel, 0
    aEnvR init 1
    cabbageSet 1,"analoglight","colour(200, 70, 200)"
        kRelease release
        if kRelease == 1 then
        gkMidiAnalog = 0
        cabbageSet 1,"analoglight","colour(80, 50, 50, 255))"
        endif
    elseif p3 >= 0 then
        if kAnalog == 0 then
        turnoff
        endif
    iMidi = p4
    iFrq mtof iMidi
    aEnv linseg 0, p3/2, 1, p3/2, 0
    aEnvR linsegr 1, 0.01, 0
    endif
 kCent cabbageGet "wgcent"
 kFilterIn cabbageGet "wgfilt"
 
 kFmAmp cabbageGet "pos"
 kFrqFMMin cabbageGet "vib"
 kFrqFMMax cabbageGet "vibSpd"
 kSpeedMin cabbageGet "spdstrngmin"
 kSpeedMax cabbageGet "spdstrngmax"
 iWave  	  	 ftgen		0, 0, 2^10,10,1, 0.5, 0.3
 kAmp1    rspline  0.1, 0.2, 0.7, 1
 kAmp2    rspline  0.1, 0.2, 0.7, 1
 kAmp3    rspline  0.1, 0.2, 0.7, 1
 kAmp4    rspline  0.1, 0.2, 0.7, 1
 kFrqRnd2 jspline  100, kSpeedMin, kSpeedMax
 kFrqRnd3 jspline  100, kSpeedMin, kSpeedMax
 kFrqRnd4 jspline  100, kSpeedMin, kSpeedMax
 kFrq     rspline  iFrq, iFrq*cent(kCent), kSpeedMin,kSpeedMax
 kFmFrq rspline kFrqFMMin*1000, kFrqFMMax*1000, kSpeedMin, kSpeedMax
 aFM poscil kFmAmp*50, kFmFrq
 aSound1 poscil kAmp1, kFrq+aFM, iWave
 aSound2 poscil kAmp2*0.5, iFrq+kFrqRnd2
 aSound3 poscil kAmp3*0.4, iFrq+kFrqRnd3
 aSound4 poscil kAmp4*0.3, iFrq+kFrqRnd4
 aSound sum aSound1,aSound2,aSound3,aSound4
 kFilter rspline kFilterIn*0.9, kFilterIn*1.1, 2, 3
 aFilt clfilt aSound, kFilter, 0, 10
 aFilt clfilt aFilt, 250, 1, 10
 aOut = aFilt*aEnv*aEnvR*aGain
 ;outall aOut
 chnmix aOut, "sndwg"
endin




 ;;morse
 gkMorse init 0
instr morse
    if gkMorse == 0 then
    cabbageSet 1,"morselight","colour(80, 50, 50, 255)"
    elseif gkMorse == 1 then
    cabbageSet 1,"morselight","colour(70, 200, 100)"
    endif
 Stype cabbageGet "morsetxt"
 puts Stype,1
    if changed(Stype) == 1 && gkMorse == 0 then
    schedulek "morseR", 0, 1, Stype
    schedulek "morseLetter", 0.1, 1
    endif
endin

instr morseR
 gkMorse = 1
 giIndx init 0
 index = 0
 Stype = p4
 iLen       strlen     Stype 
 giLen = iLen
 giTypeArr[] init iLen	
 while index < iLen do
 ichr       strchar    Stype, index
 giTypeArr[index]  = ichr
 index += 1
 od
endin

instr morseLetter
 iChar = giTypeArr[giIndx]
 iMorseArr_A[] fillarray 1,2
 iMorseArr_B[] fillarray 2,1,1,1
 iMorseArr_C[] fillarray 2,1,2,1
 iMorseArr_D[] fillarray 2,1,1
 iMorseArr_E[] fillarray 1
 iMorseArr_F[] fillarray 1,1,2,1
 iMorseArr_G[] fillarray 2,2,1
 iMorseArr_H[] fillarray 1,1,1,1
 iMorseArr_I[] fillarray 1,1
 iMorseArr_J[] fillarray 1,2,2,2
 iMorseArr_K[] fillarray 2,1,2
 iMorseArr_L[] fillarray 1,2,1,1
 iMorseArr_M[] fillarray 2,2
 iMorseArr_N[] fillarray 2,1
 iMorseArr_O[] fillarray 2,2,2
 iMorseArr_P[] fillarray 1,2,2,1
 iMorseArr_Q[] fillarray 2,2,1,2
 iMorseArr_R[] fillarray 1,2,1
 iMorseArr_S[] fillarray 1,1,1
 iMorseArr_T[] fillarray 2
 iMorseArr_U[] fillarray 1,1,2
 iMorseArr_V[] fillarray 1,1,1,2
 iMorseArr_W[] fillarray 1,2,2
 iMorseArr_X[] fillarray 2,1,1,2
 iMorseArr_Y[] fillarray 2,1,2,2
 iMorseArr_Z[] fillarray 2,2,1,1
    if iChar == 97 then
    giMorseArr[] = iMorseArr_A
    elseif iChar == 98 then
    giMorseArr[] = iMorseArr_B
    elseif iChar == 99 then
    giMorseArr[] = iMorseArr_C
    elseif iChar == 100 then
    giMorseArr[] = iMorseArr_D
    elseif iChar == 101 then
    giMorseArr[] = iMorseArr_E
    elseif iChar == 102 then
    giMorseArr[] = iMorseArr_F
    elseif iChar == 103 then
    giMorseArr[] = iMorseArr_G
    elseif iChar == 104 then
    giMorseArr[] = iMorseArr_H
    elseif iChar == 105 then
    giMorseArr[] = iMorseArr_I
    elseif iChar == 106 then
    giMorseArr[] = iMorseArr_J
    elseif iChar == 107 then
    giMorseArr[] = iMorseArr_K
    elseif iChar == 108 then
    giMorseArr[] = iMorseArr_L
    elseif iChar == 109 then
    giMorseArr[] = iMorseArr_M
    elseif iChar == 110 then
    giMorseArr[] = iMorseArr_N
    elseif iChar == 111 then
    giMorseArr[] = iMorseArr_O
    elseif iChar == 112 then
    giMorseArr[] = iMorseArr_P
    elseif iChar == 113 then
    giMorseArr[] = iMorseArr_Q
    elseif iChar == 114 then
    giMorseArr[] = iMorseArr_R
    elseif iChar == 115 then
    giMorseArr[] = iMorseArr_S
    elseif iChar == 116 then
    giMorseArr[] = iMorseArr_T
    elseif iChar == 117 then
    giMorseArr[] = iMorseArr_U
    elseif iChar == 118 then
    giMorseArr[] = iMorseArr_V
    elseif iChar == 119 then
    giMorseArr[] = iMorseArr_W
    elseif iChar == 120 then
    giMorseArr[] = iMorseArr_X
    elseif iChar == 121 then
    giMorseArr[] = iMorseArr_Y
    elseif iChar == 122 then
    giMorseArr[] = iMorseArr_Z
    elseif iChar == 32 then
    giMorseArr[] fillarray 5
    endif
 schedule "morseMachine",0.3,99999,iChar
endin



instr morseMachine
 iBPM cabbageGetValue "morsebpm" ; 120
 iTempo = iBPM/60
 kTime init iTempo
 kMorseIndx init 0
    if metro(1/kTime) == 1 then
    kTime = (giMorseArr[kMorseIndx])/(iTempo*4)
    schedulek "morseSound", 0, kTime*0.5,p4
    kMorseIndx += 1
    endif
    if kMorseIndx == lenarray(giMorseArr) && changed(kMorseIndx) == 1 then
    giIndx += 1
	    if giIndx >= giLen then
	    gkMorse = 0
	    turnoff
	    endif
    schedulek "morseLetter",0,1
    turnoff
    endif
endin




instr morseSound
 iFrq cabbageGetValue "morsefrq"
 iMorseNoise cabbageGetValue "morsenoise"
 iMorseSine cabbageGetValue "morsesine"
 iNoiseGain = iMorseNoise
 iSineGain = iMorseSine
 iAmpIn cabbageGetValue "morseamp"
 iAmp ampdb iAmpIn
    if p4 == 32 then
    iGain = 0
    else
    iGain = 1
    endif
 iAtt = 0.01
 iTest = (p3-iAtt)-(iAtt*2)
 aEnv linseg 0,iAtt,iAmp,(p3-iAtt)-(iAtt*2),iAmp,iAtt,0
 aSound poscil aEnv, iFrq
 aNoise noise aEnv, 0.9
 iFilter cabbageGetValue "morsefilt"
 aNoise clfilt  aNoise, iFilter, 0, 10
 aNoiseOut clfilt aNoise*ampdb(3), iFilter*0.9, 1, 10
 aOut = ((aSound*iSineGain)+(aNoise*iNoiseGain))*iGain
 out aOut,aOut
endin



instr sampleSound
SFilenames[] directory ".", ".wav"
iFileNumbers lenarray SFilenames
indx = int(random:i(0,iFileNumbers))
Sfile = SFilenames[indx]
aSound diskin2 Sfile, 1, 0, 0
outall aSound
endin


; Effects
instr FxDust
 aIn chnget "snddust"
 aRvrb,aRvrb  reverbsc aIn,aIn, 0.65, 17000, sr, 1, 1
 aMix ntrpol aIn, aRvrb, 0.4
 iRel = 2
 aEnv linsegr 1, iRel, 0
 aOut = aMix*aEnv
 outall aOut
 chnclear "snddust"
endin

instr FxSeq
 aIn chnget "sndseq"
 giDelayTime init 0.4
 giFeedback init 0.3
 aTim	interp	giDelayTime
 abuf	delayr	15
 aDelay	deltapi	aTim	
 delayw	aIn + (aDelay*giFeedback)
 kDelayMix rspline 0.2, 0.7, 1, 3
 aDelayMix ntrpol aIn, aDelay, kDelayMix
 aRvrb,aRvrb  reverbsc aDelayMix,aDelayMix, 0.7, 3000, sr, 0.3, 1
 kRvbMix rspline 0.3, 0.7, 2, 5
 aMix ntrpol aIn, aRvrb, kRvbMix
 iRel = 2
 aEnv linsegr 1, iRel, 0
 aOut = aMix*aEnv
 outall aOut
 chnclear "sndseq"
endin


instr FxWg
 aIn chnget "sndwg"
    idBClip ampdb -5
    aIn clip aIn, 1, idBClip, 0.1
 aRvrb,aRvrb  reverbsc aIn,aIn, 0.85, 17000, sr, 1, 1
 aMix ntrpol aIn, aRvrb, 0.3
 iRel = 2
 aEnv linsegr 1, iRel, 0
 aOut = aMix*aEnv
 outall aOut
 chnclear "sndwg"
endin


instr empty
print p1
endin



 gkSpeaker1 init -45
 gkSpeaker2 init -45
 gkSpeaker3 init -60
 gkSpeaker4 init -60
instr speaker
 iMidi notnum
 iVel veloc
 iSpeed = 20
 iStart1 = i(gkSpeaker1)
 iStart2 = i(gkSpeaker2)
 iStart3 = i(gkSpeaker3)
 iStart4 = i(gkSpeaker4)
    if iMidi == 0 then
    gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1-1))
        if gkSpeaker1 <= -90 then
        gkSpeaker1 = -90
        endif
    elseif iMidi == 1 then
    gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1+1))
        if gkSpeaker1 >= 20 then
        gkSpeaker1 = 20
        endif
    endif
    if iMidi == 2 then
    gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2-1))
        if gkSpeaker2 <= -90 then
        gkSpeaker2 = -90
        endif
    elseif iMidi == 3 then
    gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2+1))
        if gkSpeaker2 >= 20 then
        gkSpeaker2 = 20
        endif
    endif
    if iMidi == 4 then
    gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3-1))
        if gkSpeaker3 <= -90 then
        gkSpeaker3 = -90
        endif
    elseif iMidi == 5 then
    gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3+1))
        if gkSpeaker3 >= 20 then
        gkSpeaker3 = 20
        endif
    endif
    if iMidi == 6 then
    gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4-1))
        if gkSpeaker4 <= -90 then
        gkSpeaker4 = -90
        endif
    elseif iMidi == 7 then
    gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4+1))
        if gkSpeaker4 >= 20 then
        gkSpeaker4 = 20
        endif
    endif
    if iMidi == 0 || iMidi == 1 then
    cabbageSetValue  "out1", gkSpeaker1+65
    cabbageSetValue  "outn1", gkSpeaker1
    endif
    if iMidi == 2 || iMidi == 3 then
    cabbageSetValue  "out2", gkSpeaker2+65
    cabbageSetValue  "outn2", gkSpeaker2
    endif
    if iMidi == 4 || iMidi == 5 then
    cabbageSetValue  "out3", gkSpeaker3+65
    cabbageSetValue  "outn3", gkSpeaker3
    endif
    if iMidi == 6 || iMidi == 7 then
    cabbageSetValue  "out4", gkSpeaker4+65
    cabbageSetValue  "outn4", gkSpeaker4
    endif
endin

instr time
 kTimer line 0, 1, 1
 kSec = int(kTimer)
 kMin init 0
 kSec = kSec % 60
    if kSec == 0 && changed(kSec) == 1 then
    kMin += 1
    endif
 STimer sprintfk "%02d : %02d", kMin, kSec
 cabbageSet 1, "sec", "text", STimer
endin

instr Widgets
 iDurMaster = 9^9
;;start
 kStart init 0
 kStart cabbageGet "start"
    if kStart == 1 && changed(kStart) == 1  then
    schedulek "time", 0, iDurMaster
    schedulek "FxWg", 0, iDurMaster
    schedulek "FxDust", 0, iDurMaster
    schedulek "FxSeq", 0, iDurMaster
    elseif kStart == 0 && changed(kStart) == 1 then
    turnoff2 "time", 0, 0
    turnoff2 "FxWg", 0, 0
    turnoff2 "FxDust", 0, 0
    endif

;;DustMachine
 kDustMachine ctrl7 10, 57, 0, 1
    if kDustMachine == 1 && changed(kDustMachine) == 1 then
    cabbageSet 1,"dustlight","colour(200, 70, 200)"
    schedulek "dustMachine", 0, iDurMaster
    elseif kDustMachine == 0 && changed(kDustMachine) == 1 then
    cabbageSet 1,"dustlight","colour(80, 50, 50, 255)"
    turnoff2 "dustMachine", 0, 0
    turnoff2 "guiroPlay", 0, 0
    turnoff2 "guiroSound", 0, 0
    endif

;;seqMachine
 kSeqMachine ctrl7 10, 58, 0, 1
    if kSeqMachine == 1 && changed(kSeqMachine) == 1 then
    cabbageSet 1,"seqlight","colour(100, 200, 100)"
    schedulek "seqMachine", 0, iDurMaster
    elseif kSeqMachine == 0 && changed(kSeqMachine) == 1 then
    cabbageSet 1,"seqlight","colour(80, 50, 50, 255)"
    turnoff2 "seqMachine", 0, 0
    turnoff2 "sineSound", 0, 0
    turnoff2 "barSound", 0, 0
    turnoff2 "bamSound", 0, 0
    turnoff2 "shakeSound", 0, 0
    turnoff2 "pluckSound", 0, 0
    endif

;;wgMachin
 kMachineSpdMin   ctrl7     1,28,0.1,10
    if changed(kMachineSpdMin) == 1 then
    cabbageSetValue  "machinespdmin", kMachineSpdMin
    endif
 kMachineSpdMax   ctrl7     1,36,0.2,15
    if changed(kMachineSpdMax) == 1 then
    cabbageSetValue  "machinespdmax", kMachineSpdMax
    endif
 kwgBow ctrl7 10, 59, 0, 1
    if kwgBow == 1 && changed(kwgBow) == 1 then
    schedulek "bowMachine", 0, iDurMaster
    elseif kwgBow == 0 && changed(kwgBow) == 1 then
    cabbageSet 1,"bowlight","colour(80, 50, 50, 255)"
    turnoff2 "bowMachine", 0, 0
    turnoff2 "bowSound", 0, 1
    endif
 kwgFlute ctrl7 10, 60, 0, 1
    if kwgFlute == 1 && changed(kwgFlute) == 1 then
    schedulek "fltMachine", 0, iDurMaster
    elseif kwgFlute == 0 && changed(kwgFlute) == 1 then
    cabbageSet 1,"flutelight","colour(80, 50, 50, 255)"
    turnoff2 "fltMachine", 0, 0
    turnoff2 "fluteSound", 0, 1
    endif
 kwgClr ctrl7 10, 61, 0, 1
    if kwgClr == 1 && changed(kwgClr) == 1 then
    schedulek "clrMachine", 0, iDurMaster
    elseif kwgClr == 0 && changed(kwgClr) == 1 then
    cabbageSet 1,"clarinetlight","colour(80, 50, 50, 255)"
    turnoff2 "clrMachine", 0, 0
    turnoff2 "clarinetSound", 0, 1
    endif
 kwgAmb ctrl7 10, 62, 0, 1
    if kwgAmb == 1 && changed(kwgAmb) == 1 then
    schedulek "ambwgMachine", 0, iDurMaster
    elseif kwgAmb == 0 && changed(kwgAmb) == 1 then
    cabbageSet 1,"wgamblight","colour(80, 50, 50, 255)"
    turnoff2 "ambwgMachine", 0, 0
    turnoff2 "wgAmbSound", 0, 1
    endif
  kAnalog ctrl7 10, 63, 0, 1
    if kAnalog == 1 && changed(kAnalog) == 1 then
    schedulek "analogMachine", 0, iDurMaster
    elseif kAnalog == 0 && changed(kAnalog) == 1 then
    printk2 k(2)
    cabbageSet 1,"analoglight","colour(80, 50, 50, 255)"
    turnoff2 "analogMachine", 0, 0
    turnoff2 "analogSound", 0, 1
    endif

;;noise
  kNoiseRng   ctrl7     1,0,0,500
    if changed(kNoiseRng) == 1 then
    cabbageSetValue  "noiserng", kNoiseRng
    endif
  kAmpNoise   ctrl7    1,21,0,30
    if changed(kAmpNoise) == 1 then
    cabbageSetValue  "noiseamp", kAmpNoise
    endif  
  kNoisePress   ctrl7     1,22,30,400
    if changed(kNoisePress) == 1 then
    cabbageSetValue  "noisepress", kNoisePress
    cabbageSetValue  "noisepresss", kNoisePress
    endif  
  knFilter   ctrl7     1,31,200,9000
    if changed(knFilter) == 1 then
    cabbageSetValue  "nfilt", knFilter
    cabbageSetValue  "nfilts", knFilter
    endif
  
    
 ;;wg setting
 kPos   ctrl7    1,23,0.025,2
    if changed(kPos) == 1 then
    cabbageSetValue  "pos", kPos
    cabbageSetValue  "poss", kPos
    endif
    
 kSpeedMin   ctrl7    1,27,0.1,5 
    if changed(kSpeedMin) == 1 then
    cabbageSetValue "spdstrngmin", kSpeedMin
    cabbageSetValue "spdstrngmins", kSpeedMin
    endif
 kSpeedMax   ctrl7     1,35,0.5,12
    if changed(kSpeedMax) == 1 then
    cabbageSetValue  "spdstrngmax", kSpeedMax
    cabbageSetValue  "spdstrngmaxs", kSpeedMax
    endif
    
 kwgVib   ctrl7     1,26,0,1
    if changed(kwgVib) == 1 then
    cabbageSetValue  "wgvib", kwgVib ;0, 0.27
    cabbageSetValue  "wgvibs", kwgVib ;0, 0.27
    endif
 kwgVibSpd  ctrl7     1,34,0,0.27
    if changed(kwgVibSpd) == 1 then
    cabbageSetValue  "vibSpd", kwgVibSpd ;0, 0.27
    cabbageSetValue  "vibSpds", kwgVibSpd ;0, 0.27
    endif
     
  kwgFilter   ctrl7     1,33,500,12000
    if changed(kwgFilter) == 1 then
    cabbageSetValue  "wgfilt", kwgFilter
    cabbageSetValue  "wgfilts", kwgFilter
    endif
    
 kAmpWg   ctrl7    1,29,0,30
    if changed(kAmpWg) == 1 then
    cabbageSetValue  "wgamp", kAmpWg
    endif  

  kwgCent   ctrl7     1,24,0,500
    if changed(kwgCent) == 1 then
    cabbageSetValue  "wgcent", kwgCent
    endif

 ;; morse
 kMorseStart cabbageGet "morsestart"
    if kMorseStart == 1 && changed(kMorseStart) == 1 then
    schedulek "morse", 0, iDurMaster
    elseif kMorseStart == 0 && changed(kMorseStart) == 1 then
    turnoff2 "morse", 0, 0
    turnoff2 "morseLetter", 0, 0
    turnoff2 "morseMachine", 0, 0
    turnoff2 "morseSound", 0, 0
    endif
    
    
    
 kstatus, kchan, kdata1, kdata2  midiin
 if changed(kchan) == 1 then
 SchShow     sprintfk "text(%d)", kchan
 cabbageSet 1, "datach", SchShow
 endif
 if kdata1 == 64 then
    if kdata2 == 127 then
    cabbageSet 1,"suslight","colour(250, 150, 200)"
    elseif kdata2 == 0 then
    cabbageSet 1,"suslight","colour(80, 50, 50, 255)"
    endif
 endif
    if changed(kdata2) == 1 then
    SMidiShow     sprintfk "text(%d)", kdata2
    cabbageSet 1, "data",SMidiShow
    cabbageSetValue "data", kdata2
    endif

;schedule "seqMachine", 0, 9999
;schedule "FxSeq", 0, 9999

;schedule "DustMachine", 0, 9999
;schedule "FxDust", 0, 9999
;schedule "noiseSound", 0, 1999

;schedule "wgMachine", 0, 9999
;schedule "FxWg", 0, 9999

endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

