<CsoundSynthesizer>
<CsOptions>
-m128  
</CsOptions>
<CsInstruments>


sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1


seed 0

instr 1
ime3     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0

  kamp1 ampdb -10
  kfreq1 = 300
;  ktens1 jspline .012, 0.7, 2
;  ktens1 = ktens1 + .3
  ktens1 rspline 0.25, 0.45, 0.7, 1
  iatt1 = 1.2
  
  kvibf1 jspline 5, 0.7, 3
;  kvibf1 = kvibf1 + 0.201
;  kvibf1 = 0.1
  kvamp1 jspline 0.05, 0.7, 5
  kvamp1 = kvamp1 + 0.07
  kvamp1 = 0.08
;printk2 ktens1
  abrass wgbrass kamp1, kfreq1, ktens1, iatt1, kvibf1, kvamp1; , ime3

   aout butlp abrass, 700
  outs aout,aout
endin


</CsInstruments>
<CsScore>

; Table #1, a sine wave.
f 1 0 2048 10 1

i1 0 999
e


</CsScore>
</CsoundSynthesizer>


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="nobackground">
  <r>255</r>
  <g>255</g>
  <b>255</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
