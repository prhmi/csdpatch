;v3
<Cabbage>
form caption("Puls")    size(900, 500)   guiMode("queue") colour(10,50,30) pluginId("puls") ; style("legacy")



vslider bounds(638, 342, 50, 150) channel("out1") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100) value(-90)
vslider bounds(674, 342, 50, 150) channel("out2") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100)
vslider bounds(710, 342, 50, 150) channel("out3") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100)
vslider bounds(744, 342, 50, 150) channel("out4") range(0, 100, 0, 1, 1) trackerColour(71, 137, 100)

vmeter bounds(798, 342, 15, 150) channel("meter1") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(822, 342, 15, 150) channel("meter2") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(846, 342, 15, 150) channel("meter3") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(870, 342, 15, 150) channel("meter4") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
image bounds(798, 328, 15, 15) channel("clip1") colour(0,0,0)
image bounds(822, 328, 15, 15) channel("clip2") colour(0,0,0)
image bounds(846, 328, 15, 15) channel("clip3") colour(0,0,0)
image bounds(870, 328, 15, 15) channel("clip4") colour(0,0,0)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0


opcode meterClip, 0, SakS
 SClip, aSig, kTrig, Smeter	xin
 iDbRange = 60 ;shows 60 dB
 iHoldTim = 0.5;seconds to "hold the red light"
 kOn init 0
 kTim init 0
 kStart init 0
 kEnd init 0
 kMax max_k aSig, kTrig, 1
 
 cabbageSetValue Smeter, kMax, metro(3)
 
 if kTrig == 1 then
 kMeter = (iDbRange + dbfsamp(kMax)) / iDbRange
  if kOn == 0 && kMax > 1 then
   kTim = 0
   kEnd = iHoldTim
   cabbageSet 1,SClip,"colour(250,0, 0)"
   kOn = 1
  endif
  if kOn == 1 && kTim > kEnd then
   cabbageSet 1,SClip,"colour(0,0,0)"
   kOn =	0
  endif
 endif
 kTim += ksmps/sr
endop




instr pulsPlay
kTime init 1
    if metro(kTime) == 1 then
    kTime random 2, 20
    kQ random 0, 3
    kFrq random 1000, 5000
    schedulek "puls", 0, 1, kFrq, kQ
    endif
endin


instr puls
iAmpIn1 cabbageGetValue "out1"
iAmpIn2 cabbageGetValue "out2"
iAmpIn3 cabbageGetValue "out3"
iAmpIn4 cabbageGetValue "out4"
iAmp1 = iAmpIn1-90
iAmp2 = iAmpIn2-90
iAmp3 = iAmpIn3-90
iAmp4 = iAmpIn4-90
iAmpdB1 ampdb iAmp1
iAmpdB2 ampdb iAmp2
iAmpdB3 ampdb iAmp3
iAmpdB4 ampdb iAmp4
iFrq = p4
	aSamp = mpulse:a(2, p3+1)
	iQ = p5
	aFilt = mode:a(aSamp, iFrq, iQ)
	
	aOut1 = aFilt*iAmpdB1
	aOut2 = aFilt*iAmpdB2
	aOut3 = aFilt*iAmpdB3
	aOut4 = aFilt*iAmpdB4
	
	iCh = int(random:i( 1, 3))
	outch 1, aOut1
	outch 2, aOut2
;	outch 3, aOut3
;	outch 4, aOut4
	
kRMS1 rms aOut1, 10
kRMSout1 = kRMS1*1.4
;printk2 kRMSout1
;cabbageSetValue "meter1", kRMSout1, metro(50)
meterClip "clip1", aOut1, metro(50), "meter1"
meterClip "clip2", aOut2, metro(50), "meter2"
meterClip "clip3", aOut3, metro(50), "meter3"
meterClip "clip4", aOut4, metro(50), "meter4"
	
endin




instr Widgets
kTimePort linseg 0, 0.01, 0.05

kSlider1   ctrl7    1,7,0,100
kSlider1 portk kSlider1, kTimePort
cabbageSetValue  "out1", kSlider1
kSlider2   ctrl7    1,8,0,100
kSlider2 portk kSlider2, kTimePort
cabbageSetValue  "out2", kSlider2

kSlider3  ctrl7    1,15,0,100
kSlider3 portk kSlider3, kTimePort
cabbageSetValue  "out3", kSlider3

kSlider4   ctrl7    1,16,0,100
kSlider4 portk kSlider4, kTimePort
cabbageSetValue  "out4", kSlider4

endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
;i "WidgetRead" 0  999
 i "pulsPlay" 0 999
</CsScore>
</CsoundSynthesizer>

