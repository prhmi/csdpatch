<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0

instr 1
 kTime init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 if metro(1/kTime) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 12))
 	trim kSeqArr, kLen
 	kIndx = 0 
 		while kIndx < kLen-1 do
 		kSeqValue random 1, 3
 		kSeqArr[kIndx] = kSeqValue
 		kIndx += 1
 		od
 	kMaxValue random 15, 20
 	kSeqArr[kLen-1] = kMaxValue
 	kDurSeq sumarray kSeqArr
; 	schedulek 4, 0, kDurSeq
 	endif 
 schedulek 3, 0, kTime*3
 kIndxSeq = (kIndxSeq+1) % kLen
 kTime = kSeqArr[kIndxSeq]/10
 endif
endin

instr 2
iFrq random 200, 1200
iAtt = 0.005
iAmp = 0.05
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq
outall aSound
endin

instr 3
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
iFrq random 10, 20
;kScan rspline 0.1, 0.8, p3*2, p3*4
iPoseMin random 0.001, 0.3
iPoseMax random 20, 30
iScan = random(0, 100) > 50 ? iPoseMin : iPoseMax
iRel random 0.001, 0.2
iPose random 0.001, 0.3
iPres random 0.01, 0.3
aSound    barmodel       1, 1, iFrq, iRel, iScan, 5, iPose, 5000, iPres
iFilter random 300, 500
aFilt clfilt aSound, iFilter, 1, 10
;outall aSound
chnmix aFilt, "snd"
endin

instr 4
aIn chnget "snd"
kDelayMix jspline 0.25, 1, 3
	
 	aTim	interp	giDelayTime
 	abuf	delayr	p3
 	aDelay	deltapi	aTim	
 	delayw	aIn + (aDelay*giFeedback)
 	aDelayMix ntrpol aIn, aDelay, kDelayMix+0.25
	aRvrb reverb aDelayMix, 0.7
	aMix ntrpol aIn, aRvrb, 0.3
	aOut = aMix
outall aOut
chnclear "snd"
endin

</CsInstruments>
<CsScore>
i1 0 9999
i4 0 9999
</CsScore>
</CsoundSynthesizer>








<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
