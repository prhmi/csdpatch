<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0

opcode lenRnd, k[], k[]
 kInArr[] xin
 kOutArr[] init lenarray:i(kInArr)+1
 xout kOutArr
endop

instr 1
 kTime init 1
 kIndxSeq init 0
 kSeqArr[] init 2
 if metro(4) == 1 then
 	if kIndxSeq == 0 then
 	kSeqArr[] lenRnd kSeqArr
 	kLenSeq lenarray kSeqArr
; 	kIndx = 0 
; 		while kIndx < kLenSeq do
; 		kSeqValue random 1, 5
; 		kSeqArr[kIndx] = kSeqValue
; 		kIndx += 1
; 		od
 	printarray kSeqArr
 	endif
 
; printk2 kLenSeq
 kIndxSeq = (kIndxSeq+1) % kLenSeq
 kTime = kSeqArr[kIndxSeq]/5
 endif
endin

</CsInstruments>
<CsScore>
i1 0 9999
</CsScore>
</CsoundSynthesizer>


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
