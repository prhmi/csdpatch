;v3
<Cabbage>
form caption("PixyLa")    size(900, 500)   guiMode("queue") colour(100,70,70) pluginId("pxla") ; style("legacy")



vslider bounds(638, 342, 50, 150) channel("out1") range(0, 40, 25.1968, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)
vslider bounds(674, 342, 50, 150) channel("out2") range(0, 40, 25.1968, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)
vslider bounds(710, 342, 50, 150) channel("out3") range(0, 40, 0, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)
vslider bounds(744, 342, 50, 150) channel("out4") range(0, 40, 0, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)

vmeter bounds(798, 342, 15, 150) channel("meter1") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(822, 342, 15, 150) channel("meter2") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(846, 342, 15, 150) channel("meter3") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(870, 342, 15, 150) channel("meter4") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
image bounds(798, 328, 15, 15) channel("clip1") colour(0,0,0)
image bounds(822, 328, 15, 15) channel("clip2") colour(0,0,0)
image bounds(846, 328, 15, 15) channel("clip3") colour(0,0,0)
image bounds(870, 328, 15, 15) channel("clip4") colour(0,0,0)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0


opcode CsdMeter, 0, SakS
 SClip, aSig, kTrig, Smeter	xin
 iDbRange = 60 ;shows 60 dB
 iHoldTim = 0.5;seconds to "hold the red light"
 kOn init 0
 kTim init 0
 kStart init 0
 kEnd init 0
 kMax max_k aSig, kTrig, 1
 cabbageSetValue Smeter, kMax, metro(20)
 
 if kTrig == 1 then
 kMeter = (iDbRange + dbfsamp(kMax)) / iDbRange
  if kOn == 0 && kMax > 1 then
   kTim = 0
   kEnd = iHoldTim
   cabbageSet 1,SClip,"colour(250,0, 0)"
   kOn = 1
  endif
  if kOn == 1 && kTim > kEnd then
   cabbageSet 1,SClip,"colour(0,0,0)"
   kOn =	0
  endif
 endif
 kTim += ksmps/sr
endop




instr pulsPlay
kTime init 1
    if metro(kTime) == 1 then
    kTime random 2, 12
    kQ random 0, 3
    kFrq random 1000, 5000
    schedulek "puls", 0, 1, kFrq, kQ
    endif
endin


instr puls
iFrq = p4
	aSamp = mpulse:a(1/2, p3+1)
	iQ = p5
	aFilter = mode:a(aSamp, iFrq, iQ)	
	a1 dust 0.4, 2
	a2 gausstrig 0.5, 3, 0.9	
	aDust sum a1,a2,aFilter	
    iCh = int(random:i( 1, 5))
	SchnSend sprintf "snddust%d", iCh
	chnmix aDust, SchnSend
endin



instr OutSound
kGain cabbageGet "gain"
kAmpIn1 cabbageGet "out1"
kAmpIn2 cabbageGet "out2"
kAmpIn3 cabbageGet "out3"
kAmpIn4 cabbageGet "out4"

idB = 25
kAmp1 = kAmpIn1-idB
kAmp2 = kAmpIn2-idB
kAmp3 = kAmpIn3-idB
kAmp4 = kAmpIn4-idB
kAmpdB1 ampdb kAmp1
kAmpdB2 ampdb kAmp2
kAmpdB3 ampdb kAmp3
kAmpdB4 ampdb kAmp4


aInPlus1 chnget "snddust1"
aInPlus2 chnget "snddust2"
aInPlus3 chnget "snddust3"
aInPlus4 chnget "snddust4"

aOut1 = aInPlus1*kAmpdB1*kGain
aOut2 = aInPlus2*kAmpdB2*kGain
aOut3 = aInPlus3*kAmpdB3*kGain
aOut4 = aInPlus4*kAmpdB4*kGain



CsdMeter "clip1", aOut1, metro(20), "meter1"	
CsdMeter "clip2", aOut2, metro(20), "meter2"	
CsdMeter "clip3", aOut3, metro(20), "meter3"	
CsdMeter "clip4", aOut4, metro(20), "meter4"	

	outch 1, aOut1
	outch 2, aOut2
	outch 3, aOut3
	outch 4, aOut4
	
	chnclear "snddust1","snddust2","snddust3","snddust4"
endin


instr Widgets
kTimePort linseg 0, 0.01, 0.05

kSlider1   ctrl7    1,27,0,40
kSlider1 portk kSlider1, kTimePort
cabbageSetValue  "out1", kSlider1

kSlider2   ctrl7    1,28,0,40
kSlider2 portk kSlider2, kTimePort
cabbageSetValue  "out2", kSlider2

kSlider3  ctrl7    1,35,0,40
kSlider3 portk kSlider3, kTimePort
cabbageSetValue  "out3", kSlider3

kSlider4   ctrl7    1,36,0,40
kSlider4 portk kSlider4, kTimePort
cabbageSetValue  "out4", kSlider4

endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
i "pulsPlay" 0 999
i "OutSound" 0 999
</CsScore>
</CsoundSynthesizer>

