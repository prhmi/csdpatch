;v3
<Cabbage>
form caption("PixyPulse")    size(900, 500)   guiMode("queue") colour(100,70,70) pluginId("pxpl") ; style("legacy")



vslider bounds(638, 342, 50, 150) channel("out1") range(0, 40, 25.1968, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)
vslider bounds(674, 342, 50, 150) channel("out2") range(0, 40, 25.1968, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)
vslider bounds(710, 342, 50, 150) channel("out3") range(0, 40, 0, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)
vslider bounds(744, 342, 50, 150) channel("out4") range(0, 40, 0, 1, 1) trackerColour(71, 137, 100, 255) valueTextBox(1)

vmeter bounds(798, 342, 15, 150) channel("meter1") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(822, 342, 15, 150) channel("meter2") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(846, 342, 15, 150) channel("meter3") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(870, 342, 15, 150) channel("meter4") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
image bounds(798, 328, 15, 15) channel("clip1") colour(0,0,0)
image bounds(822, 328, 15, 15) channel("clip2") colour(0,0,0)
image bounds(846, 328, 15, 15) channel("clip3") colour(0,0,0)
image bounds(870, 328, 15, 15) channel("clip4") colour(0,0,0)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0


opcode CsdMeter, 0, SakS
 SClip, aSig, kTrig, Smeter	xin
 iDbRange = 60 ;shows 60 dB
 iHoldTim = 0.5;seconds to "hold the red light"
 kOn init 0
 kTim init 0
 kStart init 0
 kEnd init 0
 kMax max_k aSig, kTrig, 1
 cabbageSetValue Smeter, kMax, metro(20)
 
 if kTrig == 1 then
 kMeter = (iDbRange + dbfsamp(kMax)) / iDbRange
  if kOn == 0 && kMax > 1 then
   kTim = 0
   kEnd = iHoldTim
   cabbageSet 1,SClip,"colour(250,0, 0)"
   kOn = 1
  endif
  if kOn == 1 && kTim > kEnd then
   cabbageSet 1,SClip,"colour(0,0,0)"
   kOn =	0
  endif
 endif
 kTim += ksmps/sr
endop

opcode limiter, a,ai
aIn, iThrshhol xin
kThrsh rms aIn, 0.1
kTrig metro 20
kMax max_k aIn, kTrig, 1
kAmpdB dbamp kMax
if kAmpdB <= -90 then
kAmpdB = -90
elseif kAmpdB >= 1 then
kAmpdB = 1
endif
 kFctr = iThrshhol-kAmpdB
 kLimitdB ampdb kFctr
if kLimitdB >= 1 then
kLimitdB = 1
endif
 aLimiter interp kLimitdB
 aDelay delay aIn, 0.1
 aOut = aDelay*aLimiter
xout aOut
endop




instr pulsPlay
kTime init 1
    if metro(kTime) == 1 then
    kTime random 2, 12
    kQ random 0, 3
    kFrq random 1000, 5000
    schedulek "puls", 0, 1, kFrq, kQ
    endif
endin


instr puls
iFrq = p4
	aSamp = mpulse:a(1/2, p3+1)
	iQ = p5
	aFilter = mode:a(aSamp, iFrq, iQ)	
	a1 dust 0.4, 2
	a2 gausstrig 0.5, 3, 0.9	
	aDust sum a1,a2,aFilter	
    iCh = int(random:i( 1, 5))
	SchnSend sprintf "snddust%d", iCh
	chnmix aDust, SchnSend
endin


instr seqMachine
SinstrArr[] fillarray "sineSound", "barSound", "bamSound", "bamSound", "shakeSound", "pluckSound"
 kTime init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 if metro(1/kTime) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 12))
 	trim kSeqArr, kLen
 		kIndx = 0 
 		while kIndx < kLen-1 do
 		kSeqValue random 1, 3
 		kSeqArr[kIndx] = kSeqValue
 		kIndx += 1
 		od
 	kMaxValue random 15, 20
 	kSeqArr[kLen-1] = kMaxValue
 	endif 
 kInstr = int(random:k(0, 6))
 Sinstr = SinstrArr[kInstr]
 schedulek Sinstr, 0, kTime
 kIndxSeq = (kIndxSeq+1) % kLen
 kTime = kSeqArr[kIndxSeq]/10
 endif
endin

instr sineSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
iFrq random 200, 1200
iAtt = 0.005
iAmp = 0.1
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq
chnmix aSound, "sndseq"
endin

instr barSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
iFrq random 10, 70
;kScan rspline 0.1, 0.8, p3*2, p3*4
iPoseMin random 0.001, 1
iPoseMax random 2, 10
iScan = random(0, 100) > 90 ? iPoseMin : iPoseMax
iRel = 0.5 ;random 0.01, 0.5
iPose = 0.005 ;random 0.001, 0.1
iPres random 0.1, 0.5
aSound    barmodel       1, 1, iFrq, iRel, iScan, 1, iPose, 50000, iPres
iAtt = 0.001
aEnv transeg 0, iAtt, 6, 1;, p3-iAtt, -6, 0
iFilter random 800, 3000
aFilt clfilt aSound*aEnv, iFilter, 1, 10
;outall aFilt
chnmix aFilt, "sndseq"
endin

instr bamSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
p3 random 0.05, 3
iFrq random 10, 50
iFilter random 3000, 8000
iAtt = 0.01
aEnv transeg 0, iAtt, 6, 0.5, p3-iAtt, -6, 0
iAmp = 2000
iNumber random 1, 7
iDamp random 0.0001, 0.05
iDecay random 0.001, 0.1
aSound  bamboo iAmp, iDecay, iNumber, iDamp, 1, iFrq, 400
aFilt clfilt aSound*aEnv, iFilter, 1, 10
aLimit limiter aFilt, -15
chnmix aLimit, "sndseq"
endin


instr shakeSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
p3 random 0.01, 0.1
iRel random 0.1, 1
aEnv linsegr 1, iRel, 0
knum  rspline 2, 15, 2, 7
kFrq rspline 700, 3000, 2, 15
asig shaker .03, kFrq, 8, 0.9, knum
iFilter random 300, 500
aFilt clfilt asig*aEnv, iFilter, 1, 10		
chnmix aFilt, "sndseq"
endin


instr pluckSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
giRvrbTime random 0.7, 0.9
iAmp random 0.3, 0.5
iAtt random 0.008, 0.01
iRel random 0.1, 1
aEnv linsegr 0, iAtt, 1, iRel, 0
iFrq random 30, 1500
iResample random 20, 1500
iMeth = random:i(0, 100) < 50 ? 1 : 6
aSound  pluck iAmp, iFrq, iResample, 0, iMeth;, 2, 1
iFilter random 300, 1500
aFilt clfilt aSound*aEnv, iFilter, 0, 10	
aFilt clfilt aSound*aEnv, 200, 1, 10	
chnmix aFilt, "sndseq"
endin



instr FxSeq
aIn chnget "sndseq"
	
 	aTim	interp	giDelayTime
 	abuf	delayr	15
 	aDelay	deltapi	aTim	
 	delayw	aIn + (aDelay*giFeedback)
 	kDelayMix rspline 0.2, 0.7, 1, 3
 	aDelayMix ntrpol aIn, aDelay, kDelayMix
 	aRvrb,aRvrb  reverbsc aDelayMix,aDelayMix, 0.7, 3000, sr, 0.3, 1
;	aRvrb reverb aDelayMix, 1
	kRvbMix rspline 0.3, 0.7, 2, 5
	aMix ntrpol aIn, aRvrb, kRvbMix
	aOut = aMix
outall aOut
chnclear "sndseq"
endin




instr Widgets
schedule "seqMachine", 0, 9999
schedule "FxSeq", 0, 9999
endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

