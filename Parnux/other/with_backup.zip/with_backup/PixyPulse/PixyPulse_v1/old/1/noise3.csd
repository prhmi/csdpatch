<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



seed 0

instr 1
iAmpdB ampdb -10
iDelayTime = 0.1
kFb rspline 50, 200, 1, 12
kGainRnd rspline 0, 1, 2, 13
aNoise noise 1, 0.5
aNoise = aNoise*5
aFb init 1
aNoise = (aNoise*kFb)+aFb
aSine poscil 1, aNoise
aPhas phasor aNoise
aSum sum aSine, aPhas
aFb delay aSum, iDelayTime
kHighCut = 15000
kLowCut = 5000
  aFilt clfilt aFb, kHighCut, 0, 10
  aFilt  clfilt aFilt, kLowCut, 1, 10
aOut = aFilt*kGainRnd*iAmpdB
outall aOut
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>




<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
