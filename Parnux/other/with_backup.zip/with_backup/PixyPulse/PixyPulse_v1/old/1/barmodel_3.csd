<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0

instr 1
kTime init 1
if metro(kTime) == 1 then
kTime random 10, 15
schedulek 2, 0, 1
endif
endin


instr 2
print 1
;gkK = 120-130
;gkT30 = 0.3-30
;gkb = 0.0001-10
;gkpos = 0.7-0.9
;gkvel = 300-30000
;gkscan = 0.2-100
;gkwid = 0.03
;gkbcL = 0-1
;gkbcR = 0-1

; #i0 = 1.000  #i1 = 1.000  #i2 = 130.000  #i3 = 0.077  #i4 = 0.775  #i5 = 20.000  #i6 = 0.837  #i7 = 16000.000  #i8 = 0.016

iMod = int(random:i(1, 6))

if iMod == 1 then
iDur1 = 0.077
iscan  = 0.175
iDur2 = 20
elseif iMod == 2 then
iDur1 = 0.4
iscan  = 70
iDur2 =  1
elseif iMod == 3 then
iDur1 random 0.1, 0.7
iscan  random 50, 70
iDur2 random 1, 10
elseif iMod == 4 then
iDur1 = 1
iscan = 0.008
iDur2 random 0.1, 1
elseif iMod == 5 then
iDur1 = 0.077
iscan  random 30, 50
iDur2 random 0.1, 20
endif



iK = 125
ipos =  0.837 
ivel = 16000
iwid = 0.016



	aSound 	barmodel 	1, 1, iK, iDur1, iscan,   iDur2, ipos, ivel, iwid

outall aSound
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>








<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>631</x>
 <y>103</y>
 <width>320</width>
 <height>240</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
