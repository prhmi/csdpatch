<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


instr 1
a1 dust 1, 100
kAmpdb rspline -20, 20, 50, 70
kAmp ampdb kAmpdb
a2 poscil kAmp, 800

aIn = a2
krms rms aIn, 1
kdB dbamp krms
printk2 int(kdB+3)
kdBLimit = ampdb:k(-10-3)
  if krms > kdBLimit then
  kfctr      =           kdBLimit/krms           
  afctr      interp      kfctr               
  aOut       =           aIn * afctr    
  else
  aOut = aIn       
	endif
  
outall aOut
endin

</CsInstruments>
<CsScore>
i1 0 9999
</CsScore>
</CsoundSynthesizer>






<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
