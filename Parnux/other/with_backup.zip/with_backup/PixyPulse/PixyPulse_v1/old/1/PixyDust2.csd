;v3
<Cabbage>
form caption("PixyDust")    size(1350, 700)   guiMode("queue") colour(45,10,35) pluginId("pxds") ; style("legacy")

vslider bounds(1052, 536, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(219, 120, 120, 255) 
vslider bounds(1094, 536, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(219, 120, 120, 255)
vslider bounds(1134, 536, 50, 150) channel("out3") range(0, 80, 0, 1, 1) trackerColour(219, 120, 120, 255)
vslider bounds(1176, 536, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(219, 120, 120, 255)
nslider bounds(1058, 502, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(80, 50, 50, 255)
nslider bounds(1098, 502, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(80, 50, 50, 255)
nslider bounds(1138, 502, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(80, 50, 50, 255)
nslider bounds(1178, 502, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(80, 50, 50, 255)
nslider bounds(1226, 468, 93, 44) channel("gain") range(-90, 50, 0, 1, 1) colour(80, 50, 50, 255) text("Master Gain (dB)")

label bounds(1068, 50, 239, 66) channel("sec") text("00 : 12") fontColour(241, 178, 178, 255)
label bounds(1108, 14, 70, 33) channel("data")  fontColour(241, 178, 178, 255) colour(80, 50, 50, 255) text("0")
button bounds(1188, 18, 116, 27) channel("start") text("S  T  A  R  T", "S  T  O  P")  colour:0(171, 81, 152, 255) colour:1(99, 85, 85, 255) value(1)
image bounds(1088, 424, 30, 30) channel("dustlight") corners(5) colour(80, 50, 50, 255)
image bounds(1128, 424, 30, 30) channel("seqlight") corners(5) colour(80, 50, 50, 255)
image bounds(1166, 424, 30, 30) channel("bowlight") corners(5) colour(80, 50, 50, 255)
image bounds(1204, 424, 30, 30) channel("flutelight") corners(5) colour(80, 50, 50, 255)
image bounds(1242, 424, 30, 30) channel("clarinetlight") corners(5) colour(80, 50, 50, 255)
image bounds(1282, 424, 30, 30) channel("wgamblight") corners(5) colour(80, 50, 50, 255)


hslider bounds(65, 308, 219, 40) channel("pos") range(0.025, 2, 1, 1, 0.001) trackerColour(219, 120, 120, 255)
hslider bounds(64, 334, 220, 40) channel("spdstrngmin") range(0.7, 5, 2, 1, 0.1) trackerColour(219, 120, 120, 255)
hslider bounds(65, 360, 219, 40) channel("spdstrngmax") range(1, 12, 5, 1, 0.01) trackerColour(219, 120, 120, 255)
hslider bounds(65, 382, 219, 40) channel("bowvib") range(0, 1, 0, 1, 0.001) trackerColour(219, 120, 120, 255) 
hslider bounds(65, 408, 219, 40) channel("vibSpd") range(0, 0.27, 0.03, 1, 0.001) trackerColour(219, 120, 120, 255) 

nslider bounds(292, 312, 64, 42) channel("padcent") range(0, 500, 0, 1, 1) colour(80, 50, 50, 255) fontColour(241, 178, 178, 255) text("Pad Cent")
label bounds(294, 358, 59, 18) channel("label25") text("CC-00") fontColour(224, 219, 219, 255)

vmeter bounds(1230, 536, 15, 150) channel("meter1")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1254, 536, 15, 150) channel("meter2")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1278, 536, 15, 150) channel("meter3")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1302, 536, 15, 150) channel("meter4")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
image bounds(1230, 522, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(1254, 522, 15, 15) channel("clip2") colour(0, 0, 0, 255)
image bounds(1278, 522, 15, 15) channel("clip3") colour(0, 0, 0, 255)
image bounds(1302, 522, 15, 15) channel("clip4") colour(0, 0, 0, 255)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 4
0dbfs = 1


seed 0


opcode CsdMeter, 0, SakS
 SClip, aSig, kTrig, Smeter	xin
 iDbRange = 60 ;shows 60 dB
 iHoldTim = 0.5;seconds to "hold the red light"
 kOn init 0
 kTim init 0
 kStart init 0
 kEnd init 0
 kMax max_k aSig, kTrig, 1
 cabbageSetValue Smeter, kMax, metro(20)
 
 if kTrig == 1 then
 kMeter = (iDbRange + dbfsamp(kMax)) / iDbRange
  if kOn == 0 && kMax > 1 then
   kTim = 0
   kEnd = iHoldTim
   cabbageSet 1,SClip,"colour(250,0, 0)"
   kOn = 1
  endif
  if kOn == 1 && kTim > kEnd then
   cabbageSet 1,SClip,"colour(0,0,0)"
   kOn =	0
  endif
 endif
 kTim += ksmps/sr
endop

opcode limiter, a,ai
aIn, iThrshhol xin
kThrsh rms aIn, 0.1
kTrig metro 10
kMax max_k aIn, kTrig, 1
kAmpdB dbamp kMax
if kAmpdB <= -50 then
kAmpdB = -90
elseif kAmpdB >= 1 then
kAmpdB = 1
endif
 kFctr = iThrshhol-kAmpdB
 kLimitdB ampdb kFctr
if kLimitdB >= 1 then
kLimitdB = 1
endif
 aLimiter interp kLimitdB
 aDelay delay aIn, 0.1
 aOut = aDelay*aLimiter
xout aOut
endop



massign 1,8
massign 16,23




instr dustMachine
 kTimeG init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 kFrq init 7000
 if metro(kTimeG) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 3))
 	kSeqValue random 1/3, 1/2
 	trim kSeqArr, kLen
 		kIndx = 0
 		while kIndx < kLen-1 do
		kRndSeq random 0, 0.2
 		kSeqArr[kIndx] = kSeqValue+kRndSeq
 		kIndx += 1
 		od
 	kMaxValue random 1/7, 1/15
 	kSeqArr[kLen-1] = kMaxValue
 	kFrq random 1000, 9000
 	kLoop random 2, 4
 	endif 
 kLenOut random 1, 7
 kDur random 0.5, 3
 schedulek "guiroPlay", 0, 1, kFrq, kLoop,kLenOut
 	kIndx = 0
 	kFrq2 random 1000, 9000 
 	kNumber random 1, 6
 	while kIndx < int(kNumber) do
 	kStart random 1, 7
 	schedulek "guiroSound", kStart, 1, kFrq2, kLoop
 	kIndx += 1
 	od
 kTimeG = kSeqArr[kIndxSeq]
 kIndxSeq = (kIndxSeq+1) % kLen
 endif

endin

instr noiseSound
iAmpdB ampdb -10
iDelayTime = 0.1
kFb rspline 50, 200, 1, 12
kGainRnd rspline 0, 1, 2, 13
aNoise noise 1, 0.5
aNoise = aNoise*5
aFb init 1
aNoise = (aNoise*kFb)+aFb
aSine poscil 1, aNoise
aPhas phasor aNoise
aSum sum aSine, aPhas
aFb delay aSum, iDelayTime
kHighCut = 700
kLowCut = 700
  aFilt clfilt aFb, kHighCut, 0, 10
  aFilt  clfilt aFilt, kLowCut, 1, 10
  
  aFiltNoise clfilt aNoise*0.0001, kHighCut, 0, 10
  aFiltNoise  clfilt aFiltNoise, kLowCut, 1, 10
  
aOut = aFilt*kGainRnd*iAmpdB
outall aFiltNoise
endin





instr pulseSound
print 1
iFrq = 400
	aSamp = mpulse:a(1/2, p3+1)
	iQ = 2
	aFilter = mode:a(aSamp, iFrq, iQ)	
	a1 dust 0.4, 2
	a2 gausstrig 0.5, 3, 0.9	
	aDust sum a1,a2,aFilter	
;    iCh = int(random:i( 1, 5))
;	SchnSend sprintf "snddust%d", iCh
;	chnmix aDust, "snddust"
	outall aDust
endin


instr guiroPlay
iLen = int(p6)
indx = 0
iStart = 0
while indx < iLen do
schedule "guiroSound", iStart, 1,p4,p6
iStart += 0.175
indx += 1
od
endin

instr guiroSound
iFrqIn = p4
iFrq random iFrqIn, iFrqIn*1.01
iNum random 128, 128
iAmp = (iFrqIn/10000)^2
aSound  guiro iAmp*0.1, 0, 128, 0, 0, iFrq, iFrq*2
iLoopDur = p5
iRndLoop random 3, 10
iLoop = iLoopDur/iRndLoop
aComb comb aSound, iLoopDur, iLoop
iFrqRnd random 0, 100
iRel = 0.1
;aRel transegr 1, iRel, -6, 0
aRes reson aSound, iFrq*1.1+iFrqRnd, 200
chnmix aRes, "snddust"
;outall aSound
endin


instr seqMachine
SinstrArr[] fillarray "sineSound", "barSound", "bamSound", "bamSound", "shakeSound", "pluckSound"
 kTime init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 if metro(1/kTime) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 12))
 	trim kSeqArr, kLen
 		kIndx = 0 
 		while kIndx < kLen-1 do
 		kSeqValue random 1, 3
 		kSeqArr[kIndx] = kSeqValue
 		kIndx += 1
 		od
 	kMaxValue random 15, 20
 	kSeqArr[kLen-1] = kMaxValue
 	endif 
 kInstr = int(random:k(0, 6))
 Sinstr = SinstrArr[kInstr]
 schedulek Sinstr, 0, kTime
 kIndxSeq = (kIndxSeq+1) % kLen
 kTime = kSeqArr[kIndxSeq]/10
 endif
endin

instr sineSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
iFrq random 200, 1200
iAtt = 0.005
iAmp = 0.1
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq
chnmix aSound, "sndseq"
endin

instr barSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
iFrq random 10, 70
;kScan rspline 0.1, 0.8, p3*2, p3*4
iPoseMin random 0.001, 1
iPoseMax random 2, 10
iScan = random(0, 100) > 90 ? iPoseMin : iPoseMax
iRel = 0.5 ;random 0.01, 0.5
iPose = 0.005 ;random 0.001, 0.1
iPres random 0.1, 0.5
aSound    barmodel       1, 1, iFrq, iRel, iScan, 1, iPose, 50000, iPres
iAtt = 0.001
aEnv transeg 0, iAtt, 6, 1;, p3-iAtt, -6, 0
iFilter random 800, 3000
aFilt clfilt aSound*aEnv, iFilter, 1, 10
;outall aFilt
chnmix aFilt, "sndseq"
endin

instr bamSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
p3 random 0.05, 3
iFrq random 10, 50
iFilter random 3000, 8000
iAtt = 0.01
aEnv transeg 0, iAtt, 6, 0.5, p3-iAtt, -6, 0
iAmp = 2000
iNumber random 1, 7
iDamp random 0.0001, 0.05
iDecay random 0.001, 0.1
aSound  bamboo iAmp, iDecay, iNumber, iDamp, 1, iFrq, 400
aFilt clfilt aSound*aEnv, iFilter, 1, 10
aLimit limiter aFilt, -15
chnmix aLimit, "sndseq"
endin


instr shakeSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
p3 random 0.01, 0.1
iRel random 0.1, 1
aEnv linsegr 1, iRel, 0
knum  rspline 2, 15, 2, 7
kFrq rspline 700, 3000, 2, 15
asig shaker .03, kFrq, 8, 0.9, knum
iFilter random 300, 500
aFilt clfilt asig*aEnv, iFilter, 1, 10		
chnmix aFilt, "sndseq"
endin


instr pluckSound
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
giRvrbTime random 0.7, 0.9
iAmp random 0.3, 0.5
iAtt random 0.008, 0.01
iRel random 0.1, 1
aEnv linsegr 0, iAtt, 1, iRel, 0
iFrq random 30, 1500
iResample random 20, 1500
iMeth = random:i(0, 100) < 50 ? 1 : 6
aSound  pluck iAmp, iFrq, iResample, 0, iMeth;, 2, 1
iFilter random 300, 1500
aFilt clfilt aSound*aEnv, iFilter, 0, 10	
aFilt clfilt aSound*aEnv, 200, 1, 10	
chnmix aFilt, "sndseq"
endin






instr bowMachine
kTimeBow init 1
if metro(1/kTimeBow) == 1 then
kTimeBow random 5, 7
kDurBow = kTimeBow*1.3
schedulek "bowSound", 0, kDurBow
endif
endin

instr fltMachine
kTimeFlute init 1
if metro(1/kTimeFlute) == 1 then
kTimeFlute random 5, 7
kDurFlute = kTimeFlute*1.3
schedulek "fluteSound", 0, kDurFlute
endif
endin
instr clrMachine
print 2
kTimeClr init 1
if metro(1/kTimeClr) == 1 then
kTimeClr random 5, 7
kDurClr = kTimeClr*1.3
schedulek "clarinetSound", 0, kDurClr
endif
endin
instr ambwgMachine
kTimeAmbWg init 1
if metro(1/kTimeAmbWg) == 1 then
kTimeAmbWg random 5, 7
kDurAmbWg = kTimeAmbWg*1.3
schedulek "wgAmbSound", 0, kDurAmbWg
endif
endin

instr bowSound
iAtt = 1
iRel = 1
iMidi notnum
if iMidi != 0 then
cabbageSet 1,"bowlight","colour(200, 150, 100)"
kRelease release
    if kRelease == 1 then
    cabbageSet 1,"bowlight","colour(80, 50, 50, 255)"
    endif
aEnv linsegr 0, iAtt, 1, iRel, 0
 iFrq mtof iMidi
 iFrqMin = iFrq/2
elseif iMidi == 0 then
aEnv linseg 0, p3/2, 1, p3/2, 0
 	iFrqMin random 10, 1000
endif

iGain ampdb -15
;iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
iWave     ftgenonce 1,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
 	iBaseFrq random 100, 400


 print iBaseFrq,iFrqMin
 kSpeedMin  = 0.1
 kSpeedMax  = 0.7
 kVibIn     = 5
  kVibRng  = 5
 kPosIn     = 0.1
	kAmp   rspline  0.2, 0.7, 0.7, 1
	kCent = 10
	kCentFrq    jspline  kCent, kSpeedMin, kSpeedMax
	kFrq = iBaseFrq*cent(kCentFrq)
	kPres  rspline  3, 4, kSpeedMin, kSpeedMax
	kRate   rspline 0.025, kPosIn, kSpeedMin, kSpeedMax
	kVib   jspline  kVibIn/1000, kSpeedMin, kSpeedMax
	aBow	wgbow    kAmp,kFrq,kPres,kRate,kVib,kVibRng/100,iWave, iFrqMin
    kFilterBow = 12000
    aFiltBow clfilt aBow, kFilterBow, 0, 10
    aFiltBow clfilt aFiltBow, 150, 1, 10

;    aOut linen aFiltBow*iGain, p3/2, p3, p3/2
	aOut = aFiltBow*iGain*aEnv
;	outall aOut
	chnmix aOut, "sndwg"
endin



instr fluteSound
iGain ampdb -1
iMidi notnum
if iMidi != 0 then
iAtt = 1
iRel = 1
aEnv linsegr 0, iAtt, 1, iRel, 0
 iFrq mtof iMidi
 iFrqMin = iFrq/2
elseif iMidi == 0 then
aEnv linseg 0, p3/2, 1, p3/2, 0
 	iFrqMin random 10, 1000
endif
iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
;iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
iBaseFrq random 100, 500
 kSpeedMin = 0.03
 kSpeedMax = 0.1
kAmp rspline 0.03, 0.2, kSpeedMin, kSpeedMax
kJet rspline 0.01, 0.9, kSpeedMin, kSpeedMax
kVib rspline 0, 1, kSpeedMin, kSpeedMax
kVamp rspline 0.1, 0.5, kSpeedMin, kSpeedMax
kAirSound rspline 0, 0.4, kSpeedMin, kSpeedMax
kCent = 0
kGliss jspline kCent, kSpeedMin, kSpeedMax
kFrq = iBaseFrq*cent(kGliss)
iAtt = 0.5
iDecay = 0.2
   aFlute  wgflute kAmp, kFrq, kJet, iAtt, iDecay, kAirSound, kVib, kVamp, iWave,iFrqMin
		kFilterFlute = 7000
    aFiltFlute clfilt aFlute, kFilterFlute, 0, 10
    aFiltFlute clfilt aFiltFlute, 250, 1, 10
;    aOut linen aFiltFlute, p3/2, p3, p3/2
    aOut = aFiltFlute*iGain*aEnv
  chnmix aOut, "sndwg"
endin



instr clarinetSound

iGain ampdb -1
iMidi notnum
if iMidi != 0 then
iAtt = 1
iRel = 1
aEnv linsegr 0, iAtt, 1, iRel, 0
 iFrq mtof iMidi
 iFrqMin = iFrq/2
elseif iMidi == 0 then
aEnv linseg 0, p3/2, 1, p3/2, 0
 	iFrqMin random 10, 1000
endif


;iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
iBaseFrq random 100, 200

 kSpeedMin = 0.03
 kSpeedMax = 0.1
kAmp rspline 0.03, 0.2, kSpeedMin, kSpeedMax
kCent = 0
kGliss jspline kCent, kSpeedMin, kSpeedMax
kFrq = iBaseFrq*cent(kGliss)
  kStiff rspline -0.4, -0.18, 2, 3
  iAtt1 = 1.2
  iDetk = 0.1
  kAirNoise rspline 0, 0.3, 2, 3
  kVibClr jspline 3, 0.4, 0.7
  kvAmpClr rspline 0.5, 2, 2, 7
  aClar wgclar kAmp, kFrq, kStiff, iAtt1, iDetk, \
  kAirNoise, kVibClr, kvAmpClr, iWave, iFrqMin

		kFilterClr = 7000
    aFiltClr clfilt aClar, kFilterClr, 0, 10
    aFiltClr clfilt aFiltClr, 250, 1, 10
;    aOut linen aFiltClr, p3/2, p3, p3/2
    aOut = aFiltClr*iGain*aEnv
  chnmix aOut, "sndwg"
;outall aFiltClr
endin




instr wgAmbSound
iGainMaster ampdb -1
iMidi notnum
    if iMidi != 0 then
    iAtt = 1
    iRel = 1
    aEnv linsegr 0, iAtt, 1, iRel, 0
    kFrqBwIn mtof iMidi
    iFrqMin = i(kFrqBwIn)/2
    elseif iMidi == 0 then
    aEnv linseg 0, p3/2, 1, p3/2, 0
 	iFrqMin random 10, 1000
    kFrqBwIn = 40
    endif
iGainClr ampdb -7
iGainBw ampdb -10
iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0

	;;clr
  kAmpClr rspline 0.3, 0.4, 2, 5
  kFrqClrIn = 270
  kFrqClr rspline kFrqClrIn, kFrqClrIn*1.01, 0.4, 0.7
  kStiff rspline -0.4, -0.18, 2, 3
  iAtt1 = 1.2
  iDetk = 0.1
  kAirNoise rspline 0, 0.5, 2, 3
  kVibClr jspline 50, 0.4, 0.7
  kvAmpClr rspline 0.5, 2, 2, 7
  aClar wgclar kAmpClr*iGainClr, kFrqClr, kStiff, iAtt1, iDetk, \
  kAirNoise, kVibClr, kvAmpClr, iWave, iFrqMin
  ;;bow
   kAmpBw rspline 0.3, 0.4, 2, 5
   kPres rspline 0.01, 5, 5, 10
	kRate rspline 0.025, 0.225, 4, 13
	kVibBw jspline 0.1, 0.9, 1
	kvAmpBw = 0.02
	kCent = 50
	kFrqCent jspline kCent, 0.1, 0.4
	kFrqBw = kFrqBwIn*cent(kFrqCent)
   aBow  wgbow kAmpBw*iGainBw, kFrqBw, kPres, kRate, kVibBw, kvAmpBw,\
   iWave, iFrqMin
   ;;output
   aSum sum  aBow , aClar
   kFilt rspline 700, 5000, 0.4, 0.7
   aFilt clfilt aSum, kFilt, 0, 10
   aFilt clfilt aFilt, 150, 1, 10
   aDel delay aFilt, 0.4
   aMix ntrpol aFilt, aDel, 0.3  
   aOut = aMix*iGainMaster*aEnv
  outall aOut
endin

instr FxDust
aIn chnget "snddust"
aRvrb,aRvrb  reverbsc aIn,aIn, 0.65, 17000, sr, 1, 1
aMix ntrpol aIn, aRvrb, 0.4
	iRel = 2
	aEnv linsegr 1, iRel, 0
	aOut = aMix*aEnv
outall aOut
chnclear "snddust"
endin

instr FxSeq
aIn chnget "sndseq"
	
 	aTim	interp	giDelayTime
 	abuf	delayr	15
 	aDelay	deltapi	aTim	
 	delayw	aIn + (aDelay*giFeedback)
 	kDelayMix rspline 0.2, 0.7, 1, 3
 	aDelayMix ntrpol aIn, aDelay, kDelayMix
 	aRvrb,aRvrb  reverbsc aDelayMix,aDelayMix, 0.7, 3000, sr, 0.3, 1
;	aRvrb reverb aDelayMix, 1
	kRvbMix rspline 0.3, 0.7, 2, 5
	aMix ntrpol aIn, aRvrb, kRvbMix
	iRel = 2
	aEnv linsegr 1, iRel, 0
	aOut = aMix*aEnv
outall aOut
chnclear "sndseq"
endin


instr FxWg
aIn chnget "sndwg"
aRvrb,aRvrb  reverbsc aIn,aIn, 0.85, 17000, sr, 1, 1
aMix ntrpol aIn, aRvrb, 0.3
	iRel = 2
	aEnv linsegr 1, iRel, 0
	aOut = aMix*aEnv
outall aOut
chnclear "sndwg"
endin

gkSpeaker1 init -45
gkSpeaker2 init -45
gkSpeaker3 init -60
gkSpeaker4 init -60
instr speaker
iMidi notnum
iVel veloc

;print iMidi,iVel
iSpeed = 20
iStart1 = i(gkSpeaker1)
iStart2 = i(gkSpeaker2)
iStart3 = i(gkSpeaker3)
iStart4 = i(gkSpeaker4)

if iMidi == 0 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1-1))
    if gkSpeaker1 <= -90 then
    gkSpeaker1 = -90
    endif
elseif iMidi == 1 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1+1))
    if gkSpeaker1 >= 20 then
    gkSpeaker1 = 20
    endif
endif

if iMidi == 2 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2-1))
    if gkSpeaker2 <= -90 then
    gkSpeaker2 = -90
    endif
elseif iMidi == 3 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2+1))
    if gkSpeaker2 >= 20 then
    gkSpeaker2 = 20
    endif
endif

if iMidi == 4 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3-1))
    if gkSpeaker3 <= -90 then
    gkSpeaker3 = -90
    endif
elseif iMidi == 5 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3+1))
    if gkSpeaker3 >= 20 then
    gkSpeaker3 = 20
    endif
endif

if iMidi == 6 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4-1))
    if gkSpeaker4 <= -90 then
    gkSpeaker4 = -90
    endif
elseif iMidi == 7 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4+1))
    if gkSpeaker4 >= 20 then
    gkSpeaker4 = 20
    endif
endif


if iMidi == 0 || iMidi == 1 then
cabbageSetValue  "out1", gkSpeaker1+65
cabbageSetValue  "outn1", gkSpeaker1
endif
if iMidi == 2 || iMidi == 3 then
cabbageSetValue  "out2", gkSpeaker2+65
cabbageSetValue  "outn2", gkSpeaker2
endif
if iMidi == 4 || iMidi == 5 then
cabbageSetValue  "out3", gkSpeaker3+65
cabbageSetValue  "outn3", gkSpeaker3
endif
if iMidi == 6 || iMidi == 7 then
cabbageSetValue  "out4", gkSpeaker4+65
cabbageSetValue  "outn4", gkSpeaker4
endif
endin

instr time
kTimer line 0, 1, 1
kSec = int(kTimer)
kMin init 0
kSec = kSec % 60
if kSec == 0 && changed(kSec) == 1 then
kMin += 1
endif
STimer sprintfk "%02d : %02d", kMin, kSec
cabbageSet 1, "sec", "text", STimer

endin

instr Widgets
iDurMaster = 9^9
kStart init 0
kStart cabbageGet "start"

if kStart == 1 && changed(kStart) == 1  then
schedulek "time", 0, iDurMaster
schedulek "FxWg", 0, iDurMaster
elseif kStart == 0 && changed(kStart) == 1 then
turnoff2 "time", 0, 0
turnoff2 "FxWg", 0, 0
endif

;;DustMachine
 kDustMachine ctrl7 10, 57, 0, 1
    if kDustMachine == 1 && changed(kDustMachine) == 1 then
    cabbageSet 1,"dustlight","colour(200, 70, 200)"
    schedulek "FxDust", 0, iDurMaster
    schedulek "dustMachine", 0, iDurMaster
    schedulek "noiseSound", 0, 9999
    elseif kDustMachine == 0 && changed(kDustMachine) == 1 then
    cabbageSet 1,"dustlight","colour(80, 50, 50, 255)"
    turnoff2 "dustMachine", 0, 0
    turnoff2 "noiseSound", 0, 0
;    turnoff2 "pulseSound", 0, 0
    turnoff2 "guiroPlay", 0, 0
    turnoff2 "guiroSound", 0, 0
    turnoff2 "FxDust", 0, 1
    endif

;;seqMachine
 kSeqMachine ctrl7 10, 58, 0, 1
    if kSeqMachine == 1 && changed(kSeqMachine) == 1 then
    cabbageSet 1,"seqlight","colour(100, 200, 100)"
    schedulek "FxSeq", 0, iDurMaster
    schedulek "seqMachine", 0, iDurMaster
    elseif kSeqMachine == 0 && changed(kSeqMachine) == 1 then
    cabbageSet 1,"seqlight","colour(80, 50, 50, 255)"
    turnoff2 "seqMachine", 0, 0
    turnoff2 "sineSound", 0, 0
    turnoff2 "barSound", 0, 0
    turnoff2 "bamSound", 0, 0
    turnoff2 "shakeSound", 0, 0
    turnoff2 "pluckSound", 0, 0
    turnoff2 "FxSeq", 0, 1
    endif



;;wgMachin
 kwgBow ctrl7 10, 59, 0, 1
    if kwgBow == 1 && changed(kwgBow) == 1 then
    cabbageSet 1,"bowlight","colour(200, 150, 100)"
    schedulek "bowMachine", 0, iDurMaster
    elseif kwgBow == 0 && changed(kwgBow) == 1 then
    cabbageSet 1,"bowlight","colour(80, 50, 50, 255)"
    turnoff2 "bowMachine", 0, 0
    turnoff2 "bowSound", 0, 0
    endif
 kwgFlute ctrl7 10, 60, 0, 1
    if kwgFlute == 1 && changed(kwgFlute) == 1 then
    cabbageSet 1,"flutelight","colour(100, 200, 100)"
    schedulek "fltMachine", 0, iDurMaster
    elseif kwgFlute == 0 && changed(kwgFlute) == 1 then
    cabbageSet 1,"flutelight","colour(80, 50, 50, 255)"
    turnoff2 "fltMachine", 0, 1
    turnoff2 "fluteSound", 0, 0
    endif
 kwgClr ctrl7 10, 61, 0, 1
    if kwgClr == 1 && changed(kwgClr) == 1 then
    cabbageSet 1,"clarinetlight","colour(70, 200, 250)"
    schedulek "clrMachine", 0, iDurMaster
    elseif kwgClr == 0 && changed(kwgClr) == 1 then
    cabbageSet 1,"clarinetlight","colour(80, 50, 50, 255)"
    turnoff2 "clrMachine", 0, 1
    turnoff2 "clarinetSound", 0, 0
    endif
 kwgAmb ctrl7 10, 62, 0, 1
    if kwgAmb == 1 && changed(kwgAmb) == 1 then
    cabbageSet 1,"wgamblight","colour(50, 50, 250)"
    schedulek "ambwgMachine", 0, iDurMaster
    elseif kwgAmb == 0 && changed(kwgAmb) == 1 then
    cabbageSet 1,"wgamblight","colour(80, 50, 50, 255)"
    turnoff2 "ambwgMachine", 0, 1
    turnoff2 "wgAmbSound", 0, 0
    endif



;schedule "seqMachine", 0, 9999
;schedule "FxSeq", 0, 9999

;schedule "DustMachine", 0, 9999
;schedule "FxDust", 0, 9999
;schedule "noiseSound", 0, 1999

;schedule "wgMachine", 0, 9999
;schedule "FxWg", 0, 9999

endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

