<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


instr 1
kAmpdb rspline -20, 20, 50, 70
kAmp ampdb kAmpdb
kRndFrq rspline 40, 800, 2, 8
a1 dust kAmp, kRndFrq
a2 poscil kAmp, 400
idBClip ampdb -10
aIn = a1
aOut clip aIn, 1, idBClip
  
outall aOut
endin

</CsInstruments>
<CsScore>
i1 0 9999
</CsScore>
</CsoundSynthesizer>






<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
