<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



instr 1
if metro(1) == 1 then
schedulek 2, 0, 1
endif
endin


instr 2
print 1
;gkK = 120-130
;gkT30 = 0.3-30
;gkb = 0.0001-10
;gkpos = 0.7-0.9
;gkvel = 300-30000
;gkscan = 0.2-100
;gkwid = 0.03
;gkbcL = 0-1
;gkbcR = 0-1

; #i0 = 1.000  #i1 = 1.000  #i2 = 130.000  #i3 = 0.077  #i4 = 0.775  #i5 = 20.000  #i6 = 0.837  #i7 = 16000.000  #i8 = 0.016

kbcL = 1
kbcR = 1
iK =  130
ib = 0.077
kscan  = 0.775
iT30 = 20
ipos =  0.837 
ivel = 16000
iwid = 0.016


	aSound 	barmodel 	kbcL+1, kbcR+1, iK, ib, kscan,   iT30, ipos, ivel, iwid

outall aSound
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>






<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>631</x>
 <y>103</y>
 <width>320</width>
 <height>240</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
