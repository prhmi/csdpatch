<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0

instr 1
 kTime init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 kFrq init 7000
 if metro(kTime) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 3))
 	kSeqValue random 1/3, 1/2
 	trim kSeqArr, kLen
 		kIndx = 0
 		while kIndx < kLen-1 do
		kRndSeq random 0, 0.2
 		kSeqArr[kIndx] = kSeqValue+kRndSeq
 		kIndx += 1
 		od
 	kMaxValue random 1/7, 1/15
 	kSeqArr[kLen-1] = kMaxValue
 	kFrq random 1000, 9000
 	kLoop random 2, 4
 	endif 
 kLenOut random 1, 7
 kDur random 0.5, 3
 schedulek 2, 0, 1, kFrq, kLoop,kLenOut
 	kIndx = 0
 	kFrq2 random 1000, 9000 
 	kNumber random 1, 6
 	while kIndx < int(kNumber) do
 	kStart random 1, 7
 	schedulek 3, kStart, 1, kFrq2, kLoop
 	kIndx += 1
 	od
 kTime = kSeqArr[kIndxSeq]
 kIndxSeq = (kIndxSeq+1) % kLen
 endif

aNoise noise 0.5, 0.1
kDustFrq rspline 1, 20, 2, 7
kDustFilt rspline 3000, 5000, 0.4, 0.7
	aDust dust 0.1, kDustFrq
	aFiltDust clfilt aDust, kDustFilt, 0, 10
	aFiltDust clfilt aFiltDust, 1000, 1, 10
kFilter rspline 400, 450, 0.4, 0.7
aFilt clfilt aNoise, kFilter, 0, 10
aFilt clfilt aFilt, 150, 1, 10
aOut 	comb aFilt+aFiltDust, 3, 0.3
chnmix aOut, "snd"
endin




instr 2
iLen = int(p6)
print iLen
indx = 0
iStart = 0
while indx < iLen do
schedule 3, iStart, 1,p4,p6
iStart += 0.175
indx += 1
od

endin

instr 3
iFrqIn = p4
iFrq random iFrqIn, iFrqIn*1.01
iNum random 128, 128
iAmp = (iFrqIn/10000)^2
aSound  guiro iAmp*0.1, 0, 128, 0, 0, iFrq, iFrq*2
iLoopDur = p5
iRndLoop random 3, 10
iLoop = iLoopDur/iRndLoop
aComb comb aSound, iLoopDur, iLoop
iFrqRnd random 0, 100
iRel = 0.1
;aRel transegr 1, iRel, -6, 0
aRes reson aSound, iFrq*1.1+iFrqRnd, 200
chnmix aRes, "snd"
;outall aSound
endin

instr 4
kTimeBow init 1
if metro(1/kTimeBow) == 1 then
kTimeBow random 5, 7
kDurBow = kTimeBow*1.3
;schedulek 5, 0, kDurBow
endif
kTimeBrass init 1
if metro(1/kTimeBrass) == 1 then
kTimeBrass random 5, 7
kDurBrass = kTimeBrass*1.3
schedulek 6, 0, kDurBrass
endif
kTimeFlute init 1
if metro(1/kTimeFlute) == 1 then
kTimeFlute random 5, 7
kDurFlute = kTimeFlute*1.3
;schedulek 7, 0, kDurFlute
endif
endin

instr 5
;iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
iWave     ftgenonce 1,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
 	iBaseFrq = 100
 	iFrqMin = 300
 kSpeedMin = 0.031
 kSpeedMax = 0.4
 kVibSpeed = 1
	kAmp   rspline  0.2, 0.7, 0.7, 1
	kCentFrq    jspline  100, kSpeedMin, kSpeedMax
	kFrq = iBaseFrq*cent(kCentFrq)
	kPres  rspline  3, 4, kSpeedMin, kSpeedMax
;	kRate   rspline 0.025, kPosIn, kSpeedMin, kSpeedMax
kPosIn = 0.75
	kRate   rspline 0.025, kPosIn, kSpeedMin, kSpeedMax
	kVibIn = 0.0052
	kVib   rspline  0, kVibIn, kSpeedMin, kSpeedMax
	aBow	wgbow    kAmp,kFrq,kPres,kRate,kVib,kVibSpeed,iWave, iFrqMin
		kFilterBow = 700
    aFiltBow clfilt aBow, kFilterBow, 0, 10
    aFiltBow clfilt aFiltBow, 150, 1, 10

    aOut linen aFiltBow, p3/2, p3, p3/2
	
;	outall aOut
	chnmix aOut, "sndwg"
endin

instr 6
iGain = 1
;iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
iWave     ftgenonce 1,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
 	iBaseFrq = 270 ;random 250, 500
 kSpeedMin = 0.2
 kSpeedMax = 7
	kAmpBrass  rspline  0.3, 0.5, 0.7, 1
	kCent = 0
	kBrassCent   jspline  kCent, kSpeedMin, kSpeedMax
	kFrqBrass = iBaseFrq*cent(kBrassCent)
	kTens rspline  0.4, 0.45, kSpeedMin, kSpeedMax
	iAtt = 0
	kvibf rspline 0.01, 3, 5, 17
	kvamp rspline 0.3, 0.4, 2, 15
	aBrass wgbrass kAmpBrass, kFrqBrass, kTens, iAtt, kvibf, kvamp, iWave
kBrass rms aBrass, 0.01
 kBrass dbamp kBrass 
iTrsh = -35
 kFctr = iTrsh-kBrass
 kLimitdB ampdb kFctr
if kLimitdB >= 1 then
kLimitdB = 1
endif
 aLimiter interp kLimitdB
 aDelay delay aBrass, 0.5
 aBrassOut = aDelay*aLimiter
	
	
	
	iLoopDur random 0.5, 4
	iLoop random 0.1, 0.5
	aBrassOut comb aBrassOut, iLoopDur, iLoop
;	aBrass limit aBrass, -60, -5
		kFilterBrass = 15000
    aFiltBbrass clfilt aBrassOut, kFilterBrass, 0, 10
    aFiltBbrass clfilt aFiltBbrass, 300, 1, 10
    
        aOut linen aFiltBbrass*iGain, p3/2, p3, p3/2

;	outall aOut
	chnmix aOut, "sndwg"
endin


instr 7
;iWave  ftgen     0,0,2^10,9, 1,3,0, 3,1,0, 9,0.333,180
iWave     ftgenonce 3,0,1024,9  ,  1, .4,  0, 2.2, .5, 0,   3.8, 1, 0
iBaseFrq random 10, 50
 kSpeedMin = 0.03
 kSpeedMax = 0.1
kAmp rspline 0.03, 0.2, kSpeedMin, kSpeedMax
kJet rspline 0.01, 0.9, kSpeedMin, kSpeedMax
kVib rspline 0, 2, kSpeedMin, kSpeedMax
kVamp rspline 0.1, 0.5, kSpeedMin, kSpeedMax
kCent = 0
kGliss jspline kCent, kSpeedMin, kSpeedMax
kFrq = iBaseFrq*cent(kGliss)
iAtt = 0.5
   aFlute  wgflute kAmp, kFrq, kJet, iAtt, 0.5, 0.4, kVib, kVamp, iWave

		kFilterFlute = 1200
    aFiltFlute clfilt aFlute, kFilterFlute, 0, 10
    aFiltFlute clfilt aFiltFlute, 250, 1, 10
    aOut linen aFiltFlute, p3/2, p3, p3/2
  chnmix aOut, "sndwg"
endin


instr 98
aIn chnget "snd"
aRvrb,aRvrb  reverbsc aIn,aIn, 0.65, 17000, sr, 1, 1
aMix ntrpol aIn, aRvrb, 0.4

outall aMix
chnclear "snd"
endin

instr 99
aIn chnget "sndwg"
aRvrb,aRvrb  reverbsc aIn,aIn, 0.85, 17000, sr, 1, 1
aMix ntrpol aIn, aRvrb, 0.3

outall aMix
chnclear "sndwg"
endin

</CsInstruments>
<CsScore>

;i 1  0 9999
i 4  0 9999

i 98 0 9999 
i 99 0 9999 
</CsScore>
</CsoundSynthesizer>






<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
