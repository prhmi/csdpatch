<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



seed 0

instr 1
	kNoiseFrq rspline 400, 700, 0.1, 0.3
	kFrqD rspline 0.1, 7, 2, 3
	a1 dust 0.2, kFrqD
	kFrqG rspline 0.1, 7, 2, 3
	a2 gausstrig 0.2, kFrqG, 0.5
	a3 noise 0.5, 0.5
	kFl rspline 400, 500, 2, 3
	a3 clfilt a3, kFl, 0, 10
	a3 clfilt a3, kFl, 1, 10
	kFrq rspline kNoiseFrq, kNoiseFrq*1.01, 1, 12
	aSine phasor kFrq, 5
	aout = a3*aSine
	aComb comb aout, 2, 0.15
	outall aComb
endin

</CsInstruments>
<CsScore>
i1 0 999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
