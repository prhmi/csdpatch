<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0


opcode limiter, a,ai
aIn, iThrshhol xin
kThrsh rms aIn, 0.1
kTrig metro 20
kMax max_k aIn, kTrig, 1
kAmpdB dbamp kMax
if kAmpdB <= -90 then
kAmpdB = -90
elseif kAmpdB >= 1 then
kAmpdB = 1
endif
 kFctr = iThrshhol-kAmpdB
 kLimitdB ampdb kFctr
if kLimitdB >= 1 then
kLimitdB = 1
endif
 aLimiter interp kLimitdB
 aDelay delay aIn, 0.1
 aOut = aDelay*aLimiter
xout aOut
endop


instr 1
 kTime init 1
 kIndxSeq init 0
 kSeqArr[] init 32
 if metro(1/kTime) == 1 then
 	if kIndxSeq == 0 then 	
 	kLen = int(random:k(1, 12))
 	trim kSeqArr, kLen
 		kIndx = 0 
 		while kIndx < kLen-1 do
 		kSeqValue random 1, 3
 		kSeqArr[kIndx] = kSeqValue
 		kIndx += 1
 		od
 	kMaxValue random 15, 20
 	kSeqArr[kLen-1] = kMaxValue
 	endif 
 kInstr = int(random:k(2, 7))
 schedulek kInstr, 0, kTime
 kIndxSeq = (kIndxSeq+1) % kLen
 kTime = kSeqArr[kIndxSeq]/10
 endif
endin

instr 2
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
iFrq random 200, 1200
iAtt = 0.005
iAmp = 0.1
aEnv transeg 0, iAtt, 4, iAmp, p3-iAtt, -6, 0
aSound poscil aEnv, iFrq
chnmix aSound, "snd"
endin

instr 3
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
iFrq random 10, 70
;kScan rspline 0.1, 0.8, p3*2, p3*4
iPoseMin random 0.001, 1
iPoseMax random 2, 10
iScan = random(0, 100) > 90 ? iPoseMin : iPoseMax
iRel = 0.5 ;random 0.01, 0.5
iPose = 0.005 ;random 0.001, 0.1
iPres random 0.1, 0.5
aSound    barmodel       1, 1, iFrq, iRel, iScan, 1, iPose, 50000, iPres
iAtt = 0.001
aEnv transeg 0, iAtt, 6, 1;, p3-iAtt, -6, 0
iFilter random 800, 3000
aFilt clfilt aSound*aEnv, iFilter, 1, 10
;outall aFilt
chnmix aFilt, "snd"
endin

instr 4
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
p3 random 0.05, 3
iFrq random 10, 50
iFilter random 3000, 8000
iAtt = 0.01
aEnv transeg 0, iAtt, 6, 0.5, p3-iAtt, -6, 0
iAmp = 2000
iNumber random 1, 7
iDamp random 0.0001, 0.05
iDecay random 0.001, 0.1
aSound  bamboo iAmp, iDecay, iNumber, iDamp, 1, iFrq, 400
aFilt clfilt aSound*aEnv, iFilter, 1, 10
aLimit limiter aFilt, -15
chnmix aLimit, "snd"
endin


instr 5
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
p3 random 0.01, 0.1
iRel random 0.1, 1
aEnv linsegr 1, iRel, 0
knum  rspline 2, 15, 2, 7
kFrq rspline 700, 3000, 2, 15
asig shaker .03, kFrq, 8, 0.9, knum
iFilter random 300, 500
aFilt clfilt asig*aEnv, iFilter, 1, 10		
chnmix aFilt, "snd"
endin


instr 6
giDelayTime random 0.1, 1
giFeedback random 0.1, 0.5
giRvrbTime random 0.7, 0.9
iAmp random 0.3, 0.5
iAtt random 0.008, 0.01
iRel random 0.1, 1
aEnv linsegr 0, iAtt, 1, iRel, 0
iFrq random 30, 1500
iResample random 20, 1500
iMeth = random:i(0, 100) < 50 ? 1 : 6
aSound  pluck iAmp, iFrq, iResample, 0, iMeth;, 2, 1
iFilter random 300, 1500
aFilt clfilt aSound*aEnv, iFilter, 0, 10	
aFilt clfilt aSound*aEnv, 200, 1, 10	
chnmix aFilt, "snd"
endin

instr 99
aIn chnget "snd"
	
 	aTim	interp	giDelayTime
 	abuf	delayr	15
 	aDelay	deltapi	aTim	
 	delayw	aIn + (aDelay*giFeedback)
 	kDelayMix rspline 0.2, 0.7, 1, 3
 	aDelayMix ntrpol aIn, aDelay, kDelayMix
 	aRvrb,aRvrb  reverbsc aDelayMix,aDelayMix, 0.7, 3000, sr, 0.3, 1
;	aRvrb reverb aDelayMix, 1
	kRvbMix rspline 0.3, 0.7, 2, 5
	aMix ntrpol aIn, aRvrb, kRvbMix
	aOut = aMix
outall aOut
chnclear "snd"
endin

</CsInstruments>
<CsScore>
i1 0 9999
i99 0 9999
</CsScore>
</CsoundSynthesizer>














<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
