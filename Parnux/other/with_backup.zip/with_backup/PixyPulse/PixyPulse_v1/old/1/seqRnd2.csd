<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0

opcode lenRnd, k[], k[]
 kInArr[] xin
 kLen = 2; int(random:k(2, 5))
 
 xout kInArr
endop

instr 1
 kSeqArr[] init 32
 if metro(2) == 1 then
 kLen = int(random:k(1, 5))
trim kSeqArr, kLen
 	printarray kSeqArr
 endif
endin

</CsInstruments>
<CsScore>
i1 0 9999
</CsScore>
</CsoundSynthesizer>


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
