;v5
<Cabbage>
form caption("DoubleCoreLa")    size(1200, 700)   guiMode("queue")  colour(25, 35, 50, 230) pluginId("crlp") ; style("legacy")
label    bounds(30, 104, 28, 12)    channel("label3")  text("seq") 
label    bounds(30, 144, 28, 12)   channel("label5")  text("bss")
label    bounds(30, 124, 28, 12)   channel("label6")  text("rep")
label    bounds(36, 258, 40, 12)   channel("label8")  text("On/Off")
label    bounds(30, 302, 28, 12)   channel("label10") text("seq")
label    bounds(30, 342, 28, 12)   channel("label12") text("bss")
label    bounds(30, 322, 28, 12)   channel("label13") text("rep")
label    bounds(594, 276, 46, 12)  channel("label15") text("Reverse")
label    bounds(594, 78, 46, 12)   channel("label16") text("Reverse")
label    bounds(16, 62, 60, 20)  channel("noteshow1")  fontColour(220, 234, 245, 255) align("left")  text("")
label    bounds(20, 232, 60, 20)  channel("noteshow2")  fontColour(220, 234, 245, 255) align("left") text("")
checkbox bounds(646, 76, 18, 18)   channel("rvrs1")   popupText("Synth")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(0)
checkbox bounds(646, 274, 18, 18)  channel("rvrs2")   popupText("Synth")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) 
checkbox bounds(14, 258, 18, 18)   channel("sq2")     popupText("Start")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255)  value(1)
nslider  bounds(90, 29, 60, 45)     channel("bpm1")   range(10, 210, 90, 1, 1)    fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("BPM") 
nslider  bounds(150, 44, 40, 30)    channel("DV1")     range(1, 10, 4, 1, 1)       fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("DV") 
nslider  bounds(192, 35, 40, 40)    channel("steps1")  range(1, 28, 13, 1, 1)     fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("Step")
nslider  bounds(90, 236, 60, 45)   channel("bpm2")    range(10, 250, 90, 1, 1)   fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("BPM") 
nslider  bounds(150, 250, 40, 30)  channel("DV2")     range(1, 10, 4, 1, 1)      fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("DV") 
nslider  bounds(192, 240, 40, 40)  channel("steps2")  range(1, 28, 13, 1, 1)      fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("Step")
nslider  bounds(492, 236, 45, 38)  channel("oct")  range(-2, 2, 0, 1, 1)      fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("octv") 

nslider bounds(340, 34, 90, 40) channel("att1") range(0.0001, 0.5, 0.001, 1, 0.0001) fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("att")
nslider bounds(340, 240, 90, 40) channel("att2") range(0.0001, 0.5, 0.001, 1, 0.0001)  fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("att")
nslider bounds(246, 34, 90, 40) channel("dur1") range(0.05, 5, 1.5, 1, 0.01) fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("duration")
nslider bounds(244, 240, 90, 40) channel("dur2") range(0.05, 5, 1.5, 1, 0.01)  fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("duration")

vslider bounds(788, 10, 50, 150) channel("amp1") range(0, 1, 0.4, 1, 0.001) trackerColour(160, 200, 250, 255)text("ampS1")
vslider bounds(792, 236, 50, 150) channel("amp2") range(0, 20, 15, 1, 1) trackerColour(160, 200, 250, 255) text("ampS2")
vslider bounds(672, 506, 60, 181) channel("amp3") range(0, 80, 60, 1, 1) trackerColour(160, 200, 250, 255) text("ampPad")
vslider bounds(734, 506, 60, 181) channel("amp4") range(0, 80, 60, 1, 1) trackerColour(160, 200, 250, 255) text("ampPad")
combobox bounds(712, 72, 70, 30)   channel("BNote")   text("Note", "G", "A-", "Bb", "C", "E-", "D-", "F", "A", "B", "Gb", "D", "E")   value(2) colour(50, 54, 60, 255)
combobox bounds(672, 36, 110, 35)   channel("scale")   text("Scale", "pythagorean", "shur", "abuata", "bayat tork", "afshari", "dashti", "nava", "segah", "chargah", "homayun", "bayat esf")  value(2) colour(50, 54, 60, 255)
combobox bounds(712, 268, 70, 30)  channel("BNote2")  text("Note", "G", "A-", "Bb", "C", "E-", "D-", "F", "A", "B", "Gb", "D", "E")   value(2) colour(50, 54, 60, 255)
combobox bounds(672, 232, 110, 35) channel("scale2")  text("Scale", "pythagorean", "shur", "abuata", "bayat tork", "afshari", "dashti", "nava", "segah", "chargah", "homayun", "bayat esf") value(2)  colour(50, 54, 60, 255)
combobox bounds(682, 104, 100, 30)   channel("sound1")  text("Instr", "sine", "tri", "saw", "square", "myset", "vco")   value(6) colour(50, 54, 60, 255)
combobox bounds(682, 300, 100, 30)   channel("sound2")  text("Instr", "sine", "tri", "saw", "square", "myset", "vco", "pick", "dahina", "wood", "tibetan", "albert")  value(4) colour(50, 54, 60, 255)
combobox bounds(590, 36, 70, 30)  channel("seqmod1")  text("seq", "tala", "aRnd", "iRnd")   value(1) colour(50, 54, 60, 255)
combobox bounds(590, 234, 70, 30)  channel("seqmod2")  text("seq","tala","aRnd", "iRnd")   value(1) colour(50, 54, 60, 255)
label bounds(934, 54, 239, 66) channel("sec")fontColour(220, 234, 245, 255) text("00 : 07")
button bounds(1054, 22, 116, 27) channel("start") text("S  T  A  R  T", "S  T  O  P") colour:0(124, 150, 204, 255) colour:1(69, 72, 96, 255) value(1)
label bounds(978, 24, 66, 28) channel("data")  fontColour(220, 234, 245, 255) colour(50, 60, 70, 255) text("0")
label bounds(932, 22, 44, 31) channel("chndata")  fontColour(220, 234, 245, 255) colour(50, 60, 70, 255) text("0")
combobox bounds(816, 478, 66, 31)  channel("tune")  text("440", "432")   value(2) colour(50, 54, 60, 255)
label bounds(70, 414, 564, 31) channel("narrshow") fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)  text("") align("left")   
label bounds(68, 474, 90, 40) channel("data1") fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)   text("")
label bounds(164, 474, 90, 40) channel("data2") fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)    text("")
label bounds(260, 474, 90, 40) channel("data3") fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)   text("")
label bounds(356, 474, 90, 40) channel("data4") fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)    text("")
label bounds(452, 474, 90, 40) channel("data5") fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)    text("")
label bounds(548, 474, 90, 40) channel("data6") fontColour(220, 234, 245, 255) colour(50, 60, 70, 255)    text("")
vslider bounds(914, 532, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(160, 200, 250, 255)
vslider bounds(956, 532, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(160, 200, 250, 255)
vslider bounds(996, 532, 50, 150) channel("out3") range(0, 80, 0, 1, 1)trackerColour(160, 200, 250, 255)
vslider bounds(1038, 532, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(160, 200, 250, 255)
nslider bounds(1088, 464, 93, 44) channel("gain") range(-90, 50, 0, 1, 1) colour(49, 64, 79, 255) text("Master Gain (dB)")
nslider bounds(920, 496, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(49, 64, 79, 255)
nslider bounds(960, 496, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(49, 64, 79, 255)
nslider bounds(1000, 496, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(49, 64, 79, 255)
nslider bounds(1040, 496, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(49, 64, 79, 255)
combobox bounds(812, 622, 83, 34) channel("delayt") text("sec", "sync") colour(50, 54, 60, 255) value(2)
combobox bounds(816, 544, 70, 35), populate("*.snaps"), channelType("string") automatable(0) channel("combo99") value("0")  colour(50, 54, 60, 255)
filebutton bounds(820, 516, 60, 25), text("Save", "Save"), populate("*.snaps", "test"), mode("named preset") channel("filebutton8")  colour:0(50, 54, 60, 255)
filebutton bounds(822, 584, 60, 25), text("Remove", "Remove"), populate("*.snaps", "test"), mode("remove preset") channel("filebutton101")  colour:0(50, 54, 60, 255)
vmeter bounds(1092, 532, 15, 150) channel("meter1")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1116, 532, 15, 150) channel("meter2")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1140, 532, 15, 150) channel("meter3")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
vmeter bounds(1164, 532, 15, 150) channel("meter4")  outlineColour(0, 0, 0, 255), overlayColour(0, 0, 0, 255)    outlineThickness(0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255)
image bounds(1092, 518, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(1116, 518, 15, 15) channel("clip2") colour(0, 0, 0, 255)
image bounds(1140, 518, 15, 15) channel("clip3") colour(0, 0, 0, 255)
image bounds(1164, 518, 15, 15) channel("clip4") colour(0, 0, 0, 255)
image bounds(162, 234, 15, 15) channel("fast1") corners(1) colour(70, 62, 68, 255)
image bounds(162, 28, 15, 15) channel("fast2") corners(1) colour(70, 62, 68, 255)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0


opcode MtoNameInt, S,i
iMidi xin 
SNoteArr[] fillarray "C", "C#", "D", "D#","E","F", "F#", "G","G#", "A", "Bb", "B"
iAraziArr[] fillarray 1, 3, 6, 8, 10
iNoteIndex = (iMidi) % 12
iNoteIndxInt = int(iNoteIndex)
iSCent = int((iMidi-int(iMidi))*100.5)
if iSCent  == 0 then
Sout sprintf "%s",SNoteArr[iNoteIndex]
elseif iSCent == 100 then
Sout sprintf "%s",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
else
		if iSCent > 50 then
		Sout sprintf "%s-",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
		elseif iSCent <= 50 then
		Sout sprintf "%s+",SNoteArr[iNoteIndex]
			indx = 0			
			while indx < lenarray(iAraziArr) do
				if iNoteIndxInt = iAraziArr[indx] then
				Sout sprintf "%s-",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
				endif
			indx += 1
			od
		endif
endif
xout Sout
endop



giTableSize    =    131073   
giRtosScale    =    1000  

giSine  	 ftgen		0, 0, 2^10,10,1
giSineTwo  	 ftgen		0, 0, 2^10,10,1, 0.5
giMyset      ftgen		0, 0, 2^10,10,1, 0.7, 0, 0.1, 0, 0, 0.3, 0, 0, 0, 0.2
ift          vco2init   -1, 10000, 0, 0, 0, giMyset


giwave1        ftgen    0, 0, giTableSize, 9, 1000,1.000,0, 2890,0.500,0,		\
					     4950,0.250,0,     6990,0.125,0,     8010,0.062,0,     			\
					     9020,0.031,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,	\
					     0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,   	\
					     0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,    	\
					     0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,    	\
					     0,0.000,0
giwave2    ftgen    0, 0, giTableSize, 9, 1000,1.000,0,     2572,0.667,0,  	\
						  4644,0.444,0,     6984,0.296,0,     9723,0.198,0,   				\
						   0,0.132,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,    \
						   0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,     \
						   0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,     \
						   0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,     \
						   0,0.000,0
giwave3        ftgen    0, 0, giTableSize, 9, 1000,1.000,0,     1027,1.000,0,\
					     1422,1.000,0,     1448,1.000,0,     1466,1.000,0,     \
					     1499,1.000,0,     1789,1.000,0,     1877,1.000,0,     \
					     1965,1.000,0,     1979,1.000,0,     2033,1.000,0,     \
					     2145,1.000,0,     2156,1.000,0,     2253,1.000,0,     \
					     2291,1.000,0,     2333,1.000,0,     2457,1.000,0,     \
					     2493,1.000,0,     2566,1.000,0,     2606,1.000,0,     \
					     2669,1.000,0,     2714,1.000,0

giwave4    ftgen    0, 0, giTableSize, 9, 1000,1.000,0,     1002,0.833,0, \
					    1794,0.694,0,     1801,0.579,0,     2520,0.482,0,    \
					    2522,0.402,0,     2991,0.335,0,     2994,0.279,0,     \
					    3786,0.233,0,     3806,0.194,0,     4569,0.162,0,     \
					    4575,0.135,0,     5030,0.112,0,     5046,0.093,0,     \
					    6076,0.078,0,     5909,0.065,0,     6412,0.054,0,     \
					    6443,0.045,0,     7083,0.038,0,     7092,0.031,0,     \
					    7319,0.026,0,     7555,0.022,0







;;midi
opcode RmvZ, i[],i[]
iArrIn[] xin
iLen lenarray iArrIn
indxc = 0
iLenA = 0
while indxc < iLen do
	if iArrIn[indxc] != 0 then
	iLenA += 1
	endif
indxc += 1
od
		if iLenA == 0 then
		iLenA = 1
		endif
iArrOut [] init iLenA
indx = 0
indxw = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iArrOut [indxw] = iArrIn[indx]
	indxw += 1
	endif
indx += 1
od
xout iArrOut
endop


opcode skpZ, i[],i[]
iArrIn[] xin
iLen lenarray iArrIn
indxc = 0
iLenA = 0
while indxc < iLen do
	if iArrIn[indxc] != 0 then
	iLenA += 1
	endif
indxc += 1
od
		if iLenA == 0 then
		iLenA = 1
		endif
iArrOut[] init iLen
indx = 0
indxw = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iArrOut[indxw] = iArrIn[indx]
	indxw += 1
	endif
indx += 1
od
xout iArrOut
endop


;;string
opcode StrToArr, i[],S
SIn xin
Snote     sprintf "%s ",SIn
iLen strlen SIn
iReadChar = 0
iLenCount = 0
while iReadChar < iLen do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	od	
	iReadChar2 = iReadChar+1
			while strchar(Snote,iReadChar2) == 32 do
			iReadChar2 += 1
			iReadChar += 1
			od
iReadChar += 1
iLenCount += 1
od
iArrOut [] init iLenCount

iWrite = 0
iRead = 0
while iRead < iLen do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
		Schar     strsub    Snote, iStart, iStart+iCountChr
	if strchar(Schar,0) != 0 then
	inum strtod Schar
	;print inum
	iArrOut [iWrite] = inum
	iWrite += 1
	endif
iRead += 1
od
xout iArrOut
endop

opcode ArrToStrg, S,i[]
  iArrIn [] xin
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    Sscale     sprintf " %d",iArrIn[indx]
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop



opcode ArrToStrgN, S,i[]
  iArrIn[] xin
  
  iArrIn RmvZ iArrIn
  
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    SNote MtoNameInt iArrIn[indx]
    Sscale     sprintf "%s ", SNote
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop





;;scale
giScaleArr[] init 13
giNormal[]          fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
giPythaArr[]        fillarray 1, 2187/2048, 9/8, 32/27, 81/64, 4/3, 729/512, 3/2, 6561/4096, 27/16, 16/9, 243/128, 2/1
giShurArr[] 	    fillarray 0, 1.5, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1
giAbuataArr[] 		fillarray 0, 0.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
giBayattorkArr[] 	fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5
giAfshariArr[] 		fillarray 0, 1.5,0.5, 1, 1, 1, 1, 1, 1.5,0.5, 1, 1
giDashtiArr[] 		fillarray 0, 1, 1, 1, 1, 1, 1.5,0.5,  1, 1, 1, 1
giNavaArr[] 		fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5, 1, 1
gi3gahArr[] 		fillarray 0, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1, 1
gi4gahArr[] 		fillarray 0, 1.5, 0.5, 1, 1,1, 1, 1, 1.5, 0.5, 1, 1
giHomayunArr[]   	fillarray 0, 0.5, 1, 1, 1,1, 1, 1.5, 0.5, 1, 1, 1
giBayatEsArr[]   	fillarray 0, 1,1,1, 1, 1,1,1, 1.5, 0.5, 1.5, 0.5

opcode pythagorean,i,ii
iBaseNote,iNote xin
iMidi = iNote
		iOct = 0
     until iMidi < iBaseNote+12 do
  		iMidi = iMidi-12
  		iOct += 1
  		enduntil
 iMidiMin = (iMidi-iBaseNote)
  	iRatio = 1
  	if iMidiMin == 0 then
  	iRatio = 1/1
  	elseif iMidiMin == 1 then
  	iRatio = 2187/2048
  	elseif iMidiMin == 2 then
  	iRatio = 9/8
  	elseif iMidiMin == 3 then
  	iRatio = 32/27
  	elseif iMidiMin == 4 then
  	iRatio = 81/64
  	elseif iMidiMin == 5 then
  	iRatio = 4/3
  	elseif iMidiMin == 6 then
  	iRatio = 729/512
  	elseif iMidiMin == 7 then
  	iRatio = 3/2
  	elseif iMidiMin == 8 then
  	iRatio = 6561/4096
  	elseif iMidiMin == 9 then
  	iRatio = 27/16
  	elseif iMidiMin == 10 then
  	iRatio = 16/9
  	elseif iMidiMin == 11 then
  	iRatio = 243/128
  	elseif iMidiMin == 12 then
  	iRatio = 2/1
  	endif 	
iBaseFrq mtof iBaseNote+(iOct*12)
iFrq = (iBaseFrq)*iRatio
iMidiOut ftom iFrq
xout iMidiOut
endop


opcode dastgah, i,i[]iii
  iInArr[],iBaseMidi,iMidiIn,iQ xin
  iLen lenarray iInArr
  iOutArr[] init iLen
  iNote = iBaseMidi
  indx = 0
	while indx < iLen do
	iNote = iNote+(iInArr[indx])
	iOutArr[indx] = iNote
	indx += 1
	od
	iMidi = int(iMidiIn)+iQ
	indxOct = 0
	     until iMidi < iBaseMidi+12 do
	     indxOct += 1
  		iMidi = iMidi-12
  		enduntil
  		iIntrval = (iMidi-iBaseMidi)
iMidiOut = iOutArr[iIntrval]+(12*indxOct)
SnoteOut mton iMidiOut
  xout iMidiOut
endop




opcode noteBase, ii, i
iBaseNoteIn xin
if iBaseNoteIn == 2 then
SbaseNote = "0G"
iQ = 0
elseif iBaseNoteIn == 3 then
SbaseNote = "0A-"
iQ = 1
elseif iBaseNoteIn == 4 then
SbaseNote = "0Bb"
iQ = 0
elseif iBaseNoteIn == 5 then
SbaseNote = "0C"
iQ = 0
elseif iBaseNoteIn == 6 then
SbaseNote = "0E-"
iQ = 1
elseif iBaseNoteIn == 7 then
SbaseNote = "0D-"
iQ = 1
elseif iBaseNoteIn == 8 then
SbaseNote = "0F"
iQ = 0
elseif iBaseNoteIn == 9 then
SbaseNote = "0A"
iQ = 0
elseif iBaseNoteIn == 10 then
SbaseNote = "0B"
iQ = 0
elseif iBaseNoteIn == 11 then
SbaseNote = "0Gb"
iQ = 0
elseif iBaseNoteIn == 12 then
SbaseNote = "0D"
iQ = 0
elseif iBaseNoteIn == 13 then
SbaseNote = "0E"
iQ = 0
endif
iBaseNote ntom SbaseNote
xout iBaseNote, iQ
endop


opcode noteScale, i,iiii
iMidiNote, iBaseNote, iScale,iQ xin
if iScale == 1 then
iMidiOut = iMidiNote
elseif iScale == 2 then
iMidiOut pythagorean iBaseNote,iMidiNote
elseif iScale == 3 then
iMidiOut dastgah giShurArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 4 then
iMidiOut dastgah giAbuataArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 5 then
iMidiOut dastgah giBayattorkArr,iBaseNote,iMidiNote, iQ
elseif iScale == 6 then
iMidiOut dastgah giAfshariArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 7 then
iMidiOut dastgah giDashtiArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 8 then
iMidiOut dastgah giNavaArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 9 then
iMidiOut dastgah gi3gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 10 then
iMidiOut dastgah gi4gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 11 then
iMidiOut dastgah giHomayunArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 12 then
iMidiOut dastgah giBayatEsArr,  iBaseNote,iMidiNote, iQ
endif
xout iMidiOut
endop



opcode MirrorMe,i,iii
iValue,iMin,iMax xin
iMiddle = iMin+((iMax-iMin)/2)
if iValue == iMiddle then
iOut = iValue
elseif iValue > iMiddle then
iOut = iMiddle - (iValue-iMiddle)
elseif iValue < iMiddle then
iOut = iMiddle + (iMiddle-iValue)
endif
xout iOut

endop


opcode rateCCk, k, kii
kValue, iMin, iMax xin
iDiff = iMax-iMin
kOut = (kValue*iDiff)+iMin
xout kOut
endop 


opcode rateCCi, i, iii
iValue, iMin, iMax xin
iDiff = iMax-iMin
iOut = (iValue*iDiff)+iMin
xout iOut
endop 


 giArrNote[]    init 11
 giArrEmpty[]   init lenarray:i(giArrNote)
 giArrVeloc[]   init lenarray:i(giArrNote)
 giArrVel[] =   giArrVeloc
 giLenVel       lenarray giArrVel
; giNote[]       fillarray 1,1
 giWriteNote    init 0


gSfile1 init 0
gSfile2 init 0

giSteps init 28
giStepArr1[]    init giSteps
giAccArr1[]     init giSteps
giRepArr1[]     init giSteps
giBassArr1[]    init giSteps

giStepArr2[]    init giSteps
giAccArr2[]     init giSteps
giRepArr2[]     init giSteps
giBassArr2[]    init giSteps


massign 1,1
massign 3,13
massign 5,15
massign 7,16
massign 16,31


massign 2,0
massign 4,0
massign 6,0
massign 8,0
massign 9,0
massign 10,0
massign 11,0
massign 12,0
massign 13,0
massign 14,0
massign 15,0

ctrlinit 3, 64, 1
pgmassign 0, 0

iLenSeq init 11
gkNote init 0

 giArrNote[]    init iLenSeq
 giNote[] init iLenSeq
 giArrEmpty[]   init iLenSeq
 giWriteNote init 0
 gkSec init 0


instr GetMidi ;1
 iActive active "GetMidi"
 iHold cabbageGetValue "hold"
 kHold cabbageGet "hold"
 kRel release
 iMidi notnum
  if iActive == 1 then
  giArrNote[] = giArrEmpty
  giWriteNote = 0
  endif
 giArrNote[giWriteNote] = iMidi
 giWriteNote = (giWriteNote+1) % lenarray(giArrNote)
giNote[] RmvZ giArrNote
 giLenNote lenarray giNote
 gkLenNote lenarray giNote
 
 SnArrShow ArrToStrgN giNote
     SnoteShow     sprintf "text(%s)", SnArrShow
    cabbageSet "narrshow",SnoteShow
; puts SnArrShow,1
; printarray giNote,"%d","Notes:"
 
 if kRel == 1 && kHold == 0  then
 schedulek "rmvMidi", 0, 0.1, iMidi
 endif
 
endin
instr rmvMidi ;2
 iRead = 0
    while iRead < lenarray(giArrNote) do
        if giArrNote[iRead] == p4 then
        giArrNote[iRead] = 0
        endif
    iRead += 1
    od
 giArrNote[] skpZ giArrNote
 giNote[] RmvZ giArrNote
 
 
  giLenNote lenarray giNote
 gkLenNote lenarray giNote
 
 
   giNoteCopyArr[] = giNote
 SnArrShow ArrToStrgN giNote
      SnoteShow     sprintf "text(%s)", SnArrShow
    cabbageSet "narrshow",SnoteShow
; puts SnArrShow,1

; printarray giNote,"%d","Notes(R):"
 giWriteNote -= 1
endin


instr seq1
schedule "copyArr1", 0, 1
kActive1 active 1
kDing cabbageGet "dng1"
kHold cabbageGet "hold"
kAtt cabbageGet "att1"
gkSeqIndx1   init 0
kNoteIndx  init 0
kBPM cabbageGet "bpm1"
kTempo = kBPM/60
kTms cabbageGet "DV1"
kSteps cabbageGet "steps1"
kRndWidget cabbageGet "seqmod1"
kTime = (kTempo*kTms)
ksel = 0
kNoteIn = giNote[ksel]
kDur cabbageGet "dur1"


kFilterIn cabbageGet "slider1"
kFilterBsIn cabbageGet "slider2"
kFilter rateCCk kFilterIn, 300, 8000
kFilterBs rateCCk kFilterBsIn, 0, 800

    if metro(kTime) == 1 then
    if kNoteIn > 20 then
    ;;sound
    SseqValue sprintfk "sqsteps%d",gkSeqIndx1
    kSeqValue cabbageGet SseqValue
        if kSeqValue == 1 then 
        kNoteIndx  = (kNoteIndx+1)  % giLenNote
            if changed(gkLenNote) == 1 then
            kNoteIndx = gkLenNote-1
            endif
            kNote  = giNote[kNoteIndx]
            iSeqAmp = -10
            schedulek "Sound1" ,0,kDur,kNote, kAtt,iSeqAmp, kFilter
        endif
    ;;Bss
    SbssValue sprintfk "sqsteps%d",gkSeqIndx1+(giSteps*2)
    kBssValue cabbageGet SbssValue
    if kBssValue == 1 then
    	kBidx = 0
        kNoteBass = giNote[kBidx]
	    until kNoteBass < 45 do
  		kNoteBass = kNoteBass-12
  		enduntil
    iBassAtt = 0.005
    iBassAmpdB = -3
        schedulek "Sound1" ,0,kDur,kNoteBass, iBassAtt,iBassAmpdB, kFilterBs
    endif
    ;;Rep
    SrepValue sprintfk "sqsteps%d",gkSeqIndx1+(giSteps)
    kRepValue cabbageGet SrepValue
    if kRepValue == 1 then
        kNoteRep = kNote
	    until kNoteRep > 80 do
  		kNoteRep = kNoteRep+12
  		enduntil
    kRepR = ((int(random:k(0,6)))/4)+1
        if kRepR <= 1.5 then
        kRepT = int(random:k( 3,7))
        else
        kRepT = int(random:k( 2,4))
        endif
    kDurRep = (1/kTime)/kRepR
    kTrigRep = kDurRep
    kndxRep = 0
        while kndxRep < kRepT do
        iRepAtt = 1/5000
        iRepAmpdB = -15
			schedulek "Sound1",kTrigRep,kDurRep,kNoteRep, iRepAtt,iRepAmpdB, kFilter
	    kTrigRep += kDurRep
		kndxRep += 1
		od	
    endif
    endif
    schedulek "LEDon1",0,0.1,gkSeqIndx1
    schedulek "LEDoff1",1/kTime,0.1,gkSeqIndx1
        if gkSeqIndx1 == 0 && changed(gkSeqIndx1) == 1 then 
            if kRndWidget == 1 && changed(kRndWidget) == 1 && gkSec > 5 then
            schedulek "ResetWidget1", 0, 1
            elseif kRndWidget == 2 then
            schedulek "RndtWidget1", 0, 1
            elseif kRndWidget == 3 then
            schedulek "RndaWidget1", 0, 1
            elseif kRndWidget == 4 then
            schedulek "RndiWidget1", 0, 1
            endif
        endif
    gkSeqIndx1 = (gkSeqIndx1+1) % kSteps
    endif
endin

instr LEDon1
Slte sprintf "lte%d",p4
cabbageSet 1,Slte,"colour(160, 200, 250, 255)"
endin
instr LEDoff1
Slte sprintf "lte%d",p4
cabbageSet 1,Slte,"colour(100, 100, 100, 200)"
endin



;gifn vco2init giSine 
instr Sound1 ;5
iMidi = p4
iAmpIn cabbageGetValue "amp1"
iAmpdB rateCCi iAmpIn, -30, 20
iAmp ampdb iAmpdB+p6
iBaseNoteIn cabbageGetValue "BNote"
iScale      cabbageGetValue "scale"
iBaseMidi,iQ noteBase iBaseNoteIn
iMidiOut noteScale iMidi,iBaseMidi,iScale, iQ
Snote MtoNameInt iMidiOut
if changed(Snote) == 1 then
    SnoteShow     sprintf "text(%s)", Snote
    cabbageSet "noteshow1",SnoteShow
endif
gkNote = iMidiOut
iFrqIn mtof iMidiOut
iTuneIn cabbageGetValue "tune"
    if iTuneIn == 1 then
    iTune = 440
    elseif iTuneIn == 2 then
    iTune = 432
    endif
iRatio = iTune/440
iFrq = iFrqIn*iRatio

iAtt = p5
    if iMidi <= 55 && iAtt < 0.001 then
    iAtt = 0.005
    endif

iRvrs cabbageGetValue "rvrs1"
if iRvrs == 0 then
 aEnv transeg 0, iAtt,1, iAmp, p3-iAtt,-6, 0
elseif iRvrs == 1 then
        if iAtt <= 0.008 then
        iAtt = 0.008
        endif
        if iMidi > 80 then
        iAtt = p3*0.4
        endif
 aEnv transeg 0, p3*(1-iAtt),4, iAmp,p3*iAtt,-4,0
endif

 

kpwIn cabbageGet "slider3"
kpw rateCCk kpwIn, 0.05, 0.95
 iSineMod cabbageGetValue "sound1"
 

if iSineMod == 2 then
aSound poscil aEnv, iFrq, giSineTwo
elseif iSineMod == 3 then
iMod = 12; tria
elseif iSineMod == 4 then
iMod = 0 ;saw
elseif iSineMod == 5 then
iMod = 2 ; square
elseif iSineMod == 6  then
iMod = 14 ;mey set
elseif iSineMod == 7  then
iMod = 0 ;vco
else
iMod = 1
endif

if iSineMod != 2 then
aVco    vco2   1,iFrq,iMod, kpw
aSound = aVco*aEnv
endif



iFilter  = p7
aOut clfilt aSound, iFilter+(iFrq*0.7), 0, 10
chnmix aOut, "sndseq1"
endin




instr seq2
kActive1 active 1
schedule "copyArr2", 0, 1
kDing cabbageGet "dng2"
kHold cabbageGet "hold"
gkSeqIndx2   init 0
kNoteIndx  init 0
kVelocIndx init 0
kBPM cabbageGet "bpm2"
kTempo = kBPM/60
kTms cabbageGet "DV2"
kSteps cabbageGet "steps2"
kAtt cabbageGet "att2"
kOctave cabbageGet "oct"
kRndWidget cabbageGet "seqmod2"
kOct = 12*kOctave
kTime = (kTempo*kTms)
;printk2 kTime
ksel = 0
kNoteIn = giNote[ksel]
kDur cabbageGet "dur2"

kFilterIn cabbageGet "slider1"
kFilterBsIn cabbageGet "slider2"
kFilter rateCCk kFilterIn, 300, 8000
kFilterBs rateCCk kFilterBsIn, 0, 800

    if metro(kTime) == 1 then
    if kNoteIn > 20 then
    ;;sound
    SseqValue sprintfk "sqsteps%d",gkSeqIndx2+(giSteps*3)
    kSeqValue cabbageGet SseqValue
        if kSeqValue == 1 then 
        kNoteIndx  = (kNoteIndx+1)  % giLenNote
            if changed(gkLenNote) == 1 then
            kNoteIndx = gkLenNote-1
            endif
            kNote  = giNote[kNoteIndx]+kOct
            schedulek "Sound2" ,0,kDur,kNote, kAtt, -1,kFilter
        endif
    ;;Bss
    SbssValue sprintfk "sqsteps%d",gkSeqIndx2+(giSteps*5)
    kBssValue cabbageGet SbssValue
    if kBssValue == 1 then
    kBidx = 0
    kNoteBass = giNote[kBidx]
        until kNoteBass < 45 do
  	    kNoteBass = kNoteBass-12
  		enduntil
        schedulek "Sound2" ,0,kDur,kNoteBass, 0.005, -1, kFilterBs
    endif
    ;;Rep
    SrepValue sprintfk "sqsteps%d",gkSeqIndx2+(giSteps*4)
    kRepValue cabbageGet SrepValue
    if kRepValue == 1 then
    kNoteRep = kNote
	    until kNoteRep > 90 do
  		kNoteRep = kNoteRep+12
  		enduntil
     kRepR = ((int(random:k(0,3)))/2)+1
     kRepT = int(random:k( 2,7))
     kDurRep = (1/kTime)/kRepR
     kTrigRep = kDurRep
     kndxRep = 0
        while kndxRep < kRepT do
		    schedulek "Sound2",kTrigRep,kDurRep,kNoteRep, 0.0005, -3, kFilter
		kTrigRep += kDurRep
		kndxRep += 1
		od	
    endif
    endif
    schedulek "LEDon2",0,0.1,gkSeqIndx2
    schedulek "LEDoff2",1/kTime,0.1,gkSeqIndx2
        if gkSeqIndx2 == 0 && changed(gkSeqIndx2) == 1 then 
            if kRndWidget == 1 && changed(kRndWidget) == 1 && gkSec > 5 then
            schedulek "ResetWidget2", 0, 1
            elseif kRndWidget == 2 then
            schedulek "RndtWidget2", 0, 1
            elseif kRndWidget == 3 then
            schedulek "RndaWidget2", 0, 1
            elseif kRndWidget == 4 then
            schedulek "RndiWidget2", 0, 1
            endif
        endif
    gkSeqIndx2 = (gkSeqIndx2+1) % kSteps
    endif
endin

instr LEDon2
Slte sprintf "lte%d",p4+giSteps
cabbageSet 1,Slte,"colour(160, 200, 250, 255)"
endin
instr LEDoff2
Slte sprintf "lte%d",p4+giSteps
cabbageSet 1,Slte,"colour(100, 100, 100, 200)"
endin

instr Sound2 ;5
iMidi = p4
iAmpIn cabbageGetValue "amp1"
iAmpdB rateCCi iAmpIn, -30, 20
iAmp ampdb iAmpdB+p6
iBaseNoteIn cabbageGetValue "BNote2"
iScale      cabbageGetValue "scale2"
iBaseMidi,iQ noteBase iBaseNoteIn
iMidiOut noteScale iMidi,iBaseMidi,iScale, iQ
Snote MtoNameInt iMidiOut
if changed(Snote) == 1 then
    SnoteShow     sprintf "text(%s)", Snote
    cabbageSet "noteshow2",SnoteShow
endif


iFrqIn mtof iMidiOut
iTuneIn cabbageGetValue "tune"
    if iTuneIn == 1 then
    iTune = 440
    elseif iTuneIn == 2 then
    iTune = 432
    endif
iRatio = iTune/440
iFrq = iFrqIn*iRatio

iAtt = p5
    if iMidi <= 55 && iAtt < 0.001 then
    iAtt = 0.005
    endif
iRvrs cabbageGetValue "rvrs2"
if iRvrs == 0 then
 aEnv transeg 0, iAtt,6, iAmp, p3-iAtt,-6, 0
elseif iRvrs == 1 then
        if iAtt <= 0.008 then
        iAtt = 0.008
        endif
        if iMidi > 80 then
        iAtt = p3*0.4
        endif
 aEnv transeg 0, p3*(1-iAtt),4, iAmp,p3*iAtt,-4,0
endif

kpwIn cabbageGet "slider3"
kpw rateCCk kpwIn, 0.05, 0.95
 iSineMod cabbageGetValue "sound2"
 

if iSineMod == 2 then
aSound poscil aEnv, iFrq, giSineTwo
elseif iSineMod == 3 then
iMod = 12; tria
elseif iSineMod == 4 then
iMod = 0 ;saw
elseif iSineMod == 5 then
iMod = 2 ; square
elseif iSineMod == 6  then
iMod = 14 ;mey set
elseif iSineMod == 7  then
iMod = 0 ;vco
else
iMod = 1
endif

if iSineMod != 2 then
aVco    vco2   1,iFrq,iMod, kpw
aSound = aVco*aEnv
endif



iFilter  = p7
aOut clfilt aSound, iFilter+(iFrq*0.7), 0, 10
chnmix aOut, "sndseq2"
endin


;--------------------------------------------------
;pad sound

instr AmbientMachine
iBaseNoteIn cabbageGetValue "BNote"
iBaseMidi,iQ noteBase iBaseNoteIn
kTime init 1
if metro(1/kTime) == 1 then

kTime random 3, 7
kDur = kTime*1.3
    if gkNote != 0 then
    kMidi = gkNote
    else
    kMidi random 45, 55
    endif
    if kMidi == 0 then
    kMidi = iBaseMidi
    endif
        until kMidi > 45 do
  		kMidi = kMidi+12
  		enduntil
      	until kMidi < 55 do
  		kMidi = kMidi-12
  		enduntil 
    schedulek "AmbientSound", 0, kDur, kMidi
endif
endin


instr AmbientSound
kAmpdB ampdb 0
    cabbageSet 1,"mtrx1","colour(100, 150, 200)"
    kRelease release
    if kRelease == 1 then
    cabbageSet 1,"mtrx1","colour(70, 62, 68, 255)"
    endif
kCentIn cabbageGet "slider1"
kCentIn rateCCk kCentIn, 0, 500
iMidi = p4
 iFrqIn mtof iMidi
iTuneIn cabbageGetValue "tune"
    if iTuneIn == 1 then
    iTune = 440
    elseif iTuneIn == 2 then
    iTune = 432
    endif
iRatio = iTune/440
iFrq = iFrqIn*iRatio


kPoseIn      cabbageGet "slider2"
kSpeedMinIn   cabbageGet "slider3"
kSpeedMaxIn   cabbageGet "slider4"
kFilterIn     cabbageGet "slider5"
kPose   rateCCk kPoseIn, 0.7, 20
kbriteIn rateCCk kPoseIn, 1, 20
kFrqRnd   rateCCk kPoseIn, 0, 2
kFilter    rateCCk kFilterIn, 200, 3000
kSpeedMin  rateCCk kSpeedMinIn, 1, 10
kSpeedMax  rateCCk kSpeedMaxIn, 3, 12

kCent1 jspline kCentIn, kSpeedMin/10, kSpeedMax/10
kCent2 jitter kCentIn, kSpeedMin/10, kSpeedMax/10
kFrq1 = k(iFrq)*cent(kCent1)
kFrq2 = k(iFrq)*cent(kCent2)
kFrqRnd1 jspline kFrqRnd, kSpeedMin, kSpeedMax
kFrqRnd2 = kFrqRnd1*(-1)
iAmp        ampdb -16
avco        vco iAmp, kFrq1, 3, .5, giSine
avcoFlt     clfilt avco, kFilter, 0, 10
avcoFlt     clfilt avcoFlt, 200, 1, 10

iblend ftgen 2, 0, 1024, -19, 1, 0.5, 270, 0.5
;iwave  ftgen 1, 0, 1024, 10, 10, 1, 2, 5, 2, 1
iwave  ftgen 1, 0, 1024, 10, 1, 1, 1, 1
  kbrite    jspline kbriteIn, kSpeedMin, kSpeedMax
  ibasfreq  random 50, 120
  ktone     rspline 0.1, kbriteIn/5,  kSpeedMin/10, kSpeedMax/10
aSboscil hsboscil ampdb(-10), ktone, kbrite, ibasfreq, iwave, iblend, 8, 1
aFiltSboscil clfilt aSboscil, kFilter, 0, 10
aFiltSboscil clfilt aFiltSboscil,300,1,10
  iAtt random 1, 2
  if iAtt >= p3/2 then
  iAtt = p3/2
  endif
 aEnv transeg 0, iAtt, 1, 1, p3-(iAtt*2),1, 1, iAtt, -4, 0
; aEnv linen 1, iAtt, p3, iAtt
 aEnvR linsegr 1, 0.1, 0
;xtratim iAtt/2
aOut = (avcoFlt+aFiltSboscil)*kAmpdB*aEnv*aEnvR
	chnmix aOut, "sndpad"
endin




instr sineMidi
isAmp ampdb  0
 ;isAmp = 0 ;cabbageGetValue "seqamp"
 iAmp ampdb -35
 iNum notnum
 iFrqIn mtof iNum
iTuneIn cabbageGetValue "tune"

kVibRng cabbageGet "slider2"
kVibSpd cabbageGet "slider3"

kVibRng rateCCk kVibRng, 1, 200
kVibSpd rateCCk kVibSpd, 1, 23
    if iTuneIn == 1 then
    iTune = 440
    elseif iTuneIn == 2 then
    iTune = 432
    endif
iRatio = iTune/440
iFrq = iFrqIn*iRatio
 iVel veloc 5, 0.1
 iAtt = (iVel^5)/1000
    if iAtt <= 0.001 then
    iAtt = 0.001
    endif
 iRel  random 0.5, 1
    aEnv linsegr 0, iAtt, 1, iRel, 0
    iRnd1 random 1.1, 2
    iRnd2 random 1.5, 3
    kVib randi kVibRng, kVibSpd
    kVib = int(kVib/10) * 10 
 aSine1 poscil iAmp, iFrq+kVib, giMyset, 0
 aSine2 poscil iAmp*0.8, (iFrq*iRnd1)+kVib, giMyset, 0.25
 aSine3 poscil iAmp*0.5, (iFrq*iRnd2)+kVib, giMyset, 0.5
 aSound sum aSine1,aSine2,aSine3
 aOut = aSound*aEnv
; chnmix aOut, "sndpad"
 outall aOut
endin


instr PadFx
aIn chnget "sndpad"
	aRvrb nreverb aIn,1, 0.3
	aMix		ntrpol	 aIn,aRvrb,  .4
outall aMix
 
chnclear "sndpad"
endin


;;--------------------------------------------------------------
;sample




instr hold
 cabbageSetValue "hold",p4
endin

instr Empty ;7
if p4 == 1 then
 giArrNote[] = giArrEmpty
 giNote[] = giArrEmpty
    SnoteShow     sprintf "text(%s)", " "
    cabbageSet "narrshow",SnoteShow
elseif p4 == 2 then
giArrVel[] RmvZ giArrVeloc
giLenVel lenarray giArrVel
;printarray giArrVel, "%d"
endif
endin


;-------------------------------------------------------
;Effects


instr FxSeq

kPortTime linseg 0, 0.01, 0.0001
;;seq
iBPM            cabbageGetValue "bpm1"
iTms            cabbageGetValue "DV1"
iDelayTimeIn    cabbageGetValue "delaytseq"
kFeedback       cabbageGet "dfbseq"
kDelayMix       cabbageGet "dmixseq"
kRvrbMix        cabbageGet "rmixseq"
kSizeRvrb       cabbageGet "rsizeseq"
kRoomRvrb       cabbageGet "rroomeseq"


iDelay = 1+(int(iDelayTimeIn*5))

iTime = (1/((iBPM/60)*iTms))*iDelay
iDelayT cabbageGetValue "delayt"
if iDelayT == 1 then
iDelayTime = iDelayTimeIn
elseif iDelayT == 2 then
iDelayTime = iTime
endif


aIn1 chnget "sndseq1"
aIn2 chnget "sndseq2"


aSound sum aIn1,aIn2


aDelay init 0
aDelay  delay    aSound+(aDelay*kFeedback), iDelayTime
  	aDelMix		ntrpol	 aSound,aDelay,  kDelayMix
 
  
;  aRvrb	nreverb	aSound, 1, 0.2

  aRvrb,aRvrb  reverbsc aSound,aSound, kSizeRvrb, kRoomRvrb, sr, 1, 1
  
  aRvrbMix ntrpol aSound,aRvrb, kRvrbMix
  
  aMixOut = (aDelMix+aRvrbMix)/2
  outall aMixOut
  chnclear "sndseq1", "sndseq2"
endin



;-------------------------------------------------------
;widgets
instr widgetWrite    
 iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 while indx < giSteps*6 do
 SSteps    sprintf "bounds(%d, %d, 18, 18),valueTextBox(0)\
 channel(\"sqsteps%d\"),colour:0(70, 70, 70) colour:1(160, 200, 250)",\
 iX+65+ispcx, iY+100, indx
 cabbageCreate "checkbox", SSteps 
 iX = (iX+21)
 indx += 1
    if (indx%4) == 0 then
    iX += 4
;    ispcx = 0
    endif
    if (indx%giSteps) == 0 then
    iY += 21
    iX = 0
    endif
    if (indx%(giSteps*3)) == 0 then
    iY += 136
    endif
 od
 iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 while indx < giSteps*2 do
 Sleds    sprintf "bounds(%d, %d, 16, 16),valueTextBox(0)\
 channel(\"lte%d\") colour(100, 100, 100, 200)",\
 iX+66+ispcx, iY+164, indx
 cabbageCreate "image", Sleds
 iX = (iX+21)
 indx += 1
    if (indx%4) == 0 then
    iX += 4
    endif
    if (indx%giSteps) == 0 then
    iY += 200
    iX = 0
    endif
 od
  schedule "loadbang", 0.1, 0.1   
      
 iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 while indx < 16 do
 SKnob    sprintf "bounds(%d, %d, 70, 70),valueTextBox(0)\
 channel(\"slider%d\") range(0, 1, 0, 1, 0.01), text(%d)\
 markerColour(255, 255, 255, 255) trackerColour(160, 200, 250)\
  colour(130, 140, 150)",\
 iX+65+ispcx, iY+530, indx+1, indx+1
 cabbageCreate "rslider", SKnob 
 iX = (iX+70)
 indx += 1
    if (indx%4) == 0 then
    iX += 20
    ispcx = 0
    endif
    if (indx%8) == 0 then
    iY += 80
    iX = 0
    ispcx = 0
    endif
 od
 iX = 0
 iY = 0
 indx = 0
 while indx < 16 do
 SmPad    sprintf "bounds(%d, %d, 35, 35),\
 channel(\"mpad%d\") colour:0(70, 70, 70) colour:1(160, 200, 250) text()", \
 iX+850, iY+350, indx+1
 cabbageCreate "button", SmPad 
 iX = (iX+40)
 indx += 1
    if (indx%4) == 0 then
    iX += 5
    endif
    if (indx%16) == 0 then
    iY += 10
    iX = 0
    endif
    if (indx%8) == 0 then
    iY += 40
    iX = 0
    endif
 od
  iX = 0
 iY = 0
 indx = 0
 ispcx = 0
 ispcy = 0
 while indx < 84 do
 Smtrx    sprintf "bounds(%d, %d, 20, 20),\
 channel(\"mtrx%d\") colour(70, 70, 70)", \
 860+iX+ispcx, iY+150+ispcy, indx+1
 cabbageCreate "image", Smtrx 
  iX += 24
  indx += 1
    if (indx%4) == 0 then
    ispcx += 5
    endif
    if (indx%12) == 0 then
    iY += 20
    iX = 0
    ispcx = 0
    endif
    if (indx%12) == 0 then
    ispcy += 5
    endif
 od
endin


instr loadbang
    iArrSeq1[] fillarray 1,0,0,1,1,0,0,1,0,1,0,0,1
    iArrRep1[] fillarray 0,0,0,0,0,1,0,0,0,0,0,0,0
    iArrBas1[] fillarray 0,0,0,0,1,0,0,0,0,0,0,0,0   
    iArrSeq2[] fillarray 0,1,1,0,0,1,0,0,1,0,0,1,0
    iArrRep2[] fillarray 0,0,0,0,0,0,0,0,0,0,0,1,0
    iArrBas2[] fillarray 1,0,0,0,0,0,1,0,0,0,0,0,0
    indx = 0
    while indx < 13 do
     Ssq1 sprintf "sqsteps%d",indx
     Srp1 sprintf "sqsteps%d",(indx+giSteps)
     Sbs1 sprintf "sqsteps%d",indx+(giSteps*2)
     Ssq2 sprintf "sqsteps%d",indx+(giSteps*3)
     Srp2 sprintf "sqsteps%d",indx+(giSteps*4)
     Sbs2 sprintf "sqsteps%d",indx+(giSteps*5)
     cabbageSetValue Ssq1, iArrSeq1[indx]
     cabbageSetValue Srp1, iArrRep1[indx]
     cabbageSetValue Sbs1, iArrBas1[indx]
     cabbageSetValue Ssq2, iArrSeq2[indx]
     cabbageSetValue Srp2, iArrRep2[indx]
     cabbageSetValue Sbs2, iArrBas2[indx]
     indx += 1
    od
endin

instr copyArr1
iLen init 28
giArrCopySeq1[] init iLen
giArrCopyAcc1[] init iLen
giArrCopyRep1[] init iLen
giArrCopyBas1[] init iLen
giStepsCopy1 cabbageGetValue "steps1"
    iWrite = 0
    while iWrite < iLen do
     Ssq sprintf "seq1%d",iWrite
     Sac sprintf "acc1%d",iWrite
     SRp sprintf "rep1%d",iWrite
     Sbs sprintf "bass1%d",iWrite
     giArrCopySeq1[iWrite] cabbageGetValue Ssq
     giArrCopyAcc1[iWrite] cabbageGetValue Sac
     giArrCopyRep1[iWrite] cabbageGetValue SRp
     giArrCopyBas1[iWrite] cabbageGetValue Sbs
     iWrite += 1
    od   
endin

instr copyArr2
iLen init 28
giArrCopySeq2[] init iLen
giArrCopyAcc2[] init iLen
giArrCopyRep2[] init iLen
giArrCopyBas2[] init iLen
giStepsCopy2 cabbageGetValue "steps2"
    iWrite = 0
    while iWrite < iLen do
     Ssq sprintf "seq2%d",iWrite
     Sac sprintf "acc2%d",iWrite
     SRp sprintf "rep2%d",iWrite
     Sbs sprintf "bass2%d",iWrite
     giArrCopySeq2[iWrite] cabbageGetValue Ssq
     giArrCopyAcc2[iWrite] cabbageGetValue Sac
     giArrCopyRep2[iWrite] cabbageGetValue SRp
     giArrCopyBas2[iWrite] cabbageGetValue Sbs
     iWrite += 1
    od   
endin



instr ResetWidget1
gkSeqIndx1 init 0
cabbageSetValue "steps1", giStepsCopy1
iLen init 28
indx = 0 
while indx < iLen do
     Ssq sprintf "seq1%d",indx
     Sac sprintf "acc1%d",indx 
     SRp sprintf "rep1%d",indx 
     Sbs sprintf "bass1%d",indx
     cabbageSetValue Ssq,giArrCopySeq1[indx]
     cabbageSetValue Sac,giArrCopyAcc1[indx]
     cabbageSetValue SRp,giArrCopyRep1[indx]
     cabbageSetValue Sbs,giArrCopyBas1[indx]
indx += 1
od
endin

instr ResetWidget2
gkSeqIndx2 init 0
cabbageSetValue "steps2", giStepsCopy2
iLen init 28
indx = 0 
while indx < iLen do
     Ssq sprintf "seq2%d",indx
     Sac sprintf "acc2%d",indx 
     SRp sprintf "rep2%d",indx 
     Sbs sprintf "bass2%d",indx
     cabbageSetValue Ssq,giArrCopySeq2[indx]
     cabbageSetValue Sac,giArrCopyAcc2[indx]
     cabbageSetValue SRp,giArrCopyRep2[indx]
     cabbageSetValue Sbs,giArrCopyBas2[indx]
indx += 1
od
endin

instr RndtWidget1
iLen cabbageGetValue "steps1"
iArrSeq[] init iLen
iArrRep[] init iLen
iArrBas[] init iLen
    iWrite = 0
    iRead = 1
    while iWrite < iLen do
    Ssq sprintf "seq1%d",iRead 
    SRp sprintf "rep1%d",iRead 
    Sbs sprintf "bass1%d",iRead   
    iSeqValue cabbageGetValue Ssq
    iRepValue cabbageGetValue SRp
    ibasValue cabbageGetValue Sbs
    iArrSeq[iWrite] = iSeqValue
    iArrRep[iWrite] = iRepValue
    iArrBas[iWrite] = ibasValue
     iWrite += 1
     iRead = (iRead+1)%iLen
    od     
    iWrite = 0
    while iWrite < iLen do
     Ssq sprintf "seq1%d",iWrite 
     SRp sprintf "rep1%d",iWrite 
     Sbs sprintf "bass1%d",iWrite    
     cabbageSetValue Ssq,iArrSeq[iWrite]
     cabbageSetValue SRp,iArrRep[iWrite]
     cabbageSetValue Sbs,iArrBas[iWrite]
     iWrite += 1
    od  
endin

instr RndaWidget1
iLen = int(random:i( 8, 18))
cabbageSetValue "steps1", iLen
;iLen cabbageGetValue "steps1"
iArrSeq[] init iLen
    iWrite = 0
    while iWrite < iLen do
    iRndSeq = int(random:i(0,2))
    iArrSeq[iWrite] = iRndSeq
     Ssq sprintf "seq1%d",iWrite  
     SRp sprintf "rep1%d",iWrite   
     cabbageSetValue Ssq,iArrSeq[iWrite]
     cabbageSetValue SRp,0
     iWrite += 1
    od 
iRepIndx = int(random:i(0,iLen)) 
SRp sprintf "rep1%d",iRepIndx 
cabbageSetValue SRp,1
endin


instr RndiWidget1
iLen cabbageGetValue "steps1"
    iWrite = 0
    while iWrite < iLen do
     Ssq sprintf "seq1%d",iWrite 
     Sac sprintf "acc1%d",iWrite 
     SRp sprintf "rep1%d",iWrite 
     Sbs sprintf "bass1%d",iWrite    
     cabbageSetValue Ssq,giArrCopySeq1[iWrite]
     cabbageSetValue Sac,giArrCopyAcc1[iWrite]
     cabbageSetValue SRp,giArrCopyRep1[iWrite]
     cabbageSetValue Sbs,giArrCopyBas1[iWrite]
     iWrite += 1
    od  
iSeqIndx = int(random:i(0,iLen))
iAccIndx = int(random:i(0,iLen))
iRepIndx = int(random:i(0,iLen))
iBasIndx = int(random:i(0,iLen))
iSeqValue = int(random:i(0,2))
iAccValue = int(random:i(0,2))
iRepValue = int(random:i(0,2))
iBasValue = int(random:i(0,2))
     Ssq sprintf "seq1%d",iSeqIndx
     Sac sprintf "acc1%d",iAccIndx 
     SRp sprintf "rep1%d",iRepIndx 
     Sbs sprintf "bass1%d",iBasIndx
     cabbageSetValue Ssq,iSeqValue
     cabbageSetValue Sac,iAccValue
     cabbageSetValue SRp,iRepValue
     cabbageSetValue Sbs,iBasValue
endin


instr RndtWidget2
iLen cabbageGetValue "steps2"
iArrSeq[] init iLen
iArrRep[] init iLen
iArrBas[] init iLen
    iWrite = 0
    iRead = 1
    while iWrite < iLen do
    Ssq sprintf "seq2%d",iRead 
    SRp sprintf "rep2%d",iRead 
    Sbs sprintf "bass2%d",iRead   
    iSeqValue cabbageGetValue Ssq
    iRepValue cabbageGetValue SRp
    ibasValue cabbageGetValue Sbs
    iArrSeq[iWrite] = iSeqValue
    iArrRep[iWrite] = iRepValue
    iArrBas[iWrite] = ibasValue
     iWrite += 1
     iRead = (iRead+1)%iLen
    od     
    iWrite = 0
    while iWrite < iLen do
     Ssq sprintf "seq2%d",iWrite 
     SRp sprintf "rep2%d",iWrite 
     Sbs sprintf "bass2%d",iWrite    
     cabbageSetValue Ssq,iArrSeq[iWrite]
     cabbageSetValue SRp,iArrRep[iWrite]
     cabbageSetValue Sbs,iArrBas[iWrite]
     iWrite += 1
    od  
endin

instr RndaWidget2
iLen = int(random:i( 8, 18))
cabbageSetValue "steps2", iLen
;iLen cabbageGetValue "steps2"
iArrSeq[] init iLen
iArrBas[] init iLen
    iWrite = 0
    while iWrite < iLen do
    iRndSeq = int(random:i(0,2))
    iRndBas = random:i(0,100) > 20 ? 0 : 1
    iArrSeq[iWrite] = iRndSeq
    iArrBas[iWrite] = iRndBas
     Ssq sprintf "seq2%d",iWrite
     SRp sprintf "rep2%d",iWrite
     Sbs sprintf "bass2%d",iWrite
     cabbageSetValue Ssq,iArrSeq[iWrite]
     cabbageSetValue SRp,0
     cabbageSetValue Sbs,iArrBas[iWrite]
     iWrite += 1
    od   
iRepIndx = int(random:i(0,iLen)) 
SRp sprintf "rep2%d",iRepIndx 
cabbageSetValue SRp,1
endin

instr RndiWidget2
iLen cabbageGetValue "steps2"
    iWrite = 0
    while iWrite < iLen do
     Ssq sprintf "seq2%d",iWrite 
     Sac sprintf "acc2%d",iWrite 
     SRp sprintf "rep2%d",iWrite 
     Sbs sprintf "bass2%d",iWrite    
     cabbageSetValue Ssq,giArrCopySeq2[iWrite]
     cabbageSetValue Sac,giArrCopyAcc2[iWrite]
     cabbageSetValue SRp,giArrCopyRep2[iWrite]
     cabbageSetValue Sbs,giArrCopyBas2[iWrite]
     iWrite += 1
    od  
iSeqIndx = int(random:i(0,iLen))
iAccIndx = int(random:i(0,iLen))
iRepIndx = int(random:i(0,iLen))
iBasIndx = int(random:i(0,iLen))
iSeqValue = int(random:i(0,2))
iAccValue = int(random:i(0,2))
iRepValue = int(random:i(0,2))
iBasValue = int(random:i(0,2))
     Ssq sprintf "seq2%d",iSeqIndx
     Sac sprintf "acc2%d",iAccIndx 
     SRp sprintf "rep2%d",iRepIndx 
     Sbs sprintf "bass2%d",iBasIndx
     cabbageSetValue Ssq,iSeqValue
     cabbageSetValue Sac,iAccValue
     cabbageSetValue SRp,iRepValue
     cabbageSetValue Sbs,iBasValue
endin




gkSpeaker1 init -45
gkSpeaker2 init -45
gkSpeaker3 init -60
gkSpeaker4 init -60
gkSpkrCopy1 init -45
gkSpkrCopy2 init -45
gkSpkrCopy3 init -60
gkSpkrCopy4 init -60

instr Speaker
iMidi notnum
iVel veloc
iSpeed = 20
iStart1 = i(gkSpeaker1)
iStart2 = i(gkSpeaker2)
iStart3 = i(gkSpeaker3)
iStart4 = i(gkSpeaker4)

iBaseMidi = 60


if iMidi == iBaseMidi+1 then
print rnd(9)
gkSpeaker1 = gkSpkrCopy1
gkSpeaker2 = gkSpkrCopy2
gkSpeaker3 = gkSpkrCopy3
gkSpeaker4 = gkSpkrCopy4
endif

if iMidi == iBaseMidi then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1-1))
elseif iMidi == iBaseMidi+2 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1+1))
endif
if iMidi == iBaseMidi+4 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2-1))
elseif iMidi == iBaseMidi+5 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2+1))
endif
if iMidi == iBaseMidi+7 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3-1))
elseif iMidi == iBaseMidi+9 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3+1))
endif
if iMidi == iBaseMidi+11 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4-1))
elseif iMidi == iBaseMidi+12 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4+1))
endif
cabbageSetValue  "out1", gkSpeaker1+65
cabbageSetValue  "outn1", gkSpeaker1
cabbageSetValue  "out2", gkSpeaker2+65
cabbageSetValue  "outn2", gkSpeaker2
cabbageSetValue  "out3", gkSpeaker3+65
cabbageSetValue  "outn3", gkSpeaker3
cabbageSetValue  "out4", gkSpeaker4+65
cabbageSetValue  "outn4", gkSpeaker4
endin


instr record
SFilenames[] directory "./record", ".wav"
iLen lenarray SFilenames
print iLen
SrecordFile sprintf "record/record%d.wav", iLen
aInArr[] monitor
aIn = aInArr[0]
fout SrecordFile, 8, aIn
endin

instr Time
kTimer line 0, 1, 1
kSec = int(kTimer)
kMin init 0
kSec = kSec % 60
if kSec == 0 && changed(kSec) == 1 then
kMin += 1
endif
STimer sprintfk "%02d : %02d", kMin, kSec
cabbageSet 1, "sec", "text", STimer
gkSec = kSec
endin

instr Widgets
iDurMaster = 9^9
    schedule "widgetWrite", 0, 1
    
kStart init 0
kStart cabbageGet "start"
kRecord cabbageGet "rcrd"
kSeq2Play cabbageGet "sq2"
if kStart == 1 && changed(kStart) == 1 then
schedulek "Time", 0, iDurMaster
;schedulek "seq1",0,iDurMaster
schedulek "FxSeq" , 0, iDurMaster
schedulek "PadFx",0,iDurMaster
    if kSeq2Play == 1 then
    schedulek "seq2",0,iDurMaster
    endif
    if kRecord == 1 then
    schedulek "record",0,iDurMaster
    endif
elseif kStart == 0 && changed(kStart) == 1 then
turnoff2 "Time", 0, 0
turnoff2 "seq1", 0,0
turnoff2 "seq2", 0,0
turnoff2 "FxSeq", 0,0
turnoff2 "PadFx", 0,0
turnoff2 "record", 0,0
endif

if kSeq2Play == 0 && changed(kSeq2Play) == 1 then
turnoff2 "seq2",0,0
endif
    
    
    
    


  kType, kChn, kNum, kData midiin
if kType == 176 && kNum >= 49 then ;;cc
	if changed(kNum, kData) == 1 then
	printks  "num=%d, value=%d\\n", -1, kNum, kData
	SCCnum sprintfk "mpad%d",(kNum-48)
	cabbageSetValue SCCnum, kData
	endif
elseif kType == 176 && kNum <= 48 then
SsliderNum sprintfk "slider%d",kNum-20
cabbageSetValue SsliderNum , kData/127
endif
    SMidiShow     sprintfk "text(%d)", kData
    cabbageSet 1, "data",SMidiShow
    SChnShow     sprintfk "text(%d)", kChn
    cabbageSet 1, "chndata",SChnShow



    if      cabbageGet:k("mpad1") == 127 && changed(cabbageGet:k("mpad1")) == 1 then
    schedulek "AmbientMachine", 0, iDurMaster
    elseif  cabbageGet:k("mpad1") == 0 && changed(cabbageGet:k("mpad1")) == 1 then
    turnoff2 "AmbientMachine", 0, 0
    turnoff2 "AmbientSound", 0, 1
    endif
    if      cabbageGet:k("mpad2") == 1 && changed(cabbageGet:k("mpad2")) == 1 then
    schedulek "pulseMachine", 0, iDurMaster
    elseif  cabbageGet:k("mpad2") == 0 && changed(cabbageGet:k("mpad2")) == 1 then
    turnoff2 "pulseMachine", 0, 0
    turnoff2 "pulseSound", 0, 0
    endif
    if      cabbageGet:k("mpad3") == 1 && changed(cabbageGet:k("mpad3")) == 1 then
    schedulek "jikjikMachine", 0, iDurMaster
    elseif  cabbageGet:k("mpad3") == 0 && changed(cabbageGet:k("mpad3")) == 1 then
    turnoff2 "jikjikMachine", 0, 0
    turnoff2 "jikjikSound", 0, 0
    endif
    if      cabbageGet:k("mpad4") == 1 && changed(cabbageGet:k("mpad4")) == 1 then
    schedulek "seqMachine", 0, iDurMaster
    elseif  cabbageGet:k("mpad4") == 0 && changed(cabbageGet:k("mpad4")) == 1 then
    turnoff2 "seqMachine", 0, 0
    turnoff2 "seqSound", 0, 0
    endif
    if      cabbageGet:k("mpad5") == 1 && changed(cabbageGet:k("mpad5")) == 1 then
    schedulek "fbSound", 0, iDurMaster
    elseif  cabbageGet:k("mpad5") == 0 && changed(cabbageGet:k("mpad5")) == 1 then
    turnoff2 "fbSound", 0, 0
    endif
    if      cabbageGet:k("mpad6") == 1 && changed(cabbageGet:k("mpad6")) == 1 then
    schedulek "drumMachine", 0, iDurMaster
    elseif  cabbageGet:k("mpad6") == 0 && changed(cabbageGet:k("mpad6")) == 1 then
    turnoff2 "drumMachine", 0, 0
    turnoff2 "drumSound", 0, 0
    endif
 
 kPedal cabbageGet "mpad8"
 kPedal = 127
  if kPedal == 127 && changed(kPedal) == 1 then
  schedulek "hold", 0,0.1,1
  elseif kPedal == 0 && changed(kPedal) == 1 then
  schedulek "Empty",0,0.1,1
  schedulek "hold",0,0.1,0
  endif
   
   kHold cabbageGet "hold"
   kActive1 active 1
    if kHold == 0 && changed(kActive1) == 1 && kActive1 == 0 then
    schedulek "Empty",0,0.1,kActive1+1
    endif
  

endin


</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

