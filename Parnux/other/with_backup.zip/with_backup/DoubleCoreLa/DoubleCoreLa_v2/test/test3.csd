
<Cabbage>
form caption("DoubleCoreLa") size(570, 350)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crlp")
checkbox bounds(10, 10, 20, 20) colour:0(100, 100, 100, 255) popupText("Start")  channel("sq1") colour:1(100, 250, 60, 255) value(1)

;image bounds(92, 160, 10, 10) channel("image10258") colour:0(100, 100, 100, 255)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0



instr 1
iActive active 1
print iActive
endin




</CsInstruments>
<CsScore>

</CsScore>
</CsoundSynthesizer>

