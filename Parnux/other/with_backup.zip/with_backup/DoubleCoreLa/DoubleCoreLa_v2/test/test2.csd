
<Cabbage>
form caption("DoubleCoreLa") size(570, 350)  guiMode("queue")  colour(0,0,0) style("legacy") pluginId("crlp")
checkbox bounds(10, 10, 20, 20) colour:0(100, 100, 100, 255) popupText("Start")  channel("sq1") colour:1(100, 250, 60, 255) value(1)

;image bounds(92, 160, 10, 10) channel("image10258") colour:0(100, 100, 100, 255)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0



instr Widgets
;schedule "widgetWrite",0,0.1
kSeq1Play chnget "sq1"
if kSeq1Play == 1 && changed(kSeq1Play) == 1 then
schedulek "seq1",0,99
elseif kSeq1Play == 0 && changed(kSeq1Play) == 1 then
turnoff2 "seq1",0,1
endif
endin


instr seq1

endin


instr Sound1 ;5

 aSine    poscil    .1,500
 aout = aSine
 out aout,aout
endin


</CsInstruments>
<CsScore>
i "Widgets" 0 999
;i "seq1" 0 999
i "Sound1" 0 9999
</CsScore>
</CsoundSynthesizer>

