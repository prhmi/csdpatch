
<Cabbage>
form caption("DoubleCoreLa") size(650, 350)  guiMode("queue")  colour(30,0,40) style("legacy") pluginId("crlp")
button bounds(56, 142, 70, 30) channel("saveA") text("Save A", "Save A") colour:0(120, 45, 113, 255) colour:1(120, 45, 113, 255)
button bounds(132, 142, 70, 30) channel("saveB") text("Save B", "Save B") colour:0(120, 45, 113, 255) colour:1(120, 45, 113, 255)

button bounds(56, 182, 70, 30) channel("loadA") text("Load A", "Load A") colour:0(120, 45, 113, 255) colour:1(120, 45, 113, 255)
button bounds(132, 182, 70, 30) channel("loadB") text("Load B", "Load B") colour:0(120, 45, 113, 255) colour:1(120, 45, 113, 255)

texteditor bounds(310, 132, 200, 20) channel("saveload") colour(180, 140, 250, 150) colour:0(180, 140, 250, 200)fontSize(20) visible(1)

data channel("sequences"), text("1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1")


</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



opcode ArrToStrg, S,i[]
  iArrIn [] xin
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    Sscale     sprintf "%d ",iArrIn[indx]
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop
opcode StrToArr, i[],S
SIn xin
Snote     sprintf "%s ",SIn
iLen strlen SIn
iReadChar = 0
iLenCount = 0
while iReadChar < iLen do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	od	
	iReadChar2 = iReadChar+1
			while strchar(Snote,iReadChar2) == 32 do
			iReadChar2 += 1
			iReadChar += 1
			od
iReadChar += 1
iLenCount += 1
od
iArrOut [] init iLenCount

iWrite = 0
iRead = 0
while iRead < iLen do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
	Schar     strsub    Snote, iStart, iStart+iCountChr
	if strchar(Schar,0) != 0 then
	inum strtod Schar
	;print inum
	iArrOut [iWrite] = inum
	iWrite += 1
	endif
iRead += 1
od
xout iArrOut
endop



instr widgetWrite
iX = 0
iCount = 0
ispc = 0
        while iCount < 10 do
            Sseq1 sprintf "bounds(%d, 70, 15, 15) , channel(\"seq1%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
            cabbageCreate "checkbox", Sseq1
            iCount += 1
            iX = (iX+1) % 4
            if iX == 0 then
            ispc += 5
            endif
        od
iArrSeq1 [] fillarray 1,0,0,1,1,0,0,1,0,1,0,0,0

        iWrite = 0
        while iWrite < lenarray(iArrSeq1) do
        Ssq1 sprintf "seq1%d",iWrite
        cabbageSetValue Ssq1,iArrSeq1[iWrite]
        iWrite += 1
        od
endin


instr Widgets
schedule "widgetWrite", 0, 1

kSave cabbageGet "saveA"
if changed(kSave) == 1 then
schedulek "saveWidgets", 0, 1
endif


kLoad cabbageGet "loadA"
if changed(kLoad) == 1 then
schedulek "loadWidgets", 0, 1
endif



endin


instr saveWidgets
giArrSave[] init 10
iGetWidgets = 0
while iGetWidgets < 10 do
SArrSave sprintf "seq1%d",iGetWidgets
iArrSave cabbageGetValue SArrSave
giArrSave[iGetWidgets] = iArrSave
iGetWidgets += 1
od
SArrSave ArrToStrg giArrSave
 Sout     sprintf "text(%s)",SArrSave
  ;puts Sscale,1
  Sprint init ""
  Sprint strcat Sprint, Sout
 cabbageSet 1, "saveload",Sprint

endin


instr loadWidgets
SArrLoad cabbageGet "saveload"
iLoadArr[] StrToArr SArrLoad
        iWrite = 0
        while iWrite < 10 do
        SArrLoad sprintf "seq1%d",iWrite
        iValue = iLoadArr[iWrite]
        cabbageSetValue SArrLoad,iValue
        iWrite += 1
        od
endin

</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

