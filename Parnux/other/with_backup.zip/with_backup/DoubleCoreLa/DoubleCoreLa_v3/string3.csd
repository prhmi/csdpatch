<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


instr 1
start:
kAmp = 0.5
kFrq = 800
kFrqLog log kFrq

kSet = ((kFrq/kFrqLog)-5)/200
kPres = jspline:k( 3, 2, 6)+ 3
kRate = jspline:k( kSet, 0.7, 2)+ kSet+0.05
printk2 kRate
kVib =  0;jspline:k( 0.1, 0.7, 1)+ 1
kVamp = jspline:k( 0.1, 0.7, 1)+ 1
aSound wgbow kAmp, kFrq, kPres, kRate, kVib, kVamp, 1
kfr, kdb ptrack aSound, 1024, 10
;printk2 kfr
;if kfr <= (kFrq/2) kgoto start
outall aSound

endin

</CsInstruments>
<CsScore>
f 1 0 2048 10 1
i1 0 30
</CsScore>
</CsoundSynthesizer>








<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>100</x>
 <y>100</y>
 <width>320</width>
 <height>240</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
