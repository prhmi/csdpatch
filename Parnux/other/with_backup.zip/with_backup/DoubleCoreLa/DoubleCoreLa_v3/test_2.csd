<CsoundSynthesizer>

<CsOptions>
-odac
</CsOptions>

<CsInstruments>

sr      =       44100
ksmps   =       32
nchnls  =       2
0dbfs   =       1
        seed    0

gisine  ftgen	0,0,4096,10,1
giTri     ftgen     0, 0, 2^10, 10, 1, 0, -1/9, 0, 1/25, 0, -1/49, 0, 1/81
giSaw     ftgen     0, 0, 2^10, 10, 1, 1/2, 1/3, 1/4, 1/5, 1/6, 1/7, 1/8, 1/9  ;harmonics
giSquare  ftgen     0, 0, 2^10, 10, 1, 0, 1/3, 0, 1/5, 0, 1/7, 0, 1/9

gaSend init 0

 instr 1 ; wgbow instrument
 iFrqMin = 400
 kFrqRange = 10
kamp     rspline  0.2, 0.3, 0.7, 1
kfreq    rspline  iFrqMin, iFrqMin+kFrqRange, 0.7, 1
kpres    rspline  0.1, 5, 0.1, 5
krat     rspline  0.1, 2, 0.1, 5
kvibf    rspline  1,   7, 0.7, 5
aSig	 wgbow    kamp,kfreq,kpres,krat,kvibf,0,giSquare,iFrqMin
aSig     butlp     aSig,3000
aSig     pareq    aSig,200,6,0.707, 1
         outs     aSig,aSig
gaSend   =        gaSend + aSig/3
 endin

 instr 2 ; reverb
aRvbL,aRvbR reverbsc gaSend,gaSend,0.9,7000
            outs     aRvbL,aRvbR
            clear    gaSend
 endin

</CsInstruments>

<CsScore>
; instr. 1 (wgbow instrument)
;  p4 = pitch (hertz)
; wgbow instrument
i 1  0 480  
;i 1  0 480  40
;i 1  0 480  80
;i 1  0 480  160
;i 1  0 480  320
;i 1  0 480  640
;i 1  0 480  1280
;i 1  0 480  2460
; reverb instrument
i 2 0 480
</CsScore>

</CsoundSynthesizer>


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
