<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



opcode Dastgah, i[],i[]i
  iInArr[],iBaseMidi xin
  iLen lenarray iInArr
  iOutArr[] init iLen
  iNote = iBaseMidi-1.5
  indx = 0
	while indx < iLen do
	iNote = iNote+(iInArr[indx])
	iOutArr[indx] = iNote
	indx += 1
	od
  xout iOutArr
endop


opcode shur,i,ii
iBaseNote,iMidiNote xin
iMidi = iMidiNote
;i3gahArr[] fillarray 0, 1.5, 1.5, 2, 1.5, 1.5, 2
i3gahArr[] fillarray 0, 1, 1.5, 0.5, 1.5, 0.5, 1.5, 0.5, 1, 1.5, 1, 2

     until iMidi < iBaseNote+12 do
  		iMidi = iMidi-12
  		enduntil
  		iMidiMin = (iMidi-iBaseNote)
;print iMidiMin

indx = 0 
iValue = 0
while indx < iMidiMin+1 do

iValue += i3gahArr[indx]
indx += 1
od
;  	print iValue, iMidiMin
  	iMidiOut = iBaseNote+iValue
xout iMidiOut
endop

instr 1
;iRatio = 432/440
iRatio = 440/440
Sname ="4C"
iBaseMidi ntom Sname
i3gahArr[] fillarray 0, 1.5, 1.5, 2, 1.5, 1.5, 2
iDastgah[] Dastgah i3gahArr,iBaseMidi


Snote = "4G"
iMidiNote ntom Snote
iBaseNote = iBaseMidi
iMidiOut shur iBaseNote,iMidiNote

;print iMidiOut
SnoteShow mton iMidiOut

puts SnoteShow,1

endin

</CsInstruments>
<CsScore>
i1 0 .1
</CsScore>
</CsoundSynthesizer>
















<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
