
<Cabbage>
form caption("DoubleCoreLa")    size(800, 500)   guiMode("queue")         colour(30,0,40)             pluginId("crlp") ; style("legacy")

label    bounds(35, 15, 40, 12)    channel("label1")  text("On/Off")
label    bounds(35, 42, 30, 12)    channel("label2")  text("Hold")
label    bounds(198, 16, 50, 12)   channel("labe12")  text("Duration")
label    bounds(10, 72, 28, 12)    channel("label3")  text("seq") 
label    bounds(10, 92, 28, 12)    channel("label4")  text("acc")
label    bounds(10, 130, 28, 12)   channel("label5")  text("bss")
label    bounds(10, 110, 28, 12)   channel("label6")  text("rep")
label    bounds(434, 10, 90, 12)   channel("label7")  text("sound On/Off")
label    bounds(35, 187, 40, 12)   channel("label8")  text("On/Off")
label    bounds(196, 188, 50, 12)  channel("labe19")  text("Duration")
label    bounds(10, 242, 28, 12)   channel("label10") text("seq")
label    bounds(10, 262, 28, 12)   channel("label11") text("acc")
label    bounds(10, 300, 28, 12)   channel("label12") text("bss")
label    bounds(10, 280, 28, 12)   channel("label13") text("rep")
label    bounds(441, 182, 83, 12)  channel("label14") text("sound On/Off")
label    bounds(478, 206, 46, 12)  channel("label15") text("Reverse")
label    bounds(478, 36, 46, 12)   channel("label16") text("Reverse")
label    bounds(48, 356, 78, 13)   channel("label17") text("Fx on/off")

checkbox bounds(10, 10, 20, 20)    channel("sq1")     popupText("Start")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(1)
checkbox bounds(12, 40, 15, 15)    channel("hold")    popupText("Hold")            colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(0)
checkbox bounds(530, 8, 15, 15)    channel("dng1")    popupText("Synth")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(1)
checkbox bounds(530, 180, 15, 15)  channel("dng2")    popupText("Synth")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(1)
checkbox bounds(530, 34, 15, 15)   channel("rvrs1")   popupText("Synth")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(0)
checkbox bounds(530, 204, 15, 15)  channel("rvrs2")   popupText("Synth")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(0)
checkbox bounds(12, 186, 15, 15)   channel("sq2")     popupText("Start")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(1)
checkbox bounds(22, 350, 22, 22)   channel("fx")                                   colour:0(100, 100, 100, 255) colour:1(141, 88, 156, 255) value(1)

nslider  bounds(90, 9, 40, 31)     channel("BPM1")    range(50, 180, 90, 1, 1)     fontColour(208, 157, 253, 255) text("BPM") 
nslider  bounds(130, 9, 30, 31)    channel("DV1")     range(1, 10, 4, 1, 1)        fontColour(208, 157, 253, 255) text("DV") 
nslider  bounds(162, 9, 30, 31)    channel("steps1")  range(1, 28, 13, 1, 1)       fontColour(208, 157, 253, 255) text("Step") 
nslider  bounds(90, 180, 40, 31)   channel("BPM2")    range(50, 180, 90, 1, 1)     fontColour(208, 157, 253, 255) text("BPM") 
nslider  bounds(130, 181, 30, 31)  channel("DV2")     range(1, 10, 4, 1, 1)        fontColour(208, 157, 253, 255) text("DV") 
nslider  bounds(162, 181, 30, 31)  channel("steps2")  range(1, 28, 13, 1, 1)       fontColour(208, 157, 253, 255) text("Step") 

hslider  bounds(198, 32, 137, 21)  channel("dur1")    range(0.05, 2, 1.5, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) 
hslider  bounds(195, 204, 146, 21) channel("dur2")    range(0.05, 2, 1.3, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) 


rslider  bounds(130, 356, 60, 60)    channel("pan1")     range(0, 1, 0.5, 1, 0.1) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("pan1")     
rslider  bounds(190, 356, 60, 60)   channel("gn1")     range(0, 2, 1, 1, 0.001) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Gn1")
rslider  bounds(312, 356, 60, 60)   channel("gn2")     range(0, 2, 1, 1, 0.001) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Gn2")
rslider  bounds(250, 356, 60, 60)    channel("pan2")     range(0, 1, 0.5, 1, 0.1) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("pan2")     


combobox bounds(340, 30, 77, 25)   channel("BNote")   text("Note", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")   value(2)
combobox bounds(308, 4, 109, 25)   channel("scale")   text("Scale", "pythagorean", "shur", "homayun", "segah", "chargah")  value(2) 
combobox bounds(346, 202, 77, 25)  channel("BNote2")  text("Note", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")   value(2)
combobox bounds(318, 174, 105, 25) channel("scale2")  text("Scale", "pythagorean", "shur", "homayun", "segah", "chargah") value(2) 
combobox bounds(58, 376, 68, 22)   channel("sound1")  text("sound", "sound1", "sound2", "sound3")   value(2)
combobox bounds(58, 399, 68, 22)   channel("sound2")  text("sound", "sound1", "sound2", "sound3")   value(2)


button   bounds(568, 432, 60, 25)  channel("saveA") text("Save A", "Save A") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)
button   bounds(568, 468, 60, 25)  channel("saveB") text("Save B", "Save B") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)
button   bounds(732, 432, 60, 25)  channel("loadA") text("Load A", "Load A") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)
button   bounds(732, 468, 60, 25)  channel("loadB") text("Load B", "Load B") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)


keyboard bounds(4, 432, 554, 68) channel("keyboard10043") value(40)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0

massign 1,1
#include "DoubleCoreLa.udo"


 giArrNote[]    init 8
 giArrEmpty[]   init lenarray:i(giArrNote)
 giArrVeloc[]   init lenarray:i(giArrNote)
 giArrVel[] =   giArrVeloc
 giLenVel       lenarray giArrVel
 giNote[]       fillarray 1,1
 giWriteNote    init 0




giSteps init 28
giStepArr1[]    init giSteps
giAccArr1[]     init giSteps
giRepArr1[]     init giSteps
giBassArr1[]    init giSteps

giStepArr2[]    init giSteps
giAccArr2[]     init giSteps
giRepArr2[]     init giSteps
giBassArr2[]    init giSteps






instr GetMidi ;1
 iActive1 active 1
 iHold cabbageGetValue "hold"
 kRel release
 iNum notnum
 iVel veloc 0,127
 if iActive1 == 1 then
 giArrNote[] = giArrEmpty
 giArrVeloc[] = giArrEmpty
 giWriteNote = 0
 endif
 schedule "WriteMidi",0,.1,iNum,iVel
 	if kRel == 1 && changed(kRel) == 1 && iHold == 0 then
 	schedulek "WriteMidi", 0, .1,iNum,0
 	endif
endin
instr WriteMidi ;2
 iActive1 active 1
 iNote = p4
 iVel = p5
 iveloc = int((p5/127)*10)
 iveloc = ((iveloc/10)^1.5)*10
 if iveloc == 0 then
 iveloc = 1
 endif

 iLen lenarray giArrNote
 if iVel != 0 then
 					indxr = 0
 					iCountZero = 0
					while indxr < iLen do
						if giArrNote[indxr] != 0 then
						iCountZero += 1
						endif
					indxr += 1
					od
		if iCountZero != iLen then
			while giArrNote[giWriteNote] != 0 do
			giWriteNote = (giWriteNote+1) % iLen
			od
		else
			giWriteNote = (giWriteNote+1) % iLen
		endif
 giArrNote[giWriteNote] = iNote
 giArrVeloc[giWriteNote] = iveloc
 elseif iVel == 0 then
		indxw = 0
		while indxw < iLen do
			if giArrNote[indxw] == iNote then
			giArrNote[indxw] = 0
			giArrVeloc[indxw] = 0
			giWriteNote = indxw-1
			endif
		indxw += 1
		od
 giWriteNote = (giWriteNote-1) <= 0 ? 0 : giWriteNote
 endif
			if iActive1 == 0 then
			giWriteNote = 0
			endif
 giNote[] RmvZ giArrNote
 giLenNote lenarray giNote
 gkLenNote lenarray giNote

  giArrVel[] RmvZ giArrVeloc
  giLenVel lenarray giArrVel

endin


instr seq1
kActive1 active 1
kSeq2 cabbageGet "sq2"
  if kSeq2 == 1 then
  ;schedule "seq2",0,-1
  endif
kDing cabbageGet "dng1"
kHold cabbageGet "hold"
kVelocity cabbageGet "vlc"
kSeqIndx   init 0
kNoteIndx  init 0
kVelocIndx init 0
kBPM cabbageGet "BPM1"
kTempo = kBPM/60
kTms cabbageGet "DV1"
kSteps cabbageGet "steps1"
kTime = (kTempo*kTms)
;printk2 kTime
ksel = 0
kNoteIn = giNote[ksel]
kDur cabbageGet "dur1"
    if metro(kTime) == 1 then
    if kNoteIn > 20 then
    ;;sound
    SseqValue sprintfk "seq1%d",kSeqIndx
    kSeqValue cabbageGet SseqValue
    SaccValue sprintfk "acc1%d",kSeqIndx
    kAccValue cabbageGet SaccValue
      if kSeqValue == 1 then 
                    kNoteIndx  = (kNoteIndx+1)  % giLenNote
                    if changed(gkLenNote) == 1 then
                    kNoteIndx = gkLenNote-1
                    endif
                    kNote  = giNote[kNoteIndx]
                    kAcc = (kAccValue == 1) ? .8 : 1.2
                    kVelocIndx = (kVelocIndx+1) % giLenVel
                    if kVelocity == 0 then
                    kVeloc = giArrVel[kVelocIndx]
                    elseif kVelocity == 1 then
                    kVeloc = random:k( 1, 3)
                    endif
                    kVeloc = ((kVeloc/10)^kAcc)*10
        if kDing == 1 then
        schedulek "Sound1" ,0,kDur,kNote,kVeloc, 0.0001
        endif
      schedulek "MidiOut1",0,kDur,kNote,kVeloc
      endif
    ;;acc

    ;;Bss
    SbssValue sprintfk "bass1%d",kSeqIndx
    kBssValue cabbageGet SbssValue
    if kBssValue == 1 then
    		kBidx = 0
        kNoteBass = giNote[kBidx]
			  until kNoteBass < 45 do
  			kNoteBass = kNoteBass-12
  			enduntil
      if kDing == 1 then
      schedulek "Sound1" ,0,kDur,kNoteBass,2, 0.00001
      endif
    schedulek "MidiOut1",0,kDur,kNoteBass,2
    ;printk2 kNoteBass
    endif
    ;;Rep
    SrepValue sprintfk "rep1%d",kSeqIndx
    kRepValue cabbageGet SrepValue
    if kRepValue == 1 then
                kNoteRep = kNote
					    	until kNoteRep > 80 do
  							kNoteRep = kNoteRep+12
  							enduntil
            kRepR = ((int(random:k(0,6)))/4)+1
            if kRepR <= 1.5 then
            kRepT = int(random:k( 3,7))
            else
            kRepT = int(random:k( 2,4))
            endif
            kDurRep = (1/kTime)/kRepR
            kTrigRep = kDurRep
            kndxRep = 0
          	while kndxRep < kRepT do
              if kDing == 1 then
						  schedulek "Sound1",kTrigRep,kDurRep,kNoteRep,2, 0.0001
					    endif
					  schedulek "MidiOut1",kTrigRep,kDurRep,kNoteRep,2
						kTrigRep += kDurRep
						kndxRep += 1
					od	
    endif
    endif
    schedulek "LEDon1",0,0.1,kSeqIndx
    schedulek "LEDoff1",1/kTime,0.1,kSeqIndx
    kSeqIndx = (kSeqIndx+1) % kSteps

    endif
endin

instr LEDon1
Slte sprintf "lte1%d",p4
cabbageSet 1,Slte,"colour(150, 150, 200, 250)"
endin
instr LEDoff1
Slte sprintf "lte1%d",p4
cabbageSet 1,Slte,"colour(100, 100, 100, 200)"
endin

instr Sound1 ;5
iMidiNote = p4
iAmp = p5*0.1
;print 1
;iBaseNote  ntom "0C"
iBaseNoteIn cabbageGetValue "BNote"
iBaseNote = iBaseNoteIn-2
iScale      cabbageGetValue "scale"
if iScale == 1 then
iFrq mtof iMidiNote
elseif iScale == 2 then
iFrq pythagorean iBaseNote-2,iMidiNote
elseif iScale == 3 then
iFrq shur iBaseNote-2,iMidiNote
elseif iScale == 4 then
iFrq homayun iBaseNote-2,iMidiNote
elseif iScale == 5 then
iFrq segah iBaseNote-2,iMidiNote
elseif iScale == 6 then
iFrq chargah iBaseNote-2,iMidiNote
endif
iAtt = p6

iRvrs cabbageGetValue "rvrs1"
if iRvrs == 0 then
 aEnv transeg 0, iAtt,6, iAmp, p3-iAtt,-13, 0
elseif iRvrs == 1 then
 aEnv transeg 0, p3*0.99,4, iAmp*0.1,p3*0.01,-6,0
endif
 aSine    vco2    1,iFrq,0,0.5
 aFilter clfilt aSine, 1000+(iFrq), 0, 10
 aFilter clfilt aFilter, 150, 1, 10
 aout = aFilter*aEnv
 iFx cabbageGetValue "fx"
 kPan cabbageGet "pan1"
 if iFx == 1 goto fx
aoutL,aoutR	pan2	aout, kPan
outs aoutL, aoutR
goto end
fx:
chnmix aout, "snd1"
end:
endin




instr seq2
kActive1 active 1
kDing cabbageGet "dng2"
kHold cabbageGet "hold"
kSeqIndx   init 0
kNoteIndx  init 0
kVelocIndx init 0
kBPM cabbageGet "BPM2"
kTempo = kBPM/60
kTms cabbageGet "DV2"
kSteps cabbageGet "steps2"
kVelocity cabbageGet "vlc"
kTime = (kTempo*kTms)
;printk2 kTime
ksel = 0
kNoteIn = giNote[ksel]
kDur cabbageGet "dur2"
    if metro(kTime) == 1 then
    if kNoteIn > 20 then
    ;;sound
    SseqValue sprintfk "seq2%d",kSeqIndx
    kSeqValue cabbageGet SseqValue
    SaccValue sprintfk "acc2%d",kSeqIndx
    kAccValue cabbageGet SaccValue
      if kSeqValue == 1 then 
                    kNoteIndx  = (kNoteIndx+1)  % giLenNote
                    if changed(gkLenNote) == 1 then
                    kNoteIndx = gkLenNote-1
                    endif
                    kNote  = giNote[kNoteIndx]
                    kAcc = (kAccValue == 1) ? 1 : 1.5
                    kVelocIndx = (kVelocIndx+1) % giLenVel
                    if kVelocity == 0 then
                    kVeloc = giArrVel[kVelocIndx]
                    elseif kVelocity == 1 then
                    kVeloc = random:k( 1, 3)
                    endif
                    kVeloc = ((kVeloc/10)^kAcc)*10
          ;printk2 kAcc
        if kDing == 1 then
        schedulek "Sound2" ,0,kDur,kNote,kVeloc,0.0003
        endif
      schedulek "MidiOut2",0,kDur,kNote,kVeloc
      endif
    ;;acc

    ;;Bss
    SbssValue sprintfk "bass2%d",kSeqIndx
    kBssValue cabbageGet SbssValue
    if kBssValue == 1 then
    		kBidx = 0
        kNoteBass = giNote[kBidx]
			  until kNoteBass < 45 do
  			kNoteBass = kNoteBass-12
  			enduntil
      if kDing == 1 then
      schedulek "Sound2" ,0,kDur,kNoteBass,kVeloc,0.005
      endif
    schedulek "MidiOut2",0,kDur,kNoteBass,kVeloc
    ;printk2 kNoteBass
    endif
    ;;Rep
    SrepValue sprintfk "rep2%d",kSeqIndx
    kRepValue cabbageGet SrepValue
    if kRepValue == 1 then
                kNoteRep = kNote
					    	until kNoteRep > 90 do
  							kNoteRep = kNoteRep+12
  							enduntil
            kRepR = ((int(random:k(0,3)))/2)+1
            kRepT = int(random:k( 2,7))
            kDurRep = (1/kTime)/kRepR
            kTrigRep = kDurRep
            kndxRep = 0
          	while kndxRep < kRepT do
              if kDing == 1 then
						  schedulek "Sound2",kTrigRep,kDurRep+.5,kNoteRep,3,.0003
					    endif
					  schedulek "MidiOut2",kTrigRep,kDurRep,kNoteRep,3
						kTrigRep += kDurRep
						kndxRep += 1
					od	
    endif
    endif
    schedulek "LEDon2",0,0.1,kSeqIndx
    schedulek "LEDoff2",1/kTime,0.1,kSeqIndx
    kSeqIndx = (kSeqIndx+1) % kSteps
    endif
endin

instr LEDon2
Slte sprintf "lte2%d",p4
cabbageSet 1,Slte,"colour(150, 150, 200, 250)"
endin
instr LEDoff2
Slte sprintf "lte2%d",p4
cabbageSet 1,Slte,"colour(100, 100, 100, 200)"
endin

instr Sound2 ;5

iMidiNote = p4
iVeloc = p5
;iBaseNote  ntom "0C"
iBaseNoteIn cabbageGetValue "BNote"
iBaseNote = iBaseNoteIn-2
iScale      cabbageGetValue "scale"
if iScale == 1 then
iFrq mtof iMidiNote
elseif iScale == 2 then
iFrq pythagorean iBaseNote-2,iMidiNote
elseif iScale == 3 then
iFrq shur iBaseNote-2,iMidiNote
elseif iScale == 4 then
iFrq homayun iBaseNote-2,iMidiNote
elseif iScale == 5 then
iFrq segah iBaseNote-2,iMidiNote
elseif iScale == 6 then
iFrq chargah iBaseNote-2,iMidiNote
endif
iAtt = p6
iRvrs cabbageGetValue "rvrs2"
if iRvrs == 0 then
aEnv transeg 0, iAtt,4, 1,p3-iAtt,-6,0
elseif iRvrs == 1 then
 aEnv transeg 0, p3*0.95,4, 1,p3*0.05,0,0
endif

  iplk = MirrorMe:i(iVeloc/30,0.01,0.3) +  (random:i( .01, .1))
  ;print iplk
  ipick =  iVeloc/30 + (random:i( .01, .1))
  iDur = (p3/2.3)+0.1
  irefl =  MirrorMe:i(iDur,0.1,0.9)
  aPick wgpluck2 iplk,0.4, iFrq, ipick, irefl
 aout clfilt aPick, 20, 1, 10
  aout = aout*aEnv
 iFx cabbageGetValue "fx"
  kPan cabbageGet "pan2"
 if iFx == 1 goto fx
aoutL,aoutR	pan2	aout, kPan
outs aoutL, aoutR
goto      end
 fx:
chnmix aout, "snd2"
end:
endin






instr hold
 cabbageSetValue "hold",p4
endin

instr Empty ;7
print 1
if p4 == 1 then
 giArrNote [] = giArrEmpty
 giNote    [] = giArrEmpty
elseif p4 == 2 then
giArrVel [] RmvZ giArrVeloc
giLenVel lenarray giArrVel
;printarray giArrVel, "%d"
endif
endin

;--------------------------------------------------------
;Midi
instr MidiOut1 ;12
inum = p4
ivel = int((p5*127)/10)
midion 1, inum, ivel
endin

instr MidiOut2 ;12
inum = p4
ivel = int((p5*127)/10)
midion 2, inum, ivel
endin


;-------------------------------------------------------
;Effects


instr Effect

kDelayTime cabbageGet "dlt"
kFeedback cabbageGet "fdb"

;;sound
kGain1 cabbageGet "gn1"
aGn1	interp	kGain1
aIn1 chnget "snd1"
aSound1 = aIn1*aGn1
kGain2 cabbageGet "gn2"
aGn2	interp	kGain2
aIn2 chnget "snd2"
aSound2 = aIn2*aGn2
;;time
kBPM1 cabbageGet "BPM1"
kTempo1 = kBPM1/60
kTms1 cabbageGet "DV1"
kTime1 = (1/(kTempo1*kTms1))*kDelayTime
kBPM2 cabbageGet "BPM2"
kTempo2 = kBPM2/60
kTms2 cabbageGet "DV2"
kTime2 = (1/(kTempo2*kTms2))*kDelayTime


kDelay1 cabbageGet "dl1"
kDelay2 cabbageGet "dl2"

if kDelay1 == 0 && kDelay2 == 0 then
aSoundD = aSound1*0
kTime = 0.1
elseif kDelay1 == 1 && kDelay2 == 0 then
kTime = kTime1
aSoundD = aSound1
elseif kDelay1 == 0 && kDelay2 == 1 then
kTime = kTime2
aSoundD = aSound2
elseif kDelay1 == 1 && kDelay2 == 1 then
kTime = kTime1
aSoundD = aSound1+aSound2
endif
 	aTim	interp	kTime
 	abuf	delayr	7
 	aDelay	deltapi	aTim	
 	delayw	aSoundD + (aDelay*kFeedback)
  	aDelMix		ntrpol	 aSoundD,aDelay,  .65
  
  aSound = aSound1+aSound2
  
  aRvrbL, aRvrbR reverbsc aSound,aSound, 0.7, 1600
  aoutL	ntrpol	 aSound,aRvrbL+aDelMix,  .4
  aoutR	ntrpol	 aSound,aRvrbR+aDelMix,  .4
out aoutL,aoutR
chnclear "snd1"
chnclear "snd2"
endin



;-------------------------------------------------------
;widgets
instr widgetWrite
    iX = 0
    iCount = 0
    ispc = 0
    while iCount < giSteps do
            Sseq1    sprintf "bounds(%d, 70, 15, 15)  , channel(\"seq1%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Sseq1Preset1    sprintf "bounds(%d, 70, 15, 15)  , channel(\"seq1saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
     Sseq1Preset2    sprintf "bounds(%d, 70, 15, 15)  , channel(\"seq1saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
            Sacc1    sprintf "bounds(%d, 90, 15, 15)  , channel(\"acc1%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Sacc1Preset1    sprintf "bounds(%d, 90, 15, 15)  , channel(\"acc1saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
     Sacc1Preset2    sprintf "bounds(%d, 90, 15, 15)  , channel(\"acc1saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount            
            Srep1    sprintf "bounds(%d, 110, 15, 15) , channel(\"rep1%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount           
     Srep1Preset1    sprintf "bounds(%d, 110, 15, 15) , channel(\"rep1saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount           
     Srep1Preset2    sprintf "bounds(%d, 110, 15, 15) , channel(\"rep1saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount            
            Sbass1   sprintf "bounds(%d, 130, 15, 15) , channel(\"bass1%d\")      colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount           
     Sbass1Preset1   sprintf "bounds(%d, 130, 15, 15) , channel(\"bass1saveA%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount 
     Sbass1Preset2   sprintf "bounds(%d, 130, 15, 15) , channel(\"bass1saveB%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
             Slte1   sprintf "bounds(%d, 150, 12, 12) , channel(\"lte1%d\")       colour(100, 100, 100, 200) ", 51+iCount*(17)+ispc, iCount

            Sseq2    sprintf "bounds(%d, 240, 15, 15) , channel(\"seq2%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Sseq2Preset1    sprintf "bounds(%d, 240, 15, 15) , channel(\"seq2saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
     Sseq2Preset2    sprintf "bounds(%d, 240, 15, 15) , channel(\"seq2saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
            Sacc2    sprintf "bounds(%d, 260, 15, 15) , channel(\"acc2%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Sacc2Preset1    sprintf "bounds(%d, 260, 15, 15) , channel(\"acc2saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
     Sacc2Preset2    sprintf "bounds(%d, 260, 15, 15) , channel(\"acc2saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
            Srep2    sprintf "bounds(%d, 280, 15, 15) , channel(\"rep2%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Srep2Preset1    sprintf "bounds(%d, 280, 15, 15) , channel(\"rep2saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
     Srep2Preset2    sprintf "bounds(%d, 280, 15, 15) , channel(\"rep2saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
            Sbass2   sprintf "bounds(%d, 300, 15, 15) , channel(\"bass2%d\")      colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Sbass2Preset1   sprintf "bounds(%d, 300, 15, 15) , channel(\"bass2saveA%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount      
     Sbass2Preset2   sprintf "bounds(%d, 300, 15, 15) , channel(\"bass2saveB%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
             Slte2   sprintf "bounds(%d, 320, 12, 12) , channel(\"lte2%d\")       colour(100, 100, 100, 200) ", 51+iCount*(17)+ispc, iCount
            
     cabbageCreate "checkbox", Sseq1
     cabbageCreate "checkbox", Sseq1Preset1
     cabbageCreate "checkbox", Sseq1Preset2
     cabbageCreate "checkbox", Sacc1
     cabbageCreate "checkbox", Sacc1Preset1
     cabbageCreate "checkbox", Sacc1Preset2
     cabbageCreate "checkbox", Srep1
     cabbageCreate "checkbox", Srep1Preset1
     cabbageCreate "checkbox", Srep1Preset2
     cabbageCreate "checkbox", Sbass1
     cabbageCreate "checkbox", Sbass1Preset1
     cabbageCreate "checkbox", Sbass1Preset2
     cabbageCreate "image"   , Slte1
            
     cabbageCreate "checkbox", Sseq2
     cabbageCreate "checkbox", Sseq2Preset1
     cabbageCreate "checkbox", Sseq2Preset2
     cabbageCreate "checkbox", Sacc2
     cabbageCreate "checkbox", Sacc2Preset1
     cabbageCreate "checkbox", Sacc2Preset2
     cabbageCreate "checkbox", Srep2
     cabbageCreate "checkbox", Srep2Preset1
     cabbageCreate "checkbox", Srep2Preset2
     cabbageCreate "checkbox", Sbass2
     cabbageCreate "checkbox", Sbass2Preset1
     cabbageCreate "checkbox", Sbass2Preset2 
     cabbageCreate "image"   , Slte2          

     iCount += 1
     iX = (iX+1) % 4
     if iX == 0 then
     ispc += 5
     endif
    od
    
    kArrSeq1[] fillarray 1,0,0,1,1,0,0,1,0,1,0,0,1
    kArrSeq2[] fillarray 0,1,1,0,0,1,0,0,1,0,0,1,0
    kWrite = 0
    while kWrite < lenarray(kArrSeq1) do
     Ssq1 sprintfk "seq1%d",kWrite
     Ssq2 sprintfk "seq2%d",kWrite
     cabbageSetValue Ssq1,kArrSeq1[kWrite]
     cabbageSetValue Ssq2,kArrSeq2[kWrite]
     kWrite += 1
    od    
endin


instr saveWidgets
    Sp4 = p4
    indx = 0
    while indx < giSteps do
    Sseq1Save   sprintf "seq1%d",indx
    Sacc1Save   sprintf "acc1%d",indx
    Srep1Save   sprintf "rep1%d",indx
    Sbass1Save  sprintf "bass1%d",indx
    
    Sseq2Save   sprintf "seq2%d",indx
    Sacc2Save   sprintf "acc2%d",indx
    Srep2Save   sprintf "rep2%d",indx
    Sbass2Save  sprintf "bass2%d",indx

    iSeq1   cabbageGetValue Sseq1Save
    iAcc1   cabbageGetValue Sacc1Save
    iRep1   cabbageGetValue Srep1Save
    iBass1  cabbageGetValue Sbass1Save
    
    iSeq2   cabbageGetValue Sseq2Save
    iAcc2   cabbageGetValue Sacc2Save
    iRep2   cabbageGetValue Srep2Save
    iBass2  cabbageGetValue Sbass2Save
    
    giStepArr1[indx]    = iSeq1
    giAccArr1[indx]     = iAcc1
    giRepArr1[indx]     = iRep1
    giBassArr1[indx]    = iBass1
    
    giStepArr2[indx]    = iSeq2
    giAccArr2[indx]     = iAcc2
    giRepArr2[indx]     = iRep2
    giBassArr2[indx]    = iBass2
    
    Sseq1    sprintf "seq1save%s%d",Sp4,indx
    Sacc1    sprintf "acc1save%s%d",Sp4,indx
    Srep1    sprintf "rep1save%s%d",Sp4,indx
    Sbass1   sprintf "bass1save%s%d",Sp4,indx
    
    Sseq2    sprintf "seq2save%s%d",Sp4,indx
    Sacc2    sprintf "acc2save%s%d",Sp4,indx
    Srep2    sprintf "rep2save%s%d",Sp4,indx
    Sbass2   sprintf "bass2save%s%d",Sp4,indx
    
    cabbageSetValue Sseq1,giStepArr1[indx]
    cabbageSetValue Sacc1,giAccArr1[indx]
    cabbageSetValue Srep1,giRepArr1[indx]
    cabbageSetValue Sbass1,giBassArr1[indx]
    
    cabbageSetValue Sseq2,giStepArr2[indx]
    cabbageSetValue Sacc2,giAccArr2[indx]
    cabbageSetValue Srep2,giRepArr2[indx]
    cabbageSetValue Sbass2,giBassArr2[indx]
    
    indx += 1
    od
endin


instr loadWidgets
    Sp4 = p4
    indx = 0
    while indx < giSteps do

    Sseq1Load   sprintf "seq1save%s%d",Sp4,indx
    Sacc1Load   sprintf "acc1save%s%d",Sp4,indx
    Srep1Load   sprintf "rep1save%s%d",Sp4,indx
    Sbass1Load  sprintf "bass1save%s%d",Sp4,indx

    Sseq2Load   sprintf "seq2save%s%d",Sp4,indx
    Sacc2Load   sprintf "acc2save%s%d",Sp4,indx
    Srep2Load   sprintf "rep2save%s%d",Sp4,indx
    Sbass2Load  sprintf "bass2save%s%d",Sp4,indx

    iSeq1   cabbageGetValue Sseq1Load
    iAcc1   cabbageGetValue Sacc1Load
    iRep1   cabbageGetValue Srep1Load
    iBass1  cabbageGetValue Sbass1Load
    
    iSeq2   cabbageGetValue Sseq2Load
    iAcc2   cabbageGetValue Sacc2Load
    iRep2   cabbageGetValue Srep2Load
    iBass2  cabbageGetValue Sbass2Load
    
    Sseq1   sprintf "seq1%d",indx
    Sacc1   sprintf "acc1%d",indx
    Srep1   sprintf "rep1%d",indx
    Sbass1  sprintf "bass1%d",indx
    
    Sseq2   sprintf "seq2%d",indx
    Sacc2   sprintf "acc2%d",indx
    Srep2   sprintf "rep2%d",indx
    Sbass2  sprintf "bass2%d",indx
    
    cabbageSetValue Sseq1,iSeq1
    cabbageSetValue Sacc1,iAcc1
    cabbageSetValue Srep1,iRep1
    cabbageSetValue Sbass1,iBass1
    
    cabbageSetValue Sseq2,iSeq2
    cabbageSetValue Sacc2,iAcc2
    cabbageSetValue Srep2,iRep2
    cabbageSetValue Sbass2,iBass2
    
    indx += 1
    od
endin


instr Widgets
    schedule "widgetWrite", 0, 1
    kSaveA cabbageGet "saveA"
    if changed(kSaveA) == 1 then
    schedulek "saveWidgets", 0, 1, "A"
    endif

    kSaveB cabbageGet "saveB"
    if changed(kSaveB) == 1 then
    schedulek "saveWidgets", 0, 1, "B"
    endif

    kLoadA cabbageGet "loadA"
    if changed(kLoadA) == 1 then
    schedulek "loadWidgets", 0, 1, "A"
    endif

    kLoadB cabbageGet "loadB"
    if changed(kLoadB) == 1 then
    schedulek "loadWidgets", 0, 1, "B"
    endif
    
    
    kSeq1Play cabbageGet "sq1"
kSeq2Play cabbageGet "sq2"
if kSeq1Play == 1 && changed(kSeq1Play) == 1 then
schedulek "seq1",0,-1
  if kSeq2Play == 1 then
  schedulek "seq2",0,-1
  endif
elseif kSeq1Play == 0 && changed(kSeq1Play) == 1 then
turnoff2 "seq1",0,0
turnoff2 "seq2",0,0
endif

if kSeq2Play == 0 && changed(kSeq2Play) == 1 then
turnoff2 "seq2",0,0
endif

    
endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

