<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



opcode MtoName, S,i
iMidi xin 
SNoteArr [] fillarray "C", "C#", "D", "D#","E", "F", "F#", "G","G#", "A", "A#", "B"
iAraziArr[] fillarray 1, 3, 6, 8, 10
iNoteIndex = (iMidi) % 12
iNoteIndxInt = int(iNoteIndex)
iSnumber = int(iMidi/12)-1
iSCent = (iMidi-int(iMidi))*100
if iSCent  == 0 then
Sout sprintfk "%d%s",iSnumber,SNoteArr[iNoteIndex]
elseif iSCent != 0 then
		if iSCent > 50 then
		Sout sprintfk "%d%s-%d",iSnumber,SNoteArr[iNoteIndex+1],(100-iSCent)
		elseif iSCent < 50 then
		Sout sprintfk "%d%s+%d",iSnumber,SNoteArr[iNoteIndex],iSCent
		elseif iSCent == 50 then
			if iNoteIndxInt == 1 || iNoteIndxInt == 3 || iNoteIndxInt == 6 ||
			iNoteIndxInt == 8 || iNoteIndxInt == 10 then
			Sout sprintfk "%d%s-",iSnumber,SNoteArr[iNoteIndex+1]
			elseif iNoteIndxInt == 0 || iNoteIndxInt == 2 || iNoteIndxInt == 4 ||
			iNoteIndxInt == 5 || iNoteIndxInt == 7 || iNoteIndxInt == 9 || 
			iNoteIndxInt == 11 then
			Sout sprintfk "%d%s+",iSnumber,SNoteArr[iNoteIndex]
			endif
		endif
endif
xout Sout
endop

/*
D+ segah:
03. In 60.61 Hz.   (Sound Block 03 in B)
07. In 54 Hz.      (Sound Block 07 in A)
08. in 37.09 Hz.   (Sound Block 08 in D Quarter Sharp)
13. In 45.41 Hz.   (Sound Block 13 in F Sharp)
17. In 40.45 Hz.   (Sound Block 17 in E)
22. In 49.51 Hz.   (Sound Block 22 in G Quarter Sharp)
23. In 34.02 Hz.   (Sound Block 23 in C Sharp)
*/


opcode segah, i[],i[]i
  iInArr[],iBaseMidi xin
  iLen lenarray iInArr
  iOutArr[] init iLen
  iNote = iBaseMidi-1.5
  indx = 0
	while indx < iLen do
	iNote = iNote+(iInArr[indx])
	iOutArr[indx] = iNote
	indx += 1
	od
  xout iOutArr
endop



opcode dastgah, i,i[]iii
  iInArr[],iBaseMidi,iMidiIn,iQ xin
  iLen lenarray iInArr
  iOutArr[] init iLen
  iNote = iBaseMidi
  indx = 0
	while indx < iLen do
	iNote = iNote+(iInArr[indx])
	iOutArr[indx] = iNote
	indx += 1
	od
	iMidi = int(iMidiIn)+iQ
	indxOct = 0
	     until iMidi < iBaseMidi+12 do
	     indxOct += 1
  		iMidi = iMidi-12
  		enduntil
  		iIntrval = (iMidi-iBaseMidi)
iMidiOut = iOutArr[iIntrval]+(12*indxOct)
SnoteOut mton iMidiOut
  xout iMidiOut
endop


instr 1
;iRatio = 432/440
iRatio = 440/440
Sname ="0D"
iBaseMidi ntom Sname
giShurArr[] 		fillarray 0, 1.5, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1
giAbuataArr[] 		fillarray 0, 0.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
giBayattorkArr[] fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5
giAfshariArr[] 	fillarray 0, 1.5,0.5, 1, 1, 1, 1, 1, 1.5,0.5, 1, 1
giDashtiArr[] 		fillarray 0, 1, 1, 1, 1, 1, 1.5,0.5,  1, 1, 1, 1
giNavaArr[] 		fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5, 1, 1
gi3gahArr[] 		fillarray 0, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1, 1
gi4gahArr[] 		fillarray 0, 1.5, 0.5, 1, 1,1, 1, 1, 1.5, 0.5, 1, 1
giHomayunArr[]   fillarray 0, 0.5, 1, 1, 1,1, 1, 1.5, 0.5, 1, 1, 1
giBayatEsArr[]   fillarray 0, 1,1,1, 1, 1,1,1, 1.5, 0.5, 1.5, 0.5

iScaleArr[] = giBayatEsArr
Snote ="5Bb"
iMidi ntom Snote
iQ = 0
iMidiOut dastgah iScaleArr,iBaseMidi,iMidi, iQ

print iMidiOut
endin

</CsInstruments>
<CsScore>
i1 0 .1
</CsScore>
</CsoundSynthesizer>






























<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
