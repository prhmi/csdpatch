
<Cabbage>
form caption("DoubleCoreLa")    size(800, 500)   guiMode("queue")         colour(30,0,40)             pluginId("crlp") ; style("legacy")

label    bounds(35, 15, 40, 12)    channel("label1")  text("On/Off")
label    bounds(35, 42, 30, 12)    channel("label2")  text("Hold")
label    bounds(198, 16, 50, 12)   channel("labe12")  text("Duration")
label    bounds(10, 72, 28, 12)    channel("label3")  text("seq") 
label    bounds(10, 92, 28, 12)    channel("label4")  text("acc")
label    bounds(10, 112, 28, 12)   channel("label5")  text("bss")
label    bounds(10, 132, 28, 12)   channel("label6")  text("rep")
label    bounds(434, 10, 90, 12)   channel("label7")  text("sound On/Off")
label    bounds(35, 187, 40, 12)   channel("label8")  text("On/Off")
label    bounds(196, 188, 50, 12)  channel("labe19")  text("Duration")
label    bounds(10, 242, 28, 12)   channel("label10") text("seq")
label    bounds(10, 262, 28, 12)   channel("label11") text("acc")
label    bounds(10, 282, 28, 12)   channel("label12") text("bss")
label    bounds(10, 302, 28, 12)   channel("label13") text("rep")
label    bounds(441, 182, 83, 12)  channel("label14") text("sound On/Off")
label    bounds(478, 206, 46, 12)  channel("label15") text("Reverse")
label    bounds(478, 36, 46, 12)   channel("label16") text("Reverse")
label    bounds(10, 390, 57, 12)   channel("label17") text("Fx on/off")

checkbox bounds(10, 10, 20, 20)    channel("sq1")     popupText("Start")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(1)
checkbox bounds(12, 40, 15, 15)    channel("hold")    popupText("Hold")            colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(0)
checkbox bounds(530, 8, 15, 15)    channel("dng1")    popupText("Synth")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(1)
checkbox bounds(530, 180, 15, 15)  channel("dng2")    popupText("Synth")           colour:0(100, 100, 100, 255)  colour:1(100, 250, 60, 255) value(1)
checkbox bounds(530, 34, 15, 15)   channel("rvrs1")   popupText("Synth")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(0)
checkbox bounds(530, 204, 15, 15)  channel("rvrs2")   popupText("Synth")           colour:0(100, 100, 100, 255)  colour:1(100, 250, 60, 255) value(0)

nslider  bounds(90, 9, 40, 31)     channel("BPM1")    range(50, 180, 90, 1, 1)     fontColour(208, 157, 253, 255) text("BPM") 
nslider  bounds(130, 9, 30, 31)    channel("DV1")     range(1, 10, 4, 1, 1)        fontColour(208, 157, 253, 255) text("DV") 
nslider  bounds(162, 9, 30, 31)    channel("steps1")  range(1, 28, 13, 1, 1)       fontColour(208, 157, 253, 255) text("Step") 
nslider  bounds(90, 180, 40, 31)   channel("BPM2")    range(50, 180, 90, 1, 1)     fontColour(208, 157, 253, 255) text("BPM") 
nslider  bounds(130, 181, 30, 31)  channel("DV2")     range(1, 10, 4, 1, 1)        fontColour(208, 157, 253, 255) text("DV") 
nslider  bounds(162, 181, 30, 31)  channel("steps2")  range(1, 28, 13, 1, 1)       fontColour(208, 157, 253, 255) text("Step") 

hslider  bounds(198, 32, 137, 21)  channel("dur1")    range(0.05, 2, 1.5, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) 
hslider  bounds(195, 204, 146, 21) channel("dur2")    range(0.05, 2, 1.3, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) 

rslider bounds(730, 114, 60, 60)   channel("gn1")     range(0, 2, 1, 1, 0.001) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Gn1")
rslider bounds(730, 266, 60, 60)   channel("gn2")     range(0, 2, 1, 1, 0.001) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Gn2")


combobox bounds(340, 30, 77, 25)   channel("BNote")   text("Note", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")   value(2)
combobox bounds(308, 4, 109, 25)   channel("scale")   text("Scale", "pythagorean", "shur", "homayun", "segah", "chargah")  value(2) 
combobox bounds(346, 202, 77, 25)  channel("BNote2")  text("Note", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")   value(2)
combobox bounds(318, 174, 105, 25) channel("scale2")  text("Scale", "pythagorean", "shur", "homayun", "segah", "chargah") value(2) 


button   bounds(588, 404, 70, 30)  channel("saveA") text("Save A", "Save A") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)
button   bounds(588, 438, 70, 30)  channel("saveB") text("Save B", "Save B") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)
button   bounds(672, 404, 70, 30)  channel("loadA") text("Load A", "Load A") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)
button   bounds(672, 438, 70, 30)  channel("loadB") text("Load B", "Load B") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)


</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0
giSteps init 28

giStepArr1[]    init giSteps
giAccArr1[]     init giSteps
giRepArr1[]     init giSteps
giBassArr1[]    init giSteps

giStepArr2[]    init giSteps
giAccArr2[]     init giSteps
giRepArr2[]     init giSteps
giBassArr2[]    init giSteps


instr widgetWrite
    iX = 0
    iCount = 0
    ispc = 0
    while iCount < giSteps do
            Sseq1    sprintf "bounds(%d, 70, 15, 15)  , channel(\"seq1%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Sseq1Preset1    sprintf "bounds(%d, 70, 15, 15)  , channel(\"seq1saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
     Sseq1Preset2    sprintf "bounds(%d, 70, 15, 15)  , channel(\"seq1saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
            Sacc1    sprintf "bounds(%d, 90, 15, 15)  , channel(\"acc1%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Sacc1Preset1    sprintf "bounds(%d, 90, 15, 15)  , channel(\"acc1saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
     Sacc1Preset2    sprintf "bounds(%d, 90, 15, 15)  , channel(\"acc1saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount            
            Srep1    sprintf "bounds(%d, 110, 15, 15) , channel(\"rep1%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount           
     Srep1Preset1    sprintf "bounds(%d, 110, 15, 15) , channel(\"rep1saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount           
     Srep1Preset2    sprintf "bounds(%d, 110, 15, 15) , channel(\"rep1saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount            
            Sbass1   sprintf "bounds(%d, 130, 15, 15) , channel(\"bass1%d\")      colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount           
     Sbass1Preset1   sprintf "bounds(%d, 130, 15, 15) , channel(\"bass1saveA%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount 
     Sbass1Preset2   sprintf "bounds(%d, 130, 15, 15) , channel(\"bass1saveB%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
             Slte1   sprintf "bounds(%d, 150, 12, 12) , channel(\"lte1%d\")       colour(100, 100, 100, 200) ", 51+iCount*(17)+ispc, iCount

            Sseq2    sprintf "bounds(%d, 240, 15, 15) , channel(\"seq2%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Sseq2Preset1    sprintf "bounds(%d, 240, 15, 15) , channel(\"seq2saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
     Sseq2Preset2    sprintf "bounds(%d, 240, 15, 15) , channel(\"seq2saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
            Sacc2    sprintf "bounds(%d, 260, 15, 15) , channel(\"acc2%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Sacc2Preset1    sprintf "bounds(%d, 260, 15, 15) , channel(\"acc2saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
     Sacc2Preset2    sprintf "bounds(%d, 260, 15, 15) , channel(\"acc2saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
            Srep2    sprintf "bounds(%d, 280, 15, 15) , channel(\"rep2%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Srep2Preset1    sprintf "bounds(%d, 280, 15, 15) , channel(\"rep2saveA%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
     Srep2Preset2    sprintf "bounds(%d, 280, 15, 15) , channel(\"rep2saveB%d\")  colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
            Sbass2   sprintf "bounds(%d, 300, 15, 15) , channel(\"bass2%d\")      colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
     Sbass2Preset1   sprintf "bounds(%d, 300, 15, 15) , channel(\"bass2saveA%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount      
     Sbass2Preset2   sprintf "bounds(%d, 300, 15, 15) , channel(\"bass2saveB%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
             Slte2   sprintf "bounds(%d, 320, 12, 12) , channel(\"lte2%d\")       colour(100, 100, 100, 200) ", 51+iCount*(17)+ispc, iCount
            
     cabbageCreate "checkbox", Sseq1
     cabbageCreate "checkbox", Sseq1Preset1
     cabbageCreate "checkbox", Sseq1Preset2
     cabbageCreate "checkbox", Sacc1
     cabbageCreate "checkbox", Sacc1Preset1
     cabbageCreate "checkbox", Sacc1Preset2
     cabbageCreate "checkbox", Srep1
     cabbageCreate "checkbox", Srep1Preset1
     cabbageCreate "checkbox", Srep1Preset2
     cabbageCreate "checkbox", Sbass1
     cabbageCreate "checkbox", Sbass1Preset1
     cabbageCreate "checkbox", Sbass1Preset2
     cabbageCreate "image"   , Slte1
            
     cabbageCreate "checkbox", Sseq2
     cabbageCreate "checkbox", Sseq2Preset1
     cabbageCreate "checkbox", Sseq2Preset2
     cabbageCreate "checkbox", Sacc2
     cabbageCreate "checkbox", Sacc2Preset1
     cabbageCreate "checkbox", Sacc2Preset2
     cabbageCreate "checkbox", Srep2
     cabbageCreate "checkbox", Srep2Preset1
     cabbageCreate "checkbox", Srep2Preset2
     cabbageCreate "checkbox", Sbass2
     cabbageCreate "checkbox", Sbass2Preset1
     cabbageCreate "checkbox", Sbass2Preset2 
     cabbageCreate "image"   , Slte2          

     iCount += 1
     iX = (iX+1) % 4
     if iX == 0 then
     ispc += 5
     endif
    od
    
    kArrSeq1[] fillarray 1,0,0,1,1,0,0,1,0,1,0,0,1
    kWrite = 0
    while kWrite < lenarray(kArrSeq1) do
     Ssq1 sprintfk "seq1%d",kWrite
     cabbageSetValue Ssq1,kArrSeq1[kWrite]
     kWrite += 1
    od    
endin


instr saveWidgets
    Sp4 = p4
    indx = 0
    while indx < giSteps do
    Sseq1Save   sprintf "seq1%d",indx
    Sacc1Save   sprintf "acc1%d",indx
    Srep1Save   sprintf "rep1%d",indx
    Sbass1Save  sprintf "bass1%d",indx
    
    Sseq2Save   sprintf "seq2%d",indx
    Sacc2Save   sprintf "acc2%d",indx
    Srep2Save   sprintf "rep2%d",indx
    Sbass2Save  sprintf "bass2%d",indx

    iSeq1   cabbageGetValue Sseq1Save
    iAcc1   cabbageGetValue Sacc1Save
    iRep1   cabbageGetValue Srep1Save
    iBass1  cabbageGetValue Sbass1Save
    
    iSeq2   cabbageGetValue Sseq2Save
    iAcc2   cabbageGetValue Sacc2Save
    iRep2   cabbageGetValue Srep2Save
    iBass2  cabbageGetValue Sbass2Save
    
    giStepArr1[indx]    = iSeq1
    giAccArr1[indx]     = iAcc1
    giRepArr1[indx]     = iRep1
    giBassArr1[indx]    = iBass1
    
    giStepArr2[indx]    = iSeq2
    giAccArr2[indx]     = iAcc2
    giRepArr2[indx]     = iRep2
    giBassArr2[indx]    = iBass2
    
    Sseq1    sprintf "seq1save%s%d",Sp4,indx
    Sacc1    sprintf "acc1save%s%d",Sp4,indx
    Srep1    sprintf "rep1save%s%d",Sp4,indx
    Sbass1   sprintf "bass1save%s%d",Sp4,indx
    
    Sseq2    sprintf "seq2save%s%d",Sp4,indx
    Sacc2    sprintf "acc2save%s%d",Sp4,indx
    Srep2    sprintf "rep2save%s%d",Sp4,indx
    Sbass2   sprintf "bass2save%s%d",Sp4,indx
    
    cabbageSetValue Sseq1,giStepArr1[indx]
    cabbageSetValue Sacc1,giAccArr1[indx]
    cabbageSetValue Srep1,giRepArr1[indx]
    cabbageSetValue Sbass1,giBassArr1[indx]
    
    cabbageSetValue Sseq2,giStepArr2[indx]
    cabbageSetValue Sacc2,giAccArr2[indx]
    cabbageSetValue Srep2,giRepArr2[indx]
    cabbageSetValue Sbass2,giBassArr2[indx]
    
    indx += 1
    od
    ;Spreset sprintf "preset%s.txt",Sp4
    ;fprints Spreset, "%d ", iArrSave
endin


instr loadWidgets
    Sp4 = p4
    indx = 0
    while indx < giSteps do

    Sseq1Load   sprintf "seq1save%s%d",Sp4,indx
    Sacc1Load   sprintf "acc1save%s%d",Sp4,indx
    Srep1Load   sprintf "rep1save%s%d",Sp4,indx
    Sbass1Load  sprintf "bass1save%s%d",Sp4,indx

    Sseq2Load   sprintf "seq2save%s%d",Sp4,indx
    Sacc2Load   sprintf "acc2save%s%d",Sp4,indx
    Srep2Load   sprintf "rep2save%s%d",Sp4,indx
    Sbass2Load  sprintf "bass2save%s%d",Sp4,indx

    iSeq1   cabbageGetValue Sseq1Load
    iAcc1   cabbageGetValue Sacc1Load
    iRep1   cabbageGetValue Srep1Load
    iBass1  cabbageGetValue Sbass1Load
    
    iSeq2   cabbageGetValue Sseq2Load
    iAcc2   cabbageGetValue Sacc2Load
    iRep2   cabbageGetValue Srep2Load
    iBass2  cabbageGetValue Sbass2Load
    
    Sseq1   sprintf "seq1%d",indx
    Sacc1   sprintf "acc1%d",indx
    Srep1   sprintf "rep1%d",indx
    Sbass1  sprintf "bass1%d",indx
    
    Sseq2   sprintf "seq2%d",indx
    Sacc2   sprintf "acc2%d",indx
    Srep2   sprintf "rep2%d",indx
    Sbass2  sprintf "bass2%d",indx
    
    cabbageSetValue Sseq1,iSeq1
    cabbageSetValue Sacc1,iAcc1
    cabbageSetValue Srep1,iRep1
    cabbageSetValue Sbass1,iBass1
    
    cabbageSetValue Sseq2,iSeq2
    cabbageSetValue Sacc2,iAcc2
    cabbageSetValue Srep2,iRep2
    cabbageSetValue Sbass2,iBass2
    
    indx += 1
    od
endin


instr Widgets
    schedule "widgetWrite", 0, 1
    kSaveA cabbageGet "saveA"
    if changed(kSaveA) == 1 then
    schedulek "saveWidgets", 0, 1, "A"
    endif

    kSaveB cabbageGet "saveB"
    if changed(kSaveB) == 1 then
    schedulek "saveWidgets", 0, 1, "B"
    endif

    kLoadA cabbageGet "loadA"
    if changed(kLoadA) == 1 then
    schedulek "loadWidgets", 0, 1, "A"
    endif

    kLoadB cabbageGet "loadB"
    if changed(kLoadB) == 1 then
    schedulek "loadWidgets", 0, 1, "B"
    endif
endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

