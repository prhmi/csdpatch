<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1

seed 0

instr 1
kamp = 0.1
kcps  linseg 40, 15, 80; random 80, 200
printk2 kcps
kpos = 0.3; randi 0.5, 5,2
kbowpres = 0.6;randi:k( .2, 6,2) + 0.7
gkgain = 0.9
iconst = 0.8 ;random 0.8, 0.9
ivel = 0
ibowpos = 0
ilow = 20 
print iconst
	ain  wgbowedbar 	kamp, kcps, kpos, kbowpres, gkgain,iconst, ivel, ibowpos, ilow
	aout linen ain, p3/2, p3, p3/2	
   kMix = randi:k(0.4, 1,2)+0.5
   aEnvRvb interp (kMix+1)
 aRvbOut,aRvbOut freeverb aout, aout, 0.65,1
 aRvbMix		ntrpol		aout*aEnvRvb, aRvbOut , kMix
	outs aout,aout
endin

</CsInstruments>
<CsScore>
i1 0 15
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>100</x>
 <y>100</y>
 <width>320</width>
 <height>240</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
