<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


instr 1
kAmp = 0.2
;kFrq = jspline:k( 100, 2, 5)+ 400
kFrq = 700



kPos = jspline:k( 0.5, 0.7,1.5)+ 0.5
;kPos = 0.9
;kBowPres = ((kFrq/1000)+1)*1.5
kBowPres = jspline:k( 2.5, 0.7, 1)+ 3
printk2 kBowPres
kGain = 0.809
iconst = 0.8 ;random 0.8, 0.9
ivel = 0
ibowpos = 0
ilow = 20 
aSound wgbowedbar kAmp, kFrq, kPos, kBowPres, kGain ,iconst, ivel, ibowpos, ilow
outall aSound
endin

</CsInstruments>
<CsScore>
i1 0 9999
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>100</x>
 <y>100</y>
 <width>320</width>
 <height>240</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
