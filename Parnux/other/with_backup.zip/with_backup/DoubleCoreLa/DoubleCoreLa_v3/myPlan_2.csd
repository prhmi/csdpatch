<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



opcode MtoName, S,i
iMidi xin 
SNoteArr [] fillarray "C", "C#", "D", "D#","E", "F", "F#", "G","G#", "A", "A#", "B"
iAraziArr[] fillarray 1, 3, 6, 8, 10
iNoteIndex = (iMidi) % 12
iNoteIndxInt = int(iNoteIndex)
iSnumber = int(iMidi/12)-1
iSCent = (iMidi-int(iMidi))*100
if iSCent  == 0 then
Sout sprintfk "%d%s",iSnumber,SNoteArr[iNoteIndex]
elseif iSCent != 0 then
		if iSCent > 50 then
		Sout sprintfk "%d%s-%d",iSnumber,SNoteArr[iNoteIndex+1],(100-iSCent)
		elseif iSCent < 50 then
		Sout sprintfk "%d%s+%d",iSnumber,SNoteArr[iNoteIndex],iSCent
		elseif iSCent == 50 then
			if iNoteIndxInt == 1 || iNoteIndxInt == 3 || iNoteIndxInt == 6 ||
			iNoteIndxInt == 8 || iNoteIndxInt == 10 then
			Sout sprintfk "%d%s-",iSnumber,SNoteArr[iNoteIndex+1]
			elseif iNoteIndxInt == 0 || iNoteIndxInt == 2 || iNoteIndxInt == 4 ||
			iNoteIndxInt == 5 || iNoteIndxInt == 7 || iNoteIndxInt == 9 || 
			iNoteIndxInt == 11 then
			Sout sprintfk "%d%s+",iSnumber,SNoteArr[iNoteIndex]
			endif
		endif
endif
xout Sout
endop

/*
D+ segah:
03. In 60.61 Hz.   (Sound Block 03 in B)
07. In 54 Hz.      (Sound Block 07 in A)
08. in 37.09 Hz.   (Sound Block 08 in D Quarter Sharp)
13. In 45.41 Hz.   (Sound Block 13 in F Sharp)
17. In 40.45 Hz.   (Sound Block 17 in E)
22. In 49.51 Hz.   (Sound Block 22 in G Quarter Sharp)
23. In 34.02 Hz.   (Sound Block 23 in C Sharp)
*/


opcode segah, i[],i[]i
  iInArr[],iBaseMidi xin
  iLen lenarray iInArr
  iOutArr[] init iLen
  iNote = iBaseMidi-1.5
  indx = 0
	while indx < iLen do
	iNote = iNote+(iInArr[indx])
	iOutArr[indx] = iNote
	indx += 1
	od
  xout iOutArr
endop



opcode dastgah, i[]S,i[]ii
  iInArr[],iBaseMidi,iMidiIn xin
  iLen lenarray iInArr
  iOutArr[] init iLen
  iNote = iBaseMidi
  indx = 0
	while indx < iLen do
	iNote = iNote+(iInArr[indx])
	iOutArr[indx] = iNote
	indx += 1
	od
	iMidi = iMidiIn
	     until iMidi < iBaseMidi+12 do
  		iMidi = iMidi-12
  		enduntil
  		iIntrval = (iMidi-iBaseMidi)
iMidiOut = iOutArr[iIntrval]
SnoteOut mton iMidiOut
  xout iOutArr,SnoteOut
endop


instr 1
;iRatio = 432/440
iRatio = 440/440
Sname ="4G"
iBaseMidi ntom Sname
iShurArr[] 		fillarray 0, 1.5, 1.5, 2, 1.5, 1.5, 2
iAbuataArr[] 		fillarray 0, 1.5, 2, 2, 1, 2, 2
iBayattorkArr[] fillarray 0, 2, 2, 1, 2, 2, 1.5
iAfshariArr[] 	fillarray 0, 1.5, 1.5, 2, 2, 1.5, 1.5
iDashtiArr[] 		fillarray 0, 1, 2, 2, 1.5, 1.5, 2
iNavaArr[] 		fillarray 0, 2, 1, 2, 2, 1.5, 1.5
i3gahArr[] 		fillarray 0, 1.5, 2, 1.5, 1.5, 2, 2
i4gahArr[] 		fillarray 0, 1.5, 2.5, 1, 2, 1.5, 2.5
iHomayunArr[]   fillarray 0, 2.5, 1, 2, 1, 2, 2
iBayatEsArr[]   fillarray 0, 2, 1, 2, 2, 1.5, 2

Snote ="4A"
iMidi ntom Snote

iDastgah[],SnoteOut dastgah iShurArr,iBaseMidi,iMidi
indx = 0
while indx < lenarray(iDastgah) do
iMidi = iDastgah[indx]
iFrq mtof iMidi
iFrqOut = iFrq*iRatio
Snote MtoName iDastgah[indx]
printf_i  "%s ", 1, Snote
indx += 1
od
printf_i  "| Midi = %s\n", 1,SnoteOut
;printarray iDastgah, "%.1f"
endin

</CsInstruments>
<CsScore>
i1 0 .1
</CsScore>
</CsoundSynthesizer>




















<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
