<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0
giSine  ftgen	0,0,4096,10,1
instr 1
 	iFrqMin = 1000
 	iAtt = 0.01
kFilter = 2000
 	iFrq = iFrqMin+100
 	kFrqRange = 500
	kAmp    rspline  0.2, 0.3, 0.7, 1
	kFrq    rspline  iFrq, iFrq+kFrqRange, 0.7, 1
	kTens   rspline  0.3, 0.5, 2, 5
	kVib    = kFrq-cent(500)
	kvamp   rspline  0.1, 0.4, 1, 3
	aSound	wgbrass    kAmp,kFrq,kTens,iAtt,kVib,kvamp,giSine,iFrqMin
	aSound  butlp     aSound,kFilter
	aSound  pareq    aSound,500,6,0.707, 1
	aRvbL,aRvbR reverbsc aSound,aSound,0.9,7000
	aMixL		ntrpol	 aSound,aRvbL,  .4
	aMixR		ntrpol	 aSound,aRvbR,  .4
   outs     aMixL,aMixR
endin

</CsInstruments>
<CsScore>
i1 0 10
</CsScore>
</CsoundSynthesizer>


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>100</x>
 <y>100</y>
 <width>320</width>
 <height>240</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
