
<Cabbage>
form caption("DoubleCoreLa") size(650, 350)  guiMode("queue")  colour(30,0,40) style("legacy") pluginId("crlp")
button bounds(56, 142, 70, 30) channel("saveA") text("Save A", "Save A") colour:0(120, 45, 113, 255) colour:1(120, 45, 113, 255)
button bounds(132, 142, 70, 30) channel("saveB") text("Save B", "Save B") colour:0(120, 45, 113, 255) colour:1(120, 45, 113, 255)

button bounds(56, 182, 70, 30) channel("loadA") text("Load A", "Load A") colour:0(120, 45, 113, 255) colour:1(120, 45, 113, 255)
button bounds(132, 182, 70, 30) channel("loadB") text("Load B", "Load B") colour:0(120, 45, 113, 255) colour:1(120, 45, 113, 255)


</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1



opcode ArrToStrg, S,i[]
  iArrIn [] xin
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    Sscale     sprintf "%d ",iArrIn[indx]
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop
opcode StrToArr, i[],S
SIn xin
Snote     sprintf "%s ",SIn
iLen strlen SIn
iReadChar = 0
iLenCount = 0
while iReadChar < iLen do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	od	
	iReadChar2 = iReadChar+1
			while strchar(Snote,iReadChar2) == 32 do
			iReadChar2 += 1
			iReadChar += 1
			od
iReadChar += 1
iLenCount += 1
od
iArrOut [] init iLenCount

iWrite = 0
iRead = 0
while iRead < iLen do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
	Schar     strsub    Snote, iStart, iStart+iCountChr
	if strchar(Schar,0) != 0 then
	inum strtod Schar
	;print inum
	iArrOut [iWrite] = inum
	iWrite += 1
	endif
iRead += 1
od
xout iArrOut
endop



instr widgetWrite
iX = 0
iCount = 0
ispc = 0
        while iCount < 10 do
            Sseq1 sprintf "bounds(%d, 70, 15, 15) , channel(\"seq1%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(17)+ispc, iCount
            cabbageCreate "checkbox", Sseq1
            SPreset1 sprintf "bounds(%d, 90, 15, 15) , channel(\"saveA%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
            cabbageCreate "checkbox", SPreset1
            SPreset2 sprintf "bounds(%d, 110, 15, 15) , channel(\"saveB%d\") colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255), visible(0)", 50+iCount*(17)+ispc, iCount
            cabbageCreate "checkbox", SPreset2
            iCount += 1
            iX = (iX+1) % 4
            if iX == 0 then
            ispc += 5
            endif
        od
kArrSeq1[] fillarray 1,0,0,1,1,0,0,1,0,1,0,0,0
        kWrite = 0
        while kWrite < lenarray(kArrSeq1) do
        Ssq1 sprintfk "seq1%d",kWrite
        cabbageSetValue Ssq1,kArrSeq1[kWrite]
        kWrite += 1
        od
endin


instr Widgets
schedule "widgetWrite", 0, 1

kSaveA cabbageGet "saveA"
if changed(kSaveA) == 1 then
schedulek "saveWidgets", 0, 1, "A"
endif

kSaveB cabbageGet "saveB"
if changed(kSaveB) == 1 then
schedulek "saveWidgets", 0, 1, "B"
endif


kLoadA cabbageGet "loadA"
if changed(kLoadA) == 1 then
schedulek "loadWidgets", 0, 1, "A"
endif

kLoadB cabbageGet "loadB"
if changed(kLoadB) == 1 then
schedulek "loadWidgets", 0, 1, "B"
endif



endin


instr saveWidgets
Sp4 = p4

giArrSave[] init 10
iGetWidgets = 0
while iGetWidgets < 10 do
SArrSave sprintf "seq1%d",iGetWidgets
iArrSave cabbageGetValue SArrSave
giArrSave[iGetWidgets] = iArrSave
Ssq1 sprintf "save%s%d",Sp4,iGetWidgets
;Spreset sprintf "preset%s.txt",Sp4
;fprints Spreset, "%d ", iArrSave
cabbageSetValue Ssq1,giArrSave[iGetWidgets]
iGetWidgets += 1
od
endin


instr loadWidgets
Sp4 = p4
iGetWidgets = 0
while iGetWidgets < 10 do
SArrSave sprintf "save%s%d",Sp4,iGetWidgets
iArrSave cabbageGetValue SArrSave

SArrLoad sprintf "seq1%d",iGetWidgets
cabbageSetValue SArrLoad,iArrSave
iGetWidgets += 1
od

endin

</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

