<CsoundSynthesizer>

<CsOptions>
-odac
</CsOptions>

<CsInstruments>

sr      =       44100
ksmps   =       32
nchnls  =       2
0dbfs   =       1
        seed    0

gisine  ftgen	0,0,4096,10,1
giTri     ftgen     0, 0, 2^10, 10, 1, 0, -1/9, 0, 1/25, 0, -1/49, 0, 1/81
giSaw     ftgen     0, 0, 2^10, 10, 1, 1/2, 1/3, 1/4, 1/5, 1/6, 1/7, 1/8, 1/9  ;harmonics
giSquare  ftgen     0, 0, 2^10, 10, 1, 0, 1/3, 0, 1/5, 0, 1/7, 0, 1/9


 instr 1 
 	iFrqMin = 400
 	kFilter = 3000
 	iFrq = iFrqMin+10
 	kFrqRange = 10
	kAmp    rspline  0.2, 0.3, 0.7, 1
	kFrq    rspline  iFrq, iFrq+kFrqRange, 0.7, 1
	kPres   rspline  0.1, 5, 0.1, 5
	kRate   rspline  0.1, 2, 0.1, 5
	kVib    rspline  1,   7, 0.7, 5
	aSound	wgbow    kAmp,kFrq,kPres,kRate,kVib,0,giSquare,iFrqMin
	aSound  butlp     aSound,kFilter
	aSound  pareq    aSound,500,6,0.707, 1
	aRvbL,aRvbR reverbsc aSound,aSound,0.9,7000
	aMixL		ntrpol	 aSound,aRvbL,  .4
	aMixR		ntrpol	 aSound,aRvbR,  .4
   outs     aMixL,aMixR
 endin


</CsInstruments>

<CsScore>
i 1  0 480  

</CsScore>

</CsoundSynthesizer>


<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
