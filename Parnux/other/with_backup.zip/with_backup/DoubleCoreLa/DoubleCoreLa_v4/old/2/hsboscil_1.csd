<CsoundSynthesizer>
<CsOptions>
; Select audio/midi flags here according to platform
-odac     ;;;realtime audio out
;-iadc    ;;;uncomment -iadc if realtime audio input is needed too
; For Non-realtime ouput leave only the line below:
; -o hsboscil.wav -W ;;; for file output any platform
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 32
nchnls = 2
0dbfs  = 1

; synth waveform
giwave  ftgen 1, 0, 1024, 10, 10, 1, 2, 5, 2, 1
; blending window
giblend ftgen 2, 0, 1024, -19, 1, 0.5, 270, 0.5
seed 0


instr 1
if metro(1/5) == 1 then
schedulek 2, 0, 7
endif

endin


instr 2 ; produces Risset's glissando.
  kamp = .4
  kbrite jspline 20, 1, 15
  ibasfreq random 50, 120
  ioctcnt = 10
  ktone rspline 0.1, 0.5,  0.4, 0.7

aSound hsboscil kamp, ktone, kbrite, ibasfreq, giwave, giblend, ioctcnt, 2

iplk = 1
iFrq random 30, 80
print iFrq
	rireturn
ipick = 0.1
krefl rspline 0.2, 0.9, 0.4, 0.7
aSound2 repluck iplk, 0.5, iFrq, ipick, krefl, aSound

aSound3 dcblock2 aSound2

kFiltTable rspline 0, 1000, 12, 17
aFilt clfilt aSound3, 1200+kFiltTable, 0, 10
iAtt = 0.2
aEnv linseg 0, iAtt, 1, p3-(iAtt*2), 1, iAtt, 0
aOut = aFilt*aEnv*2
chnmix aOut, "snd"

endin


instr 3
aIn chnget "snd"


aRvrb nreverb aIn, 2, 0.3
aMix ntrpol aIn, aRvrb, 0.2
outall aMix

chnclear "snd"

endin



</CsInstruments>
<CsScore>

i 1 0 99999
i 3 0 9999
</CsScore>
</CsoundSynthesizer>








<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>350</x>
 <y>448</y>
 <width>407</width>
 <height>226</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
 <bsbObject type="BSBScope" version="2">
  <objectName/>
  <x>9</x>
  <y>19</y>
  <width>350</width>
  <height>150</height>
  <uuid>{56b8e540-019a-4221-bc94-8606a0f31c70}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <value>-255.00000000</value>
  <type>scope</type>
  <zoomx>2.00000000</zoomx>
  <zoomy>1.00000000</zoomy>
  <dispx>1.00000000</dispx>
  <dispy>1.00000000</dispy>
  <mode>0.00000000</mode>
  <triggermode>NoTrigger</triggermode>
 </bsbObject>
</bsbPanel>
<bsbPresets>
</bsbPresets>
