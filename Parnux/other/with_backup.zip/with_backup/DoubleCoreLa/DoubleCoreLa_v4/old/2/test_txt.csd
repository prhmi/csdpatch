<CsoundSynthesizer>
<CsOptions>
-m128
</CsOptions>
<CsInstruments>

sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


instr 1
SFilenames[] directory ".", ".txt"
Sfile1 = "files\test.txt"
iLenFile1    strlen   Sfile1

Snote = "test."
iLenFile1    strlen   Snote
iChr strchar Snote, 0
print iChr
indx = 0
while indx < iLenFile1 do
iChr strchar Snote, indx
print iChr
	if iChr == 46 then
;	print indx
	endif
indx += 1
od
;puts Sfile1, 1
    Sfile3 strsub  Sfile1, indx, iLenFile1-4
;    puts Sfile3,1
    SFileShow1    sprintfk "text(%s)", Sfile3
endin

</CsInstruments>
<CsScore>
i1 0 1
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>0</width>
 <height>0</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>240</r>
  <g>240</g>
  <b>240</b>
 </bgcolor>
</bsbPanel>
<bsbPresets>
</bsbPresets>
