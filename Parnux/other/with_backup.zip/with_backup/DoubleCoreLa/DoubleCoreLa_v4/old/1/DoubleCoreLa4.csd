;v3
<Cabbage>
form caption("DoubleCoreLa")    size(1350, 700)   guiMode("queue")  colour(30,30,50) pluginId("crlp") ; style("legacy")


label    bounds(35, 32, 30, 12)    channel("label2")  text("Hold")

label    bounds(50, 104, 28, 12)    channel("label3")  text("seq") 
label    bounds(50, 124, 28, 12)    channel("label4")  text("acc")
label    bounds(50, 162, 28, 12)   channel("label5")  text("bss")
label    bounds(50, 142, 28, 12)   channel("label6")  text("rep")

label    bounds(36, 258, 40, 12)   channel("label8")  text("On/Off")

label    bounds(50, 302, 28, 12)   channel("label10") text("seq")
label    bounds(50, 322, 28, 12)   channel("label11") text("acc")
label    bounds(50, 360, 28, 12)   channel("label12") text("bss")
label    bounds(50, 340, 28, 12)   channel("label13") text("rep")

label    bounds(596, 272, 46, 12)  channel("label15") text("Reverse")
label    bounds(598, 72, 46, 12)   channel("label16") text("Reverse")

label    bounds(84, 430, 78, 13)   channel("label18") text("pad on/off")
label    bounds(936, 462, 45, 16)   channel("label19") text("FM")
label    bounds(16, 62, 60, 20)  channel("noteshow1")  fontColour(208, 157, 253, 255) align("left")  text(" ")
label    bounds(20, 232, 60, 20)  channel("noteshow2")  fontColour(208, 157, 253, 255) align("left") text("")



checkbox bounds(12, 28, 20, 20)    channel("hold")    popupText("Hold")            colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(1)
checkbox bounds(708, 76, 20, 20)    channel("rndwidgets1")    popupText("Rnd")            colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(0)
checkbox bounds(706, 274, 20, 20)    channel("rndwidgets2")    popupText("Rnd")            colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) 



checkbox bounds(650, 70, 18, 18)   channel("rvrs1")   popupText("Synth")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(0)
checkbox bounds(648, 270, 18, 18)  channel("rvrs2")   popupText("Synth")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) 
checkbox bounds(14, 258, 18, 18)   channel("sq2")     popupText("Start")           colour:0(100, 100, 100, 255) colour:1(100, 250, 60, 255) value(1)



checkbox bounds(54, 426, 22, 22)   channel("pdfx")                                   colour:0(100, 100, 100, 255) colour:1(141, 88, 156, 255) value(1)


nslider  bounds(90, 29, 60, 45)     channel("bpm1")   range(10, 210, 90, 1, 1)     fontColour(208, 157, 253, 255) text("BPM") colour(60, 50, 60, 255)
nslider  bounds(150, 44, 40, 30)    channel("DV1")     range(1, 10, 4, 1, 1)        fontColour(208, 157, 253, 255) text("DV") colour(60, 50, 60, 255)
nslider  bounds(192, 35, 40, 40)    channel("steps1")  range(1, 28, 13, 1, 1)       fontColour(208, 157, 253, 255) text("Step") colour(60, 50, 60, 255)
nslider  bounds(90, 236, 60, 45)   channel("bpm2")    range(10, 250, 90, 1, 1)     fontColour(208, 157, 253, 255) text("BPM") colour(60, 50, 60, 255)
nslider  bounds(150, 250, 40, 30)  channel("DV2")     range(1, 10, 4, 1, 1)        fontColour(208, 157, 253, 255) text("DV") colour(60, 50, 60, 255)
nslider  bounds(192, 240, 40, 40)  channel("steps2")  range(1, 28, 13, 1, 1)       fontColour(208, 157, 253, 255) text("Step")colour(60, 50, 60, 255)
nslider  bounds(940, 620, 47, 31)  channel("cnt")  range(10, 500, 50, 1, 1)       fontColour(208, 157, 253, 255) text("Cent") colour(60, 50, 60, 255)
nslider  bounds(492, 236, 45, 38)  channel("oct")  range(-2, 2, 0, 1, 1)       fontColour(208, 157, 253, 255) text("octv") colour(60, 50, 60, 255)

hslider  bounds(238, 22, 190, 30)  channel("dur1")    range(0.05, 5, 1.5, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255)  text("dur")  
hslider  bounds(236, 226, 190, 30) channel("dur2")    range(0.05, 5, 1.3, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255)  text("dur")  
hslider  bounds(44, 550, 200, 25) channel("spdstrngmin")    range(0.1, 1, 0.7, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("spdMin")  
hslider  bounds(46, 466, 200, 25) channel("pres")    range(0.2, 0.7, 0.3, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("pres")  
hslider  bounds(318, 464, 200, 25) channel("pos")    range(0.2, 0.7, 0.7, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("pose")  
hslider  bounds(320, 498, 200, 25) channel("vib")    range(0.2, 0.7, 0.5, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("vib")  
hslider  bounds(44, 520, 200, 25) channel("spdstrng")    range(0.7, 12, 5, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("spdMax")  
hslider  bounds(44, 580, 200, 25) channel("spdfrq")    range(0.6, 12, 1, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("spdFrq")  
hslider  bounds(238, 54, 190, 30) channel("att1")    range(0.0001, 0.05, 0.001, 1, 0.0001) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("att")  
hslider  bounds(236, 258, 190, 30) channel("att2")    range(0.0001, 0.05, 0.001, 1, 0.0001) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("att")  

hslider  bounds(44, 612, 200, 25) channel("pdfltr")    range(100, 12000, 1000, 1, 1) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("Filter")  
hslider  bounds(1118, 276, 190, 30) channel("fltr")    range(100, 12000, 1000, 1, 1) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("Filter")  

vslider  bounds(940, 478, 20, 130) channel("fma")    range(0, 400, 40, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("a")  
vslider  bounds(960, 478, 20, 130) channel("fmf")    range(1, 400, 100, 1, 0.01) colour(208, 157, 253, 255) trackerColour(208, 157, 253, 255) text("f")  

;rslider  bounds(574, 460, 60, 60)   channel("att")     range(0.0001, 0.05, 0.001, 1, 0.0001) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Att")     
;rslider  bounds(258, 366, 60, 60)   channel("fltr")     range(100, 8000, 1000, 1, 1) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Fltr")     
rslider  bounds(1204, 204, 60, 60)   channel("rvbpad")     range(0.3, 0.9, 0.75, 1, 0.001) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("reverb")     
;rslider  bounds(732, 418, 60, 60)   channel("attpad")     range(0.1, 2, 0.1, 1, 0.01) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Att")     

;rslider  bounds(884, 418, 60, 60)   channel("ginpad")     range(0.1, 5, 1, 1, 0.01) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Gain")     
;rslider  bounds(834, 418, 60, 60)   channel("pdfltr")     range(100, 8000, 1000, 1, 1) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Fltr")     
rslider  bounds(1136, 204, 60, 60)   channel("dltmpd")     range(0, 3, 1, 1, 0.1) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("delay")     


vslider bounds(808, 10, 50, 150) channel("gn1") range(0, 20, 15, 1, 1) trackerColour(208, 157, 253, 255)
vslider bounds(812, 236, 50, 150) channel("gn2") range(0, 20, 15, 1, 1) trackerColour(208, 157, 253, 255)
vslider bounds(986, 482, 50, 150) channel("gnpd") range(0, 80, 60, 1, 1) trackerColour(208, 157, 253, 255)



;rslider  bounds(190, 460, 60, 60)   channel("gn1")      range(0, 5, 0.5, 1, 0.001) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Gn1")
;rslider  bounds(312, 460, 60, 60)   channel("gn2")      range(0, 5, 0.5, 1, 0.001) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Gn2")

rslider bounds(1036, 150, 60, 60)    channel("fdb")      range(0, 1, 0.3, 1, 0.001) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("FdB")
rslider bounds(918, 150, 60, 60)    channel("rvrb")      range(0.3, 3, 0.3, 1, 0.001) valueTextBox(1) colour(250, 200, 250, 250) trackerColour(250, 150, 250, 255) text("Rvrb")



nslider  bounds(984, 152, 44, 44) range(1, 12, 4, 1, 1)  fontColour(208, 157, 253, 255) text("Delay") channel("dlt")


combobox bounds(732, 72, 70, 30)   channel("BNote")   text("Note", "G", "A-", "Bb", "C", "E-", "D-", "F", "A", "B", "Gb", "D")   value(2) colour(60, 50, 60, 255)
combobox bounds(692, 36, 110, 35)   channel("scale")   text("Scale", "pythagorean", "shur", "abuata", "bayat tork", "afshari", "dashti", "nava", "segah", "chargah",  "homayun", "bayat esf")  value(2) colour(60, 50, 60, 255)
combobox bounds(732, 268, 70, 30)  channel("BNote2")  text("Note", "G", "A-", "Bb", "C", "E-", "D-", "F", "A", "B", "Gb", "D")   value(2) colour(60, 50, 60, 255)
combobox bounds(692, 232, 110, 35) channel("scale2")  text("Scale", "pythagorean", "shur", "abuata", "bayat tork", "afshari", "dashti", "nava", "segah", "chargah", "homayun", "bayat esf") value(2)  colour(60, 50, 60, 255)
combobox bounds(702, 104, 100, 30)   channel("sound1")  text("Instr", "Dahina", "Wood", "Tibetan", "Albert", "sine", "Tri", "Saw", "Square", "myset", "Pick", "VCO")   value(6) colour(60, 50, 60, 255)
combobox bounds(702, 300, 100, 30)   channel("sound2")  text("Instr", "Dahina", "Wood", "Tibetan", "Albert", "sine", "Tri", "Saw", "Square", "myset", "Pick", "VCO")  value(4) colour(60, 50, 60, 255)
combobox bounds(178, 424, 71, 26)   channel("sound3")  text("Instr", "Sine", "Tri", "Saw", "Square")   value(2) colour(60, 50, 60, 255)


label bounds(1092, 52, 239, 66) channel("sec") fontColour(219, 169, 206, 255) text("00 : 19")
button bounds(1212, 20, 116, 27) channel("start") text("S  T  A  R  T", "S  T  O  P") colour:0(204, 124, 188, 255) colour:1(96, 69, 69, 255) value(1)
label bounds(1132, 16, 70, 33) channel("data")  fontColour(219, 169, 206, 255) colour(78, 49, 79, 255) text("0")
label bounds(1158, 134, 128, 57) channel("showBPM") fontColour(219, 169, 206, 255) text("00")

button   bounds(1100, 358, 60, 25)  channel("saveA") text("Save A", "Save A") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)
button   bounds(1100, 394, 60, 25)  channel("saveB") text("Save B", "Save B") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)
button   bounds(1264, 358, 60, 25)  channel("loadA") text("Load A", "Load A") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)
button   bounds(1264, 394, 60, 25)  channel("loadB") text("Load B", "Load B") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)
filebutton bounds(1182, 358, 60, 25) channel("sampleA") text("sample A", "Loaded") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)
filebutton bounds(1182, 394, 60, 25) channel("sampleB") text("sample B", "Loaded") colour:0(120, 45, 113, 255)  colour:1(120, 45, 113, 255)




label bounds(252, 468, 59, 18) channel("label25") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(524, 464, 59, 18) channel("label26") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(526, 500, 59, 18) channel("label27") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(250, 522, 59, 18) channel("label28") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(250, 550, 59, 18) channel("label29") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(250, 580, 59, 18) channel("label30") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(430, 28, 59, 18) channel("label31") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(430, 58, 59, 18) channel("label32") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(428, 262, 59, 18) channel("label33") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(428, 232, 59, 18) channel("label34") text("CC-03") fontColour(224, 219, 219, 255)
label bounds(1002, 118, 59, 18) channel("label35") text("CC-03") fontColour(224, 219, 219, 255)

label bounds(250, 614, 59, 18) channel("label36") text("CC-03") fontColour(224, 219, 219, 255)
vslider bounds(1066, 540, 50, 150) channel("out1") range(0, 80, 20, 1, 1) trackerColour(208, 157, 253, 255)
vslider bounds(1108, 540, 50, 150) channel("out2") range(0, 80, 20, 1, 1) trackerColour(208, 157, 253, 255)
vslider bounds(1148, 540, 50, 150) channel("out3") range(0, 80, 0, 1, 1) trackerColour(208, 157, 253, 255)
vslider bounds(1190, 540, 50, 150) channel("out4") range(0, 80, 0, 1, 1) trackerColour(208, 157, 253, 255)
nslider bounds(1240, 472, 93, 44) channel("gain") range(-90, 50, 0, 1, 1) colour(78, 49, 79, 255) text("Master Gain (dB)")
nslider bounds(1072, 504, 40, 35) channel("outn1") range(-90, 50, -45, 1, 1) colour(78, 49, 79, 255)
nslider bounds(1112, 504, 40, 35) channel("outn2") range(-90, 50, -45, 1, 1) colour(78, 49, 79, 255)
nslider bounds(1152, 504, 40, 35) channel("outn3") range(-90, 50, -60, 1, 1) colour(78, 49, 79, 255)
nslider bounds(1192, 504, 40, 35) channel("outn4") range(-90, 50, -60, 1, 1) colour(78, 49, 79, 255)
vmeter bounds(1244, 540, 15, 150) channel("meter1") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(1268, 540, 15, 150) channel("meter2") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(1292, 540, 15, 150) channel("meter3") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
vmeter bounds(1316, 540, 15, 150) channel("meter4") value(0) outlineColour(0, 0, 0), overlayColour(0, 0, 0) meterColour:0(250, 10, 0, 255) meterColour:1(10, 120, 40, 255) meterColour:2(10, 70, 200, 255) outlineThickness(0)
image bounds(1244, 526, 15, 15) channel("clip1") colour(0, 0, 0, 255)
image bounds(1268, 526, 15, 15) channel("clip2") colour(0,0,0)
image bounds(1292, 526, 15, 15) channel("clip3") colour(0,0,0)
image bounds(1316, 526, 15, 15) channel("clip4") colour(0,0,0)


image bounds(1088, 424, 30, 30) channel("dustlight") corners(5)  colour(70, 62, 68, 255)
image bounds(1128, 424, 30, 30) channel("seqlight") corners(5) colour(70, 62, 68, 255)
image bounds(1166, 424, 30, 30) channel("bowlight") corners(5) colour(70, 62, 68, 255)
image bounds(1204, 424, 30, 30) channel("flutelight") corners(5) colour(70, 62, 68, 255)
image bounds(1242, 424, 30, 30) channel("ambienlight") corners(5) colour(70, 62, 68, 255)
image bounds(1282, 424, 30, 30) channel("loadlight") corners(5) colour(70, 62, 68, 255)


</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-m128 	-dm0 -n -+rtmidi=null -M0 -d  -m0d -Q0 --midi-key=4
</CsOptions>
<CsInstruments>

;sr = 44100
ksmps = 64
nchnls = 2
0dbfs = 1


seed 0





opcode MtoNameInt, S,i
iMidi xin 
SNoteArr[] fillarray "C", "C#", "D", "D#","E","F", "F#", "G","G#", "A", "Bb", "B"
iAraziArr[] fillarray 1, 3, 6, 8, 10
iNoteIndex = (iMidi) % 12
iNoteIndxInt = int(iNoteIndex)
iSCent = int((iMidi-int(iMidi))*100.5)
if iSCent  == 0 then
Sout sprintf "%s",SNoteArr[iNoteIndex]
elseif iSCent == 100 then
Sout sprintf "%s",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
else
		if iSCent > 50 then
		Sout sprintf "%s-",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
		elseif iSCent <= 50 then
		Sout sprintf "%s+",SNoteArr[iNoteIndex]
			indx = 0			
			while indx < lenarray(iAraziArr) do
				if iNoteIndxInt = iAraziArr[indx] then
				Sout sprintf "%s-",SNoteArr[(iNoteIndex+1)%lenarray(SNoteArr)]
				endif
			indx += 1
			od
		endif
endif
xout Sout
endop



giTableSize    =    131073   
giRtosScale    =    1000  

giSine  	  	 ftgen		0, 0, 2^10,10,1
giSineTwo  	  	 ftgen		0, 0, 2^10,10,1, 0.5
giTri     ftgen     0, 0, 2^10, 10, 1, 0, -1/9, 0, 1/25, 0, -1/49, 0, 1/81
giSaw     ftgen     0, 0, 2^10, 10, 1, 1/2, 1/3, 1/4, 1/5, 1/6, 1/7, 1/8, 1/9  ;harmonics
giSquare  ftgen     0, 0, 2^10, 10, 1, 0, 1/3, 0, 1/5, 0, 1/7, 0, 1/9
giMyset  ftgen		0, 0, 2^10,10,1, 0.7, 0, 0.1, 0, 0, 0.3, 0, 0, 0, 0.2

giwave1        ftgen    0, 0, giTableSize, 9, 1000,1.000,0, 2890,0.500,0,		\
					     4950,0.250,0,     6990,0.125,0,     8010,0.062,0,     			\
					     9020,0.031,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,	\
					     0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,   	\
					     0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,    	\
					     0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,    	\
					     0,0.000,0
giwave2    ftgen    0, 0, giTableSize, 9, 1000,1.000,0,     2572,0.667,0,  	\
						  4644,0.444,0,     6984,0.296,0,     9723,0.198,0,   				\
						   0,0.132,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,    \
						   0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,     \
						   0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,     \
						   0,0.000,0,     0,0.000,0,     0,0.000,0,     0,0.000,0,     \
						   0,0.000,0
giwave3        ftgen    0, 0, giTableSize, 9, 1000,1.000,0,     1027,1.000,0,\
					     1422,1.000,0,     1448,1.000,0,     1466,1.000,0,     \
					     1499,1.000,0,     1789,1.000,0,     1877,1.000,0,     \
					     1965,1.000,0,     1979,1.000,0,     2033,1.000,0,     \
					     2145,1.000,0,     2156,1.000,0,     2253,1.000,0,     \
					     2291,1.000,0,     2333,1.000,0,     2457,1.000,0,     \
					     2493,1.000,0,     2566,1.000,0,     2606,1.000,0,     \
					     2669,1.000,0,     2714,1.000,0

giwave4    ftgen    0, 0, giTableSize, 9, 1000,1.000,0,     1002,0.833,0, \
					    1794,0.694,0,     1801,0.579,0,     2520,0.482,0,    \
					    2522,0.402,0,     2991,0.335,0,     2994,0.279,0,     \
					    3786,0.233,0,     3806,0.194,0,     4569,0.162,0,     \
					    4575,0.135,0,     5030,0.112,0,     5046,0.093,0,     \
					    6076,0.078,0,     5909,0.065,0,     6412,0.054,0,     \
					    6443,0.045,0,     7083,0.038,0,     7092,0.031,0,     \
					    7319,0.026,0,     7555,0.022,0






giScaleArr[] init 12
giShurArr[] 			fillarray 0, 1.5, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1
giAbuataArr[] 		fillarray 0, 0.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
giBayattorkArr[] 	fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5
giAfshariArr[] 		fillarray 0, 1.5,0.5, 1, 1, 1, 1, 1, 1.5,0.5, 1, 1
giDashtiArr[] 		fillarray 0, 1, 1, 1, 1, 1, 1.5,0.5,  1, 1, 1, 1
giNavaArr[] 			fillarray 0, 1, 1, 1, 1, 1, 1, 1, 1.5, 0.5, 1, 1
gi3gahArr[] 			fillarray 0, 0.5, 1, 1, 1, 1.5, 0.5, 1.5, 0.5, 1, 1, 1
gi4gahArr[] 			fillarray 0, 1.5, 0.5, 1, 1,1, 1, 1, 1.5, 0.5, 1, 1
giHomayunArr[]   	fillarray 0, 0.5, 1, 1, 1,1, 1, 1.5, 0.5, 1, 1, 1
giBayatEsArr[]   	fillarray 0, 1,1,1, 1, 1,1,1, 1.5, 0.5, 1.5, 0.5



;;midi
opcode RmvZ, i[],i[]
iArrIn[] xin
iLen lenarray iArrIn
indxc = 0
iLenA = 0
while indxc < iLen do
	if iArrIn[indxc] != 0 then
	iLenA += 1
	endif
indxc += 1
od
		if iLenA == 0 then
		iLenA = 1
		endif
iArrOut [] init iLenA
indx = 0
indxw = 0
while indx < iLen do
	if iArrIn[indx] != 0 then
	iArrOut [indxw] = iArrIn[indx]
	indxw += 1
	endif
indx += 1
od
xout iArrOut
endop


;;scale
opcode pythagorean,i,ii
iBaseNote,iNote xin
iMidi = iNote
		iOct = 0
     until iMidi < iBaseNote+12 do
  		iMidi = iMidi-12
  		iOct += 1
  		enduntil
 iMidiMin = (iMidi-iBaseNote)
  	iRatio = 1
  	if iMidiMin == 0 then
  	iRatio = 1/1
  	elseif iMidiMin == 1 then
  	iRatio = 2187/2048
  	elseif iMidiMin == 2 then
  	iRatio = 9/8
  	elseif iMidiMin == 3 then
  	iRatio = 32/27
  	elseif iMidiMin == 4 then
  	iRatio = 81/64
  	elseif iMidiMin == 5 then
  	iRatio = 4/3
  	elseif iMidiMin == 6 then
  	iRatio = 729/512
  	elseif iMidiMin == 7 then
  	iRatio = 3/2
  	elseif iMidiMin == 8 then
  	iRatio = 6561/4096
  	elseif iMidiMin == 9 then
  	iRatio = 27/16
  	elseif iMidiMin == 10 then
  	iRatio = 16/9
  	elseif iMidiMin == 11 then
  	iRatio = 243/128
  	elseif iMidiMin == 12 then
  	iRatio = 2/1
  	endif
  	
iBaseFrq mtof iBaseNote+(iOct*12)
iFrq = (iBaseFrq)*iRatio
iMidiOut ftom iFrq
xout iMidiOut
endop


opcode dastgah, i,i[]iii
  iInArr[],iBaseMidi,iMidiIn,iQ xin
  iLen lenarray iInArr
  iOutArr[] init iLen
  iNote = iBaseMidi
  indx = 0
	while indx < iLen do
	iNote = iNote+(iInArr[indx])
	iOutArr[indx] = iNote
	indx += 1
	od
	iMidi = int(iMidiIn)+iQ
	indxOct = 0
	     until iMidi < iBaseMidi+12 do
	     indxOct += 1
  		iMidi = iMidi-12
  		enduntil
  		iIntrval = (iMidi-iBaseMidi)
iMidiOut = iOutArr[iIntrval]+(12*indxOct)
SnoteOut mton iMidiOut
  xout iMidiOut
endop



;;string
opcode StrToArr, i[],S
SIn xin
Snote     sprintf "%s ",SIn
iLen strlen SIn
iReadChar = 0
iLenCount = 0
while iReadChar < iLen do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	od	
	iReadChar2 = iReadChar+1
			while strchar(Snote,iReadChar2) == 32 do
			iReadChar2 += 1
			iReadChar += 1
			od
iReadChar += 1
iLenCount += 1
od
iArrOut [] init iLenCount

iWrite = 0
iRead = 0
while iRead < iLen do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
		Schar     strsub    Snote, iStart, iStart+iCountChr
	if strchar(Schar,0) != 0 then
	inum strtod Schar
	;print inum
	iArrOut [iWrite] = inum
	iWrite += 1
	endif
iRead += 1
od
xout iArrOut
endop

opcode ArrToStrg, S,i[]
  iArrIn [] xin
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    Sscale     sprintf " %d",iArrIn[indx]
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop


;;saveload
opcode save1,i,i
isave xin
giArrSeq1Save1 [] init 28
giArrAcc1Save1 [] init 28
giArrBss1Save1 [] init 28
giArrRep1Save1 [] init 28
giArrSeq2Save1 [] init 28
giArrAcc2Save1 [] init 28
giArrBss2Save1 [] init 28
giArrRep2Save1 [] init 28

iGetWidgets = 0
while iGetWidgets < 28 do
SseqValue1 sprintf "seq1%d",iGetWidgets
iSeqValue1 cabbageGetValue SseqValue1
giArrSeq1Save1 [iGetWidgets] = iSeqValue1
SaccValue1 sprintf "acc1%d",iGetWidgets
iAccValue1 cabbageGetValue SaccValue1
giArrAcc1Save1 [iGetWidgets] = iAccValue1
SbssValue1 sprintf "bss1%d",iGetWidgets
iBssValue1 cabbageGetValue SbssValue1
giArrBss1Save1 [iGetWidgets] = iBssValue1
SrepValue1 sprintf "rep1%d",iGetWidgets
iRepValue1 cabbageGetValue SrepValue1
giArrRep1Save1 [iGetWidgets] = iRepValue1
SseqValue2 sprintf "seq2%d",iGetWidgets
iSeqValue2 cabbageGetValue SseqValue2
giArrSeq2Save1 [iGetWidgets] = iSeqValue2
SaccValue2 sprintf "acc2%d",iGetWidgets
iAccValue2 cabbageGetValue SaccValue2
giArrAcc2Save1 [iGetWidgets] = iAccValue2
SbssValue2 sprintf "bss2%d",iGetWidgets
iBssValue2 cabbageGetValue SbssValue2
giArrBss2Save1 [iGetWidgets] = iBssValue2
SrepValue2 sprintf "rep2%d",iGetWidgets
iRepValue2 cabbageGetValue SrepValue2
giArrRep2Save1 [iGetWidgets] = iRepValue2
iGetWidgets += 1
od
; printarray giArrSeq1Save1, "%d"
xout isave 
endop

opcode ArrToStrg, S,i[]
  iArrIn [] xin
  Sprint init ""
  indx = 0
  while indx < lenarray(iArrIn) do
    Sscale     sprintf "%d ",iArrIn[indx]
    Sprint strcat Sprint, Sscale
  indx += 1
  od
  xout Sprint
endop

opcode StrToArr, i[],S
SIn xin
Snote     sprintf "%s ",SIn
iLen strlen SIn
iReadChar = 0
iLenCount = 0
while iReadChar < iLen do
	until strchar(Snote,iReadChar) == 32 do
	iReadChar += 1
	od	
	iReadChar2 = iReadChar+1
			while strchar(Snote,iReadChar2) == 32 do
			iReadChar2 += 1
			iReadChar += 1
			od
iReadChar += 1
iLenCount += 1
od
iArrOut [] init iLenCount

iWrite = 0
iRead = 0
while iRead < iLen do
iCountChr = 0
iStart = iRead 
	until strchar(Snote,iRead) == 32 do
	iRead += 1
	iCountChr += 1
	od	
		Schar     strsub    Snote, iStart, iStart+iCountChr
	if strchar(Schar,0) != 0 then
	inum strtod Schar
	;print inum
	iArrOut [iWrite] = inum
	iWrite += 1
	endif
iRead += 1
od
xout iArrOut
endop


;;udos
opcode MirrorMe,i,iii
iValue,iMin,iMax xin
iMiddle = iMin+((iMax-iMin)/2)
if iValue == iMiddle then
iOut = iValue
elseif iValue > iMiddle then
iOut = iMiddle - (iValue-iMiddle)
elseif iValue < iMiddle then
iOut = iMiddle + (iMiddle-iValue)
endif
xout iOut

endop



 giArrNote[]    init 8
 giArrEmpty[]   init lenarray:i(giArrNote)
 giArrVeloc[]   init lenarray:i(giArrNote)
 giArrVel[] =   giArrVeloc
 giLenVel       lenarray giArrVel
 giNote[]       fillarray 1,1
 giWriteNote    init 0


gSfile1 init 0
gSfile2 init 0

giSteps init 28
giStepArr1[]    init giSteps
giAccArr1[]     init giSteps
giRepArr1[]     init giSteps
giBassArr1[]    init giSteps

giStepArr2[]    init giSteps
giAccArr2[]     init giSteps
giRepArr2[]     init giSteps
giBassArr2[]    init giSteps


massign 1,1
massign 2,11
massign 3,13
massign 5,15
massign 6,16
massign 16,23


instr GetMidi ;1
 iActive1 active 1
 iHold cabbageGetValue "hold"
 kRel release
 iNum notnum
 iVel veloc 0,127
 if iActive1 == 1 then
 giArrNote[] = giArrEmpty
 giArrVeloc[] = giArrEmpty
 giWriteNote = 0
 endif
 schedule "WriteMidi",0,.1,iNum,iVel
 	if kRel == 1 && changed(kRel) == 1 && iHold == 0 then
 	schedulek "WriteMidi", 0, .1,iNum,0
 	endif
endin
instr WriteMidi ;2
 iActive1 active 1
 iNote = p4
 iVel = p5
 iveloc = int((p5/127)*10)
 iveloc = ((iveloc/10)^1.5)*10
 if iveloc == 0 then
 iveloc = 1
 endif

 iLen lenarray giArrNote
 if iVel != 0 then
 					indxr = 0
 					iCountZero = 0
					while indxr < iLen do
						if giArrNote[indxr] != 0 then
						iCountZero += 1
						endif
					indxr += 1
					od
		if iCountZero != iLen then
			while giArrNote[giWriteNote] != 0 do
			giWriteNote = (giWriteNote+1) % iLen
			od
		else
			giWriteNote = (giWriteNote+1) % iLen
		endif
 giArrNote[giWriteNote] = iNote
 giArrVeloc[giWriteNote] = iveloc
 elseif iVel == 0 then
		indxw = 0
		while indxw < iLen do
			if giArrNote[indxw] == iNote then
			giArrNote[indxw] = 0
			giArrVeloc[indxw] = 0
			giWriteNote = indxw-1
			endif
		indxw += 1
		od
 giWriteNote = (giWriteNote-1) <= 0 ? 0 : giWriteNote
 endif
			if iActive1 == 0 then
			giWriteNote = 0
			endif
 giNote[] RmvZ giArrNote
 giLenNote lenarray giNote
 gkLenNote lenarray giNote

  giArrVel[] RmvZ giArrVeloc
  giLenVel lenarray giArrVel

endin


instr seq1
kActive1 active 1
kSeq2 cabbageGet "sq2"
  if kSeq2 == 1 then
  ;schedule "seq2",0,-1
  endif
kDing cabbageGet "dng1"
kHold cabbageGet "hold"

kAtt cabbageGet "att1"
kFilter cabbageGet "fltr"
kSeqIndx   init 0
kNoteIndx  init 0
kBPM cabbageGet "bpm1"
kTempo = kBPM/60
kTms cabbageGet "DV1"
kSteps cabbageGet "steps1"
kRndWidget cabbageGet "rndwidgets1"
kTime = (kTempo*kTms)
ksel = 0
kNoteIn = giNote[ksel]
kDur cabbageGet "dur1"
    if metro(kTime) == 1 then
    if kNoteIn > 20 then
    ;;sound
    SseqValue sprintfk "seq1%d",kSeqIndx
    kSeqValue cabbageGet SseqValue
    SaccValue sprintfk "acc1%d",kSeqIndx
    kAccValue cabbageGet SaccValue
        if kSeqValue == 1 then 
        kNoteIndx  = (kNoteIndx+1)  % giLenNote
            if changed(gkLenNote) == 1 then
            kNoteIndx = gkLenNote-1
            endif
            kNote  = giNote[kNoteIndx]
            if kDing == 1 then
            schedulek "Sound1" ,0,kDur,kNote,kAccValue*2, kAtt,kFilter
            endif
        endif
    ;;Bss
    SbssValue sprintfk "bass1%d",kSeqIndx
    kBssValue cabbageGet SbssValue
    if kBssValue == 1 then
    	kBidx = 0
        kNoteBass = giNote[kBidx]
	    until kNoteBass < 45 do
  		kNoteBass = kNoteBass-12
  		enduntil
        if kDing == 1 then
        schedulek "Sound1" ,0,kDur,kNoteBass,0, 0.005,kFilter
        endif
    endif
    ;;Rep
    SrepValue sprintfk "rep1%d",kSeqIndx
    kRepValue cabbageGet SrepValue
    if kRepValue == 1 then
        kNoteRep = kNote
	    until kNoteRep > 80 do
  		kNoteRep = kNoteRep+12
  		enduntil
    kRepR = ((int(random:k(0,6)))/4)+1
        if kRepR <= 1.5 then
        kRepT = int(random:k( 3,7))
        else
        kRepT = int(random:k( 2,4))
        endif
    kDurRep = (1/kTime)/kRepR
    kTrigRep = kDurRep
    kndxRep = 0
        while kndxRep < kRepT do
            if kDing == 1 then
			schedulek "Sound1",kTrigRep,kDurRep,kNoteRep,-3, 0.0001,kFilter
			endif
	    kTrigRep += kDurRep
		kndxRep += 1
		od	
    endif
    endif
    schedulek "LEDon1",0,0.1,kSeqIndx
    schedulek "LEDoff1",1/kTime,0.1,kSeqIndx
        if kSeqIndx == 0 && changed(kSeqIndx) == 1 && kRndWidget == 1 then
        schedulek "RndWidget1", 0, 1
        endif
    kSeqIndx = (kSeqIndx+1) % kSteps

    endif
endin

instr LEDon1
Slte sprintf "lte1%d",p4
cabbageSet 1,Slte,"colour(150, 150, 200, 250)"
endin
instr LEDoff1
Slte sprintf "lte1%d",p4
cabbageSet 1,Slte,"colour(100, 100, 100, 200)"
endin

instr Sound1 ;5
iMidiNote = p4
iAmpIn cabbageGetValue "gn1"
iAmpseq ampdb iAmpIn-30
iAmpdB ampdb p5
iAmp = iAmpseq*iAmpdB
;print iAmp
iBaseNoteIn cabbageGetValue "BNote"

if iBaseNoteIn == 2 then
SbaseNote = "0G"
iQ = 0
elseif iBaseNoteIn == 3 then
SbaseNote = "0A-"
iQ = 1
elseif iBaseNoteIn == 4 then
SbaseNote = "0Bb"
iQ = 0
elseif iBaseNoteIn == 5 then
SbaseNote = "0C"
iQ = 0
elseif iBaseNoteIn == 6 then
SbaseNote = "0E-"
iQ = 1
elseif iBaseNoteIn == 7 then
SbaseNote = "0D-"
iQ = 1
elseif iBaseNoteIn == 8 then
SbaseNote = "0F"
iQ = 0
elseif iBaseNoteIn == 9 then
SbaseNote = "0A"
iQ = 0
elseif iBaseNoteIn == 10 then
SbaseNote = "0B"
iQ = 0
elseif iBaseNoteIn == 11 then
SbaseNote = "0Gb"
iQ = 0
elseif iBaseNoteIn == 12 then
SbaseNote = "0D"
iQ = 0
endif
iBaseNote ntom SbaseNote
iScale      cabbageGetValue "scale"
if iScale == 1 then
iMidiOut = iMidiNote
elseif iScale == 2 then
iMidiOut pythagorean iBaseNote,iMidiNote
SnoteName mton iMidiOut
elseif iScale == 3 then
iMidiOut dastgah giShurArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 4 then
iMidiOut dastgah giAbuataArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 5 then
iMidiOut dastgah giBayattorkArr,iBaseNote,iMidiNote, iQ
elseif iScale == 6 then
iMidiOut dastgah giAfshariArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 7 then
iMidiOut dastgah giDashtiArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 8 then
iMidiOut dastgah giNavaArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 9 then
iMidiOut dastgah gi3gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 10 then
iMidiOut dastgah gi4gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 11 then
iMidiOut dastgah giHomayunArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 12 then
iMidiOut dastgah giBayatEsArr,  iBaseNote,iMidiNote, iQ
endif


Snote MtoNameInt iMidiOut
if changed(Snote) == 1 then
    SnoteShow     sprintf "text(%s)", Snote
    cabbageSet "noteshow1",SnoteShow
endif
iFrq mtof iMidiOut
iAtt = p6
;iAtt cabbageGetValue "att"

iRvrs cabbageGetValue "rvrs1"
if iRvrs == 0 then
 aEnv transeg 0, iAtt,6, iAmp, p3-iAtt,-6, 0
elseif iRvrs == 1 then
 aEnv transeg 0, p3*(1-iAtt),4, iAmp,p3*iAtt,-4,0
endif


 
 iModIn cabbageGetValue "sound1"
iMod = iModIn-1

if iMod == 0 goto end
if iMod == 1 || iMod == 2 || iMod == 3 || iMod == 4 goto sine
if iMod == 5 || iMod == 6 || iMod == 7 || iMod == 8 \
|| iMod == 9 goto sine2

if iMod == 10 goto pick
if iMod == 11 goto VCO

sine:
if iMod == 1 then
giWave = giwave1
elseif iMod == 2 then
giWave = giwave2
elseif iMod == 3 then
giWave = giwave3
elseif iMod == 4 then
giWave = giwave4
endif

aSine poscil3 aEnv, (iFrq)/giRtosScale,giWave
aout = aSine
goto OUT



sine2:

if iMod == 5 then
giWave = giSineTwo
elseif iMod == 6 then
giWave = giTri
elseif iMod == 7 then
giWave = giSaw
elseif iMod == 8 then
giWave = giSquare
elseif iMod == 9 then
giWave = giMyset
endif


aSine poscil aEnv, iFrq,giWave
aout = aSine
goto OUT


pick:
iplk  random 0.1, 0.8
ipick random 0.3, 0.9
iRel random p3-0.1, p3+0.1
irefl MirrorMe iRel, 0.5,1.5,0; random p3/2, 1
aPick wgpluck2 iplk,1, iFrq, ipick, irefl-0.01
aout = aPick*aEnv

goto OUT

VCO:
aVco    vco2   0.5,iFrq,0,0.5
aout = aVco*aEnv


OUT:

chnmix aout, "snd1"
;outall aout
end:
endin




instr seq2
kActive1 active 1
kDing cabbageGet "dng2"
kHold cabbageGet "hold"
kSeqIndx   init 0
kNoteIndx  init 0
kVelocIndx init 0
kBPM cabbageGet "bpm2"
kTempo = kBPM/60
kTms cabbageGet "DV2"
kSteps cabbageGet "steps2"
kAtt cabbageGet "att2"
kFilter cabbageGet "fltr"
kOctave cabbageGet "oct"
kRndWidget cabbageGet "rndwidgets2"
kOct = 12*kOctave
kTime = (kTempo*kTms)
;printk2 kTime
ksel = 0
kNoteIn = giNote[ksel]
kDur cabbageGet "dur2"
    if metro(kTime) == 1 then
    if kNoteIn > 20 then
    ;;sound
    SseqValue sprintfk "seq2%d",kSeqIndx
    kSeqValue cabbageGet SseqValue
    SaccValue sprintfk "acc2%d",kSeqIndx
    kAccValue cabbageGet SaccValue
        if kSeqValue == 1 then 
        kNoteIndx  = (kNoteIndx+1)  % giLenNote
            if changed(gkLenNote) == 1 then
            kNoteIndx = gkLenNote-1
            endif
            kNote  = giNote[kNoteIndx]+kOct
            if kDing == 1 then
            schedulek "Sound2" ,0,kDur,kNote,kAccValue*2, kAtt,kFilter
            endif
        endif
    ;;Bss
    SbssValue sprintfk "bass2%d",kSeqIndx
    kBssValue cabbageGet SbssValue
    if kBssValue == 1 then
    kBidx = 0
    kNoteBass = giNote[kBidx]
        until kNoteBass < 45 do
  	    kNoteBass = kNoteBass-12
  		enduntil
        if kDing == 1 then
        schedulek "Sound2" ,0,kDur,kNoteBass,0, 0.005,kFilter
        endif
    endif
    ;;Rep
    SrepValue sprintfk "rep2%d",kSeqIndx
    kRepValue cabbageGet SrepValue
    if kRepValue == 1 then
    kNoteRep = kNote
	    until kNoteRep > 90 do
  		kNoteRep = kNoteRep+12
  		enduntil
     kRepR = ((int(random:k(0,3)))/2)+1
     kRepT = int(random:k( 2,7))
     kDurRep = (1/kTime)/kRepR
     kTrigRep = kDurRep
     kndxRep = 0
        while kndxRep < kRepT do
            if kDing == 1 then
		    schedulek "Sound2",kTrigRep,kDurRep,kNoteRep,-3, 0.0001,kFilter
		    endif
		kTrigRep += kDurRep
		kndxRep += 1
		od	
    endif
    endif
    schedulek "LEDon2",0,0.1,kSeqIndx
    schedulek "LEDoff2",1/kTime,0.1,kSeqIndx
        if kSeqIndx == 0 && changed(kSeqIndx) == 1 && kRndWidget == 1 then
        schedulek "RndWidget2", 0, 1
        endif
    kSeqIndx = (kSeqIndx+1) % kSteps
    endif
endin

instr LEDon2
Slte sprintf "lte2%d",p4
cabbageSet 1,Slte,"colour(150, 150, 200, 250)"
endin
instr LEDoff2
Slte sprintf "lte2%d",p4
cabbageSet 1,Slte,"colour(100, 100, 100, 200)"
endin

instr Sound2 ;5
iMidiNote = p4
iAmpIn cabbageGetValue "gn2"
iAmpseq ampdb iAmpIn-30
iAmpdB ampdb p5
iAmp = iAmpseq*iAmpdB
iBaseNoteIn cabbageGetValue "BNote2"

if iBaseNoteIn == 2 then
SbaseNote = "0G"
iQ = 0
elseif iBaseNoteIn == 3 then
SbaseNote = "0A-"
iQ = 1
elseif iBaseNoteIn == 4 then
SbaseNote = "0Bb"
iQ = 0
elseif iBaseNoteIn == 5 then
SbaseNote = "0C"
iQ = 0
elseif iBaseNoteIn == 6 then
SbaseNote = "0E-"
iQ = 1
elseif iBaseNoteIn == 7 then
SbaseNote = "0D-"
iQ = 1
elseif iBaseNoteIn == 8 then
SbaseNote = "0F"
iQ = 0
elseif iBaseNoteIn == 9 then
SbaseNote = "0A"
iQ = 0
elseif iBaseNoteIn == 10 then
SbaseNote = "0B"
iQ = 0
elseif iBaseNoteIn == 11 then
SbaseNote = "0Gb"
iQ = 0
elseif iBaseNoteIn == 12 then
SbaseNote = "0D"
iQ = 0
endif
iBaseNote ntom SbaseNote
iScale      cabbageGetValue "scale2"
if iScale == 1 then
iMidiOut = iMidiNote
elseif iScale == 2 then
iMidiOut pythagorean iBaseNote,iMidiNote
SnoteName mton iMidiOut
elseif iScale == 3 then
iMidiOut dastgah giShurArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 4 then
iMidiOut dastgah giAbuataArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 5 then
iMidiOut dastgah giBayattorkArr,iBaseNote,iMidiNote, iQ
elseif iScale == 6 then
iMidiOut dastgah giAfshariArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 7 then
iMidiOut dastgah giDashtiArr,   iBaseNote,iMidiNote, iQ
elseif iScale == 8 then
iMidiOut dastgah giNavaArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 9 then
iMidiOut dastgah gi3gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 10 then
iMidiOut dastgah gi4gahArr,     iBaseNote,iMidiNote, iQ
elseif iScale == 11 then
iMidiOut dastgah giHomayunArr,  iBaseNote,iMidiNote, iQ
elseif iScale == 12 then
iMidiOut dastgah giBayatEsArr,  iBaseNote,iMidiNote, iQ
endif
Snote MtoNameInt iMidiOut
if changed(Snote) == 1 then
    SnoteShow     sprintf "text(%s)", Snote
    cabbageSet "noteshow2",SnoteShow
endif
iFrq mtof iMidiOut

iAtt = p6
;iAtt cabbageGetValue "att"

iRvrs cabbageGetValue "rvrs2"
if iRvrs == 0 then
 aEnv transeg 0, iAtt,6, iAmp, p3-iAtt,-6, 0
elseif iRvrs == 1 then
 aEnv transeg 0, p3*(1-iAtt),4, iAmp,p3*iAtt,-4,0
endif





 iFilter = p7+iFrq
 
 iModIn cabbageGetValue "sound2"
iMod = iModIn-1
;print iMod

if iMod == 0 goto end
if iMod == 1 || iMod == 2 || iMod == 3 || iMod == 4 goto sine
if iMod == 5 || iMod == 6 || iMod == 7 || iMod == 8 \
|| iMod == 9 goto sine2

if iMod == 10 goto pick
if iMod == 11 goto VCO

sine:
if iMod == 1 then
giWave = giwave1
elseif iMod == 2 then
giWave = giwave2
elseif iMod == 3 then
giWave = giwave3
elseif iMod == 4 then
giWave = giwave4
endif

aSine poscil3 aEnv, (iFrq)/giRtosScale,giWave
aout = aSine
goto OUT



sine2:

if iMod == 5 then
giWave = giSineTwo
elseif iMod == 6 then
giWave = giTri
elseif iMod == 7 then
giWave = giSaw
elseif iMod == 8 then
giWave = giSquare
elseif iMod == 9 then
giWave = giMyset
endif


aSine poscil aEnv, iFrq,giWave
aout = aSine
goto OUT


pick:
iplk  random 0.1, 0.8
ipick random 0.3, 0.9
iRel random p3-0.1, p3+0.1
irefl MirrorMe iRel, 0.5,1.5,0; random p3/2, 1
aPick wgpluck2 iplk,0.3, iFrq, ipick, irefl-0.01
aout = aPick*aEnv
goto OUT

VCO:
aVco    vco2   0.5,iFrq,0,0.5
aout = aVco*aEnv


OUT:
chnmix aout, "snd2"
end:
endin


;--------------------------------------------------
;pad sound





instr String
cabbageSet 1,"bowlight","colour(200, 150, 100)"
kRelease release
iActive active p1
if kRelease == 1  then
cabbageSet 1,"bowlight","colour(70, 62, 68, 255)"
endif

iGainIn cabbageGetValue "gnpd"
iGain ampdb iGainIn-60
iPosIn cabbageGetValue "pos"
iPresIn cabbageGetValue "pres"
iVibIn cabbageGetValue "vib"
 iNum notnum
  	iFrqMin mtof iNum
 	kFilterIn cabbageGet "pdfltr"
    iCent cabbageGetValue "cnt"
 	iFrq = iFrqMin+cent(5)
 iSpeed cabbageGetValue "spdstrng"
 iSpdFrq cabbageGetValue "spdfrq"
 iSpeedMin cabbageGetValue "spdstrngmin"
	kAmp    rspline  0.4, 0.5, 0.7, 1
	kFrq    rspline  iFrq, iFrq*cent(iCent), 0.4, iSpdFrq
	kPres   rspline  0.1, iPresIn*10, iSpeedMin-0.1, iSpeed
	kRate   rspline  0.1, iPosIn*10, iSpeedMin-0.3, iSpeed
	kVib    rspline  1,   iVibIn*10, iSpeedMin, iSpeed
	aSound	wgbow    kAmp,kFrq,kPres,kRate,kVib,0,giSine,iFrqMin
	kFilter rspline kFilterIn*0.9, kFilterIn*1.1, 2, 3
    aFilt clfilt aSound, kFilter, 0, 10
    aFilt clfilt aFilt, 250, 1, 10
    iAtt random 0.7, 2
    iRel random 0.7, 2
    aEnv linsegr 0, iAtt, 1, iRel, 0
	aOut = aFilt*aEnv*iGain
;	outall aOut
	chnmix aOut, "sndpad"
endin


instr AmbientSine
print 1
kTime init 1
if metro(1/kTime) == 1 then
kTime random 5, 7
kDur = kTime*1.3
    kIndx = 0
    while kIndx < 5 do
    kStart random 0, 3
    schedulek "Sine", kStart, kDur
    kIndx += 1
    od
endif
endin

instr Sine
kGainIn cabbageGet "gnpd"
kGain ampdb kGainIn-60
 iMidi notnum
 if iMidi != 0 then
 iFrq mtof iMidi
 iAtt random 1, 2
 iRel random 1, 1
 aEnv linsegr 0, iAtt, 1, iRel, 0
 cabbageSet 1,"ambienlight","colour(100, 150, 200)"
 kRelease release
    if kRelease == 1 then
    cabbageSet 1,"ambienlight","colour(70, 62, 68, 255)"
    endif
 elseif iMidi == 0 then
 iFrq random 400, 700 
 aEnv linseg 0, p3/2, 1, p3/2, 0
 endif
 
 iCent cabbageGetValue "cnt"
; print iCent
 iMod cabbageGetValue "sound3"
 iSpeed cabbageGetValue "spdstrng"
  	kFilterIn cabbageGet "pdfltr"
  
kPlusF1 cabbageGet "pres"
kPlusF2 cabbageGet "pos"
kPlusF3 cabbageGet "vib"
 iSpdFrq cabbageGetValue "spdfrq"
 iSpeedMin cabbageGetValue "spdstrngmin"
 
if iMod == 2 then
giWave = giSineTwo
elseif iMod == 3 then
giWave = giTri
elseif iMod == 4 then
giWave = giSaw
elseif iMod == 5 then
giWave = giSquare
endif
 	kAmp1    rspline  0.2, 0.3, 0.7, 1
    kAmp2    rspline  0.2, 0.3, 0.7, 1
    kAmp3    rspline  0.2, 0.3, 0.7, 1
    kAmp4    rspline  0.2, 0.3, 0.7, 1
 	kFrq    rspline  iFrq, iFrq*cent(iCent), iSpeedMin,iSpdFrq

kFmAmp cabbageGet "fma"
kFmFrq cabbageGet "fmf"
aFM poscil kFmAmp, kFmFrq
aSound1 poscil kAmp1, kFrq+aFM, giWave
aSound2 poscil kAmp2*0.2, kFrq+(kPlusF1*10)
aSound3 poscil kAmp3*0.1, kFrq+(kPlusF2*10)
aSound4 poscil kAmp4*0.3, kFrq+(kPlusF3*10)

aSound sum aSound1,aSound2,aSound3,aSound4

if iSpeed <= 0.7 then
aSound = aSound1
endif
	kFilter rspline kFilterIn*0.9, kFilterIn*1.1, 2, 3
    aFilt clfilt aSound, kFilter, 0, 10
    aFilt clfilt aFilt, 250, 1, 10


    aGain interp kGain
	aOut = aFilt*aEnv*aGain*0.2
	chnmix aOut, "sndpad"
endin


instr PadFx
aIn chnget "sndpad"
aSound = aIn
kTime cabbageGet "dltmpd"
kPortTime linseg 0, 0.01, 0.1
kTime portk kTime, kPortTime
if kTime <= 0.2 kgoto rvb
kFeedback cabbageGet "fdb"
 	aTim	interp	kTime
 	abuf	delayr	7
 	aDelay	deltapi	aTim	
 	delayw	aIn + (aDelay*kFeedback)
  	aSound		ntrpol	 aIn,aDelay,  .65
  
rvb:

kRvrb cabbageGet "rvbpad"
	aRvbL,aRvbR reverbsc aSound,aSound,kRvrb,7000
	aMixL		ntrpol	 aSound,aRvbL,  .4
	aMixR		ntrpol	 aSound,aRvbR,  .4	
   outs     aMixL,aMixR
 
chnclear "sndpad"
endin

;;--------------------------------------------------------------
;sample


instr Sample1
iAttEnv cabbageGetValue "attpad"
iRelEnv cabbageGetValue "relpad"
iLen filelen gSfile1
iStart random 0, iLen
iNum notnum
iInterval = (iNum-60)*50
iCent cent iInterval
aSound,aSound diskin2 gSfile1, iCent,iStart,1
	aAtt transeg 0, iAttEnv, 4, 1
    aRel transegr 1, iRelEnv, -4, 0
aOut = aSound*aAtt*aRel
outall aOut
endin

instr Sample2
iAttEnv cabbageGetValue "attpad"
iRelEnv cabbageGetValue "relpad"
iLen filelen gSfile2
iStart random 0, iLen
iNum notnum
iInterval = (iNum-60)*50
iCent cent iInterval
aSound,aSound diskin2 gSfile2, iCent,iStart,1
	aAtt transeg 0, iAttEnv, 4, 1
    aRel transegr 1, iRelEnv, -4, 0
aOut = aSound*aAtt*aRel
outall aOut
endin


instr hold
 cabbageSetValue "hold",p4
endin

instr Empty ;7
if p4 == 1 then
 giArrNote[] = giArrEmpty
 giNote[] = giArrEmpty
elseif p4 == 2 then
giArrVel[] RmvZ giArrVeloc
giLenVel lenarray giArrVel
;printarray giArrVel, "%d"
endif
endin


;-------------------------------------------------------
;Effects


instr Effect
kDelayTime cabbageGet "dlt"
kPortTime linseg 0, 0.01, 0.1
kDelayTime portk kDelayTime, kPortTime
kFeedback cabbageGet "fdb"
;;sound
kFilter cabbageGet "fltr"
;printk2 kFilter
aIn1 chnget "snd1"
 aFilt1 clfilt aIn1, kFilter, 0, 10
 aFilt1 clfilt aFilt1, 150, 1, 10
aIn2 chnget "snd2"
 aFilt2 clfilt aIn2, kFilter, 0, 10
 aFilt2 clfilt aFilt2, 150, 1, 10
;;time
kBPM cabbageGet "bpm1"
kTempo = kBPM/60
kTms cabbageGet "DV1"
kTime = (1/(kTempo*kTms))*kDelayTime

aSum sum aFilt1, aFilt2
 	aTim	interp	kTime
 	abuf	delayr	7
 	aDelay	deltapi	aTim	
 	delayw	aSum + (aDelay*kFeedback)
  	aDelMix		ntrpol	 aSum,aDelay,  0.2
  


aOut = aDelMix
outall aOut
chnclear "snd1"
chnclear "snd2"
endin



;-------------------------------------------------------
;widgets
instr widgetWrite
    iX = 0
    iCount = 0
    ispc = 30
    while iCount < giSteps do
            Sseq1    sprintf "bounds(%d, 100, 18, 18)  , channel(\"seq1%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(20)+ispc, iCount
            Sacc1    sprintf "bounds(%d, 120, 18, 18)  , channel(\"acc1%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(20)+ispc, iCount
            Srep1    sprintf "bounds(%d, 140, 18, 18) , channel(\"rep1%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(20)+ispc, iCount           
            Sbass1   sprintf "bounds(%d, 160, 18, 18) , channel(\"bass1%d\")      colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(20)+ispc, iCount           
             Slte1   sprintf "bounds(%d, 180, 15, 15) , channel(\"lte1%d\")       colour(100, 100, 100, 200) ", 51+iCount*(20)+ispc, iCount

            Sseq2    sprintf "bounds(%d, 300, 18, 18) , channel(\"seq2%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(20)+ispc, iCount
            Sacc2    sprintf "bounds(%d, 320, 18, 18) , channel(\"acc2%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(20)+ispc, iCount
            Srep2    sprintf "bounds(%d, 340, 18, 18) , channel(\"rep2%d\")       colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(20)+ispc, iCount
            Sbass2   sprintf "bounds(%d, 360, 18, 18) , channel(\"bass2%d\")      colour:0(100, 100, 100, 255) colour:1(208, 200, 253, 255)", 50+iCount*(20)+ispc, iCount
            Slte2    sprintf "bounds(%d, 380, 15, 15) , channel(\"lte2%d\")       colour(100, 100, 100, 200) ", 51+iCount*(20)+ispc, iCount
            
     cabbageCreate "checkbox", Sseq1
     cabbageCreate "checkbox", Sacc1
     cabbageCreate "checkbox", Srep1
     cabbageCreate "checkbox", Sbass1
     cabbageCreate "image"   , Slte1
            
     cabbageCreate "checkbox", Sseq2
     cabbageCreate "checkbox", Sacc2
     cabbageCreate "checkbox", Srep2
     cabbageCreate "checkbox", Sbass2
     cabbageCreate "image"   , Slte2          

     iCount += 1
     iX = (iX+1) % 4
     if iX == 0 then
     ispc += 5
     endif
    od
    
    kArrSeq1[] fillarray 1,0,0,1,1,0,0,1,0,1,0,0,1
    kArrRep1[] fillarray 0,0,0,0,0,1,0,0,0,0,0,0,0
    kArrBas1[] fillarray 0,0,0,0,1,0,0,0,0,0,0,0,0
    kArrSeq2[] fillarray 0,1,1,0,0,1,0,0,1,0,0,1,0
    kArrRep2[] fillarray 0,0,0,0,1,0,0,0,0,0,0,1,0
    kArrBas2[] fillarray 1,0,0,0,0,0,1,0,0,0,0,0,0
    kWrite = 0
    while kWrite < lenarray(kArrSeq1) do
     Ssq1 sprintfk "seq1%d",kWrite
     Srp1 sprintfk "rep1%d",kWrite
     Sbs1 sprintfk "bass1%d",kWrite
     Ssq2 sprintfk "seq2%d",kWrite
     Srp2 sprintfk "rep2%d",kWrite
     Sbs2 sprintfk "bass2%d",kWrite
     cabbageSetValue Ssq1,kArrSeq1[kWrite]
     cabbageSetValue Srp1,kArrRep1[kWrite]
     cabbageSetValue Sbs1,kArrBas1[kWrite]
     cabbageSetValue Ssq2,kArrSeq2[kWrite]
     cabbageSetValue Srp2,kArrRep2[kWrite]
     cabbageSetValue Sbs2,kArrBas2[kWrite]
     kWrite += 1
    od    
endin

instr RndWidget1
iLen cabbageGetValue "steps1"
iArrSeq[] init iLen
    iWrite = 0
    while iWrite < iLen do
    iRndSeq = int(random:i(0,2))
    iArrSeq[iWrite] = iRndSeq
     Ssq sprintf "seq1%d",iWrite     
     cabbageSetValue Ssq,iArrSeq[iWrite]
     iWrite += 1
    od   
endin

instr RndWidget2
iLen cabbageGetValue "steps2"
iArrSeq[] init iLen
iArrBas[] init iLen
    iWrite = 0
    while iWrite < iLen do
    iRndSeq = int(random:i(0,2))
    iRndBas = random:i(0,100) > 20 ? 0 : 1
    iArrSeq[iWrite] = iRndSeq
    iArrBas[iWrite] = iRndBas
     Ssq sprintf "seq2%d",iWrite
     Sbs sprintf "bass2%d",iWrite
     cabbageSetValue Ssq,iArrSeq[iWrite]
     cabbageSetValue Sbs,iArrBas[iWrite]
     iWrite += 1
    od   
endin

instr saveWidgets
    Sp4 = p4
    indx = 0
    while indx < giSteps do
    Sseq1Save   sprintf "seq1%d",indx
    Sacc1Save   sprintf "acc1%d",indx
    Srep1Save   sprintf "rep1%d",indx
    Sbass1Save  sprintf "bass1%d",indx
    
    Sseq2Save   sprintf "seq2%d",indx
    Sacc2Save   sprintf "acc2%d",indx
    Srep2Save   sprintf "rep2%d",indx
    Sbass2Save  sprintf "bass2%d",indx

    iSeq1   cabbageGetValue Sseq1Save
    iAcc1   cabbageGetValue Sacc1Save
    iRep1   cabbageGetValue Srep1Save
    iBass1  cabbageGetValue Sbass1Save
    
    iSeq2   cabbageGetValue Sseq2Save
    iAcc2   cabbageGetValue Sacc2Save
    iRep2   cabbageGetValue Srep2Save
    iBass2  cabbageGetValue Sbass2Save
    
    giStepArr1[indx]    = iSeq1
    giAccArr1[indx]     = iAcc1
    giRepArr1[indx]     = iRep1
    giBassArr1[indx]    = iBass1
    
    giStepArr2[indx]    = iSeq2
    giAccArr2[indx]     = iAcc2
    giRepArr2[indx]     = iRep2
    giBassArr2[indx]    = iBass2
    
    indx += 1
    od
    
    Sseqtxt1 ArrToStrg giStepArr1
    Sacctxt1 ArrToStrg giAccArr1
    Sreptxt1 ArrToStrg giRepArr1
    Sbastxt1 ArrToStrg giBassArr1
    
    Sseqtxt2 ArrToStrg giStepArr2
    Sacctxt2 ArrToStrg giAccArr2
    Sreptxt2 ArrToStrg giRepArr2
    Sbastxt2 ArrToStrg giBassArr2

    Spreset sprintf "preset%s.txt",Sp4
;    Spreset sprintf "d:/preset%s.txt",Sp4
if metro(0) == 1 then
    fprintks Spreset, ""
endif
    fprints Spreset, "%s \n", Sseqtxt1
    fprints Spreset, "%s \n", Sacctxt1
    fprints Spreset, "%s \n", Sreptxt1
    fprints Spreset, "%s \n", Sbastxt1
    
    fprints Spreset, "%s \n", Sseqtxt2
    fprints Spreset, "%s \n", Sacctxt2
    fprints Spreset, "%s \n", Sreptxt2
    fprints Spreset, "%s \n", Sbastxt2
    
    
    iBPM1       cabbageGetValue "bpm1"
    iBPM2       cabbageGetValue "bpm2"
    iDV1        cabbageGetValue "DV1"
    iDV2        cabbageGetValue "DV2"
    iDur1       cabbageGetValue "dur1"
    iDur2       cabbageGetValue "dur2"
    iScale1     cabbageGetValue "scale"
    iScale2     cabbageGetValue "scale2"
    iBaseNote1  cabbageGetValue "BNote"
    iBaseNote2  cabbageGetValue "BNote2"
    iSteps1     cabbageGetValue "steps1"
    iSteps2     cabbageGetValue "steps2"
    iOct        cabbageGetValue "oct"
    iSound1     cabbageGetValue "sound1"
    iSound2     cabbageGetValue "sound2"
    
    fprints Spreset, "%f \n", iBPM1
    fprints Spreset, "%f \n", iBPM2
    fprints Spreset, "%f \n", iDV1
    fprints Spreset, "%f \n", iDV2
    fprints Spreset, "%f \n", iDur1
    fprints Spreset, "%f \n", iDur2
    fprints Spreset, "%f \n", iScale1
    fprints Spreset, "%f \n", iScale2
    fprints Spreset, "%f \n", iBaseNote1
    fprints Spreset, "%f \n", iBaseNote2
    fprints Spreset, "%f \n", iSteps1
    fprints Spreset, "%f \n", iSteps2
    fprints Spreset, "%f \n", iOct
    fprints Spreset, "%f \n", iSound1
    fprints Spreset, "%f \n", iSound2
    
endin



instr loadWidgets
    Sp4 = p4
iEkhtelaf = 15
   Spreset sprintf "preset%s.txt",Sp4
;   Spreset sprintf "d:/preset%s.txt",Sp4
   iLoad ftgen 0,0,0,-23,Spreset
   iLenLoad ftlen iLoad
   
   indxtxt = 0
   indxLine = 0
   indxArr = 0
while indxtxt < iLenLoad-iEkhtelaf do
    Sseq1   sprintf "seq1%d",indxLine
    Sacc1   sprintf "acc1%d",indxLine
    Srep1   sprintf "rep1%d",indxLine
    Sbass1  sprintf "bass1%d",indxLine
    
    Sseq2   sprintf "seq2%d",indxLine
    Sacc2   sprintf "acc2%d",indxLine
    Srep2   sprintf "rep2%d",indxLine
    Sbass2  sprintf "bass2%d",indxLine

    SwidgetArr[] fillarray Sseq1,Sacc1,Srep1,Sbass1,Sseq2,Sacc2,Srep2,Sbass2

    iValue table indxtxt,iLoad  
    cabbageSetValue SwidgetArr[indxArr],iValue
    indxLine = (indxLine+1) % giSteps
    if indxLine == 0 then
    indxArr += 1
    endif
    indxtxt += 1
od


SwidgetArr2[] fillarray "bpm1","bpm2","DV1","DV2","dur1","dur2","scale","scale2","BNote","BNote2",\
    "steps1","steps2","oct","sound1","sound2"

iRead = 0
while indxtxt < iLenLoad do
iValue table indxtxt,iLoad 
cabbageSetValue SwidgetArr2[iRead],iValue
indxtxt += 1
iRead += 1
od 
    
endin




gkSpeaker1 init -45
gkSpeaker2 init -45
gkSpeaker3 init -60
gkSpeaker4 init -60
instr Speaker
iMidi notnum
iVel veloc

;print iMidi,iVel
iSpeed = 20
iStart1 = i(gkSpeaker1)
iStart2 = i(gkSpeaker2)
iStart3 = i(gkSpeaker3)
iStart4 = i(gkSpeaker4)

if iMidi == 0 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1-1))
elseif iMidi == 1 then
gkSpeaker1 = int(line:k(iStart1, 1/iSpeed, iStart1+1))
endif

if iMidi == 2 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2-1))
elseif iMidi == 3 then
gkSpeaker2 = int(line:k(iStart2, 1/iSpeed, iStart2+1))
endif

if iMidi == 4 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3-1))
elseif iMidi == 5 then
gkSpeaker3 = int(line:k(iStart3, 1/iSpeed, iStart3+1))
endif

if iMidi == 6 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4-1))
elseif iMidi == 7 then
gkSpeaker4 = int(line:k(iStart4, 1/iSpeed, iStart4+1))
endif


if iMidi == 0 || iMidi == 1 then
cabbageSetValue  "out1", gkSpeaker1+65
cabbageSetValue  "outn1", gkSpeaker1
endif
if iMidi == 2 || iMidi == 3 then
cabbageSetValue  "out2", gkSpeaker2+65
cabbageSetValue  "outn2", gkSpeaker2
endif
if iMidi == 4 || iMidi == 5 then
cabbageSetValue  "out3", gkSpeaker3+65
cabbageSetValue  "outn3", gkSpeaker3
endif
if iMidi == 6 || iMidi == 7 then
cabbageSetValue  "out4", gkSpeaker4+65
cabbageSetValue  "outn4", gkSpeaker4
endif
endin


instr Time
kTimer line 0, 1, 1
kSec = int(kTimer)
kMin init 0
kSec = kSec % 60
if kSec == 0 && changed(kSec) == 1 then
kMin += 1
endif
STimer sprintfk "%02d : %02d", kMin, kSec
cabbageSet 1, "sec", "text", STimer

endin

instr Widgets
iDurMaster = 9^9
    schedule "widgetWrite", 0, 1
    
    kStart init 0
kStart cabbageGet "start"
kSeq2Play cabbageGet "sq2"
if kStart == 1 && changed(kStart) == 1 then
schedulek "Time", 0, iDurMaster
schedulek "seq1",0,iDurMaster
schedulek "Effect" , 0, iDurMaster
    if kSeq2Play == 1 then
    schedulek "seq2",0,iDurMaster
    endif
elseif kStart == 0 && changed(kStart) == 1 then
turnoff2 "Time", 0, 0
turnoff2 "seq1", 0,0
turnoff2 "seq2", 0,0
turnoff2 "Effect", 0,0
endif

if kSeq2Play == 0 && changed(kSeq2Play) == 1 then
turnoff2 "seq2",0,0
endif
    
    
    
    
    
  kAmbientSine   ctrl7    1,62,0,1
  if kAmbientSine == 1 && changed(kAmbientSine) == 1 then
  cabbageSet 1,"ambienlight","colour(100, 150, 200)"
  schedulek "AmbientSine", 0, iDurMaster
  elseif kAmbientSine == 0 && changed(kAmbientSine) == 1 then
  cabbageSet 1,"ambienlight","colour(70, 62, 68, 255)"
  turnoff2 "AmbientSine", 0, 0
  turnoff2 "Sine", 0, 0
  endif
    
    
    kSaveA cabbageGet "saveA"
    if changed(kSaveA) == 1 then
    schedulek "saveWidgets", 0, 1, "A"
    endif
    

    kSaveB cabbageGet "saveB"
    if changed(kSaveB) == 1 then
    schedulek "saveWidgets", 0, 1, "B"
    endif

    kLoadA cabbageGet "loadA"
    if changed(kLoadA) == 1 then
    schedulek "loadWidgets", 0, 1, "A"
    endif

    kLoadB cabbageGet "loadB"
    if changed(kLoadB) == 1 then
    schedulek "loadWidgets", 0, 1, "B"
    endif
    
   kPedal ctrl7 15,64,0,1
  if kPedal == 1 && changed(kPedal) == 1 then
  schedulek "hold", 0,0.1,1
  elseif kPedal == 0 && changed(kPedal) == 1 then
  schedulek "Empty",0,0.1,1
  schedulek "hold",0,0.1,0
  endif
  
  kRndWidget ctrl7 1,61,0,1
  if changed(kRndWidget) == 1 then
  cabbageSetValue  "rndwidgets2", kRndWidget
  endif

  kBpmSlider   ctrl7    1,41,10,210
    if changed(kBpmSlider) == 1 then
;    cabbageSetValue "bpm1", kBpmSlider
;    cabbageSetValue  "bpm2", kBpmSlider
    Sbpm sprintfk "%d", kBpmSlider
    cabbageSet 1, "showBPM", "text", Sbpm
    endif
    
    

kstatus, kchan, kdata1, kdata2  midiin
    SMidiShow     sprintfk "text(%d)", kdata2
    cabbageSet 1, "data",SMidiShow





kFx cabbageGet "fx"

if kFx == 1 && changed(kFx) == 1 then
schedulek "Effect", 0, 9999999
elseif kFx == 0 && changed(kFx) == 1 then
turnoff2 "Effect",0,0
endif

kPadFx cabbageGet "pdfx"

if kPadFx == 1 && changed(kPadFx) == 1 then
schedulek "PadFx", 0, 9999999
elseif kPadFx == 0 && changed(kPadFx) == 1 then
turnoff2 "PadFx",0,0
endif

  kWidgetLoad   ctrl7    1,63,0,1
  if kWidgetLoad == 0 && changed(kWidgetLoad) == 1 then
  schedulek "loadWidgets", 0, 1, "A"
  cabbageSet 1,"loadlight","colour(70, 62, 68, 255)"
  elseif kWidgetLoad == 1 && changed(kWidgetLoad) == 1 then
  schedulek "loadWidgets", 0, 1, "B"
  cabbageSet 1,"loadlight","colour(150, 70, 200)"
  endif


gSfile1    cabbageGet    "sampleA" 
gSfile2    cabbageGet    "sampleB" 
    
    
;    aInL,aInR monitor
;    fout "record.wav", 8, aInL, aInR
endin



</CsInstruments>
<CsScore>
i "Widgets" 0 [9^9]
</CsScore>
</CsoundSynthesizer>

